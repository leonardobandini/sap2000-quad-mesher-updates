# Proposta di interfaccia e report della mesh — stato e sviluppi ulteriori

Dalla build locale 1.0.107 sono implementati il riepilogo della selezione, le tre schede, le opzioni radio e un report globale con medie per elemento pesate per superficie e anomalie dimensionali/orientamento inderogabili. La proposta sotto conserva anche migliorie **ancora da realizzare** (istogrammi e quantili, ulteriore dettaglio delle anomalie, preset di profilo veramente ottimizzati e disposizione più flessibile). Il criterio oggi in uso è descritto in `docs/QUALITA_MESH_AGGREGATA.md`.

## Finestra di generazione

La navigazione principale e **per attivita**, non per materiale. La testata blu
rimane con titolo, esempi verificati e lingua. Subito sotto, un riepilogo
compatto della **selezione acquisita all'apertura** mostra:

| Shell selezionate | Quadrilatere | Triangolari | Poligonali | Frame | Link | Nodi |
|---:|---:|---:|---:|---:|---:|---:|

Il totale shell deve coincidere con la somma delle tre categorie. Si contano
oggetti SAP, non gli elementi che saranno generati. I link selezionati sono
indicati come «rilevati, non usati come vincoli di mesh» finche il backend non
li supporta. Se la selezione cambia in SAP dopo l'apertura, il riepilogo non
finge di aggiornarsi: per acquisirla si riapre il plugin.

Un selettore a tre schede, chiaro anche da tastiera, occupa sempre lo stesso
rettangolo della finestra: **Opzioni della mesh | Fori e Aperture | Opzioni Avanzate**. Ogni scheda contiene
pochi gruppi visivi e, se necessario, scorre *solo il proprio contenuto*.

### Mesh

1. **Passo:** dimensione massima nell'unita SAP corrente; tolleranza in
   percentuale; dimensione massima vincolante anche fra nodi selezionati.
   Una riga di riscontro esplicita il limite risultante. La modalita vincolante
   porta la tolleranza a zero e la disabilita.
2. **Distribuzione:** una sola scelta radio fra **Standard**, **Regolare e
   allineata**, **Raffinamento locale**. Standard e necessaria: oggi corrisponde
   allo stato in cui entrambe le checkbox sono spente. La scelta radio evita
   stati incompatibili. Quando vincoli obliqui impediscono una griglia
   cartesiana regolare, si indica il motivo e la strategia di ripiego.
3. **Vincoli geometrici:** simmetria esatta con scelta dell'asse, attiva solo
   quando riconosciuto; **fasce quad ordinate per settori radiali** come
   preferenza geometrica separata dalla scelta radio. Se non applicabile, il
   controllo mostra *perche* anziche sparire.

Le attuali etichette «Calcestruzzo», «Acciaio» e «Uso generale» diventano un
selettore compatto di **preset** nella scheda Mesh, non le tre schede
principali. Selezionare un preset imposta i valori iniziali, ma non nasconde
funzionalita che il backend supporta. Un'opzione ancora non supportata dal
preset rimane visibile e disabilitata con motivazione.

### Fori

Due schede/card nello stesso pannello:

- **Aperture da telai o bordi shell:** attivazione e gruppo che definisce il
  contorno; inattiva quando non ci sono vincoli eleggibili.
- **Fori circolari O-grid:** attivazione, gruppo dei centri e diametro nelle
  unita SAP; il numero di centri riconosciuti compare accanto al gruppo.

Le due funzioni mantengono il comportamento esistente; la proposta riguarda
la disposizione e la spiegazione dei prerequisiti.

### Avanzate

**Esecuzione:** FAST tramite tabelle SAP o inserimento standard; worker CPU
massimi o limite manuale con valore effettivo. **Protezione:** backup numerato
prima della mesh, destinazione dello snapshot CSV di Undo e stato dell'ultimo
backup. Le impostazioni raramente cambiate stanno qui, non fra passo e fori.

### Fascia sempre visibile

Sotto le schede: stato, progressione, tempo/ETA e numero di elementi creati,
distinti almeno in quad e triangoli. La riga dei tre comandi rimane fissa:
**Genera/Applica | Qualita della mesh | Annulla mesh**. Il link aggiornamenti,
licenza e versione restano nel piede senza coprire il progresso. Usare layout
fluidi WinForms (`TableLayoutPanel`, ancoraggio, `AutoScaleMode.Dpi`), spazi
regolari e testo leggibile in italiano anche con DPI elevato; evitare
coordinate assolute per il contenuto delle schede.

## Un solo report per tutta la mesh generata

Dalla 1.0.107 `CombineQuality` aggrega gli **elementi finali**, dopo
l'eliminazione dei fori, e riporta medie pesate sulle superfici e conteggio
di elementi fuori riferimento anziche i peggiori valori delle macro-aree.
Il dettaglio per singola anomalia e ancora proposto, non implementato.

Per una metrica di qualita adimensionale `q_e` (0 peggiore, 1 migliore) di
ciascun elemento `e`, si propone come descrittore principale la media pesata
per superficie effettiva `A_e`:

`Q_area = somma(A_e * q_e) / somma(A_e)`.

Il peso per superficie evita che molte celle minuscole, create dal
raffinamento, dominino artificialmente la valutazione di una superficie
grande. **Accanto** mostrare sempre `N_accettabili / N_totali`, percentuale
di superficie accettabile e istogramma/quantile della coda sfavorevole:
P5 per Jacobiano scalato, P95 per aspect ratio o skew. Per esempio, con 1.000
elementi equivalenti di qualita 1 e uno di qualita 0,2, la media e circa
0,9992 e la quota sotto soglia e 1/1.001 (0,10%): il titolo puo dire
«qualita complessiva elevata», con una **anomalia locale** consultabile, non
presentare 0,2 come qualita dell'intera mesh. Se l'elemento anomalo copre
molta piu area, la media per superficie scende coerentemente.

Non mescolare direttamente angoli ideali di quad (90 gradi) e triangoli
(60 gradi): media, quantili e soglie vanno calcolati **separatamente per tipo
di elemento**, e solo eventualmente ricondotti a un punteggio normalizzato
esplicitando la trasformazione. L'intestazione unica riporta numero di macro-
aree sorgenti, quad, triangoli, nodi e superficie coperta; la tabella ha
**una riga per metrica**, non una riga per macro-area.

La media non sostituisce i controlli inderogabili. Jacobiano non positivo,
elementi invertiti o collassati, lati non manifold, intersezioni/giunzioni
non congruenti, vincoli frame non rappresentati e violazioni del **limite
massimo vincolante** sono errori espliciti anche se riguardano una sola shell.
Il passo massimo e un vincolo: si mostra il massimo effettivo, non una media;
gli intervalli selezionati esentati nella modalita non vincolante si
contabilizzano separatamente. Una forma valida ma sotto le soglie consigliate
produce invece un avviso con numero e superficie interessata. Un pannello
facoltativo «Localizza anomalie» elenca ID, area sorgente, metrica e posizione
degli elementi peggiori, senza appesantire il riepilogo.

L'estensione con quantili, istogrammi e localizzazione delle anomalie e ancora
**una proposta progettuale**. La soglia globale oggi implementata e una convenzione
del plugin, non una soglia prescritta da un manuale. Le definizioni e gli intervalli delle metriche
quadrangolari derivano dalla [documentazione CUBIT/Verdict](https://www.sandia.gov/files/cubit/15.2/help_manual/WebHelp/mesh_generation/mesh_quality_assessment/quadrilateral_metrics.htm).
La [guida Ansys Mesh Metric](https://ansyshelp.ansys.com/public/Views/Secured/corp/v242/en/wb_msh/msh_metrics.html)
presenta media, estremi, deviazione standard e istogrammi per numero di
elementi o quota di area/volume: conferma l'utilita di mostrare la
distribuzione oltre al singolo estremo. Le soglie di accettabilita restano
esplicite e distinte dalla statistica descrittiva.
