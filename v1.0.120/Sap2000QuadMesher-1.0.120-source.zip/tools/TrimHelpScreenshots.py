"""Remove pixels outside the captured WinForms window's rounded DWM frame."""
from pathlib import Path
import sys

from PIL import Image


def main():
    if len(sys.argv) < 2:
        raise SystemExit("Usage: TrimHelpScreenshots.py screenshot.png [screenshot.png ...]")
    for value in sys.argv[1:]:
        path = Path(value)
        with Image.open(path) as image:
            if image.width < 550 or image.height < 600:
                raise ValueError(f"Unexpected window screenshot: {path}")
            trimmed = image.crop((8, 0, image.width - 8, image.height - 10))
            trimmed.save(path)
        print(f"TRIMMED_SCREENSHOT={path}")


if __name__ == "__main__":
    main()
