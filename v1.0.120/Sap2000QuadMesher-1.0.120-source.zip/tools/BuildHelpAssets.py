"""Prepare bilingual, annotated SVG help diagrams from the verified atomic report."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent.parent
SOURCES = ROOT / "examples" / "atomic" / "results" / "diagrams"
TARGET = ROOT / "docs" / "help" / "assets"
EXAMPLES = ("nTEST001", "nTEST005", "nTEST007", "nTEST010", "nTEST011")
SELECTED = re.compile(
    r'<circle cx="([^"]+)" cy="([^"]+)" r="5" fill="#7c3aed"[^>]*/>\s*'
    r'<text[^>]*>([^<]+)</text>'
)
FRAMES = re.compile(r'<line x1="([^"]+)" y1="([^"]+)" x2="([^"]+)" '
                    r'y2="([^"]+)" stroke="#ea580c"[^>]*/>')


def annotated_result(source, result, name):
    marks = []
    for x, y, label in SELECTED.findall(source):
        marks.extend((
            f'<circle cx="{x}" cy="{y}" r="8" fill="white" stroke="#7c3aed" stroke-width="3"/>',
            f'<circle cx="{x}" cy="{y}" r="3.5" fill="#7c3aed"/>',
            f'<text x="{float(x)+10:g}" y="{float(y)-9:g}" font-family="Segoe UI,Arial" '
            f'font-size="17" font-weight="700" fill="#6d28d9" stroke="white" '
            f'stroke-width="3" paint-order="stroke">{label}</text>',
        ))
    if name == "nTEST007":
        for i, (x1, y1, x2, y2) in enumerate(FRAMES.findall(source), 1):
            marks.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" '
                         f'stroke="#ea580c" stroke-width="6" stroke-linecap="round"/>'
                         f'<text x="{(float(x1)+float(x2))/2:g}" '
                         f'y="{(float(y1)+float(y2))/2-9:g}" '
                         f'font-family="Segoe UI,Arial" font-size="19" font-weight="700" '
                         f'fill="#9a3412" stroke="white" stroke-width="3" paint-order="stroke">F{i}</text>')
    if name == "nTEST005":
        marks.append('<circle cx="600" cy="382.5" r="13" fill="white" fill-opacity="0.9" '
                     'stroke="#ea580c" stroke-width="3" stroke-dasharray="4 3"/>'
                     '<path d="M594 382.5h12m-6-6v12" stroke="#ea580c" stroke-width="2"/>'
                     '<text x="619" y="374" font-family="Segoe UI,Arial" font-size="18" '
                     'font-weight="700" fill="#9a3412" stroke="white" stroke-width="3" '
                     'paint-order="stroke">H1</text>')
    return result.replace("</svg>", "\n<g id=\"preserved-constraints\">\n" +
                          "\n".join(marks) + "\n</g>\n</svg>")


def localize(svg, lang):
    if lang == "en":
        return svg
    svg = svg.replace("Source geometry", "Geometria iniziale")
    svg = svg.replace("Generated mesh", "Mesh generata")
    svg = re.sub(r"shells (\d+)  \|  nodes (\d+)  \|  frames (\d+)",
                 r"aree \1  |  nodi \2  |  frame \3", svg)
    return svg.replace(">SAP node<", ">Nodo SAP<").replace(">selected node<", ">Nodo selezionato<") \
        .replace(">shell<", ">area<")


def main():
    if not SOURCES.is_dir() or not TARGET.parent.is_dir():
        raise SystemExit("Missing atomic diagrams or help directory")
    TARGET.mkdir(exist_ok=True)
    for name in EXAMPLES:
        source = (SOURCES / f"{name}-source.svg").read_text(encoding="utf-8")
        result = (SOURCES / f"{name}-result.svg").read_text(encoding="utf-8")
        result = annotated_result(source, result, name)
        if name == "nTEST005":
            source = source.replace("</svg>",
                '<circle cx="600" cy="382.5" r="10" fill="white" fill-opacity="0.85" '
                'stroke="#ea580c" stroke-width="3"/>'
                '<circle cx="600" cy="382.5" r="4" fill="#ea580c"/>'
                '<text x="618" y="372" font-family="Segoe UI,Arial" font-size="18" '
                'font-weight="700" fill="#9a3412" stroke="white" stroke-width="3" '
                'paint-order="stroke">H1</text></svg>')
        for lang in ("it", "en"):
            for variant, diagram in (("source", source), ("result", result)):
                output = TARGET / f"{name}-{variant}-{lang}.svg"
                output.write_text(localize(diagram, lang), encoding="utf-8")
                ET.parse(output)
    print(f"HELP_DIAGRAMS={len(EXAMPLES)*4} DIR={TARGET}")


if __name__ == "__main__":
    main()
