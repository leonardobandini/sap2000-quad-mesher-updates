param([Parameter(Mandatory=$true)][int]$SapPid,
      [Parameter(Mandatory=$true)][string]$TestModel,
      [string]$UnsavedPoint = 'UNSAVED_120')
$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $TestModel -PathType Leaf)) { throw 'Isolated test model is missing.' }
$savedHash=(Get-FileHash -LiteralPath $TestModel -Algorithm SHA256).Hash
Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes
Add-Type -Path 'C:\Program Files\Computers and Structures\SAP2000 27\SAP2000v1.dll'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class CrashClickWindows {
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left,Top,Right,Bottom; }
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr window, out RECT rect);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr window);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int x,int y);
    [DllImport("user32.dll")] public static extern void mouse_event(uint flags,uint x,uint y,uint data,UIntPtr extra);
}
'@
$process=Get-Process -Id $SapPid -ErrorAction Stop
$window=[System.Windows.Automation.AutomationElement]::FromHandle($process.MainWindowHandle)
if ($window.Current.Name -notmatch '^SAP2000 Quad Transition Mesh 1\.0\.120$') {
    throw 'The isolated plugin window is not open.'
}
$controls=$window.FindAll([System.Windows.Automation.TreeScope]::Descendants,
    [System.Windows.Automation.Condition]::TrueCondition)
$symmetry=@($controls|Where-Object {$_.Current.Name -in @('Imponi simmetria','Enforce symmetry')})[0]
if (-not $symmetry -or $symmetry.Current.IsEnabled -or $symmetry.Current.NativeWindowHandle -eq 0) {
    throw 'A disabled symmetry option was not found.'
}
$rect=New-Object CrashClickWindows+RECT
if (-not [CrashClickWindows]::GetWindowRect([IntPtr]$symmetry.Current.NativeWindowHandle,[ref]$rect)) {
    throw 'Cannot locate the symmetry control.'
}
$x=[int](($rect.Left+$rect.Right)/2)
$y=[int](($rect.Top+$rect.Bottom)/2)
$start=Get-Date
[void][CrashClickWindows]::SetForegroundWindow($process.MainWindowHandle)
foreach($click in 1..160){
    [void][CrashClickWindows]::SetCursorPos($x,$y)
    [CrashClickWindows]::mouse_event(2,0,0,0,[UIntPtr]::Zero)
    [CrashClickWindows]::mouse_event(4,0,0,0,[UIntPtr]::Zero)
    Start-Sleep -Milliseconds 110
    $process.Refresh()
    if ($process.HasExited) { throw "SAP2000 terminated after disabled-checkbox click $click." }
}
Write-Host "DISABLED_SYMMETRY_CLICKS=160 SAP_STILL_RUNNING=PASS elapsed=$([int]((Get-Date)-$start).TotalSeconds)s"
$model=(New-Object SAP2000v1.Helper).GetObjectProcess('CSI.SAP2000.API.SapObject',$SapPid).SapModel
if (-not [string]::Equals($model.GetModelFilename($true),$TestModel,
    [StringComparison]::OrdinalIgnoreCase)) { throw 'The test SAP model changed.' }
$count=0;$points=@()
if ($model.PointObj.GetNameList([ref]$count,[ref]$points) -ne 0 -or
    $UnsavedPoint -notin $points -or
    (Get-FileHash -LiteralPath $TestModel -Algorithm SHA256).Hash -ne $savedHash) {
    throw 'The unsaved point disappeared or the saved fixture was modified.'
}
Write-Host "UNSAVED_MODEL_SURVIVED=PASS POINT=$UnsavedPoint SAVED_FILE_UNCHANGED=PASS"
