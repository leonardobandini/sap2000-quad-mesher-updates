"""Check offline help links, screenshots, constraints and plugin icon."""
from html.parser import HTMLParser
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

from PIL import Image


class References(HTMLParser):
    def __init__(self):
        super().__init__()
        self.paths = []
        self.anchors = set()
        self.language = None

    def handle_starttag(self, tag, attrs):
        props = dict(attrs)
        if tag == "html":
            self.language = props.get("lang")
        if "id" in props:
            self.anchors.add(props["id"])
        for attribute in ("href", "src"):
            if attribute in props:
                self.paths.append(props[attribute])


def verify(root):
    directory = root / "docs" / "help"
    if not (root / "img" / "quad-mesher.ico").is_file():
        raise ValueError("Plugin icon not installed")
    if not (root / "img" / "quad-mesher-icon.svg").is_file():
        raise ValueError("Vector icon not installed")
    for language in ("it", "en"):
        page = directory / f"index-{language}.html"
        parsed = References()
        parsed.feed(page.read_text(encoding="utf-8"))
        if parsed.language != language or len(parsed.anchors) < 7:
            raise ValueError(f"Missing {language} language or contents sections")
        for path in parsed.paths:
            if path.startswith("#"):
                if path[1:] not in parsed.anchors:
                    raise ValueError(f"Broken anchor in {page}: {path}")
                continue
            if "://" in path:
                raise ValueError(f"Offline help uses an external asset: {path}")
            target = (directory / path).resolve()
            if not target.is_file():
                raise FileNotFoundError(target)
            if target.suffix.lower() == ".svg":
                ET.parse(target)
            if target.suffix.lower() == ".png":
                with Image.open(target) as screenshot:
                    if screenshot.width < 500 or screenshot.height < 550:
                        raise ValueError(f"UI screenshot too small: {target}")
        for name, labels in (("nTEST010", ("B1", "B2", "B3", "T1", "T2", "T3", "T4")),
                             ("nTEST011", ("P1", "P2", "P3")),
                             ("nTEST007", ("F1", "F2", "F3", "F4")),
                             ("nTEST005", ("H1",))):
            mesh = (directory / "assets" / f"{name}-result-{language}.svg").read_text(encoding="utf-8")
            if 'id="preserved-constraints"' not in mesh or any(f">{label}<" not in mesh for label in labels):
                raise ValueError(f"Missing annotated constraint in {name} ({language})")
    with Image.open(root / "img" / "quad-mesher.ico") as icon:
        if icon.format != "ICO" or (16, 16) not in icon.ico.sizes() or (256, 256) not in icon.ico.sizes():
            raise ValueError("Icon lacks taskbar and high-DPI resolutions")
    print(f"BILINGUAL_OFFLINE_HELP=PASS root={root}")


if __name__ == "__main__":
    if len(sys.argv) > 2:
        raise SystemExit("Usage: VerifyBilingualHelp.py [project-or-package-root]")
    verify(Path(sys.argv[1]).resolve() if len(sys.argv) == 2 else Path(__file__).resolve().parent.parent)
