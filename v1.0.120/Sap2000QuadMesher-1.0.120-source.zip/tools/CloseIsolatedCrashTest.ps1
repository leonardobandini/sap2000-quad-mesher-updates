param([Parameter(Mandatory=$true)][int]$SapPid,
      [Parameter(Mandatory=$true)][string]$TestModel)
$ErrorActionPreference = 'Stop'
Add-Type -Path 'C:\Program Files\Computers and Structures\SAP2000 27\SAP2000v1.dll'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class CloseCrashTestWindow {
    [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr window,uint message,IntPtr w,IntPtr l);
}
'@
$process=Get-Process -Id $SapPid -ErrorAction Stop
$sap=(New-Object SAP2000v1.Helper).GetObjectProcess('CSI.SAP2000.API.SapObject',$SapPid)
if (-not [string]::Equals($sap.SapModel.GetModelFilename($true),$TestModel,
    [StringComparison]::OrdinalIgnoreCase)) { throw 'Refusing to close a different SAP model.' }
if ($process.MainWindowTitle -match '^SAP2000 Quad Transition Mesh') {
    if (-not [CloseCrashTestWindow]::PostMessage($process.MainWindowHandle,0x10,[IntPtr]::Zero,[IntPtr]::Zero)) {
        throw 'Could not close the plugin.'
    }
    $deadline=(Get-Date).AddSeconds(15)
    do { Start-Sleep -Milliseconds 200; $process.Refresh() }
    while ($process.MainWindowTitle -match '^SAP2000 Quad Transition Mesh' -and (Get-Date) -lt $deadline)
    if ($process.MainWindowTitle -match '^SAP2000 Quad Transition Mesh') { throw 'Plugin remains open.' }
}
if ($sap.ApplicationExit($false) -ne 0) { throw 'SAP2000 refused to close without saving.' }
Write-Host 'ISOLATED_UNSAVED_TEST_CLOSED_WITHOUT_SAVING=PASS'
