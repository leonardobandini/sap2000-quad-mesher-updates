param([string]$Plugin = (Join-Path (Split-Path -Parent $PSScriptRoot) 'SapQuadTransitionPlugin\bin\Release\net48\SapQuadTransitionPlugin.dll'))
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -Path 'C:\Program Files\Computers and Structures\SAP2000 27\SAP2000v1.dll'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class CompletionTestWindow {
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr FindWindow(string kind, string title);
    [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr window, uint message, IntPtr wParam, IntPtr lParam);
}
'@
$assembly = [Reflection.Assembly]::LoadFrom((Resolve-Path -LiteralPath $Plugin).Path)
$watch = $assembly.GetType('SapQuadTransitionPlugin.cPlugin').GetMethod('DismissSapCompletionWhenShown',
    [Reflection.BindingFlags]'Static,NonPublic')
if (-not $watch) { throw 'Completion watcher missing.' }
$owner = New-Object Windows.Forms.Form
$owner.Text = 'SAP2000 v27 native completion test'
$owner.Show()
try {
    $timedOut = $false
    $safety = New-Object Windows.Forms.Timer
    $safety.Interval = 4000
    $safety.Add_Tick({
        $script:timedOut = $true
        $window = [CompletionTestWindow]::FindWindow('#32770', 'SAP2000')
        if ($window -ne [IntPtr]::Zero) {
            [void][CompletionTestWindow]::PostMessage($window, 0x10, [IntPtr]::Zero, [IntPtr]::Zero)
        }
        $safety.Stop()
    })
    try {
        $watch.Invoke($null, @()) | Out-Null
        $safety.Start()
        $clock = [Diagnostics.Stopwatch]::StartNew()
        [void][Windows.Forms.MessageBox]::Show($owner, 'Plugin completed successfully.', 'SAP2000',
            [Windows.Forms.MessageBoxButtons]::OK, [Windows.Forms.MessageBoxIcon]::Information)
        $clock.Stop()
        if ($timedOut -or $clock.Elapsed.TotalSeconds -ge 3.8) {
            throw 'The exact SAP2000 success notice was not dismissed quickly.'
        }
        "EXACT_COMPLETION_DISMISSED=PASS MS=$([int]$clock.Elapsed.TotalMilliseconds)"
    } finally { $safety.Stop(); $safety.Dispose() }

    $watch.Invoke($null, @()) | Out-Null
    $control = New-Object Windows.Forms.Timer
    $control.Interval = 650
    $control.Add_Tick({
        $window = [CompletionTestWindow]::FindWindow('#32770', 'SAP2000')
        if ($window -ne [IntPtr]::Zero) {
            [void][CompletionTestWindow]::PostMessage($window, 0x10, [IntPtr]::Zero, [IntPtr]::Zero)
        }
        $control.Stop()
    })
    try {
        $control.Start()
        $clock.Restart()
        [void][Windows.Forms.MessageBox]::Show($owner, 'Check the model geometry before continuing.',
            'SAP2000', [Windows.Forms.MessageBoxButtons]::OK, [Windows.Forms.MessageBoxIcon]::Warning)
        $clock.Stop()
        if ($clock.ElapsedMilliseconds -lt 500) { throw 'An unrelated SAP2000 warning was dismissed.' }
        "OTHER_SAP_WARNINGS_UNTOUCHED=PASS MS=$([int]$clock.Elapsed.TotalMilliseconds)"
    } finally { $control.Stop(); $control.Dispose() }
} finally { $owner.Close(); $owner.Dispose() }
