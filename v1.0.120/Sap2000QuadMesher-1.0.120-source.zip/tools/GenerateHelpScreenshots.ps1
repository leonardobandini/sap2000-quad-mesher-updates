param([string]$Plugin = (Join-Path (Split-Path -Parent $PSScriptRoot) 'SapQuadTransitionPlugin\bin\Release\net48\SapQuadTransitionPlugin.dll'))
$ErrorActionPreference = 'Stop'
$directory = Join-Path (Split-Path -Parent $PSScriptRoot) 'docs\help\assets'
if (-not (Test-Path -LiteralPath $directory -PathType Container)) { throw "Help asset directory missing: $directory" }
$test = Join-Path $PSScriptRoot 'TestTabbedOptionsLayout.ps1'
foreach ($language in @('Italiano', 'English')) {
    $suffix = if ($language -eq 'Italiano') { 'it' } else { 'en' }
    foreach ($page in @('Mesh', 'Holes', 'Advanced')) {
        $path = Join-Path $directory ('ui-' + $suffix + '-' + $page.ToLowerInvariant() + '.png')
        & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $test -Plugin $Plugin `
            -ScreenshotPath $path -ScreenshotLanguage $language -ScreenshotPage $page | Out-Host
        if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $path)) {
            throw "Screenshot failed for $language / $page"
        }
    }
    $quality = Join-Path $directory ('ui-' + $suffix + '-quality.png')
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'TestGlobalQualityAverages.ps1') `
        -Plugin $Plugin -ScreenshotPath $quality -ScreenshotLanguage $language | Out-Host
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $quality)) {
        throw "Quality screenshot failed for $language"
    }
}
& python (Join-Path $PSScriptRoot 'TrimHelpScreenshots.py') `
    @(Get-ChildItem -LiteralPath $directory -Filter 'ui-*.png' -File | ForEach-Object FullName)
if ($LASTEXITCODE -ne 0) { throw 'Screenshot framing failed.' }
Write-Host "HELP_SCREENSHOTS=8 DIR=$directory"
