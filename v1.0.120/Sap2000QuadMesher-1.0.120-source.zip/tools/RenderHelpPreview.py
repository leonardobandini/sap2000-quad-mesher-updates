"""Render the offline guide in an isolated headless Edge profile for visual review."""
from pathlib import Path
import subprocess
import tempfile
import uuid


ROOT = Path(__file__).resolve().parent.parent
EDGE = Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe")
TEMP = Path(tempfile.gettempdir()) / "opencode"


def main():
    if not EDGE.is_file() or not TEMP.is_dir():
        raise SystemExit("Edge or temporary parent directory unavailable")
    token = uuid.uuid4().hex
    profile = TEMP / ("sqm-help-preview-" + token)
    for language in ("it", "en"):
        page = (ROOT / "docs" / "help" / f"index-{language}.html").resolve()
        for section in ("top", "examples"):
            screenshot = TEMP / f"sqm-help-{language}-{section}-{token}.png"
            command = [str(EDGE), "--headless=new", "--disable-gpu", "--hide-scrollbars",
                       "--no-first-run", "--no-default-browser-check", "--virtual-time-budget=1200",
                       f"--user-data-dir={profile}", f"--screenshot={screenshot}",
                       "--window-size=1440,1080", page.as_uri() + ("#esempi" if language == "it" else "#examples")
                       if section == "examples" else page.as_uri()]
            result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    text=True, timeout=45, check=False)
            if not screenshot.is_file() or screenshot.stat().st_size == 0:
                raise RuntimeError(f"Edge did not render {language}/{section}: {result.stderr[-600:]}")
            print(f"HELP_PREVIEW_{language.upper()}_{section.upper()}={screenshot}")


if __name__ == "__main__":
    main()
