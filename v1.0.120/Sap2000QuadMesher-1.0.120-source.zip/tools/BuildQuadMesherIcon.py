"""Render the Quad Mesher mark as a multiresolution Windows taskbar icon."""
from pathlib import Path

from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "img" / "quad-mesher.ico"
SCALE = 4


def p(value):
    return round(value * SCALE)


def line(draw, points, color, width):
    draw.line([(p(x), p(y)) for x, y in points], fill=color, width=p(width), joint="curve")


def circle(draw, x, y, radius, fill, outline=None, width=1):
    box = (p(x-radius), p(y-radius), p(x+radius), p(y+radius))
    draw.ellipse(box, fill=fill, outline=outline, width=p(width))


def main():
    image = Image.new("RGBA", (p(256), p(256)), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    draw.rounded_rectangle((p(8), p(8), p(248), p(248)), radius=p(51), fill="#0f172a")
    tile = [(p(x), p(y)) for x, y in [(43, 50), (203, 43), (213, 201), (53, 210)]]
    draw.polygon(tile, fill="#2563eb")
    line(draw, [(43, 50), (203, 43), (213, 201), (53, 210), (43, 50)], "#93c5fd", 7)
    for path in [[(47, 105), (207, 98)], [(50, 157), (210, 151)],
                 [(96, 48), (104, 206)], [(151, 45), (159, 204)]]:
        line(draw, path, "#e0f2fe", 6)
    hole = [(151, 98), (207, 98), (210, 151), (158, 152)]
    draw.polygon([(p(x), p(y)) for x, y in hole], fill="#0f172a")
    line(draw, hole + hole[:1], "#e0f2fe", 6)
    circle(draw, 183, 125, 21, None, "#f97316", 8)
    for x, y in [(47, 105), (104, 157), (159, 204)]:
        circle(draw, x, y, 10, "#f97316", "#fff7ed", 3)
    image = image.resize((256, 256), Image.Resampling.LANCZOS)
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    image.save(OUTPUT, format="ICO", sizes=[(16, 16), (24, 24), (32, 32),
                                            (48, 48), (64, 64), (128, 128), (256, 256)])
    print(f"ICON={OUTPUT}")


if __name__ == "__main__":
    main()
