# SAP2000 Quad Transition Plugin

**Versione pubblica corrente: 1.0.120; prima versione per utenti: 1.0.79.** Le versioni anteriori alla 1.0.79 erano build di sviluppo/prova. Lo scopo principale del plugin è mostrare con un'applicazione funzionante come integrare SAP2000 con C# e Python/Gmsh, e come queste procedure possono migliorare il lavoro con programmi di terze parti. Genera mesh quad-dominant su aree piane da 3 a N spigoli. L'utente verifica i risultati nel proprio modello; il progetto non sostituisce il controllo tecnico di un professionista.

Funzionalita, sviluppi e ottimizzazioni delle prossime versioni dipenderanno dalle richieste ricevute e dalle idee dell'autore.

La tolleranza nella finestra della mesh e espressa in percentuale (0–50%, inizialmente 0%). La dimensione inserita rimane il **passo nominale**: con 500 mm e tolleranza 25% il limite degli spigoli nuovi e 625 mm. L'opzione non raffittisce i lati del foro i cui point object sono selezionati; **Inserisci nodi di mesh anche negli spigoli con nodi selezionati** azzera la tolleranza e consente le suddivisioni necessarie. L'opzione, preselezionata, **Prediligi elementi quadrangolari disposti a fasce radiali e pseudo-radiali** usa un riconoscimento geometrico di contorno anulare, corda esterna, cuciture e guide compatibili; i casi non riconosciuti seguono il mesher ordinario. Deselezionandola si usa sempre il percorso precedente.

Il profilo **Strutture in acciaio** offre la strategia **Regolare/Allineata**. Su aree rettangolari ortogonali si possono ottenere quadrilateri cartesiani con nodi allineati. Se sono selezionati anche i point object dei bordi e il passo richiesto ne richiede la suddivisione, attivare **Inserisci nodi di mesh anche negli spigoli con nodi selezionati**: altrimenti il plugin segnala che la griglia regolare taglierebbe un bordo immutabile. Le opzioni di mesh regolare e raffinamento delle tensioni si escludono a vicenda.

La 1.0.101 conserva la congruenza degli spigoli fra shell ortogonali quando il passo regolare e di 30 mm, evitando guide interne non presenti anche sul bordo della shell adiacente. Sul modello Nodo_2 con 14 aree e 30 nodi selezionati, profilo Acciaio e dimensione vincolante, produce 1.653 quadrilateri con lati paralleli agli assi cartesiani e spigoli non superiori a 30 mm.

La build locale 1.0.105 mostra il riepilogo della selezione e raccoglie le impostazioni nelle schede **Mesh**, **Fori** e **Avanzate**. Il preset materiale resta nella scheda Mesh; tre scelte esclusive **Standard**, **Regolare** e **Raffinamento** sostituiscono le checkbox di strategia. Stato, conteggio elementi, progresso e comandi rimangono visibili. Per tornare temporaneamente alla finestra precedente, impostare `SAP_QUAD_OPTIONS_LAYOUT=legacy` prima di avviare SAP2000 e riaprire il plugin: il percorso precedente e ancora incluso nella stessa build. Il report di qualita aggregato resta una proposta, descritta in `docs/PROPOSTA_INTERFACCIA_E_QUALITA_MESH.md`.

Nella build locale 1.0.106, se la strategia richiesta non genera una mesh, il plugin prepara e verifica le altre modalita prima di modificare il modello SAP2000. Conserva i nodi e i telai selezionati, i fori e la dimensione massima; tra le mesh congruenti sceglie in base a superamento dei controlli di qualita, numero di elementi, triangoli e punteggio di qualita pesato sulle superfici. Un messaggio finale riporta strategia, dimensione, vincoli mantenuti, simmetria, numero di elementi e triangoli, ed eventuali avvisi. Anche quando la mesh e generabile, vincoli geometrici imposti possono lasciare angoli o Jacobiani fuori riferimento: il controllo di qualita rimane consultabile prima di Applica.

Nella build locale 1.0.107, la simmetria esatta funziona anche con mesh non regolari su piu aree: le aree corrispondenti condividono una mesh riflessa e la selezione globale viene verificata rispetto agli assi scelti. Le tre schede diventano **Opzioni della mesh | Fori e Aperture | Opzioni Avanzate**, in inglese **Mesh Options | Holes and Openings | Advanced Options**. Quando la selezione comprende piu aree, il report mostra valori medi per elemento pesati in base alla superficie della shell, il punteggio globale e la quota di elementi fuori riferimento. Dimensione massima e orientamento restano controlli vincolanti anche per un solo elemento. I testi italiani delle opzioni e tooltip sono in `docs/CATALOGO_OPZIONI_E_TOOLTIP_IT.md`; criterio di aggregazione e riferimenti in `docs/QUALITA_MESH_AGGREGATA.md`. Il profilo mantiene i preset attuali, in attesa della revisione futura delle opzioni ottimali per materiale.

Nella build locale 1.0.108, le etichette e i tooltip della finestra seguono le correzioni italiane dell'autore in `docs/CATALOGO_OPZIONI_E_TOOLTIP_IT.md`, con corrispondenti traduzioni inglesi. La dicitura "Frame" sostituisce "Telai" nell'interfaccia italiana; la terminologia di strategia, simmetria, suddivisione degli spigoli selezionati e fasce radiali e piu esplicita.

Nella build locale 1.0.109, il riquadro della selezione iniziale mostra anche **Report sugli elementi creati** dopo Genera: numero complessivo di aree quadrangolari, triangolari e poligonali, frame, link e nodi presenti nella mesh del modello. Durante l'anteprima le aree originali conservate per Undo non sono conteggiate; dopo Applica i numeri sono aggiornati e dopo Annulla scompare il report della mesh, lasciando la selezione iniziale ripristinata.

Nella build locale 1.0.110, il report sostituisce la selezione nello stesso spazio; Annulla ripristina il riepilogo iniziale. Quando un tentativo fallisce, il recupero prova prima a inserire nodi anche sugli spigoli con nodi selezionati, aggiornando l'opzione visibile se questa viene utilizzata. Gli errori del generatore vengono presentati nella lingua selezionata, senza il traceback Python misto.

Nella build locale 1.0.111, la finestra del plugin si puo richiamare dalla barra delle applicazioni e l'interazione con il viewport viene riabilitata a livello di finestra Windows durante l'anteprima. La navigazione nativa SAP2000 rimaneva tuttavia bloccata finche il comando del plugin non terminava: la correzione del ciclo host e nella 1.0.112.

Nella build locale 1.0.112, la finestra interattiva continua su un thread STA dopo la restituzione del controllo al ciclo dei comandi SAP2000. Questo sblocca la navigazione del viewport durante l'anteprima; i test automatici rimangono sincroni.

Nella build locale 1.0.113, la finestra del plugin resta sempre visibile sopra SAP2000 mentre si naviga nell'area scoperta del viewport; la mesh resta in anteprima fino ad Applica.

Nella build locale 1.0.114, l'avviso standard SAP2000 "Plugin completed successfully." viene chiuso appena appare, senza interferire con la finestra del plugin né con gli altri messaggi SAP2000.

La versione 1.0.115 raccoglie le correzioni delle build locali dalla 1.0.102 alla 1.0.114 e toglie i link esterni CUBIT e COMSOL dal report di qualita. Le metriche e i valori di riferimento rimangono visibili.

Nella build locale 1.0.116, un comando di annullamento indipendente è disponibile anche durante la preparazione della selezione iniziale. Dopo Genera, Annulla si attiva prima della lettura dello snapshot e delle operazioni multi-area: se il thread del dialogo principale è occupato, la piccola finestra indipendente rimane reattiva fino al ripristino del modello.

La build locale 1.0.117 include `docs/help/index-it.html` e `docs/help/index-en.html`: dalla finestra del plugin F1 o il ? della barra del titolo apre la guida corrispondente alla lingua selezionata. La guida contiene schermate reali delle opzioni, confronti vettoriali SVG prima/dopo e annotazioni dei vincoli. L'icona Quad Mesher originale viene mostrata nella barra delle applicazioni; i sorgenti dell'icona e delle immagini sono inclusi nell'archivio corrispondente.

La versione 1.0.118 allinea la guida inglese alle correzioni dell'autore nella guida italiana, centra verticalmente GPL, aggiornamento e versione nel footer e semplifica le diciture dell'interfaccia e della guida correnti.

La build locale 1.0.119 inizializza la tolleranza al 20% nei nuovi profili (le opzioni salvate continuano ad avere precedenza), centra la finestra di annullamento sul plugin e riduce il sovraraffinamento delle mesh simmetriche con frame e bordi vincolati. Sulla copia isolata di `mod1.sdb` a 1 m, l'anteprima passa da 2.914 a 548 quadrilateri, mantiene simmetria e tutti i punti/frame selezionati, e Annulla ripristina il modello iniziale. Alcuni angoli dei quadrilateri restano fuori riferimento e vengono segnalati nel report qualità.

La versione 1.0.120 rimuove il callback WinEvent del messaggio di completamento SAP2000: due dump di crash hanno individuato l'eccezione non gestita su quel thread. Un controllo periodico chiude solo il messaggio esatto; la finestra del plugin registra gli errori in `%LOCALAPPDATA%\SAP2000QuadMesher\plugin-errors.log` invece di lasciare terminare SAP2000 un thread secondario.

Nelle build locali dalla 1.0.93, sulle selezioni di settori con guide trasversali parziali geometricamente compatibili questa opzione prova prima la **fascia globale fitta**: prolunga soltanto all'interno le guide parziali, sincronizza le cuciture e conserva i telai SAP originali. Se la geometria non e compatibile o la verifica della mesh fallisce, ritorna al percorso strutturato precedente. Le opzioni dell'ultima generazione vengono ricordate nel profilo utente, con le lunghezze convertite fra le unita del modello. Dalla 1.0.94 SAP2000 resta utilizzabile e la mesh viene visualizzata subito dopo **Genera**, prima di **Applica** o **Annulla mesh**. Dalla 1.0.95 la finestra del plugin rimane in primo piano durante l'ispezione e resta accessibile dalla barra delle applicazioni.

## Requisiti

- SAP2000 27 x64.
- .NET Framework 4.8.

Il pacchetto distribuibile include Python 3.12 e Gmsh 4.15.2 in un runtime privato. Non usa Python installato nel sistema, non modifica `PATH` e non richiede `pip`.

Il codice originale e GPL-2.0-or-later. `LICENSE` (GPLv2), `GPL-3.0.txt`, `LICENSE-APPLICATION.md` e `SOURCE.md` nel pacchetto indicano diritti e sorgenti corrispondenti. Per il backend binario con OpenSSL 3 viene scelta l'opzione GPLv3. `SAP2000-LINKING-EXCEPTION.md` riguarda **soltanto il codice C# dell'autore**: non concede diritti su SAP2000, la sua API o Gmsh, che mantengono le licenze dei loro titolari. Gli archivi sorgenti restano nell'[archivio pubblico](https://github.com/leonardobandini/sap2000-quad-mesher-updates/tree/source-archive) anche quando una release di prova non e piu scaricabile.

## Installazione

1. Estrarre interamente lo ZIP della release.
2. Chiudere SAP2000.
3. Eseguire `install_plugin.cmd`; non sono richiesti privilegi di amministratore.
4. Riaprire SAP2000: l'installer aggiunge automaticamente la voce **SAP2000 Quad Mesher** nel menu `Tools`.

L'installer verifica il runtime e copia il pacchetto in `%LOCALAPPDATA%\Programs\SAP2000QuadMesher`, nella cartella **Programmi dell'utente** (non in Download e senza richiedere UAC). Sostituisce l'eventuale installazione di prova solo dopo aver verificato i nuovi file e registra il plugin per il solo utente corrente. Aggiorna le preferenze menu SAP2000 27 senza rimuovere le voci degli altri plugin e non duplica una voce gia presente. Se le preferenze SAP2000 non sono state ancora inizializzate o non possono essere lette, avvisa che e necessario aggiungere `SapQuadTransitionPlugin` da `Tools > Add/Show Plugins`. Gli installer `.cmd` invocano `SQMPluginInstaller.exe`, senza PowerShell. Per rimuoverlo chiudere SAP2000 ed eseguire `uninstall_plugin.cmd` dalla cartella dello ZIP estratto.

## Selezione

- Selezionare una o piu aree piane con almeno tre spigoli, anche disgiunte.
- Selezionare i point object del contorno che devono essere riutilizzati per la congruenza. La distribuzione puo essere non uniforme.
- Selezionare eventuali point object interni che devono diventare nodi della mesh.
- Selezionare eventuali frame interni che devono coincidere con spigoli della mesh. Sono supportate catene aperte, forme chiuse e piu catene disgiunte non intersecanti.
- I vertici geometrici dell'area sono inclusi automaticamente.

La finestra principale contiene tutte le opzioni di esecuzione e riporta nel titolo e nel footer la versione del plugin. Usa uno sfondo bianco, intestazione blu notte, caratteri Segoe UI, azioni blu e bordi grigio chiaro; il footer include il collegamento a `CSi Italia`. E una finestra non modale, in primo piano e presente nella barra delle applicazioni: dopo **Genera** puoi utilizzare SAP2000 per osservare e navigare la mesh, mantenendo accessibili **Applica** e **Annulla mesh**. Durante l'intera operazione la barra di avanzamento e animata quando il tempo residuo non e stimabile e mostra una percentuale durante la creazione degli oggetti SAP2000. Al termine il comando `Dettagli mesh` apre, su richiesta, il controllo indipendente di dimensioni, aspect ratio, angoli, skew, Jacobiano scalato, orientamento ed elementi degeneri. Anche questa finestra usa lo stesso stile e footer. Ogni metrica e rappresentata su una scala grafica da `CRITICA` a `OTTIMA`, con valore misurato e intervallo tecnico di riferimento.

Il link `Verified examples` / `Esempi verificati` nell'intestazione apre il PDF incluso in `docs/`. Le prove riportate furono eseguite con la **build di sviluppo v0.0.57**, non destinata agli utenti; la tabella misura la durata del test SAP2000 completo, non il tempo di generazione della mesh della versione corrente. Il confronto prestazionale MODO incluso nei documenti e anch'esso una misura della fase di sviluppo, non una prestazione garantita della versione distribuita. Il link di aggiornamento e centrato nel footer.

La dimensione massima e il diametro dei fori accettano un valore nell'unita di
lunghezza SAP2000 corrente oppure un suffisso esplicito `m`, `cm`, `mm`, `ft`
o `in`: ad esempio `25mm` in un modello impostato in metri equivale a
`0.025 m`, mentre `2,5cm` e `0.025 m`. Il tooltip di entrambi i campi ricorda
questa possibilita. Dopo **Generate / Genera**, il pulsante **Cancel
generation / Annulla generazione** chiede l'interruzione della mesh corrente:
il backend viene fermato, e gli eventuali oggetti SAP2000 gia importati
vengono ripristinati prima di tornare alle opzioni. Se SAP2000 sta eseguendo
una chiamata API indivisibile, l'annullamento attende che la chiamata
termini e poi ripristina il modello; non chiude l'istanza SAP2000.

L'opzione `FAST - inserimento bulk tramite tabelle SAP2000` e selezionata automaticamente all'apertura della finestra. Prepara in sequenza le mesh di tutte le aree selezionate, propagando i vincoli condivisi. Poi invia **una sola volta** le tabelle editabili `Joint Coordinates`, `Connectivity - Area` e `Area Section Assignments` per l'intera selezione. Il plugin continua a leggere le aree originali prima di meshare, a verificare le tabelle dopo l'import e a trasferire le assegnazioni per elemento. Durante l'anteprima le aree originali restano intatte e tutte le shell generate usano label temporanee alfanumeriche corte e distinte; prima dell'importazione vengono controllati i bordi condivisi, dopo conteggi, connettivita e proprieta. Le diagnostiche note delle righe di continuazione usate da SAP2000 per aree con piu di quattro vertici sono distinte dagli errori reali. Il percorso COM ordinario resta disponibile deselezionando FAST.

Quando sono selezionati frame interni, il mesher incorpora ogni frame come curva protetta e converte la discretizzazione in soli quadrilateri. Il frame puo corrispondere a piu spigoli shell consecutivi; nessun quadrilatero puo attraversarlo usandolo come diagonale. In questo modo gli elementi racchiusi da forme chiuse possono essere individuati e cancellati per creare aperture. I frame originali non vengono modificati o suddivisi dal plugin.

L'opzione `Generate holes enclosed by selected frames or shell edges` elimina automaticamente dalla mesh tutte le shell isolate dal bordo esterno da catene chiuse formate da frame selezionati, spigoli incidenti di altre shell selezionate o una combinazione dei due. Le catene aperte non producono cancellazioni. Il comando `Undo mesh` ripristina anche le shell omesse, ricreando l'area originale completa.

L'opzione `Generate circular O-grid holes` usa i point object del gruppo scelto come centri di fori con diametro comune, espresso nelle unita correnti SAP2000. Ogni foro riceve un contorno poligonale inscritto e un anello O-grid transfinito full-quad, collegato con una transizione quadrangolare alla mesh esterna. Sulle piastre rettangolari non vincolate viene usato automaticamente un percorso strutturato: 48 o piu corde, sette strati radiali con transizione cerchio-quadrato e griglia cartesiana esterna congruente. Il plugin verifica preventivamente che i dischi siano interni all'area, disgiunti e liberi da altri nodi vincolanti.

Quando vengono elaborate piu aree, ogni area mantiene proprieta e carichi propri. Gli spigoli coincidenti, anche se orientati in verso opposto o sovrapposti solo parzialmente, vengono discretizzati con lo stesso insieme di nodi; le mesh adiacenti risultano quindi congruenti. Con la preferenza regolare attiva, i poligoni non rettangolari e i frame obliqui possono usare il mesher generale senza duplicare i nodi di confine gia raffinati. La generazione, l'annullamento e la conferma sono transazionali sull'intera selezione.

Ogni spigolo di ogni area selezionata viene clippato nel piano di tutte le altre aree. Ogni tratto interno, completo o parziale, viene incorporato come linea protetta nelle mesh ospiti; lo stesso spigolo puo quindi incidere su piu aree e ogni area puo ricevere piu vincoli. Gli incroci tra vincoli vengono suddivisi prima della meshatura. La suddivisione e propagata alle shell sorgenti e tutte le superfici riutilizzano gli stessi point object lungo ciascun tratto comune, anche con orientamenti 3D generici.

Vicino agli spigoli incidenti il mesher applica un raffinamento locale graduato basato sui campi Gmsh `Distance` e `Threshold`, con fascia fine limitata e transizione progressiva verso la dimensione globale. La mesh rimane full-quad nelle aree che contengono i vincoli e continua a usare le metriche di aspect ratio, skew, angoli e Jacobiano scalato del report qualita.

Il primo pulsante passa da **Genera** a **Applica** dopo la mesh; gli altri due mostrano la qualita e annullano la mesh. **Applica** elimina immediatamente le aree originali dal modello SAP2000 e mantiene aperta la finestra. Prima della generazione il plugin registra in `%LOCALAPPDATA%\SAP2000QuadMesher\snapshots` un CSV con i dati editabili del modello, comprese coordinate, connettivita, sezioni, carichi, vincoli, gruppi, pattern dei joint e sovrascritture. **Annulla mesh** ripristina dal CSV la geometria e le assegnazioni originali; il percorso FAST e quello COM sono entrambi supportati. Se si chiude la finestra prima di **Applica**, l'anteprima viene annullata; chiuderla dopo **Applica** lascia nel modello la mesh definitiva. Lo snapshot CSV rimane disponibile dopo l'applicazione, anche in seguito a Undo. Il plugin non salva automaticamente il modello SAP2000.

Se il generatore non trova una mesh che soddisfa i requisiti, l'errore viene mostrato senza chiudere il plugin. La finestra torna allo stato iniziale e permette di modificare dimensione o simmetria e avviare un nuovo tentativo.

Le soglie visualizzate derivano dalle metriche CUBIT/Verdict: per i quadrilateri aspect ratio `1-4`, skew normalizzato `0-0.5`, angoli `45-135 gradi` e Jacobiano scalato `0.5-1`; per i triangoli angoli `30-90 gradi`. La scala qualitativa suddivide l'intero dominio della metrica e non sostituisce uno studio di convergenza sul risultato strutturale.

Riferimenti:

- C. Geuzaine e J.-F. Remacle, *Gmsh: a three-dimensional finite element mesh generator with built-in pre- and post-processing facilities*, IJNME 79 (2009), per entita incorporate e campi di dimensione.
- J.-F. Remacle et al., *Blossom-Quad: A non-uniform quadrilateral mesh generator using a minimum-cost perfect-matching algorithm*, IJNME 89 (2012), per la ricombinazione quadrangolare.
- P. Knupp, *Algebraic Mesh Quality Metrics*, SIAM Journal on Scientific Computing 23 (2001), e P. Pebay, *Planar Quadrangle Quality Measures*, Engineering with Computers 20 (2004).
- CUBIT 15.2, [Metrics for Quadrilateral Elements](https://www.sandia.gov/files/cubit/15.2/help_manual/WebHelp/mesh_generation/mesh_quality_assessment/quadrilateral_metrics.htm), con riferimenti a P. Knupp, *Algebraic Mesh Quality Metrics*.
- CUBIT 15.2, [Metrics for Triangular Elements](https://www.sandia.gov/files/cubit/15.2/help_manual/WebHelp/mesh_generation/mesh_quality_assessment/triangular_metrics.htm).
- COMSOL 6.3, [Mesh Element Quality](https://doc.comsol.com/6.3/doc/com.comsol.help.comsol/comsol_ref_mesh.24.24.html), per l'interpretazione normalizzata `0` degenerato - `1` ideale.

## Modalita generale

- Gestisce poligoni piani da 3 a N spigoli, anche non convessi se il contorno e semplice.
- Incorpora i nodi interni selezionati come vincoli geometrici.
- Uno spigolo con almeno un nodo interno selezionato e vincolato: usa esclusivamente i nodi presenti e non introduce nuovi nodi su quello spigolo.
- Uno spigolo senza nodi interni selezionati e libero: puo essere suddiviso per rendere uniforme la mesh e rispettare il lato massimo.
- Ricombina la mesh in quadrilateri e accoppia ulteriori triangoli soltanto quando il quadrilatero risultante soddisfa aspect ratio <= 3 e skew <= 45 gradi; conserva gli altri triangoli residui invece di forzare accoppiamenti scadenti.
- Non richiede simmetria o spaziatura uniforme.

Una mesh solo quadrangolare non e sempre topologicamente possibile mantenendo invariato il contorno. In particolare, un numero dispari di intervalli complessivi sul perimetro richiede almeno un triangolo oppure l'aggiunta di un nodo di bordo.

## Transizione rettangolare automatica

Quando la selezione contiene un rettangolo, nessun vincolo interno e nodi su due soli bordi opposti, il plugin non usa il mesher poligonale generale. Attiva automaticamente il mesher strutturato di transizione, con:

- discretizzazioni dei due bordi mantenute esattamente, anche se non uniformi;
- crescita dimensionale regolare verso l'interno;
- soli quadrilateri;
- controllo automatico di lato massimo, aspect ratio <= 3, skew <= 45 gradi e Jacobiano scalato >= 0.5.

Se il numero totale di intervalli sui due bordi vincolati e dispari, i due bordi liberi ricevono discretizzazioni differenti di un intervallo per rendere possibile una topologia full-quad. Il plugin tenta prima i limiti ordinari; soltanto se nessun candidato li soddisfa ammette uno skew massimo di `60 gradi`, mantenendo aspect ratio <= 3 e Jacobiano scalato >= 0.5. Il report qualita evidenzia comunque il superamento dell'intervallo CUBIT/Verdict.

Quando la spaziatura definita dai nodi vincolati supera gia la dimensione richiesta e rende impossibili anche i limiti precedenti, viene tentato un ultimo fallback controllato: aspect ratio <= 5, skew <= 70 gradi e Jacobiano scalato >= 0.3. La mesh viene accettata soltanto se resta full-quad, non invertita, congruente e copre interamente l'area; la finestra `Dettagli mesh` evidenzia le metriche fuori dall'intervallo raccomandato.

Se anche tali soglie non sono raggiungibili, il plugin amplia automaticamente la ricerca delle suddivisioni sui lati liberi e seleziona il miglior candidato geometricamente valido. In questo livello finale le metriche qualitative non sono vincoli bloccanti: restano inderogabili il contorno imposto, la topologia full-quad, il Jacobiano orientato positivo, l'assenza di elementi invertiti e la copertura completa. I valori fuori riferimento vengono mostrati come avvisi nel report, lasciando all'utente la decisione finale tramite `Chiudi` oppure `Annulla mesh`.

La checkbox di simmetria non serve ad attivare questo percorso: se selezionata impone anche la specchiatura geometrica e topologica esatta.

Se un intervallo appartenente a uno spigolo vincolato supera il lato massimo richiesto, prevale la congruenza: il plugin conserva il bordo, completa la mesh e segnala il superamento nel riepilogo.

## Modalita simmetrica

Il plugin rileva gli assi di riflessione compatibili con il contorno e con tutti i point object vincolanti selezionati. Attivando `Enforce exact symmetry` e possibile scegliere l'asse da un menu quando la forma ne possiede piu di uno. Il dominio viene tagliato sull'asse, viene meshata una sola meta e la connettivita viene riflessa esattamente; il percorso supporta poligoni semplici piani, anche non rettangolari e concavi, purche la semisezione sia connessa.

La modalita opera su una sola area e puo includere fori circolari disposti in coppie speculari oppure con il centro esattamente sull'asse. Gli O-grid vengono costruiti nella semipiastra e riflessi insieme a corde e connettivita; per i fori sull'asse viene generato un mezzo O-grid che, dopo la riflessione, forma il contorno circolare completo senza aggiungere nodi agli spigoli vincolati. Non e ancora supportata la combinazione, nello stesso tentativo, di fori sull'asse e coppie fuori asse. Anche i frame selezionati e gli spigoli incidenti di altre shell restano esclusi. Se il contorno o i nodi vincolanti non sono speculari, la checkbox rimane disabilitata.

## Dati conservati

Il plugin trasferisce proprieta shell, angolo degli assi locali ordinari, massa per area, edge constraint e tutti i carichi assegnati direttamente all'area. Sono conservati carichi di gravita, pressione interstiziale, rotazione, deformazione imposta, pressione superficiale, temperatura, carichi uniformi, carichi uniformi trasferiti ai frame e pressioni del vento. Ogni intensita viene riapplicata a tutti i nuovi elementi, mantenendo pattern, direzione, sistema di riferimento e gli altri parametri dell'assegnazione. Il modello non viene salvato automaticamente.

## Limiti

- Molle, thickness overwrite, modificatori e assi locali avanzati assegnati direttamente all'area non vengono trasferiti.
- I frame vincolanti devono essere complanari, interamente contenuti nell'area e non devono incrociarsi se l'intersezione non coincide con un estremo comune.
- I fori circolari O-grid non possono ancora essere combinati con frame selezionati o spigoli incidenti di altre shell; in questi casi il plugin interrompe l'operazione prima di modificare il modello.
- La simmetria esatta generale richiede una sola area, una semisezione connessa e un asse rilevabile dal contorno. I fori devono formare coppie speculari oppure essere tutti centrati sull'asse; le due configurazioni non possono ancora essere combinate nello stesso tentativo. I vincoli lineari non sono ancora ammessi.
- I nodi selezionati devono giacere sul piano e all'interno o sul bordo dell'area.
- Le aree complanari sono armonizzate sui bordi coincidenti o parzialmente sovrapposti; una sovrapposizione bidimensionale tra superfici complanari non viene suddivisa automaticamente.
- La qualita vicino a vertici molto acuti e limitata dalla geometria del poligono.
