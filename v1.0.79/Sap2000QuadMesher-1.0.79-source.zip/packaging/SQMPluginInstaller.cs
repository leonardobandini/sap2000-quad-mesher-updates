// Copyright (C) 2026 Leonardo Bandini
// SPDX-License-Identifier: GPL-2.0-or-later
using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Threading;
using Microsoft.Win32;

internal static class SQMPluginInstaller
{
    private const string Guid = "{D64E6254-E9B2-46C8-8C0E-C8A5C78D94AA}";
    private const string ProgId = "SapQuadTransitionPlugin.cPlugin";
    private const string ClassKey = @"Software\Classes\CLSID\" + Guid;
    private const string ProgIdKey = @"Software\Classes\" + ProgId;
    private const string DllName = "SapQuadTransitionPlugin.dll";

    private static int Main(string[] args)
    {
        try
        {
            if (args.Length < 1 || args.Length > 2 ||
                (args[0] != "install" && args[0] != "uninstall" && args[0] != "verify" && args[0] != "test-install") ||
                (args[0] == "test-install" && args.Length != 2))
                throw new ArgumentException("Usage: SQMPluginInstaller.exe install|uninstall|verify [package directory], or test-install TEST_ROOT");

            string source = Path.GetFullPath(args[0] == "test-install" ? AppDomain.CurrentDomain.BaseDirectory :
                args.Length == 2 ? args[1] : AppDomain.CurrentDomain.BaseDirectory);
            string root = args[0] == "test-install" ? Path.GetFullPath(args[1]) :
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "SAP2000QuadMesher");
            if (args[0] == "test-install" && (!root.StartsWith(Path.GetTempPath(), StringComparison.OrdinalIgnoreCase) ||
                string.Equals(root.TrimEnd('\\'), Path.GetTempPath().TrimEnd('\\'), StringComparison.OrdinalIgnoreCase)))
                throw new ArgumentException("The test installation must use a child directory of the temporary folder.");
            if (args[0] == "verify") { VerifyPackage(source); return 0; }
            if (args[0] == "test-install") { Install(source, root, false); return 0; }
            if (Process.GetProcessesByName("SAP2000").Length != 0)
                throw new InvalidOperationException("Close SAP2000 before installing or uninstalling the plugin. Save your model first if needed.");
            if (args[0] == "install") Install(source, root, true);
            else Uninstall(root);
            return 0;
        }
        catch (Exception error)
        {
            Console.Error.WriteLine("SQM Plugin: " + error);
            return 1;
        }
    }

    private static void VerifyPackage(string source)
    {
        foreach (string file in new[] { DllName, "install_plugin.cmd", "uninstall_plugin.cmd", "README.md" })
            if (!File.Exists(Path.Combine(source, file))) throw new FileNotFoundException("Package file missing: " + file);
        string backend = Path.Combine(source, "mesher", "SapQuadMesherBackend.exe");
        if (!File.Exists(backend)) throw new FileNotFoundException("Backend missing: " + backend);
        string version = FileVersionInfo.GetVersionInfo(Path.Combine(source, DllName)).FileVersion;
        if (string.IsNullOrEmpty(version)) throw new InvalidDataException("The plugin has no file version.");
        using (var process = Process.Start(new ProcessStartInfo(backend, "--self-test")
        {
            UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true,
            RedirectStandardError = true
        }))
        {
            if (!process.WaitForExit(60000)) { process.Kill(); throw new TimeoutException("Backend self-test timed out."); }
            if (process.ExitCode != 0) throw new InvalidOperationException("Backend self-test failed: " + process.StandardError.ReadToEnd());
        }
        Console.WriteLine("Verified SQM Plugin " + version + " in " + source);
    }

    private static void CopyDirectory(string source, string destination)
    {
        Directory.CreateDirectory(destination);
        foreach (string file in Directory.GetFiles(source))
            File.Copy(file, Path.Combine(destination, Path.GetFileName(file)));
        foreach (string directory in Directory.GetDirectories(source))
            CopyDirectory(directory, Path.Combine(destination, Path.GetFileName(directory)));
    }

    private static void MoveDirectory(string source, string destination)
    {
        for (int attempt = 0; ; attempt++)
        {
            try { Directory.Move(source, destination); return; }
            catch (Exception error) when ((error is IOException || error is UnauthorizedAccessException) && attempt < 11)
            { Thread.Sleep(250); }
        }
    }

    private static void Install(string source, string root, bool register)
    {
        if (string.Equals(source.TrimEnd('\\'), root.TrimEnd('\\'), StringComparison.OrdinalIgnoreCase))
        {
            VerifyPackage(root);
            if (register) Register(Path.Combine(root, DllName));
            return;
        }
        VerifyPackage(source);
        string parent = Path.GetDirectoryName(root);
        Directory.CreateDirectory(parent);
        string staging = Path.Combine(parent, "SAP2000QuadMesher.new-" + System.Guid.NewGuid().ToString("N"));
        string backup = Path.Combine(parent, "SAP2000QuadMesher.previous-" + System.Guid.NewGuid().ToString("N"));
        string oldCodeBase = register ? RegisteredCodeBase() : null;
        bool movedOld = false, movedNew = false;
        try
        {
            CopyDirectory(source, staging);
            VerifyPackage(staging);
            if (Directory.Exists(root)) { MoveDirectory(root, backup); movedOld = true; }
            MoveDirectory(staging, root);
            movedNew = true;
            if (register) Register(Path.Combine(root, DllName));
        }
        catch
        {
            if (movedNew) Directory.Delete(root, true);
            if (movedOld) MoveDirectory(backup, root);
            if (register)
            {
                Unregister();
                if (!string.IsNullOrEmpty(oldCodeBase))
                {
                    Uri oldUri;
                    if (Uri.TryCreate(oldCodeBase, UriKind.Absolute, out oldUri) && oldUri.IsFile && File.Exists(oldUri.LocalPath))
                        Register(oldUri.LocalPath);
                }
            }
            throw;
        }
        finally { if (Directory.Exists(staging)) Directory.Delete(staging, true); }

        if (movedOld)
        {
            try { Directory.Delete(backup, true); }
            catch (IOException) { Console.WriteLine("Previous installation backup remains in " + backup); }
        }
        if (register)
        {
            string legacy = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Programs", "SQM_Plugin");
            if (Directory.Exists(legacy) && string.Equals(oldCodeBase,
                new Uri(Path.Combine(legacy, DllName)).AbsoluteUri, StringComparison.OrdinalIgnoreCase))
            {
                try { Directory.Delete(legacy, true); }
                catch (Exception error) when (error is IOException || error is UnauthorizedAccessException)
                { Console.WriteLine("Previous installation remains in " + legacy); }
            }
        }
        Console.WriteLine("SQM Plugin installed in " + root);
        Console.WriteLine("Restart SAP2000 to use the new version.");
    }

    private static string RegisteredCodeBase()
    {
        using (RegistryKey key = Registry.CurrentUser.OpenSubKey(ClassKey + @"\InprocServer32"))
            return key == null ? null : key.GetValue("CodeBase") as string;
    }

    private static void Register(string dll)
    {
        AssemblyName assembly = AssemblyName.GetAssemblyName(dll);
        string codeBase = new Uri(dll).AbsoluteUri;
        using (RegistryKey progId = Registry.CurrentUser.CreateSubKey(ProgIdKey))
            progId.SetValue(null, ProgId);
        using (RegistryKey progIdClass = Registry.CurrentUser.CreateSubKey(ProgIdKey + @"\CLSID"))
            progIdClass.SetValue(null, Guid);
        using (RegistryKey clsid = Registry.CurrentUser.CreateSubKey(ClassKey))
            clsid.SetValue(null, ProgId);
        using (RegistryKey inproc = Registry.CurrentUser.CreateSubKey(ClassKey + @"\InprocServer32"))
        {
            inproc.SetValue(null, "mscoree.dll");
            inproc.SetValue("ThreadingModel", "Both");
            SetAssemblyValues(inproc, assembly.FullName, codeBase);
        }
        using (RegistryKey version = Registry.CurrentUser.CreateSubKey(ClassKey + @"\InprocServer32\" + assembly.Version))
            SetAssemblyValues(version, assembly.FullName, codeBase);
        using (RegistryKey progId = Registry.CurrentUser.CreateSubKey(ClassKey + @"\ProgId"))
            progId.SetValue(null, ProgId);
        using (Registry.CurrentUser.CreateSubKey(ClassKey + @"\Implemented Categories\{62C8FE65-4EBB-45e7-b440-6e39b2cdbf29}")) { }
    }

    private static void SetAssemblyValues(RegistryKey key, string assembly, string codeBase)
    {
        key.SetValue("Class", ProgId);
        key.SetValue("Assembly", assembly);
        key.SetValue("RuntimeVersion", "v4.0.30319");
        key.SetValue("CodeBase", codeBase);
    }

    private static void Unregister()
    {
        Registry.CurrentUser.DeleteSubKeyTree(ClassKey, false);
        Registry.CurrentUser.DeleteSubKeyTree(ProgIdKey, false);
    }

    private static void Uninstall(string root)
    {
        string installedCodeBase = new Uri(Path.Combine(root, DllName)).AbsoluteUri;
        string activeCodeBase = RegisteredCodeBase();
        if (!string.IsNullOrEmpty(activeCodeBase) &&
            !string.Equals(activeCodeBase, installedCodeBase, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("A different plugin installation is registered; nothing was removed.");
        if (string.Equals(Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory).TrimEnd('\\'),
            Path.GetFullPath(root).TrimEnd('\\'), StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Run the uninstaller from the extracted ZIP, outside the installation folder.");
        if (Directory.Exists(root)) Directory.Delete(root, true);
        if (!string.IsNullOrEmpty(activeCodeBase)) Unregister();
        Console.WriteLine("SQM Plugin removed for the current user.");
    }
}
