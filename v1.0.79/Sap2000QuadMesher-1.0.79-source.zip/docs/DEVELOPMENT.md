# Sviluppo

Questo documento conserva le prove tecniche delle **build di sviluppo fino alla 1.0.78**. La 1.0.79 e la prima beta per utenti: lo scopo prevalente e illustrare come integrare SAP2000 con strumenti esterni, non promettere prestazioni ingegneristiche certificate. Miglioramenti futuri potranno seguire richieste degli utenti e idee dell'autore.

## Prerequisiti

- Windows x64.
- SAP2000 27 x64 installato e licenziato.
- .NET SDK capace di compilare `net48`.
- .NET Framework 4.8.
- Python 3.12 disponibile come `python` nel `PATH` per costruire il backend distribuibile.
- Dipendenze di build in `packaging/requirements-build.txt`.

Installazione delle dipendenze di build:

```cmd
python -m pip install -r packaging\requirements-build.txt
```

## Build del plugin

Dal root del workspace:

```cmd
dotnet build SapQuadTransitionPlugin\SapQuadTransitionPlugin.csproj -c Release
```

Build completa di plugin e utility:

```cmd
dotnet build Sap2000QuadMesher.sln -c Release
```

Output attuale:

```text
SapQuadTransitionPlugin\bin\Release\net48
```

Il percorso predefinito dell'API e:

```text
C:\Program Files\Computers and Structures\SAP2000 27\SAP2000v1.dll
```

Il percorso e configurabile con le proprieta MSBuild `Sap2000InstallDir` o `Sap2000ApiPath`, descritte in `CONTRIBUTING.md`. `SAP2000v1.dll` e proprietaria e non deve essere aggiunta al repository o al pacchetto senza autorizzazione esplicita di CSI.

## Pacchetto autonomo

Generazione del pacchetto con Python e Gmsh incorporati:

```cmd
powershell -NoProfile -File packaging\build-release.ps1
```

Lo script compila il plugin e il backend PyInstaller, verifica i tre mesher e l'origine della DLL e del binding Gmsh, include le licenze GPLv2/GPLv3 e produce in `artifacts` lo ZIP binario, il corrispondente ZIP sorgente, l'archivio sorgente originale Gmsh e i checksum. Lo ZIP sorgente include `packaging/SOURCE_BUILD.md` con le istruzioni di ricostruzione; i sorgenti CSI rimangono esclusi.

## Installazione locale

Dalla cartella estratta del pacchetto:

```cmd
install_plugin.cmd
```

Poi aggiungere `SapQuadTransitionPlugin` da `Tools > Add/Show Plugins` in SAP2000.

Disinstallazione:

```cmd
uninstall_plugin.cmd
```

L'installer copia il plugin in `%LOCALAPPDATA%\Programs\SAP2000QuadMesher` e crea una registrazione COM per-utente. Sostituisce la precedente installazione dopo la verifica del runtime. Non richiede UAC, non installa Python globalmente e non modifica `PATH`.

## Verifiche rapide

```cmd
dotnet build SapQuadTransitionPlugin\SapQuadTransitionPlugin.csproj -c Release
packaging\dist\SapQuadMesherBackend\SapQuadMesherBackend.exe --self-test
```

Questi comandi verificano compilazione e runtime autonomo, ma non il comportamento dentro SAP2000.

## Strategia di test attuale

I test di integrazione devono operare su copie dei modelli. Alcune utility avviano SAP2000, modificano il modello e richiedono un desktop interattivo.

Categorie correnti:

- test delle tabelle FAST: `test_sap_bulk*.cs`, `test_sap_table_roundtrip.cs`;
- automazione UI/plugin: `run_test01_fast.cs`;
- verifica geometrica C#: `verify_transition_mesh.cs`;
- verifica export Python: `verify_testqm01.py`, `verify_mesh_report.py`;
- generatori e prototipi nella root del workspace.

Problemi noti della suite:

- nessun framework xUnit/NUnit/MSTest/pytest;
- percorsi assoluti locali in molti script;
- riferimenti ad assembly di release storiche;
- dipendenza da nomi di oggetti e testo UI;
- alcuni test storici sopravvivono solo come binari in `bin`/`obj` e non sono ricostruibili.

## Regole per le fixture

- Conservare sempre un originale immutato.
- Eseguire i test su una copia nominata in modo riconoscibile.
- Separare input minimi da output attesi e risultati generati.
- Preferire fixture sintetiche prive di dati di progetto reali.
- Non pubblicare file `.sdb`, `.sbk` o `.$2k` senza conferma dei diritti e controllo dei contenuti.
- Non versionare `.ico` companion, build, cache e file temporanei se rigenerabili.

## Roadmap tecnica consigliata

Prima fase, riproducibilita:

1. Creare una solution e una struttura `src`, `tests`, `test-data`, `docs`, `tools`.
2. Configurare il percorso SAP2000 tramite proprieta MSBuild o variabile ambiente.
3. Mantenere aggiornati e verificati gli hash delle dipendenze del runtime.
4. Rendere relativi o configurabili tutti i percorsi delle utility mantenute.
5. Definire test smoke ripetibili e una checklist manuale SAP2000.

Seconda fase, affidabilita:

1. Estrarre geometria e metriche da `Plugin.cs` in una libreria senza COM.
2. Aggiungere unit test per proiezioni, appartenenza, qualita e congruenza.
3. Rendere robusto lo scambio dati con UTF-8 e quoting CSV o un formato strutturato.
4. Aggiungere timeout, log e cancellazione al processo Python.
5. Controllare tutti i codici di ritorno SAP2000 e verificare il rollback.

Terza fase, distribuzione:

1. Automatizzare pacchetto versionato e checksum.
2. Testare installazione e disinstallazione su ambiente pulito.
3. Aggiungere CI per le parti che non richiedono SAP2000.
4. Pubblicare release GitHub con sorgenti, documentazione e soli binari redistribuibili.
