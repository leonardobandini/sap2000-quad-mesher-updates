import csv
import math
import sys

# Copyright (C) 2026 Leonardo Bandini
# SPDX-License-Identifier: GPL-2.0-or-later
import gmsh


def read_input(path):
    corners = {}
    edges = {}
    interior = []
    frames = []
    holes = []
    symmetry = None
    symmetry2 = None
    force_refinement = False
    stress_refinement = False
    prefer_regular = False
    regular_points = []
    with open(path, newline="", encoding="ascii") as stream:
        for row in csv.reader(stream):
            xyz = tuple(float(value) for value in row[4:7]) if row[0] in ("CORNER", "EDGE", "INTERIOR", "FRAME", "HOLE", "REGULAR_POINT") else None
            if row[0] == "CORNER":
                corners[int(row[1])] = xyz
            elif row[0] == "EDGE":
                edges.setdefault(int(row[1]), []).append((float(row[3]), xyz))
            elif row[0] == "INTERIOR":
                interior.append(xyz)
            elif row[0] == "FRAME":
                frames.append((xyz, tuple(float(value) for value in row[7:10]),
                               len(row) > 10 and row[10] == "1", len(row) > 11 and row[11] == "1"))
            elif row[0] == "HOLE":
                holes.append((xyz, float(row[3])))
            elif row[0] == "SYMMETRY":
                symmetry = (tuple(float(value) for value in row[1:4]),
                            tuple(float(value) for value in row[4:7]))
            elif row[0] == "SYMMETRY2":
                symmetry2 = (tuple(float(value) for value in row[1:4]),
                             tuple(float(value) for value in row[4:7]))
            elif row[0] == "REFINE":
                force_refinement = row[1] == "1"
            elif row[0] == "STRESS_REFINE":
                stress_refinement = row[1] == "1"
            elif row[0] == "PREFER_REGULAR":
                prefer_regular = row[1] == "1"
            elif row[0] == "REGULAR_POINT":
                regular_points.append(xyz)
    if len(corners) < 3 or len(edges) != len(corners):
        raise RuntimeError("Incomplete polygon definition")
    for points in edges.values():
        points.sort()
    return (corners, edges, interior, frames, holes, symmetry, symmetry2, force_refinement,
            stress_refinement, prefer_regular, regular_points)


def quad_quality(quad, nodes):
    points = [nodes[tag] for tag in quad]
    lengths = [math.dist(points[i], points[(i + 1) % 4]) for i in range(4)]
    angles = []
    for i in range(4):
        previous, current, following = points[(i - 1) % 4], points[i], points[(i + 1) % 4]
        a = tuple(previous[j] - current[j] for j in range(3))
        b = tuple(following[j] - current[j] for j in range(3))
        cosine = sum(a[j] * b[j] for j in range(3)) / (math.dist(previous, current) * math.dist(following, current))
        angles.append(math.degrees(math.acos(max(-1, min(1, cosine)))))
    aspect = max(lengths) / min(lengths)
    skew = max(abs(angle - 90) for angle in angles)
    return aspect, skew


def pair_compatible_triangles(nodes, triangles):
    edge_owners = {}
    for index, triangle in enumerate(triangles):
        for i in range(3):
            edge = tuple(sorted((triangle[i], triangle[(i + 1) % 3])))
            edge_owners.setdefault(edge, []).append(index)
    candidates = []
    for owners in edge_owners.values():
        if len(owners) != 2:
            continue
        first, second = owners
        vertices = set(triangles[first]) | set(triangles[second])
        if len(vertices) != 4:
            continue
        center = tuple(sum(nodes[tag][axis] for tag in vertices) / 4 for axis in range(3))
        normal = polygon_normal([nodes[tag] for tag in triangles[first]])
        basis_u = normalize(tuple(nodes[next(iter(vertices))][axis] - center[axis] for axis in range(3)))
        basis_v = normalize(cross(normal, basis_u))
        quad = tuple(sorted(vertices, key=lambda tag: math.atan2(dot(subtract(nodes[tag], center), basis_v), dot(subtract(nodes[tag], center), basis_u))))
        aspect, skew = quad_quality(quad, nodes)
        if aspect <= 3 and skew <= 45:
            candidates.append((skew + aspect, first, second, quad))
    used = set()
    quads = []
    for _, first, second, quad in sorted(candidates):
        if first in used or second in used:
            continue
        used.update((first, second))
        quads.append(quad)
    remaining = [triangle for index, triangle in enumerate(triangles) if index not in used]
    return quads, remaining


def pair_all_triangles(nodes, triangles):
    edge_owners = {}
    for index, triangle in enumerate(triangles):
        for offset in range(3):
            edge = tuple(sorted((triangle[offset], triangle[(offset + 1) % 3])))
            edge_owners.setdefault(edge, []).append(index)
    candidates = {index: [] for index in range(len(triangles))}
    pair_quads = {}
    for owners in edge_owners.values():
        if len(owners) != 2:
            continue
        first, second = owners
        vertices = set(triangles[first]) | set(triangles[second])
        if len(vertices) != 4:
            continue
        center = tuple(sum(nodes[tag][axis] for tag in vertices) / 4 for axis in range(3))
        normal = polygon_normal([nodes[tag] for tag in triangles[first]])
        basis_u = normalize(subtract(nodes[next(iter(vertices))], center))
        basis_v = normalize(cross(normal, basis_u))
        quad = tuple(sorted(vertices, key=lambda tag: math.atan2(dot(subtract(nodes[tag], center), basis_v),
                                                                 dot(subtract(nodes[tag], center), basis_u))))
        turns = []
        for offset in range(4):
            first_point = nodes[quad[offset]]
            second_point = nodes[quad[(offset + 1) % 4]]
            third_point = nodes[quad[(offset + 2) % 4]]
            turns.append(dot(cross(subtract(second_point, first_point), subtract(third_point, second_point)), normal))
        if min(turns) <= 1e-12:
            continue
        score = sum(quad_quality(quad, nodes))
        candidates[first].append((score, second))
        candidates[second].append((score, first))
        pair_quads[tuple(sorted((first, second)))] = quad

    def solve(remaining, pairs):
        if not remaining:
            return pairs
        current = min(remaining, key=lambda item: sum(other in remaining for _, other in candidates[item]))
        for _, other in sorted(candidates[current]):
            if other in remaining:
                result = solve(remaining - {current, other}, pairs + [(current, other)])
                if result is not None:
                    return result
        return None

    pairs = solve(set(range(len(triangles))), [])
    if pairs is None:
        return [], triangles
    return [pair_quads[tuple(sorted(pair))] for pair in pairs], []


def improve_interior_nodes(nodes, quads, triangles, fixed):
    elements = list(quads) + list(triangles)
    incident = {tag: [] for tag in nodes}
    neighbors = {tag: set() for tag in nodes}
    for element_index, element in enumerate(elements):
        for i, tag in enumerate(element):
            incident[tag].append(element_index)
            neighbors[tag].update((element[(i - 1) % len(element)], element[(i + 1) % len(element)]))

    def score(element):
        points = [nodes[tag] for tag in element]
        lengths = [math.dist(points[i], points[(i + 1) % len(points)]) for i in range(len(points))]
        aspect = max(lengths) / min(lengths)
        angles = []
        for i in range(len(points)):
            a = subtract(points[(i - 1) % len(points)], points[i])
            b = subtract(points[(i + 1) % len(points)], points[i])
            angles.append(math.degrees(math.acos(max(-1, min(1, dot(a, b) / (norm(a) * norm(b)))))))
        if len(element) == 4:
            distortion = max(abs(angle - 90) for angle in angles)
            return distortion + 100 * max(0, aspect - 3)
        return max(0, 30 - min(angles), max(angles) - 120) + 100 * max(0, aspect - 3)

    movable = [tag for tag in nodes if tag not in fixed]
    for _ in range(60):
        changed = False
        for tag in movable:
            old = nodes[tag]
            local = [elements[index] for index in incident[tag]]
            old_score = max(score(element) for element in local)
            average = tuple(sum(nodes[other][axis] for other in neighbors[tag]) / len(neighbors[tag]) for axis in range(3))
            best, best_score = old, old_score
            for alpha in (0.1, 0.25, 0.5):
                candidate = tuple((1 - alpha) * old[axis] + alpha * average[axis] for axis in range(3))
                nodes[tag] = candidate
                candidate_score = max(score(element) for element in local)
                if candidate_score < best_score - 1e-8:
                    best, best_score = candidate, candidate_score
            nodes[tag] = best
            changed |= best != old
        if not changed:
            break


def set_graded_refinement(curves, max_size, far_size):
    if not curves:
        return
    distance = gmsh.model.mesh.field.add("Distance")
    gmsh.model.mesh.field.setNumbers(distance, "CurvesList", curves)
    gmsh.model.mesh.field.setNumber(distance, "Sampling", max(50, 20 * len(curves)))
    threshold = gmsh.model.mesh.field.add("Threshold")
    gmsh.model.mesh.field.setNumber(threshold, "InField", distance)
    gmsh.model.mesh.field.setNumber(threshold, "SizeMin", max_size * 0.55)
    gmsh.model.mesh.field.setNumber(threshold, "SizeMax", far_size)
    gmsh.model.mesh.field.setNumber(threshold, "DistMin", max_size * 0.5)
    gmsh.model.mesh.field.setNumber(threshold, "DistMax", max_size * 3.0)
    gmsh.model.mesh.field.setNumber(threshold, "StopAtDistMax", 1)
    gmsh.model.mesh.field.setAsBackgroundMesh(threshold)
    gmsh.option.setNumber("Mesh.MeshSizeExtendFromBoundary", 0)
    gmsh.option.setNumber("Mesh.MeshSizeFromPoints", 0)
    gmsh.option.setNumber("Mesh.MeshSizeFromCurvature", 0)


def generate(corners, edges, interior, max_size, target_factor, full_quad_mode=False, force_refinement=False):
    gmsh.initialize()
    try:
        gmsh.option.setNumber("General.Terminal", 0)
        gmsh.model.add("sap_general_polygon")
        point_tags = {}

        def point_tag(xyz):
            key = tuple(round(value, 12) for value in xyz)
            if key not in point_tags:
                point_tags[key] = gmsh.model.geo.addPoint(*xyz, max_size * 0.5)
            return point_tags[key]

        full_quad = full_quad_mode and all(len(edge) == 2 for edge in edges.values())
        target_size = max_size * target_factor
        mesh_size = max_size * (0.45 if full_quad else target_factor)
        curves = []
        refinement_curves = []
        for edge_index in range(1, len(corners) + 1):
            points = [xyz for _, xyz in edges[edge_index]]
            constrained_edge = len(points) > 2
            for first, second in zip(points[:-1], points[1:]):
                curve = gmsh.model.geo.addLine(point_tag(first), point_tag(second))
                divisions = 1 if constrained_edge else max(1, math.ceil(math.dist(first, second) / target_size - 1e-9))
                if full_quad and divisions % 2:
                    divisions += 1
                curves.append((curve, divisions))
                if constrained_edge:
                    refinement_curves.append(curve)
        surface = gmsh.model.geo.addPlaneSurface([gmsh.model.geo.addCurveLoop([curve for curve, _ in curves])])
        interior_tags = [point_tag(point) for point in interior]
        gmsh.model.geo.synchronize()
        for curve, divisions in curves:
            gmsh.model.mesh.setTransfiniteCurve(curve, divisions + 1)
        if interior_tags:
            gmsh.model.mesh.embed(0, interior_tags, 2, surface)
        if force_refinement:
            set_graded_refinement(refinement_curves, max_size, mesh_size)
        gmsh.model.mesh.setRecombine(2, surface)
        gmsh.option.setNumber("Mesh.MeshSizeMin", mesh_size * 0.4)
        gmsh.option.setNumber("Mesh.MeshSizeMax", mesh_size)
        gmsh.option.setNumber("Mesh.Algorithm", 8)
        gmsh.option.setNumber("Mesh.RecombinationAlgorithm", 2 if full_quad else 1)
        gmsh.option.setNumber("Mesh.RecombineAll", 1)
        gmsh.option.setNumber("Mesh.Smoothing", 50)
        gmsh.model.mesh.generate(2)
        gmsh.model.mesh.optimize("Relocate2D", force=True, niter=50)
        if force_refinement:
            gmsh.option.setNumber("Mesh.SubdivisionAlgorithm", 1)
            gmsh.model.mesh.refine()
            gmsh.model.mesh.optimize("Relocate2D", force=True, niter=50)

        tags, coordinates, _ = gmsh.model.mesh.getNodes()
        nodes = {int(tag): tuple(float(coordinates[i + axis]) for axis in range(3)) for tag, i in zip(tags, range(0, len(coordinates), 3))}
        fixed = set()
        for curve, _ in curves:
            curve_nodes, _, _ = gmsh.model.mesh.getNodes(1, curve, includeBoundary=True)
            fixed.update(int(tag) for tag in curve_nodes)
        for point in interior_tags:
            point_nodes, _, _ = gmsh.model.mesh.getNodes(0, point, includeBoundary=True)
            fixed.update(int(tag) for tag in point_nodes)
        triangles, quads = [], []
        types, _, connectivity = gmsh.model.mesh.getElements(2)
        for element_type, values in zip(types, connectivity):
            if element_type == 2:
                triangles.extend(tuple(int(value) for value in values[i:i + 3]) for i in range(0, len(values), 3))
            elif element_type == 3:
                quads.extend(tuple(int(value) for value in values[i:i + 4]) for i in range(0, len(values), 4))
        paired, triangles = pair_compatible_triangles(nodes, triangles)
        quads.extend(paired)
        improve_interior_nodes(nodes, quads, triangles, fixed)
        return nodes, quads, triangles
    finally:
        gmsh.finalize()


def generate_with_frames(corners, edges, interior, frames, max_size, base_factor, stress_refinement=False,
                         algorithm=8):
    gmsh.initialize()
    try:
        gmsh.option.setNumber("General.Terminal", 0)
        gmsh.model.add("sap_frame_constrained_polygon")
        point_tags = {}

        def point_tag(xyz):
            key = tuple(round(value, 12) for value in xyz)
            if key not in point_tags:
                point_tags[key] = gmsh.model.geo.addPoint(*xyz, max_size * base_factor)
            return point_tags[key]

        boundary_curves = []
        for edge_index in range(1, len(corners) + 1):
            points = [xyz for _, xyz in edges[edge_index]]
            constrained_edge = len(points) > 2
            for first, second in zip(points[:-1], points[1:]):
                curve = gmsh.model.geo.addLine(point_tag(first), point_tag(second))
                divisions = 1 if constrained_edge else max(1, math.ceil(math.dist(first, second) / (max_size * base_factor) - 1e-9))
                boundary_curves.append((curve, divisions))
        frame_curves = []
        for first, second, fixed_division, can_bound_opening in frames:
            curve = gmsh.model.geo.addLine(point_tag(first), point_tag(second))
            divisions = 1 if fixed_division else max(1, math.ceil(math.dist(first, second) / (max_size * base_factor) - 1e-9))
            frame_curves.append((curve, divisions, fixed_division, can_bound_opening))
        interior_tags = [point_tag(point) for point in interior]

        surface = gmsh.model.geo.addPlaneSurface([gmsh.model.geo.addCurveLoop([curve for curve, _ in boundary_curves])])
        gmsh.model.geo.synchronize()
        for curve, divisions in boundary_curves:
            gmsh.model.mesh.setTransfiniteCurve(curve, divisions + 1)
        for curve, divisions, _, _ in frame_curves:
            gmsh.model.mesh.setTransfiniteCurve(curve, divisions + 1)
        gmsh.model.mesh.embed(1, [curve for curve, _, _, _ in frame_curves], 2, surface)
        if interior_tags:
            gmsh.model.mesh.embed(0, interior_tags, 2, surface)
        set_graded_refinement([curve for curve, _, automatic, _ in frame_curves if automatic or stress_refinement],
                              max_size, max_size * base_factor)
        gmsh.model.mesh.setRecombine(2, surface)
        gmsh.option.setNumber("Mesh.MeshSizeMin", max_size * base_factor * 0.4)
        gmsh.option.setNumber("Mesh.MeshSizeMax", max_size * base_factor)
        gmsh.option.setNumber("Mesh.Algorithm", algorithm)
        gmsh.option.setNumber("Mesh.RecombinationAlgorithm", 1)
        gmsh.option.setNumber("Mesh.RecombineAll", 1)
        gmsh.option.setNumber("Mesh.Smoothing", 50)
        gmsh.model.mesh.generate(2)
        gmsh.option.setNumber("Mesh.SubdivisionAlgorithm", 1)
        gmsh.model.mesh.refine()
        gmsh.model.mesh.optimize("Relocate2D", force=True, niter=100)

        tags, coordinates, _ = gmsh.model.mesh.getNodes()
        nodes = {int(tag): tuple(float(coordinates[i + axis]) for axis in range(3)) for tag, i in zip(tags, range(0, len(coordinates), 3))}
        quads, other_count = [], 0
        types, _, connectivity = gmsh.model.mesh.getElements(2)
        for element_type, values in zip(types, connectivity):
            _, _, _, count, _, _ = gmsh.model.mesh.getElementProperties(element_type)
            if element_type == 3:
                quads.extend(tuple(int(value) for value in values[i:i + 4]) for i in range(0, len(values), 4))
            else:
                other_count += len(values) // count
        if other_count or not quads:
            raise RuntimeError("Frame-constrained conversion did not produce an all-quadrilateral mesh")

        protected_edges = set()
        constrained_edges = set()
        for curve, _, _, can_bound_opening in frame_curves:
            line_types, _, line_connectivity = gmsh.model.mesh.getElements(1, curve)
            for line_type, values in zip(line_types, line_connectivity):
                _, _, _, count, _, _ = gmsh.model.mesh.getElementProperties(line_type)
                for i in range(0, len(values), count):
                    edge = tuple(sorted((int(values[i]), int(values[i + 1]))))
                    constrained_edges.add(edge)
                    if can_bound_opening:
                        protected_edges.add(edge)
        quad_edges = {
            tuple(sorted((quad[i], quad[(i + 1) % 4])))
            for quad in quads for i in range(4)
        }
        missing_edges = constrained_edges - quad_edges
        if missing_edges:
            raise RuntimeError(f"{len(missing_edges)} frame segments do not coincide with shell edges")
        return nodes, quads, protected_edges
    finally:
        gmsh.finalize()


def point_segment_distance(point, first, second):
    direction = subtract(second, first)
    length_squared = dot(direction, direction)
    parameter = 0 if length_squared == 0 else dot(subtract(point, first), direction) / length_squared
    parameter = max(0, min(1, parameter))
    projection = tuple(first[axis] + parameter * direction[axis] for axis in range(3))
    return math.dist(point, projection)


def point_in_or_on_polygon_2d(point, polygon, tolerance):
    inside = False
    for index, first in enumerate(polygon):
        second = polygon[(index + 1) % len(polygon)]
        direction = (second[0] - first[0], second[1] - first[1])
        length_squared = direction[0] ** 2 + direction[1] ** 2
        parameter = 0 if length_squared == 0 else ((point[0] - first[0]) * direction[0] +
                                                     (point[1] - first[1]) * direction[1]) / length_squared
        parameter = max(0, min(1, parameter))
        projection = (first[0] + parameter * direction[0], first[1] + parameter * direction[1])
        if math.dist(point, projection) <= tolerance:
            return True
        if ((first[1] > point[1]) != (second[1] > point[1]) and
                point[0] < (second[0] - first[0]) * (point[1] - first[1]) / (second[1] - first[1]) + first[0]):
            inside = not inside
    return inside


def validate_connected_half_boundary(cleaned, original, tolerance):
    for first, second in zip(cleaned, cleaned[1:] + cleaned[:1]):
        if abs(first[0]) > tolerance or abs(second[0]) > tolerance:
            continue
        for fraction in (0.25, 0.5, 0.75):
            point = (0.0, first[1] + fraction * (second[1] - first[1]))
            if not point_in_or_on_polygon_2d(point, original, tolerance):
                raise RuntimeError("The symmetry half-domain is disconnected")


def generate_symmetric(corners, edges, interior, frames, symmetry, max_size, base_factor):
    center, axis = symmetry
    axis = normalize(axis)
    normal = polygon_normal([corners[index] for index in sorted(corners)])
    perpendicular = normalize(cross(normal, axis))
    target_size = max_size * base_factor

    def to_local(point):
        offset = subtract(point, center)
        return dot(offset, perpendicular), dot(offset, axis)

    def to_world(point):
        return tuple(center[index] + point[0] * perpendicular[index] + point[1] * axis[index] for index in range(3))

    boundary = []
    for edge_index in range(1, len(corners) + 1):
        points = [to_local(xyz) for _, xyz in edges[edge_index]]
        constrained = len(points) > 2
        for first, second in zip(points[:-1], points[1:]):
            if not boundary or math.dist(boundary[-1], first) > 1e-10:
                boundary.append(first)
            divisions = 1 if constrained else max(1, math.ceil(math.dist(first, second) / target_size - 1e-9))
            for division in range(1, divisions + 1):
                boundary.append(tuple(first[axis_index] + division / divisions * (second[axis_index] - first[axis_index])
                                      for axis_index in range(2)))
    if math.dist(boundary[0], boundary[-1]) <= 1e-10:
        boundary.pop()

    tolerance = max(1e-9, max_size * 1e-7)

    def intersection(first, second):
        parameter = first[0] / (first[0] - second[0])
        return 0.0, first[1] + parameter * (second[1] - first[1])

    clipped = []
    for first, second in zip(boundary, boundary[1:] + boundary[:1]):
        first_inside, second_inside = first[0] >= -tolerance, second[0] >= -tolerance
        if first_inside:
            clipped.append((max(0.0, first[0]) if abs(first[0]) <= tolerance else first[0], first[1]))
        if first_inside != second_inside:
            clipped.append(intersection(first, second))
    cleaned = []
    for point in clipped:
        if not cleaned or math.dist(cleaned[-1], point) > tolerance:
            cleaned.append(point)
    if len(cleaned) > 1 and math.dist(cleaned[0], cleaned[-1]) <= tolerance:
        cleaned.pop()
    if len(cleaned) < 3:
        raise RuntimeError("The selected symmetry axis does not split the polygon into a valid half-domain")
    validate_connected_half_boundary(cleaned, boundary, tolerance)

    refined = []
    for first, second in zip(cleaned, cleaned[1:] + cleaned[:1]):
        refined.append(first)
        if abs(first[0]) <= tolerance and abs(second[0]) <= tolerance:
            divisions = max(1, math.ceil(math.dist(first, second) / target_size - 1e-9))
            for division in range(1, divisions):
                refined.append((0.0, first[1] + division / divisions * (second[1] - first[1])))
    cleaned = refined

    local_frames = []
    axis_frame_points = []
    seen_frames = set()
    for first, second, fixed_division, can_bound_opening in frames:
        first, second = to_local(first), to_local(second)
        if first[0] < -tolerance and second[0] < -tolerance:
            continue
        if (first[0] < -tolerance) != (second[0] < -tolerance):
            crossing = intersection(first, second)
            axis_frame_points.append(crossing)
            if first[0] < -tolerance:
                first = crossing
            else:
                second = crossing
        first = (0.0 if abs(first[0]) <= tolerance else first[0], first[1])
        second = (0.0 if abs(second[0]) <= tolerance else second[0], second[1])
        if math.dist(first, second) <= tolerance:
            continue
        key = tuple(sorted((tuple(round(value, 10) for value in first),
                            tuple(round(value, 10) for value in second))))
        if key not in seen_frames:
            seen_frames.add(key)
            local_frames.append((first, second, fixed_division, can_bound_opening))

    axis_constraints = sorted(
        [to_local(point) for point in interior if abs(to_local(point)[0]) <= tolerance] + axis_frame_points,
        key=lambda point: point[1])
    if axis_constraints:
        expanded = []
        for first, second in zip(cleaned, cleaned[1:] + cleaned[:1]):
            expanded.append(first)
            if abs(first[0]) <= tolerance and abs(second[0]) <= tolerance:
                low, high = sorted((first[1], second[1]))
                values = [point for point in axis_constraints if low + tolerance < point[1] < high - tolerance]
                if second[1] < first[1]:
                    values.reverse()
                expanded.extend((0.0, point[1]) for point in values)
        cleaned = expanded

    gmsh.initialize()
    try:
        gmsh.option.setNumber("General.Terminal", 0)
        gmsh.model.add("sap_symmetric_polygon_half")
        point_map = {}

        def point_tag(point):
            key = tuple(round(value, 12) for value in point)
            if key not in point_map:
                point_map[key] = gmsh.model.geo.addPoint(point[0], point[1], 0, target_size * 0.5)
            return point_map[key]

        point_tags = [point_tag(point) for point in cleaned]
        curves = [gmsh.model.geo.addLine(point_tags[index], point_tags[(index + 1) % len(point_tags)])
                  for index in range(len(point_tags))]
        surface = gmsh.model.geo.addPlaneSurface([gmsh.model.geo.addCurveLoop(curves)])
        positive_interior = [to_local(point) for point in interior if to_local(point)[0] > tolerance]
        interior_tags = [point_tag(point) for point in positive_interior]
        frame_curves = []
        for first, second, fixed_division, can_bound_opening in local_frames:
            curve = gmsh.model.geo.addLine(point_tag(first), point_tag(second))
            divisions = 1 if fixed_division else max(1, math.ceil(math.dist(first, second) / target_size - 1e-9))
            frame_curves.append((curve, divisions, can_bound_opening))
        gmsh.model.geo.synchronize()
        for curve in curves:
            gmsh.model.mesh.setTransfiniteCurve(curve, 2)
        for curve, divisions, _ in frame_curves:
            gmsh.model.mesh.setTransfiniteCurve(curve, divisions + 1)
        if frame_curves:
            gmsh.model.mesh.embed(1, [curve for curve, _, _ in frame_curves], 2, surface)
        if interior_tags:
            gmsh.model.mesh.embed(0, interior_tags, 2, surface)
        gmsh.model.mesh.setRecombine(2, surface)
        gmsh.option.setNumber("Mesh.MeshSizeMin", target_size * 0.3)
        gmsh.option.setNumber("Mesh.MeshSizeMax", target_size)
        gmsh.option.setNumber("Mesh.Algorithm", 8)
        gmsh.option.setNumber("Mesh.RecombinationAlgorithm", 1)
        gmsh.option.setNumber("Mesh.RecombineAll", 1)
        gmsh.option.setNumber("Mesh.Smoothing", 50)
        gmsh.model.mesh.generate(2)
        gmsh.option.setNumber("Mesh.SubdivisionAlgorithm", 1)
        gmsh.model.mesh.refine()
        gmsh.model.mesh.optimize("Relocate2D", force=True, niter=100)

        tags, coordinates, _ = gmsh.model.mesh.getNodes()
        half_nodes = {int(tag): (float(coordinates[offset]), float(coordinates[offset + 1]))
                      for tag, offset in zip(tags, range(0, len(coordinates), 3))}
        half_quads, triangles, other_count = [], [], 0
        types, _, connectivity = gmsh.model.mesh.getElements(2)
        for element_type, values in zip(types, connectivity):
            _, _, _, count, _, _ = gmsh.model.mesh.getElementProperties(element_type)
            if element_type == 3:
                half_quads.extend(tuple(int(value) for value in values[offset:offset + 4])
                                  for offset in range(0, len(values), 4))
            else:
                other_count += len(values) // count
        if other_count or not half_quads:
            raise RuntimeError("Symmetric half-domain conversion did not produce an all-quadrilateral mesh")

        half_protected = set()
        half_constrained = set()
        for curve, _, can_bound_opening in frame_curves:
            line_types, _, line_connectivity = gmsh.model.mesh.getElements(1, curve)
            for line_type, values in zip(line_types, line_connectivity):
                _, _, _, count, _, _ = gmsh.model.mesh.getElementProperties(line_type)
                for offset in range(0, len(values), count):
                    edge = tuple(sorted((int(values[offset]), int(values[offset + 1]))))
                    half_constrained.add(edge)
                    if can_bound_opening:
                        half_protected.add(edge)

        nodes, positive_tags, negative_tags = {}, {}, {}
        for tag, point in half_nodes.items():
            positive_tags[tag] = len(nodes) + 1
            nodes[positive_tags[tag]] = to_world(point)
            if point[0] <= tolerance:
                negative_tags[tag] = positive_tags[tag]
            else:
                negative_tags[tag] = len(nodes) + 1
                nodes[negative_tags[tag]] = to_world((-point[0], point[1]))
        quads = []
        for quad in half_quads:
            quads.append(tuple(positive_tags[tag] for tag in quad))
            mirrored = tuple(negative_tags[tag] for tag in quad)
            quads.append((mirrored[0], mirrored[3], mirrored[2], mirrored[1]))
        used = set(tag for quad in quads for tag in quad)
        nodes = {tag: point for tag, point in nodes.items() if tag in used}
        quad_edges = {tuple(sorted((quad[index], quad[(index + 1) % 4])))
                      for quad in quads for index in range(4)}
        constrained_edges = set()
        protected_edges = set()
        for first, second in half_constrained:
            constrained_edges.add(tuple(sorted((positive_tags[first], positive_tags[second]))))
            constrained_edges.add(tuple(sorted((negative_tags[first], negative_tags[second]))))
        for first, second in half_protected:
            protected_edges.add(tuple(sorted((positive_tags[first], positive_tags[second]))))
            protected_edges.add(tuple(sorted((negative_tags[first], negative_tags[second]))))
        if constrained_edges - quad_edges:
            raise RuntimeError("Symmetric frame segments do not coincide with shell edges")
        return nodes, quads, protected_edges
    finally:
        gmsh.finalize()


def rectangle_basis(corners):
    if len(corners) != 4:
        return None
    points = [corners[index] for index in range(1, 5)]
    first, second = subtract(points[1], points[0]), subtract(points[3], points[0])
    width, height = norm(first), norm(second)
    if width <= 1e-12 or height <= 1e-12:
        return None
    basis_x, basis_y = normalize(first), normalize(second)
    scale = max(width, height)
    if abs(dot(basis_x, basis_y)) > 1e-7 or math.dist(points[2], tuple(points[0][i] + first[i] + second[i] for i in range(3))) > scale * 1e-7:
        return None
    return points[0], basis_x, basis_y, width, height


def generate_regular_rectangular_mesh(corners, edges, interior, frames, regular_points, max_size):
    basis = rectangle_basis(corners)
    if basis is None:
        raise RuntimeError("Regular aligned meshing requires a rectangular area")
    origin, basis_x, basis_y, width, height = basis
    normal = normalize(cross(basis_x, basis_y))
    tolerance = max(1e-9, max(width, height) * 1e-7)

    def to_local(point):
        offset = subtract(point, origin)
        if abs(dot(offset, normal)) > tolerance:
            raise RuntimeError("Regular mesh guides are not coplanar with the area")
        return dot(offset, basis_x), dot(offset, basis_y)

    x_anchors, y_anchors = [0.0, width], [0.0, height]
    guide_points = list(regular_points) + list(interior)
    guide_points.extend(point for edge in edges.values() for _, point in edge)
    guide_points.extend(point for frame in frames for point in frame[:2])
    for point in guide_points:
        x, y = to_local(point)
        if -tolerance <= x <= width + tolerance:
            x_anchors.append(min(width, max(0.0, x)))
        if -tolerance <= y <= height + tolerance:
            y_anchors.append(min(height, max(0.0, y)))

    local_frames = []
    for first, second, fixed_division, can_bound_opening in frames:
        first, second = to_local(first), to_local(second)
        dx, dy = abs(second[0] - first[0]), abs(second[1] - first[1])
        if min(dx, dy) > tolerance or max(dx, dy) <= tolerance:
            raise RuntimeError("Regular aligned meshing requires frame constraints parallel to the area edges")
        local_frames.append((first, second, fixed_division, can_bound_opening))

    def unique(values):
        result = []
        for value in sorted(values):
            if not result or abs(value - result[-1]) > tolerance:
                result.append(value)
        return result

    def subdivide(anchors):
        anchors = unique(anchors)
        values = [anchors[0]]
        for first, second in zip(anchors, anchors[1:]):
            divisions = max(1, math.ceil((second - first) / max_size - 1e-9))
            values.extend(first + division * (second - first) / divisions
                          for division in range(1, divisions + 1))
        return values

    x_values, y_values = subdivide(x_anchors), subdivide(y_anchors)
    nodes = {}
    tags = {}
    next_tag = 1
    for row, y in enumerate(y_values):
        for column, x in enumerate(x_values):
            tags[column, row] = next_tag
            nodes[next_tag] = tuple(origin[axis] + x * basis_x[axis] + y * basis_y[axis] for axis in range(3))
            next_tag += 1
    quads = [
        (tags[column, row], tags[column + 1, row], tags[column + 1, row + 1], tags[column, row + 1])
        for row in range(len(y_values) - 1) for column in range(len(x_values) - 1)
    ]

    protected_edges = set()
    for first, second, _, can_bound_opening in local_frames:
        if not can_bound_opening:
            continue
        if abs(first[0] - second[0]) <= tolerance:
            column = min(range(len(x_values)), key=lambda index: abs(x_values[index] - first[0]))
            low, high = sorted((first[1], second[1]))
            for row in range(len(y_values) - 1):
                if y_values[row] >= low - tolerance and y_values[row + 1] <= high + tolerance:
                    protected_edges.add(tuple(sorted((tags[column, row], tags[column, row + 1]))))
        else:
            row = min(range(len(y_values)), key=lambda index: abs(y_values[index] - first[1]))
            low, high = sorted((first[0], second[0]))
            for column in range(len(x_values) - 1):
                if x_values[column] >= low - tolerance and x_values[column + 1] <= high + tolerance:
                    protected_edges.add(tuple(sorted((tags[column, row], tags[column + 1, row]))))
    return nodes, quads, protected_edges


def generate_double_symmetric_stress_rectangle(corners, edges, interior, frames, symmetry, symmetry2, max_size):
    basis = rectangle_basis(corners)
    if basis is None:
        raise RuntimeError("Double-symmetric stress refinement requires a rectangular area")
    origin, basis_x, basis_y, width, height = basis

    def to_local(point):
        offset = subtract(point, origin)
        return dot(offset, basis_x), dot(offset, basis_y)

    def to_world(x, y):
        return tuple(origin[axis] + x * basis_x[axis] + y * basis_y[axis] for axis in range(3))

    x_guides = {0.0, width, width * 0.5}
    y_guides = {0.0, height, height * 0.5}
    for frame in frames:
        for point in frame[:2]:
            x, y = to_local(point)
            x_guides.add(x)
            y_guides.add(y)
    offset = max_size * 0.35
    for value in list(x_guides):
        if tolerance_between(value - offset, 0.0, width):
            x_guides.add(value - offset)
        if tolerance_between(value + offset, 0.0, width):
            x_guides.add(value + offset)
    for value in list(y_guides):
        if tolerance_between(value - offset, 0.0, height):
            y_guides.add(value - offset)
        if tolerance_between(value + offset, 0.0, height):
            y_guides.add(value + offset)
    guides = [to_world(x, height * 0.5) for x in x_guides]
    guides.extend(to_world(width * 0.5, y) for y in y_guides)
    nodes, quads, protected_edges = generate_regular_rectangular_mesh(
        corners, edges, interior, frames, guides, max_size)
    if not mesh_reflection_matches(nodes, quads, symmetry) or not mesh_reflection_matches(nodes, quads, symmetry2):
        raise RuntimeError("Stress-refined rectangle is not symmetric about both principal axes")
    return nodes, quads, protected_edges


def tolerance_between(value, low, high):
    return low + 1e-10 < value < high - 1e-10


def generate_regular_plate_with_holes(corners, edges, holes, max_size):
    basis = rectangle_basis(corners)
    if basis is None or any(len(edge) != 2 for edge in edges.values()):
        raise RuntimeError("Regular O-grid blocks require an unconstrained rectangular boundary")
    origin, basis_x, basis_y, width, height = basis

    def to_local(point):
        offset = subtract(point, origin)
        return dot(offset, basis_x), dot(offset, basis_y)

    def to_world(point):
        return tuple(origin[index] + point[0] * basis_x[index] + point[1] * basis_y[index] for index in range(3))

    local_holes = [(to_local(center), diameter * 0.5) for center, diameter in holes]
    side_segments = max(12, max(math.ceil(math.pi * radius / (2 * max_size) - 1e-9) for _, radius in local_holes))
    if side_segments % 2:
        side_segments += 1
    blocks = []
    for center, radius in local_holes:
        half_size = 2 * radius
        if center[0] - half_size <= 0 or center[0] + half_size >= width or center[1] - half_size <= 0 or center[1] + half_size >= height:
            raise RuntimeError("A circular hole is too close to the plate boundary for a square O-grid block")
        blocks.append((center, radius, half_size))
    for first in range(len(blocks)):
        for second in range(first + 1, len(blocks)):
            a, b = blocks[first], blocks[second]
            if abs(a[0][0] - b[0][0]) < a[2] + b[2] - 1e-10 and abs(a[0][1] - b[0][1]) < a[2] + b[2] - 1e-10:
                raise RuntimeError("Square O-grid blocks overlap")

    x_breaks = sorted(set([0.0, width] + [value for center, _, half in blocks for value in (center[0] - half, center[0] + half)]))
    y_breaks = sorted(set([0.0, height] + [value for center, _, half in blocks for value in (center[1] - half, center[1] + half)]))
    tolerance = max(width, height) * 1e-8

    def adjacent_breaks(values, low, high):
        return any(abs(values[index] - low) <= tolerance and abs(values[index + 1] - high) <= tolerance
                   for index in range(len(values) - 1))

    if any(not adjacent_breaks(x_breaks, center[0] - half, center[0] + half) or
           not adjacent_breaks(y_breaks, center[1] - half, center[1] + half) for center, _, half in blocks):
        raise RuntimeError("The hole layout does not admit non-overlapping rectangular O-grid blocks")

    def interval_count(low, high, axis):
        is_hole_span = any(abs(low - (center[axis] - half)) <= tolerance and
                           abs(high - (center[axis] + half)) <= tolerance for center, _, half in blocks)
        return side_segments if is_hole_span else max(1, math.ceil((high - low) / max_size - 1e-9))

    def refined_coordinates(breaks, axis):
        result = []
        for low, high in zip(breaks[:-1], breaks[1:]):
            if not result:
                result.append(low)
            count = interval_count(low, high, axis)
            result.extend(low + (high - low) * index / count for index in range(1, count + 1))
        return result

    x_values, y_values = refined_coordinates(x_breaks, 0), refined_coordinates(y_breaks, 1)
    nodes, node_tags = {}, {}

    def node_tag(point):
        key = round(point[0], 12), round(point[1], 12)
        if key not in node_tags:
            tag = len(nodes) + 1
            node_tags[key] = tag
            nodes[tag] = to_world(point)
        return node_tags[key]

    grid = [[node_tag((x, y)) for x in x_values] for y in y_values]
    quads = []
    for row in range(len(y_values) - 1):
        for column in range(len(x_values) - 1):
            midpoint = ((x_values[column] + x_values[column + 1]) * 0.5,
                        (y_values[row] + y_values[row + 1]) * 0.5)
            if any(abs(midpoint[0] - center[0]) < half - tolerance and
                   abs(midpoint[1] - center[1]) < half - tolerance for center, _, half in blocks):
                continue
            quads.append((grid[row][column], grid[row][column + 1], grid[row + 1][column + 1], grid[row + 1][column]))

    radial_parameters = (0.0, 0.10, 0.22, 0.36, 0.52, 0.69, 0.85, 1.0)
    protected_edges = set()
    station_count = side_segments * 4

    def square_point(center, half, station):
        distance = 8 * half * station / station_count
        x, y = half, 0.0
        for dx, dy, length in ((0, 1, half), (-1, 0, 2 * half), (0, -1, 2 * half),
                               (1, 0, 2 * half), (0, 1, half)):
            travel = min(distance, length)
            x, y = x + dx * travel, y + dy * travel
            distance -= travel
            if distance <= tolerance:
                break
        return center[0] + x, center[1] + y

    for center, radius, half in blocks:
        rings = []
        for parameter in radial_parameters:
            ring = []
            for station in range(station_count):
                angle = 2 * math.pi * station / station_count
                inner = (center[0] + radius * math.cos(angle), center[1] + radius * math.sin(angle))
                outer = square_point(center, half, station)
                point = (inner[0] + parameter * (outer[0] - inner[0]),
                         inner[1] + parameter * (outer[1] - inner[1]))
                ring.append(node_tag(point))
            rings.append(ring)
        for layer in range(len(rings) - 1):
            for station in range(station_count):
                following = (station + 1) % station_count
                quads.append((rings[layer][station], rings[layer + 1][station],
                              rings[layer + 1][following], rings[layer][following]))
        for station in range(station_count):
            protected_edges.add(tuple(sorted((rings[0][station], rings[0][(station + 1) % station_count]))))
    used = set(tag for quad in quads for tag in quad)
    nodes = {tag: point for tag, point in nodes.items() if tag in used}
    return nodes, quads, protected_edges


def generate_rectangular_corner_hole(corners, edges, holes, max_size):
    if len(corners) != 4 or len(holes) != 1:
        raise RuntimeError("Corner O-grids require one hole on a rectangular area")
    ordered = [corners[index] for index in sorted(corners)]
    center, diameter = holes[0]
    scale = max(math.dist(ordered[index], ordered[(index + 1) % 4]) for index in range(4))
    tolerance = max(1e-9, scale * 1e-7)
    corner_index = next((index for index, point in enumerate(ordered) if math.dist(point, center) <= tolerance), None)
    if corner_index is None:
        raise RuntimeError("The circular hole is not centered on an area corner")
    origin = ordered[corner_index]
    vector_u = subtract(ordered[(corner_index + 1) % 4], origin)
    vector_v = subtract(ordered[(corner_index - 1) % 4], origin)
    width, height = norm(vector_u), norm(vector_v)
    unit_u, unit_v = normalize(vector_u), normalize(vector_v)
    opposite = ordered[(corner_index + 2) % 4]
    expected_opposite = tuple(origin[axis] + vector_u[axis] + vector_v[axis] for axis in range(3))
    if abs(dot(unit_u, unit_v)) > 1e-7 or math.dist(opposite, expected_opposite) > tolerance:
        raise RuntimeError("Corner O-grids require a rectangular area")
    radius = diameter * 0.5
    if radius <= 0 or radius >= min(width, height) * 0.45:
        raise RuntimeError("The corner-hole diameter is incompatible with the rectangular area")
    block_limit = min(width, height) * 0.45
    block_size = min(max(radius * 2, radius + max_size * 2), block_limit)
    aligned_block = math.floor((block_limit + 1e-9) / max_size) * max_size
    if aligned_block >= radius + max_size:
        block_size = aligned_block
    quarter_sectors = max(8, math.ceil(0.5 * math.pi * radius / max_size - 1e-9))
    if quarter_sectors % 2:
        quarter_sectors += 1
    radial_layers = max(2, math.ceil((math.sqrt(2) * block_size - radius) / max_size - 1e-9))
    radial_distances = [radius + (block_size - radius) * layer / radial_layers
                        for layer in range(radial_layers + 1)]
    # The corner O-grid's two radial sides coincide with the area's edges.
    # Preserve every prescribed node on those edges, even for a small hole
    # whose radius is much smaller than the requested maximum mesh size.
    required = []
    for edge in edges.values():
        for _, point in edge:
            offset = subtract(point, center)
            along_u, along_v = dot(offset, unit_u), dot(offset, unit_v)
            if min(abs(along_u), abs(along_v)) <= tolerance:
                distance = max(along_u, along_v)
                if radius + tolerance < distance < block_size - tolerance:
                    required.append(distance)
    if any(not any(abs(distance - value) <= tolerance for value in radial_distances)
           for distance in required):
        anchors = []
        for distance in sorted([radius, block_size] + required):
            if not anchors or distance - anchors[-1] > tolerance:
                anchors.append(distance)
        diagonal_ratio = (math.sqrt(2) * block_size - radius) / (block_size - radius)
        radial_distances = [radius]
        for first, second in zip(anchors[:-1], anchors[1:]):
            divisions = max(1, math.ceil((second - first) * diagonal_ratio / max_size - 1e-9),
                            math.ceil(math.log(second / first) / math.log(1.35) - 1e-9))
            radial_distances.extend(first * (second / first) ** (part / divisions)
                                    for part in range(1, divisions + 1))
        radial_layers = len(radial_distances) - 1

    nodes = {}
    node_by_key = {}
    quads = []
    protected_edges = set()

    def node_tag(x, y):
        point = tuple(origin[axis] + x * unit_u[axis] + y * unit_v[axis] for axis in range(3))
        key = tuple(round(value, 12) for value in point)
        if key not in node_by_key:
            tag = len(nodes) + 1
            node_by_key[key] = tag
            nodes[tag] = point
        return node_by_key[key]

    rings = []
    for layer in range(radial_layers + 1):
        parameter = (radial_distances[layer] - radius) / (block_size - radius)
        ring = []
        for station in range(quarter_sectors + 1):
            angle = 0.5 * math.pi * station / quarter_sectors
            inner = radius * math.cos(angle), radius * math.sin(angle)
            if station <= quarter_sectors // 2:
                outer = block_size, 2 * block_size * station / quarter_sectors
            else:
                outer = 2 * block_size * (quarter_sectors - station) / quarter_sectors, block_size
            ring.append(node_tag(inner[0] + parameter * (outer[0] - inner[0]),
                                 inner[1] + parameter * (outer[1] - inner[1])))
        rings.append(ring)
    for layer in range(radial_layers):
        for station in range(quarter_sectors):
            quads.append((rings[layer][station], rings[layer + 1][station],
                          rings[layer + 1][station + 1], rings[layer][station + 1]))
    for station in range(quarter_sectors):
        protected_edges.add(tuple(sorted((rings[0][station], rings[0][station + 1]))))

    lower_stations = [2 * block_size * station / quarter_sectors for station in range(quarter_sectors // 2 + 1)]
    upper_divisions = max(1, math.ceil((height - block_size) / max_size - 1e-9))
    upper_stations = [block_size + (height - block_size) * division / upper_divisions
                      for division in range(1, upper_divisions + 1)]
    y_stations = lower_stations + upper_stations
    right_divisions = max(1, math.ceil((width - block_size) / max_size - 1e-9))
    x_right = [block_size + (width - block_size) * division / right_divisions
               for division in range(right_divisions + 1)]
    for x0, x1 in zip(x_right[:-1], x_right[1:]):
        for y0, y1 in zip(y_stations[:-1], y_stations[1:]):
            quads.append((node_tag(x0, y0), node_tag(x1, y0), node_tag(x1, y1), node_tag(x0, y1)))

    x_top = list(reversed([2 * block_size * (quarter_sectors - station) / quarter_sectors
                           for station in range(quarter_sectors // 2, quarter_sectors + 1)]))
    for x0, x1 in zip(x_top[:-1], x_top[1:]):
        for y0, y1 in zip([block_size] + upper_stations[:-1], upper_stations):
            quads.append((node_tag(x0, y0), node_tag(x1, y0), node_tag(x1, y1), node_tag(x0, y1)))
    node_keys = {tuple(round(value, 8) for value in point) for point in nodes.values()}
    missing_boundary = sum(tuple(round(value, 8) for value in point) not in node_keys
                           for edge in edges.values() for _, point in edge
                           if math.dist(point, center) >= radius - tolerance)
    if missing_boundary:
        raise RuntimeError(f"Corner O-grid does not embed {missing_boundary} boundary points")
    return nodes, quads, protected_edges


def generate_clipped_hole_polygon(corners, edges, holes, max_size, frames=None, algorithm=8, recombination=1,
                                  frame_size_factor=0.4):
    frames = frames or []
    ordered = [corners[index] for index in sorted(corners)]
    normal = polygon_normal(ordered)
    basis_u = normalize(subtract(ordered[1], ordered[0]))
    basis_v = normalize(cross(normal, basis_u))
    origin = ordered[0]

    def to_local(point):
        offset = subtract(point, origin)
        return dot(offset, basis_u), dot(offset, basis_v)

    def to_world(point):
        return tuple(origin[axis] + point[0] * basis_u[axis] + point[1] * basis_v[axis] for axis in range(3))

    boundary_points = []
    for edge_index in sorted(edges):
        boundary_points.extend(point for _, point in edges[edge_index][:-1])
    local_polygon = [to_local(point) for point in boundary_points]
    local_holes = [(to_local(center), diameter * 0.5) for center, diameter in holes]
    local_frames = [(to_local(first), to_local(second), fixed_division, can_bound_opening)
                    for first, second, fixed_division, can_bound_opening in frames]
    gmsh.initialize()
    try:
        gmsh.option.setNumber("General.Terminal", 0)
        gmsh.model.add("sap_clipped_circular_holes")
        point_tags = [gmsh.model.occ.addPoint(point[0], point[1], 0) for point in local_polygon]
        curves = [gmsh.model.occ.addLine(point_tags[index], point_tags[(index + 1) % len(point_tags)])
                  for index in range(len(point_tags))]
        surface = gmsh.model.occ.addPlaneSurface([gmsh.model.occ.addWire(curves)])
        disks = [(2, gmsh.model.occ.addDisk(center[0], center[1], 0, radius, radius))
                 for center, radius in local_holes]
        cut_surfaces, _ = gmsh.model.occ.cut([(2, surface)], disks, removeObject=True, removeTool=True)
        if not cut_surfaces:
            raise RuntimeError("Circular holes remove the complete area")
        frame_curves = []
        for first, second, fixed_division, can_bound_opening in local_frames:
            first_tag = gmsh.model.occ.addPoint(first[0], first[1], 0)
            second_tag = gmsh.model.occ.addPoint(second[0], second[1], 0)
            frame_curves.append((gmsh.model.occ.addLine(first_tag, second_tag), fixed_division, can_bound_opening,
                                 math.dist(first, second)))
        if frame_curves:
            fragmented, entity_map = gmsh.model.occ.fragment(
                cut_surfaces, [(1, curve) for curve, _, _, _ in frame_curves], removeObject=True, removeTool=True)
            mapped_frames = []
            for index, (_, fixed_division, can_bound_opening, length) in enumerate(frame_curves):
                mapped = [tag for dimension, tag in entity_map[len(cut_surfaces) + index] if dimension == 1]
                mapped_frames.append((mapped, fixed_division, can_bound_opening, length))
            surface_tags = [tag for dimension, tag in fragmented if dimension == 2]
        else:
            mapped_frames = []
            surface_tags = [tag for dimension, tag in cut_surfaces if dimension == 2]
        gmsh.model.occ.synchronize()
        for curve in curves:
            try:
                gmsh.model.mesh.setTransfiniteCurve(curve, 2)
            except Exception:
                pass
        for mapped, fixed_division, _, length in mapped_frames:
            divisions = 1 if fixed_division else max(1, math.ceil(length / (max_size * frame_size_factor) - 1e-9))
            for curve in mapped:
                gmsh.model.mesh.setTransfiniteCurve(curve, divisions + 1)
        for tag in surface_tags:
            gmsh.model.mesh.setRecombine(2, tag)
        gmsh.option.setNumber("Mesh.MeshSizeMin", max_size * 0.25)
        gmsh.option.setNumber("Mesh.MeshSizeMax", max_size)
        gmsh.option.setNumber("Mesh.Algorithm", algorithm)
        gmsh.option.setNumber("Mesh.RecombinationAlgorithm", recombination)
        gmsh.option.setNumber("Mesh.RecombineAll", 1)
        gmsh.option.setNumber("Mesh.Smoothing", 50)
        gmsh.model.mesh.generate(2)
        gmsh.option.setNumber("Mesh.SubdivisionAlgorithm", 1)
        gmsh.model.mesh.refine()
        gmsh.model.mesh.optimize("Relocate2D", force=True, niter=100)

        tags, coordinates, _ = gmsh.model.mesh.getNodes()
        local_nodes = {int(tag): (float(coordinates[offset]), float(coordinates[offset + 1]))
                       for tag, offset in zip(tags, range(0, len(coordinates), 3))}
        nodes = {tag: to_world(point) for tag, point in local_nodes.items()}
        quads, other_count = [], 0
        types, _, connectivity = gmsh.model.mesh.getElements(2, -1)
        for element_type, values in zip(types, connectivity):
            _, _, _, count, _, _ = gmsh.model.mesh.getElementProperties(element_type)
            if element_type == 3:
                quads.extend(tuple(int(value) for value in values[offset:offset + 4])
                             for offset in range(0, len(values), 4))
            else:
                other_count += len(values) // count
        if other_count or not quads:
            raise RuntimeError("Clipped circular-hole conversion did not produce an all-quadrilateral mesh")

        protected_edges = set()
        constrained_frame_edges = set()
        for mapped, _, can_bound_opening, _ in mapped_frames:
            for curve in mapped:
                line_types, _, line_connectivity = gmsh.model.mesh.getElements(1, curve)
                for line_type, values in zip(line_types, line_connectivity):
                    _, _, _, count, _, _ = gmsh.model.mesh.getElementProperties(line_type)
                    for offset in range(0, len(values), count):
                        edge = tuple(sorted((int(values[offset]), int(values[offset + 1]))))
                        constrained_frame_edges.add(edge)
                        if can_bound_opening:
                            protected_edges.add(edge)
        curve_tags = {tag for surface_tag in surface_tags
                      for dimension, tag in gmsh.model.getBoundary([(2, surface_tag)], oriented=False)
                      if dimension == 1}
        radial_tolerance = max(1e-8, max_size * 1e-5)
        for curve in curve_tags:
            line_types, _, line_connectivity = gmsh.model.mesh.getElements(1, curve)
            for line_type, values in zip(line_types, line_connectivity):
                _, _, _, count, _, _ = gmsh.model.mesh.getElementProperties(line_type)
                for offset in range(0, len(values), count):
                    first, second = int(values[offset]), int(values[offset + 1])
                    if any(abs(math.dist(local_nodes[first], center) - radius) <= radial_tolerance and
                           abs(math.dist(local_nodes[second], center) - radius) <= radial_tolerance
                           for center, radius in local_holes):
                        protected_edges.add(tuple(sorted((first, second))))
        quad_edges = {tuple(sorted((quad[index], quad[(index + 1) % 4])))
                      for quad in quads for index in range(4)}
        missing_frames = constrained_frame_edges - quad_edges
        if missing_frames:
            raise RuntimeError(f"{len(missing_frames)} frame segments do not coincide with shell edges")
        used = {tag for quad in quads for tag in quad}
        nodes = {tag: point for tag, point in nodes.items() if tag in used}
        fixed = set()
        for curve in curve_tags | {curve for mapped, _, _, _ in mapped_frames for curve in mapped}:
            curve_nodes, _, _ = gmsh.model.mesh.getNodes(1, curve, includeBoundary=True)
            fixed.update(int(tag) for tag in curve_nodes)
        improve_interior_nodes(nodes, quads, [], fixed)
        return nodes, quads, protected_edges
    finally:
        gmsh.finalize()


def generate_with_holes(corners, edges, interior, holes, max_size, base_factor, fixed_boundary=False,
                        frames=None, stress_refinement=False):
    frames = frames or []
    gmsh.initialize()
    try:
        gmsh.option.setNumber("General.Terminal", 0)
        gmsh.model.add("sap_circular_ogrid_polygon")
        target_size = max_size * base_factor
        ordered_corners = [corners[index] for index in sorted(corners)]
        normal = polygon_normal(ordered_corners)
        basis_u = normalize(subtract(ordered_corners[1], ordered_corners[0]))
        basis_v = normalize(cross(normal, basis_u))
        boundary_segments = [
            (first[1], second[1])
            for edge in edges.values()
            for first, second in zip(edge[:-1], edge[1:])
        ]
        radii = [diameter * 0.5 for _, diameter in holes]
        outer_radii = []
        for index, ((center, _), radius) in enumerate(zip(holes, radii)):
            boundary_clearance = min(point_segment_distance(center, first, second) for first, second in boundary_segments) - radius
            neighbor_clearance = min([
                (math.dist(center, other_center) - radius - radii[other_index]) * 0.5
                for other_index, (other_center, _) in enumerate(holes) if other_index != index
            ] or [float("inf")])
            frame_clearance = min([point_segment_distance(center, first, second) - radius
                                   for first, second, _, _ in frames] or [float("inf")])
            available = min(boundary_clearance, neighbor_clearance, frame_clearance)
            if available <= max(1e-10, radius * 1e-6):
                raise RuntimeError("Insufficient clearance around a circular hole for an O-grid")
            width = min(max(radius * 0.8, target_size * 0.5), available * 0.8)
            outer_radii.append(radius + width)
        for point in interior:
            if any(math.dist(point, center) < outer_radius - 1e-10
                   for (center, _), outer_radius in zip(holes, outer_radii)):
                raise RuntimeError("A constrained interior point lies inside a circular O-grid transition ring")

        point_tags = {}

        def point_tag(xyz, size=target_size):
            key = tuple(round(value, 12) for value in xyz)
            if key not in point_tags:
                point_tags[key] = gmsh.model.geo.addPoint(*xyz, size)
            return point_tags[key]

        boundary_curves = []
        for edge_index in range(1, len(corners) + 1):
            points = [xyz for _, xyz in edges[edge_index]]
            constrained_edge = len(points) > 2
            for first, second in zip(points[:-1], points[1:]):
                curve = gmsh.model.geo.addLine(point_tag(first), point_tag(second))
                divisions = 1 if constrained_edge else max(1, math.ceil(math.dist(first, second) / target_size - 1e-9))
                boundary_curves.append((curve, divisions))
        boundary_loop = gmsh.model.geo.addCurveLoop([curve for curve, _ in boundary_curves])

        frame_curves = []
        for first, second, fixed_division, can_bound_opening in frames:
            curve = gmsh.model.geo.addLine(point_tag(first), point_tag(second))
            divisions = 1 if fixed_division else max(1, math.ceil(math.dist(first, second) / target_size - 1e-9))
            frame_curves.append((curve, divisions, can_bound_opening))

        outer_loops = []
        ring_surfaces = []
        radial_curves = []
        inner_curves = []
        outer_curves = []
        for hole_index, ((center, _), radius, outer_radius) in enumerate(zip(holes, radii, outer_radii)):
            sector_count = max(8, math.ceil(2 * math.pi * outer_radius / target_size - 1e-9))
            sector_count = int(math.ceil(sector_count / 4) * 4)

            def ring_point(distance, sector):
                angle = 2 * math.pi * sector / sector_count
                return tuple(center[axis] + distance * (math.cos(angle) * basis_u[axis] + math.sin(angle) * basis_v[axis])
                             for axis in range(3))

            inner_points = [point_tag(ring_point(radius, sector), target_size * 0.35) for sector in range(sector_count)]
            outer_points = [point_tag(ring_point(outer_radius, sector), target_size * 0.6) for sector in range(sector_count)]
            hole_inner_curves = [gmsh.model.geo.addLine(inner_points[i], inner_points[(i + 1) % sector_count])
                                 for i in range(sector_count)]
            hole_outer_curves = [gmsh.model.geo.addLine(outer_points[i], outer_points[(i + 1) % sector_count])
                                 for i in range(sector_count)]
            hole_radial_curves = [gmsh.model.geo.addLine(inner_points[i], outer_points[i]) for i in range(sector_count)]
            inner_curves.extend(hole_inner_curves)
            outer_curves.extend(hole_outer_curves)
            radial_curves.extend(hole_radial_curves)
            outer_loops.append(gmsh.model.geo.addCurveLoop([-curve for curve in reversed(hole_outer_curves)]))
            for sector in range(sector_count):
                following = (sector + 1) % sector_count
                loop = gmsh.model.geo.addCurveLoop([
                    hole_radial_curves[sector], hole_outer_curves[sector],
                    -hole_radial_curves[following], -hole_inner_curves[sector]
                ])
                ring_surfaces.append(gmsh.model.geo.addPlaneSurface([loop]))

        exterior_surface = gmsh.model.geo.addPlaneSurface([boundary_loop] + outer_loops)
        interior_tags = [point_tag(point) for point in interior]
        gmsh.model.geo.synchronize()
        for curve, divisions in boundary_curves:
            gmsh.model.mesh.setTransfiniteCurve(curve, divisions + 1)
        for curve, divisions, _ in frame_curves:
            gmsh.model.mesh.setTransfiniteCurve(curve, divisions + 1)
        for curve in inner_curves + outer_curves:
            gmsh.model.mesh.setTransfiniteCurve(curve, 2)
        for curve in radial_curves:
            gmsh.model.mesh.setTransfiniteCurve(curve, 3, "Progression", 1.25)
        for surface in ring_surfaces:
            gmsh.model.mesh.setTransfiniteSurface(surface)
            gmsh.model.mesh.setRecombine(2, surface)
        gmsh.model.mesh.setRecombine(2, exterior_surface)
        if interior_tags:
            gmsh.model.mesh.embed(0, interior_tags, 2, exterior_surface)
        if frame_curves:
            gmsh.model.mesh.embed(1, [curve for curve, _, _ in frame_curves], 2, exterior_surface)
            set_graded_refinement([curve for curve, _, _ in frame_curves], max_size, target_size)
        elif stress_refinement:
            set_graded_refinement(outer_curves, max_size, target_size)

        gmsh.option.setNumber("Mesh.MeshSizeMin", target_size * 0.25)
        gmsh.option.setNumber("Mesh.MeshSizeMax", target_size)
        gmsh.option.setNumber("Mesh.Algorithm", 8)
        gmsh.option.setNumber("Mesh.RecombinationAlgorithm", 1)
        gmsh.option.setNumber("Mesh.RecombineAll", 1)
        gmsh.option.setNumber("Mesh.Smoothing", 50)
        gmsh.model.mesh.generate(2)
        gmsh.option.setNumber("Mesh.SubdivisionAlgorithm", 1)
        gmsh.model.mesh.refine()
        gmsh.model.mesh.optimize("Relocate2D", force=True, niter=100)

        tags, coordinates, _ = gmsh.model.mesh.getNodes()
        nodes = {int(tag): tuple(float(coordinates[i + axis]) for axis in range(3))
                 for tag, i in zip(tags, range(0, len(coordinates), 3))}
        quads, other_count = [], 0
        types, _, connectivity = gmsh.model.mesh.getElements(2)
        for element_type, values in zip(types, connectivity):
            _, _, _, count, _, _ = gmsh.model.mesh.getElementProperties(element_type)
            if element_type == 3:
                quads.extend(tuple(int(value) for value in values[i:i + 4]) for i in range(0, len(values), 4))
            else:
                other_count += len(values) // count
        if other_count or not quads:
            raise RuntimeError("Circular O-grid conversion did not produce an all-quadrilateral mesh")

        protected_edges = set()
        for curve in inner_curves:
            line_types, _, line_connectivity = gmsh.model.mesh.getElements(1, curve)
            for line_type, values in zip(line_types, line_connectivity):
                _, _, _, count, _, _ = gmsh.model.mesh.getElementProperties(line_type)
                for offset in range(0, len(values), count):
                    protected_edges.add(tuple(sorted((int(values[offset]), int(values[offset + 1])))))
        constrained_edges = set()
        for curve, _, can_bound_opening in frame_curves:
            line_types, _, line_connectivity = gmsh.model.mesh.getElements(1, curve)
            for line_type, values in zip(line_types, line_connectivity):
                _, _, _, count, _, _ = gmsh.model.mesh.getElementProperties(line_type)
                for offset in range(0, len(values), count):
                    edge = tuple(sorted((int(values[offset]), int(values[offset + 1]))))
                    constrained_edges.add(edge)
                    if can_bound_opening:
                        protected_edges.add(edge)
        quad_edges = {tuple(sorted((quad[index], quad[(index + 1) % 4])))
                      for quad in quads for index in range(4)}
        if constrained_edges - quad_edges:
            raise RuntimeError("Frame segments do not coincide with shell edges around the circular O-grids")
        used = set(tag for quad in quads for tag in quad)
        nodes = {tag: point for tag, point in nodes.items() if tag in used}
        return nodes, quads, protected_edges
    finally:
        gmsh.finalize()


def generate_symmetric_with_holes(corners, edges, interior, frames, holes, symmetry, max_size, base_factor,
                                  stress_refinement=False):
    center, axis = symmetry
    axis = normalize(axis)
    normal = polygon_normal([corners[index] for index in sorted(corners)])
    perpendicular = normalize(cross(normal, axis))
    target_size = max_size * base_factor
    tolerance = max(1e-9, max_size * 1e-7)

    def to_local(point):
        offset = subtract(point, center)
        return dot(offset, perpendicular), dot(offset, axis)

    def to_world(point):
        return tuple(center[index] + point[0] * perpendicular[index] + point[1] * axis[index] for index in range(3))

    axis_holes = [(hole_center, diameter) for hole_center, diameter in holes
                  if abs(to_local(hole_center)[0]) <= tolerance]
    if axis_holes:
        if len(axis_holes) != len(holes):
            raise RuntimeError("Mixing axis-centered holes with reflected hole pairs is not supported yet")
        if frames:
            raise RuntimeError("Axis-centered circular holes cannot currently be combined with frame constraints")
        return generate_symmetric_axis_holes(corners, edges, interior, holes, symmetry, max_size, base_factor)

    boundary = []
    for edge_index in range(1, len(corners) + 1):
        points = [to_local(xyz) for _, xyz in edges[edge_index]]
        constrained = len(points) > 2
        for first, second in zip(points[:-1], points[1:]):
            if not boundary or math.dist(boundary[-1], first) > tolerance:
                boundary.append(first)
            divisions = 1 if constrained else max(1, math.ceil(math.dist(first, second) / target_size - 1e-9))
            for division in range(1, divisions + 1):
                boundary.append(tuple(first[coordinate] + division / divisions * (second[coordinate] - first[coordinate])
                                      for coordinate in range(2)))
    if math.dist(boundary[0], boundary[-1]) <= tolerance:
        boundary.pop()

    def intersection(first, second):
        parameter = first[0] / (first[0] - second[0])
        return 0.0, first[1] + parameter * (second[1] - first[1])

    clipped = []
    for first, second in zip(boundary, boundary[1:] + boundary[:1]):
        first_inside, second_inside = first[0] >= -tolerance, second[0] >= -tolerance
        if first_inside:
            clipped.append((0.0 if abs(first[0]) <= tolerance else first[0], first[1]))
        if first_inside != second_inside:
            clipped.append(intersection(first, second))
    cleaned = []
    for point in clipped:
        if not cleaned or math.dist(cleaned[-1], point) > tolerance:
            cleaned.append(point)
    if len(cleaned) > 1 and math.dist(cleaned[0], cleaned[-1]) <= tolerance:
        cleaned.pop()
    if len(cleaned) < 3:
        raise RuntimeError("The selected symmetry axis does not split the perforated polygon into a valid half-domain")
    validate_connected_half_boundary(cleaned, boundary, tolerance)

    refined = []
    for first, second in zip(cleaned, cleaned[1:] + cleaned[:1]):
        refined.append(first)
        if abs(first[0]) <= tolerance and abs(second[0]) <= tolerance:
            divisions = max(1, math.ceil(math.dist(first, second) / target_size - 1e-9))
            for division in range(1, divisions):
                refined.append((0.0, first[1] + division / divisions * (second[1] - first[1])))
    cleaned = refined

    positive_frames = []
    axis_frame_points = []
    seen_frames = set()
    for first, second, fixed_division, can_bound_opening in frames:
        first, second = to_local(first), to_local(second)
        if first[0] < -tolerance and second[0] < -tolerance:
            continue
        if (first[0] < -tolerance) != (second[0] < -tolerance):
            crossing = intersection(first, second)
            axis_frame_points.append(crossing)
            if first[0] < -tolerance:
                first = crossing
            else:
                second = crossing
        first = (0.0 if abs(first[0]) <= tolerance else first[0], first[1])
        second = (0.0 if abs(second[0]) <= tolerance else second[0], second[1])
        if math.dist(first, second) <= tolerance:
            continue
        key = tuple(sorted((tuple(round(value, 10) for value in first),
                            tuple(round(value, 10) for value in second))))
        if key not in seen_frames:
            seen_frames.add(key)
            positive_frames.append((to_world(first), to_world(second), fixed_division, can_bound_opening))

    axis_constraints = sorted(
        [to_local(point) for point in interior if abs(to_local(point)[0]) <= tolerance] + axis_frame_points,
        key=lambda point: point[1])
    if axis_constraints:
        expanded = []
        for first, second in zip(cleaned, cleaned[1:] + cleaned[:1]):
            expanded.append(first)
            if abs(first[0]) <= tolerance and abs(second[0]) <= tolerance:
                low, high = sorted((first[1], second[1]))
                values = [point for point in axis_constraints if low + tolerance < point[1] < high - tolerance]
                if second[1] < first[1]:
                    values.reverse()
                expanded.extend((0.0, point[1]) for point in values)
        cleaned = expanded

    positive_holes = []
    negative_holes = []
    for hole_center, diameter in holes:
        local_center = to_local(hole_center)
        if abs(local_center[0]) <= diameter * 0.5 + tolerance:
            raise RuntimeError("Circular holes intersecting the symmetry axis are not supported")
        if local_center[0] > 0:
            positive_holes.append((hole_center, diameter))
        else:
            negative_holes.append((local_center, diameter))
    unmatched_negative = list(range(len(negative_holes)))
    for hole_center, diameter in positive_holes:
        local_center = to_local(hole_center)
        match = next((index for index in unmatched_negative
                      if abs(negative_holes[index][1] - diameter) <= tolerance and
                      math.dist(negative_holes[index][0], (-local_center[0], local_center[1])) <= tolerance), None)
        if match is None:
            raise RuntimeError("Circular holes do not form exact reflected pairs")
        unmatched_negative.remove(match)
    if unmatched_negative or len(positive_holes) * 2 != len(holes):
        raise RuntimeError("Circular holes must form reflected pairs across the selected symmetry axis")

    half_corners = {index + 1: to_world(point) for index, point in enumerate(cleaned)}
    half_edges = {
        index + 1: [(0.0, half_corners[index + 1]),
                    (1.0, half_corners[(index + 1) % len(cleaned) + 1])]
        for index in range(len(cleaned))
    }
    positive_interior = [point for point in interior if to_local(point)[0] > tolerance]
    half_nodes, half_quads, half_protected = generate_with_holes(
        half_corners, half_edges, positive_interior, positive_holes, max_size, base_factor,
        fixed_boundary=True, frames=positive_frames, stress_refinement=stress_refinement
    )

    nodes = dict(half_nodes)
    mirrored_tags = {}
    next_tag = max(nodes) + 1
    for tag, point in half_nodes.items():
        local_point = to_local(point)
        if abs(local_point[0]) <= tolerance:
            mirrored_tags[tag] = tag
        else:
            mirrored_tags[tag] = next_tag
            nodes[next_tag] = to_world((-local_point[0], local_point[1]))
            next_tag += 1
    quads = list(half_quads)
    for quad in half_quads:
        mirrored = tuple(mirrored_tags[tag] for tag in quad)
        quads.append((mirrored[0], mirrored[3], mirrored[2], mirrored[1]))
    protected_edges = set(half_protected)
    protected_edges.update(tuple(sorted((mirrored_tags[first], mirrored_tags[second])))
                           for first, second in half_protected)
    return nodes, quads, protected_edges


def generate_double_symmetric_with_holes(corners, edges, interior, frames, holes, symmetry, symmetry2,
                                         max_size, base_factor, stress_refinement=False):
    center, first_axis = symmetry
    second_center, second_axis = symmetry2
    first_axis, second_axis = normalize(first_axis), normalize(second_axis)
    tolerance = max(1e-9, max_size * 1e-7)
    if math.dist(center, second_center) > tolerance or abs(dot(first_axis, second_axis)) > 1e-7:
        raise RuntimeError("Double symmetry requires two orthogonal axes with a common center")

    def to_local(point):
        offset = subtract(point, center)
        return dot(offset, first_axis), dot(offset, second_axis)

    def to_world(point):
        return tuple(center[index] + point[0] * first_axis[index] + point[1] * second_axis[index]
                     for index in range(3))

    boundary = []
    target_size = max_size * base_factor
    for edge_index in range(1, len(corners) + 1):
        points = [to_local(xyz) for _, xyz in edges[edge_index]]
        constrained = len(points) > 2
        for first, second in zip(points[:-1], points[1:]):
            if not boundary or math.dist(boundary[-1], first) > tolerance:
                boundary.append(first)
            divisions = 1 if constrained else max(1, math.ceil(math.dist(first, second) / target_size - 1e-9))
            boundary.extend(tuple(first[axis] + division / divisions * (second[axis] - first[axis]) for axis in range(2))
                            for division in range(1, divisions + 1))
    if math.dist(boundary[0], boundary[-1]) <= tolerance:
        boundary.pop()

    def clip_polygon(points, coordinate):
        clipped = []
        for first, second in zip(points, points[1:] + points[:1]):
            first_inside, second_inside = first[coordinate] >= -tolerance, second[coordinate] >= -tolerance
            if first_inside:
                value = list(first)
                if abs(value[coordinate]) <= tolerance:
                    value[coordinate] = 0.0
                clipped.append(tuple(value))
            if first_inside != second_inside:
                parameter = first[coordinate] / (first[coordinate] - second[coordinate])
                value = [first[axis] + parameter * (second[axis] - first[axis]) for axis in range(2)]
                value[coordinate] = 0.0
                clipped.append(tuple(value))
        result = []
        for point in clipped:
            if not result or math.dist(result[-1], point) > tolerance:
                result.append(point)
        if len(result) > 1 and math.dist(result[0], result[-1]) <= tolerance:
            result.pop()
        return result

    quarter = clip_polygon(clip_polygon(boundary, 0), 1)
    if len(quarter) < 3:
        raise RuntimeError("The two symmetry axes do not define a valid quarter-domain")

    def clip_segment(first, second):
        first, second = to_local(first), to_local(second)
        low, high = 0.0, 1.0
        for coordinate in range(2):
            delta = second[coordinate] - first[coordinate]
            if abs(delta) <= tolerance:
                if first[coordinate] < -tolerance:
                    return None
                continue
            crossing = -first[coordinate] / delta
            if delta > 0:
                low = max(low, crossing)
            else:
                high = min(high, crossing)
        if high - low <= tolerance:
            return None
        clipped = []
        for parameter in (low, high):
            value = tuple(first[axis] + parameter * (second[axis] - first[axis]) for axis in range(2))
            clipped.append(tuple(0.0 if abs(item) <= tolerance else item for item in value))
        return tuple(clipped)

    quarter_frames = []
    boundary_constraints = [to_local(point) for point in interior
                            if min(to_local(point)) >= -tolerance and min(abs(value) for value in to_local(point)) <= tolerance]
    seen_frames = set()
    for first, second, fixed_division, can_bound_opening in frames:
        clipped = clip_segment(first, second)
        if clipped is None:
            continue
        key = tuple(sorted(tuple(round(value, 10) for value in point) for point in clipped))
        if key in seen_frames:
            continue
        seen_frames.add(key)
        boundary_constraints.extend(point for point in clipped if min(abs(value) for value in point) <= tolerance)
        quarter_frames.append((to_world(clipped[0]), to_world(clipped[1]), fixed_division, can_bound_opening))

    def insert_constraints(polygon, constraints):
        expanded = []
        for first, second in zip(polygon, polygon[1:] + polygon[:1]):
            expanded.append(first)
            direction = (second[0] - first[0], second[1] - first[1])
            length_squared = direction[0] ** 2 + direction[1] ** 2
            values = []
            for point in constraints:
                parameter = 0 if length_squared == 0 else ((point[0] - first[0]) * direction[0] +
                                                             (point[1] - first[1]) * direction[1]) / length_squared
                projection = (first[0] + parameter * direction[0], first[1] + parameter * direction[1])
                if tolerance < parameter < 1 - tolerance and math.dist(point, projection) <= tolerance:
                    values.append((parameter, point))
            expanded.extend(point for _, point in sorted(values))
        return expanded

    quarter = insert_constraints(quarter, boundary_constraints)
    quarter_holes = []
    for hole_center, diameter in holes:
        local = to_local(hole_center)
        radius = diameter * 0.5
        if abs(local[0]) <= radius + tolerance or abs(local[1]) <= radius + tolerance:
            raise RuntimeError("Circular holes intersecting either symmetry axis are not supported")
        if local[0] > 0 and local[1] > 0:
            quarter_holes.append((hole_center, diameter))
    if len(quarter_holes) * 4 != len(holes):
        raise RuntimeError("Circular holes must form complete four-hole orbits under double symmetry")

    quarter_corners = {index + 1: to_world(point) for index, point in enumerate(quarter)}
    quarter_edges = {index + 1: [(0.0, quarter_corners[index + 1]),
                                  (1.0, quarter_corners[(index + 1) % len(quarter) + 1])]
                     for index in range(len(quarter))}
    quarter_interior = [point for point in interior if min(to_local(point)) > tolerance]
    quarter_nodes, quarter_quads, quarter_protected = generate_with_holes(
        quarter_corners, quarter_edges, quarter_interior, quarter_holes, max_size, base_factor,
        fixed_boundary=True, frames=quarter_frames, stress_refinement=stress_refinement)

    nodes, node_by_key, transformed_tags = {}, {}, {}

    def node_tag(point):
        key = tuple(round(value, 10) for value in point)
        if key not in node_by_key:
            tag = len(nodes) + 1
            node_by_key[key] = tag
            nodes[tag] = point
        return node_by_key[key]

    signs = ((1, 1), (1, -1), (-1, 1), (-1, -1))
    for signs_pair in signs:
        for tag, point in quarter_nodes.items():
            local = to_local(point)
            transformed_tags[signs_pair, tag] = node_tag(to_world((signs_pair[0] * local[0], signs_pair[1] * local[1])))
    quads = []
    for signs_pair in signs:
        for quad in quarter_quads:
            transformed = tuple(transformed_tags[signs_pair, tag] for tag in quad)
            quads.append(transformed if signs_pair[0] * signs_pair[1] > 0
                         else (transformed[0], transformed[3], transformed[2], transformed[1]))
    protected_edges = set()
    for signs_pair in signs:
        for first, second in quarter_protected:
            protected_edges.add(tuple(sorted((transformed_tags[signs_pair, first],
                                              transformed_tags[signs_pair, second]))))
    return nodes, quads, protected_edges


def generate_symmetric_axis_holes(corners, edges, interior, holes, symmetry, max_size, base_factor):
    center, axis = symmetry
    axis = normalize(axis)
    dominant = max(range(3), key=lambda coordinate: abs(axis[coordinate]))
    if axis[dominant] < 0:
        axis = tuple(-value for value in axis)
    normal = polygon_normal([corners[index] for index in sorted(corners)])
    perpendicular = normalize(cross(normal, axis))
    target_size = max_size * base_factor
    tolerance = max(1e-9, max_size * 1e-7)

    def to_local(point):
        offset = subtract(point, center)
        return dot(offset, perpendicular), dot(offset, axis)

    def to_world(point):
        return tuple(center[index] + point[0] * perpendicular[index] + point[1] * axis[index] for index in range(3))

    boundary = []
    for edge_index in range(1, len(corners) + 1):
        points = [to_local(xyz) for _, xyz in edges[edge_index]]
        constrained = len(points) > 2
        for first, second in zip(points[:-1], points[1:]):
            if not boundary or math.dist(boundary[-1], first) > tolerance:
                boundary.append(first)
            divisions = 1 if constrained else max(1, math.ceil(math.dist(first, second) / target_size - 1e-9))
            for division in range(1, divisions + 1):
                boundary.append(tuple(first[coordinate] + division / divisions * (second[coordinate] - first[coordinate])
                                      for coordinate in range(2)))
    if math.dist(boundary[0], boundary[-1]) <= tolerance:
        boundary.pop()

    def intersection(first, second):
        parameter = first[0] / (first[0] - second[0])
        return 0.0, first[1] + parameter * (second[1] - first[1])

    clipped = []
    for first, second in zip(boundary, boundary[1:] + boundary[:1]):
        first_inside, second_inside = first[0] >= -tolerance, second[0] >= -tolerance
        if first_inside:
            clipped.append((0.0 if abs(first[0]) <= tolerance else first[0], first[1]))
        if first_inside != second_inside:
            clipped.append(intersection(first, second))
    cleaned = []
    for point in clipped:
        if not cleaned or math.dist(cleaned[-1], point) > tolerance:
            cleaned.append(point)
    if len(cleaned) > 1 and math.dist(cleaned[0], cleaned[-1]) <= tolerance:
        cleaned.pop()
    if len(cleaned) < 3:
        raise RuntimeError("The selected symmetry axis does not split the polygon into a valid half-domain")
    validate_connected_half_boundary(cleaned, boundary, tolerance)

    local_holes = [(to_local(hole_center), diameter * 0.5) for hole_center, diameter in holes]
    if any(abs(hole_center[0]) > tolerance for hole_center, _ in local_holes):
        raise RuntimeError("Axis-hole meshing requires every hole center to lie on the symmetry axis")
    ring_data = []
    for hole_index, (hole_center, radius) in enumerate(local_holes):
        boundary_clearance = min(point_segment_distance((0.0, hole_center[1], 0.0),
            (first[0], first[1], 0.0), (second[0], second[1], 0.0))
            for first, second in zip(boundary, boundary[1:] + boundary[:1])) - radius
        neighbor_clearance = min([
            (abs(hole_center[1] - other_center[1]) - radius - other_radius) * 0.5
            for other_index, (other_center, other_radius) in enumerate(local_holes) if other_index != hole_index
        ] or [float("inf")])
        available = min(boundary_clearance, neighbor_clearance)
        if available <= max(1e-10, radius * 1e-6):
            raise RuntimeError("Insufficient clearance around an axis-centered circular hole")
        outer_radius = radius + min(max(radius * 0.8, target_size * 0.5), available * 0.8)
        full_sectors = max(8, math.ceil(2 * math.pi * outer_radius / target_size - 1e-9))
        full_sectors = max(16, int(math.ceil(full_sectors / 4) * 4))
        half_sectors = full_sectors // 2
        angles = [-math.pi * 0.5 + math.pi * station / half_sectors for station in range(half_sectors + 1)]
        inner = [(radius * math.cos(angle), hole_center[1] + radius * math.sin(angle)) for angle in angles]
        outer = [(outer_radius * math.cos(angle), hole_center[1] + outer_radius * math.sin(angle)) for angle in angles]
        ring_data.append({"center": hole_center, "radius": radius, "outer_radius": outer_radius,
                          "inner": inner, "outer": outer})

    expanded = []
    axis_endpoints = [point[1] for ring in ring_data for point in (ring["outer"][0], ring["outer"][-1])]
    for first, second in zip(cleaned, cleaned[1:] + cleaned[:1]):
        expanded.append(first)
        if abs(first[0]) <= tolerance and abs(second[0]) <= tolerance:
            low, high = sorted((first[1], second[1]))
            values = [value for value in axis_endpoints if low + tolerance < value < high - tolerance]
            values.sort(reverse=second[1] < first[1])
            expanded.extend((0.0, value) for value in values)
    cleaned = expanded
    start = next((index for index, point in enumerate(cleaned) if point[0] > tolerance), 0)
    cleaned = cleaned[start:] + cleaned[:start]

    modified = [cleaned[0]]
    index = 0
    while index < len(cleaned):
        first = cleaned[index]
        second = cleaned[(index + 1) % len(cleaned)]
        matching = next((ring for ring in ring_data
                         if abs(first[0]) <= tolerance and abs(second[0]) <= tolerance and
                         min(first[1], second[1]) < ring["center"][1] < max(first[1], second[1]) and
                         (ring["outer"][0][1] - tolerance <= (first[1] + second[1]) * 0.5 <= ring["outer"][-1][1] + tolerance)), None)
        if matching is None:
            if index + 1 < len(cleaned):
                modified.append(second)
            index += 1
            continue
        increasing = second[1] > first[1]
        arc = matching["outer"] if increasing else list(reversed(matching["outer"]))
        target = arc[-1]
        modified.extend(arc[1:])
        index += 1
        while index < len(cleaned) and math.dist(cleaned[index], target) > tolerance:
            index += 1
        if index >= len(cleaned):
            raise RuntimeError("Unable to insert the semicircular O-grid into the symmetry boundary")

    refined = []
    for first, second in zip(modified, modified[1:] + modified[:1]):
        refined.append(first)
        if abs(first[0]) <= tolerance and abs(second[0]) <= tolerance:
            divisions = max(1, math.ceil(math.dist(first, second) / target_size - 1e-9))
            for division in range(1, divisions):
                refined.append((0.0, first[1] + division / divisions * (second[1] - first[1])))
    modified = refined

    gmsh.initialize()
    try:
        gmsh.option.setNumber("General.Terminal", 0)
        gmsh.model.add("sap_axis_centered_ogrid_half")
        point_tags = {}

        def point_tag(point):
            key = round(point[0], 12), round(point[1], 12)
            if key not in point_tags:
                point_tags[key] = gmsh.model.geo.addPoint(point[0], point[1], 0, target_size * 0.5)
            return point_tags[key]

        outer_curve_map = {}
        ring_entities = []
        for ring in ring_data:
            inner_tags = [point_tag(point) for point in ring["inner"]]
            outer_tags = [point_tag(point) for point in ring["outer"]]
            inner_curves = [gmsh.model.geo.addLine(inner_tags[i], inner_tags[i + 1]) for i in range(len(inner_tags) - 1)]
            outer_curves = [gmsh.model.geo.addLine(outer_tags[i], outer_tags[i + 1]) for i in range(len(outer_tags) - 1)]
            radial_curves = [gmsh.model.geo.addLine(inner_tags[i], outer_tags[i]) for i in range(len(inner_tags))]
            for i, curve in enumerate(outer_curves):
                first = tuple(round(value, 12) for value in ring["outer"][i])
                second = tuple(round(value, 12) for value in ring["outer"][i + 1])
                outer_curve_map[(first, second)] = curve
                outer_curve_map[(second, first)] = -curve
            ring_entities.append((inner_curves, outer_curves, radial_curves))

        boundary_curves = []
        for first, second in zip(modified, modified[1:] + modified[:1]):
            key = (tuple(round(value, 12) for value in first), tuple(round(value, 12) for value in second))
            boundary_curves.append(outer_curve_map.get(key) or gmsh.model.geo.addLine(point_tag(first), point_tag(second)))
        exterior_surface = gmsh.model.geo.addPlaneSurface([gmsh.model.geo.addCurveLoop(boundary_curves)])
        ring_surfaces = []
        for inner_curves, outer_curves, radial_curves in ring_entities:
            for sector in range(len(inner_curves)):
                loop = gmsh.model.geo.addCurveLoop([radial_curves[sector], outer_curves[sector],
                                                    -radial_curves[sector + 1], -inner_curves[sector]])
                ring_surfaces.append(gmsh.model.geo.addPlaneSurface([loop]))
        positive_interior = [to_local(point) for point in interior if to_local(point)[0] > tolerance]
        interior_tags = [gmsh.model.geo.addPoint(point[0], point[1], 0, target_size * 0.5) for point in positive_interior]
        gmsh.model.geo.synchronize()
        for curve in boundary_curves:
            gmsh.model.mesh.setTransfiniteCurve(abs(curve), 2)
        for inner_curves, outer_curves, radial_curves in ring_entities:
            for curve in inner_curves + outer_curves:
                gmsh.model.mesh.setTransfiniteCurve(curve, 2)
            for curve in radial_curves:
                gmsh.model.mesh.setTransfiniteCurve(curve, 3, "Progression", 1.25)
        for surface in ring_surfaces:
            gmsh.model.mesh.setTransfiniteSurface(surface)
            gmsh.model.mesh.setRecombine(2, surface)
        gmsh.model.mesh.setRecombine(2, exterior_surface)
        if interior_tags:
            gmsh.model.mesh.embed(0, interior_tags, 2, exterior_surface)
        gmsh.option.setNumber("Mesh.MeshSizeMin", target_size * 0.25)
        gmsh.option.setNumber("Mesh.MeshSizeMax", target_size)
        gmsh.option.setNumber("Mesh.Algorithm", 5)
        gmsh.option.setNumber("Mesh.RecombinationAlgorithm", 1)
        gmsh.option.setNumber("Mesh.RecombineOptimizeTopology", 100)
        gmsh.option.setNumber("Mesh.RecombineAll", 1)
        gmsh.option.setNumber("Mesh.Smoothing", 50)
        gmsh.model.mesh.generate(2)

        tags, coordinates, _ = gmsh.model.mesh.getNodes()
        half_local = {int(tag): (float(coordinates[offset]), float(coordinates[offset + 1]))
                      for tag, offset in zip(tags, range(0, len(coordinates), 3))}
        half_nodes = {tag: to_world(point) for tag, point in half_local.items()}
        half_quads, triangles, other_count = [], [], 0
        types, _, connectivity = gmsh.model.mesh.getElements(2)
        for element_type, values in zip(types, connectivity):
            _, _, _, count, _, _ = gmsh.model.mesh.getElementProperties(element_type)
            if element_type == 3:
                for offset in range(0, len(values), 4):
                    quad = tuple(int(value) for value in values[offset:offset + 4])
                    points = [half_local[tag] for tag in quad]
                    area = sum(points[i][0] * points[(i + 1) % 4][1] - points[(i + 1) % 4][0] * points[i][1] for i in range(4))
                    half_quads.append(quad if area > 0 else (quad[0], quad[3], quad[2], quad[1]))
            elif element_type == 2:
                triangles.extend(tuple(int(value) for value in values[offset:offset + 3])
                                 for offset in range(0, len(values), 3))
            else:
                other_count += len(values) // count
        paired, triangles = pair_compatible_triangles(half_nodes, triangles)
        forced_pairs, triangles = pair_all_triangles(half_nodes, triangles)
        paired.extend(forced_pairs)
        for quad in paired:
            points = [half_local[tag] for tag in quad]
            area = sum(points[i][0] * points[(i + 1) % 4][1] - points[(i + 1) % 4][0] * points[i][1] for i in range(4))
            half_quads.append(quad if area > 0 else (quad[0], quad[3], quad[2], quad[1]))
        oriented_quads = []
        for quad in half_quads:
            points = [half_local[tag] for tag in quad]
            area = sum(points[i][0] * points[(i + 1) % 4][1] - points[(i + 1) % 4][0] * points[i][1] for i in range(4))
            oriented_quads.append(quad if area > 0 else (quad[0], quad[3], quad[2], quad[1]))
        half_quads = oriented_quads
        if other_count or triangles or not half_quads:
            raise RuntimeError(f"Axis-centered O-grid conversion left {len(triangles)} triangles and {other_count} unsupported elements")
        half_protected = set()
        for inner_curves, _, _ in ring_entities:
            for curve in inner_curves:
                line_types, _, line_connectivity = gmsh.model.mesh.getElements(1, curve)
                for line_type, values in zip(line_types, line_connectivity):
                    _, _, _, count, _, _ = gmsh.model.mesh.getElementProperties(line_type)
                    for offset in range(0, len(values), count):
                        half_protected.add(tuple(sorted((int(values[offset]), int(values[offset + 1])))))
    finally:
        gmsh.finalize()

    nodes = dict(half_nodes)
    mirrored_tags = {}
    next_tag = max(nodes) + 1
    for tag, point in half_nodes.items():
        local_point = to_local(point)
        if abs(local_point[0]) <= tolerance:
            mirrored_tags[tag] = tag
        else:
            mirrored_tags[tag] = next_tag
            nodes[next_tag] = to_world((-local_point[0], local_point[1]))
            next_tag += 1
    quads = list(half_quads)
    for quad in half_quads:
        mirrored = tuple(mirrored_tags[tag] for tag in quad)
        quads.append((mirrored[0], mirrored[3], mirrored[2], mirrored[1]))
    protected_edges = set(half_protected)
    protected_edges.update(tuple(sorted((mirrored_tags[first], mirrored_tags[second])))
                           for first, second in half_protected)
    return nodes, quads, protected_edges


def element_metrics(nodes, quads, triangles):
    min_edge, max_edge, max_aspect = float("inf"), 0, 0
    min_angle, max_angle = 180, 0
    for element in list(quads) + list(triangles):
        points = [nodes[tag] for tag in element]
        lengths = [math.dist(points[i], points[(i + 1) % len(points)]) for i in range(len(points))]
        min_edge, max_edge = min(min_edge, min(lengths)), max(max_edge, max(lengths))
        max_aspect = max(max_aspect, max(lengths) / min(lengths))
        for i in range(len(points)):
            previous, current, following = points[(i - 1) % len(points)], points[i], points[(i + 1) % len(points)]
            a, b = subtract(previous, current), subtract(following, current)
            angle = math.degrees(math.acos(max(-1, min(1, dot(a, b) / (norm(a) * norm(b))))))
            min_angle, max_angle = min(min_angle, angle), max(max_angle, angle)
    return min_edge, max_edge, max_aspect, min_angle, max_angle


def quad_diagnostics(nodes, quads):
    metrics = element_metrics(nodes, quads, [])
    normal = polygon_normal([nodes[tag] for tag in quads[0]])
    max_skew, min_jacobian, min_oriented = 0, 1, 1
    for quad in quads:
        points = [nodes[tag] for tag in quad]
        for i in range(4):
            previous = subtract(points[(i - 1) % 4], points[i])
            following = subtract(points[(i + 1) % 4], points[i])
            length_product = norm(previous) * norm(following)
            angle = math.degrees(math.acos(max(-1, min(1, dot(previous, following) / length_product))))
            jacobian = norm(cross(previous, following)) / length_product
            oriented = dot(cross(following, previous), normal) / length_product
            max_skew = max(max_skew, abs(angle - 90))
            min_jacobian = min(min_jacobian, jacobian)
            min_oriented = min(min_oriented, oriented)
    return metrics + (max_skew, min_jacobian, min_oriented)


def mesh_reflection_matches(nodes, quads, symmetry):
    center, direction = symmetry
    direction = normalize(direction)

    def key(point):
        return tuple(round(value, 8) for value in point)

    def reflect(point):
        offset = subtract(point, center)
        projection = dot(offset, direction)
        return tuple(center[index] + 2 * projection * direction[index] - offset[index] for index in range(3))

    signatures = {tuple(sorted(key(nodes[tag]) for tag in quad)) for quad in quads}
    return all(tuple(sorted(key(reflect(nodes[tag])) for tag in quad)) in signatures for quad in quads)


def subtract(a, b):
    return tuple(a[i] - b[i] for i in range(3))


def dot(a, b):
    return sum(a[i] * b[i] for i in range(3))


def cross(a, b):
    return a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]


def norm(vector):
    return math.sqrt(dot(vector, vector))


def normalize(vector):
    length = norm(vector)
    return tuple(value / length for value in vector)


def polygon_normal(points):
    first = subtract(points[1], points[0])
    for point in points[2:]:
        candidate = cross(first, subtract(point, points[0]))
        if norm(candidate) > 1e-12:
            return normalize(candidate)
    raise RuntimeError("Degenerate polygon")


def main():
    if len(sys.argv) != 4:
        raise RuntimeError("Usage: mesher.py boundary.csv mesh.csv max_size")
    input_path, output_path, max_size = sys.argv[1], sys.argv[2], float(sys.argv[3])
    (corners, edges, interior, frames, holes, symmetry, symmetry2, force_refinement, stress_refinement,
     prefer_regular, regular_points) = read_input(input_path)
    if prefer_regular and stress_refinement:
        raise RuntimeError("Regular meshing and local refinement are mutually exclusive")
    constrained_lengths = [
        math.dist(first[1], second[1])
        for edge in edges.values() if len(edge) > 2
        for first, second in zip(edge[:-1], edge[1:])
    ]
    allowed_max = max([max_size] + constrained_lengths)
    if symmetry and symmetry2 and stress_refinement and frames and not holes:
        nodes, quads, protected_edges = generate_double_symmetric_stress_rectangle(
            corners, edges, interior, frames, symmetry, symmetry2, max_size)
        diagnostics = quad_diagnostics(nodes, quads)
        if diagnostics[1] > allowed_max * 1.001 or diagnostics[7] <= 1e-4:
            raise RuntimeError("Double-symmetric stress-refined mesh failed the geometric quality checks")
        with open(output_path, "w", newline="", encoding="ascii") as stream:
            writer = csv.writer(stream)
            for tag, xyz in nodes.items():
                writer.writerow(["N", tag, *[f"{value:.17g}" for value in xyz]])
            for quad in quads:
                writer.writerow(["E", *quad])
            for edge in sorted(protected_edges):
                writer.writerow(["F", *edge])
        print(f"Double-symmetric stress-refined rectangle: elements: {len(quads)} quadrilaterals; nodes: {len(nodes)}")
        print(f"Edge length: {diagnostics[0]:.6g}..{diagnostics[1]:.6g}; max aspect ratio: {diagnostics[2]:.3f}")
        return
    if prefer_regular and not holes:
        try:
            nodes, quads, protected_edges = generate_regular_rectangular_mesh(
                corners, edges, interior, frames, regular_points, max_size)
            diagnostics = quad_diagnostics(nodes, quads)
            if diagnostics[1] > allowed_max * 1.001 or diagnostics[7] <= 1e-4:
                raise RuntimeError("Regular aligned mesh failed the geometric quality checks")
            if symmetry and not mesh_reflection_matches(nodes, quads, symmetry):
                raise RuntimeError("Regular aligned mesh does not satisfy the primary symmetry axis")
            if symmetry2 and not mesh_reflection_matches(nodes, quads, symmetry2):
                raise RuntimeError("Regular aligned mesh does not satisfy the secondary symmetry axis")
            with open(output_path, "w", newline="", encoding="ascii") as stream:
                writer = csv.writer(stream)
                for tag, xyz in nodes.items():
                    writer.writerow(["N", tag, *[f"{value:.17g}" for value in xyz]])
                for quad in quads:
                    writer.writerow(["E", *quad])
                for edge in sorted(protected_edges):
                    writer.writerow(["F", *edge])
            print(f"Regular edge-aligned rectangle: elements: {len(quads)} quadrilaterals; nodes: {len(nodes)}")
            print(f"Edge length: {diagnostics[0]:.6g}..{diagnostics[1]:.6g}; max aspect ratio: {diagnostics[2]:.3f}")
            return
        except RuntimeError:
            pass
    if symmetry:
        candidates = []
        for factor in (1.0, 0.9, 0.8, 0.75, 0.7, 0.6, 0.5):
            try:
                if holes:
                    if symmetry2:
                        candidate_nodes, candidate_quads, protected_edges = generate_double_symmetric_with_holes(
                            corners, edges, interior, frames, holes, symmetry, symmetry2, max_size, factor,
                            stress_refinement)
                    else:
                        candidate_nodes, candidate_quads, protected_edges = generate_symmetric_with_holes(
                            corners, edges, interior, frames, holes, symmetry, max_size, factor, stress_refinement)
                else:
                    candidate_nodes, candidate_quads, protected_edges = generate_symmetric(
                        corners, edges, interior, frames, symmetry, max_size, factor
                    )
                diagnostics = quad_diagnostics(candidate_nodes, candidate_quads)
                if diagnostics[1] > allowed_max * 1.001 or diagnostics[7] <= 1e-4:
                    continue
                node_keys = {tuple(round(value, 8) for value in xyz) for xyz in candidate_nodes.values()}
                if any(tuple(round(value, 8) for value in point) not in node_keys for point in interior):
                    continue
                if symmetry2 and not mesh_reflection_matches(candidate_nodes, candidate_quads, symmetry2):
                    continue
                penalty = max(diagnostics[2] / 3, diagnostics[5] / 45, 0.5 / diagnostics[6])
                candidates.append((penalty, len(candidate_quads), factor, candidate_nodes,
                                   candidate_quads, diagnostics, protected_edges))
                if (diagnostics[2] <= 3 and diagnostics[5] <= 47.5 and diagnostics[6] >= 0.5
                        and diagnostics[3] >= 42.5 and diagnostics[4] <= 137.5):
                    break
            except Exception:
                continue
        if not candidates:
            message = "Unable to generate a valid exact-symmetric full-quad O-grid mesh" if holes else \
                "Unable to generate a valid exact-symmetric full-quad mesh"
            raise RuntimeError(message)
        _, _, selected_factor, nodes, quads, diagnostics, protected_edges = min(
            candidates, key=lambda candidate: (candidate[0], candidate[1]))
        with open(output_path, "w", newline="", encoding="ascii") as stream:
            writer = csv.writer(stream)
            for tag, xyz in nodes.items():
                writer.writerow(["N", tag, *[f"{value:.17g}" for value in xyz]])
            for quad in quads:
                writer.writerow(["E", *quad])
            for edge in sorted(protected_edges):
                writer.writerow(["F", *edge])
        mode = "Double exact-symmetric polygon" if symmetry2 else (
            "Exact-symmetric polygon with circular O-grids" if holes else "Exact-symmetric polygon")
        print(f"{mode}: {len(corners)} edges; holes: {len(holes)}; elements: {len(quads)} quadrilaterals; nodes: {len(nodes)}")
        print(f"Selected half-domain factor: {selected_factor:.2f}")
        print(f"Edge length: {diagnostics[0]:.6g}..{diagnostics[1]:.6g}; max aspect ratio: {diagnostics[2]:.3f}; "
              f"angles: {diagnostics[3]:.3f}..{diagnostics[4]:.3f}; skew: {diagnostics[5]:.3f}; min Jsc: {diagnostics[6]:.3f}")
        return
    if holes:
        candidates = []
        fallback_candidates = []
        if not interior or frames:
            boundary_segments = [(first[1], second[1]) for edge in edges.values()
                                 for first, second in zip(edge[:-1], edge[1:])]
            crosses_boundary = any(min(point_segment_distance(center, first, second)
                                       for first, second in boundary_segments) <= diameter * 0.5 + 1e-9
                                   for center, diameter in holes)
            corner_hole = len(holes) == 1 and any(math.dist(holes[0][0], corner) <= 1e-9 for corner in corners.values())
            if not frames:
                try:
                    candidate_nodes, candidate_quads, protected_edges = generate_rectangular_corner_hole(
                        corners, edges, holes, max_size
                    )
                    diagnostics = quad_diagnostics(candidate_nodes, candidate_quads)
                    if diagnostics[1] <= allowed_max * 1.001 and diagnostics[7] > 1e-4:
                        penalty = -1 if corner_hole else max(diagnostics[2] / 3, diagnostics[5] / 45, 0.5 / diagnostics[6])
                        candidates.append((penalty, len(candidate_quads), None, candidate_nodes,
                                           candidate_quads, diagnostics, protected_edges))
                except Exception:
                    pass
                try:
                    candidate_nodes, candidate_quads, protected_edges = generate_regular_plate_with_holes(
                        corners, edges, holes, max_size
                    )
                    diagnostics = quad_diagnostics(candidate_nodes, candidate_quads)
                    if diagnostics[1] <= allowed_max * 1.001 and diagnostics[7] > 1e-4:
                        penalty = max(diagnostics[2] / 3, diagnostics[5] / 45, 0.5 / diagnostics[6])
                        candidates.append((penalty, len(candidate_quads), None, candidate_nodes,
                                           candidate_quads, diagnostics, protected_edges))
                except Exception:
                    pass
        for factor in (1.0, 0.9, 0.8, 0.75, 0.7, 0.6, 0.5):
            try:
                candidate_nodes, candidate_quads, protected_edges = generate_with_holes(
                    corners, edges, interior, holes, max_size, factor,
                    frames=frames, stress_refinement=stress_refinement
                )
                diagnostics = quad_diagnostics(candidate_nodes, candidate_quads)
                if diagnostics[1] > allowed_max * 1.001 or diagnostics[7] <= 1e-4:
                    continue
                penalty = max(diagnostics[2] / 3, diagnostics[5] / 45, 0.5 / diagnostics[6])
                candidates.append((penalty, len(candidate_quads), factor, candidate_nodes,
                                   candidate_quads, diagnostics, protected_edges))
                if (diagnostics[2] <= 3 and diagnostics[5] <= 47.5 and diagnostics[6] >= 0.5
                        and diagnostics[3] >= 42.5 and diagnostics[4] <= 137.5):
                    break
            except Exception:
                continue
        if not candidates:
            if (not interior or frames) and (crosses_boundary or frames):
                for algorithm in (8, 6, 5):
                    try:
                        candidate_nodes, candidate_quads, protected_edges = generate_clipped_hole_polygon(
                            corners, edges, holes, max_size, frames, algorithm
                        )
                        diagnostics = quad_diagnostics(candidate_nodes, candidate_quads)
                        if diagnostics[1] <= allowed_max * 1.001 and diagnostics[7] > 1e-4:
                            penalty = max(diagnostics[2] / 3, diagnostics[5] / 45, 0.5 / diagnostics[6])
                            fallback_candidates.append((penalty, len(candidate_quads), None, candidate_nodes,
                                                        candidate_quads, diagnostics, protected_edges))
                            if (diagnostics[2] <= 3 and diagnostics[5] <= 45 and diagnostics[6] >= 0.5
                                    and diagnostics[3] >= 45 and diagnostics[4] <= 135):
                                break
                    except Exception:
                        continue
            candidates = fallback_candidates
        if not candidates:
            raise RuntimeError("Unable to generate a valid full-quad circular O-grid mesh")
        _, _, selected_factor, nodes, quads, diagnostics, protected_edges = min(
            candidates, key=lambda candidate: (candidate[0], candidate[1])
        )
        node_keys = {tuple(round(value, 8) for value in xyz) for xyz in nodes.values()}
        missing_constraints = sum(tuple(round(value, 8) for value in point) not in node_keys for point in interior)
        if missing_constraints:
            raise RuntimeError(f"{missing_constraints} constrained interior points were not embedded")
        with open(output_path, "w", newline="", encoding="ascii") as stream:
            writer = csv.writer(stream)
            for tag, xyz in nodes.items():
                writer.writerow(["N", tag, *[f"{value:.17g}" for value in xyz]])
            for quad in quads:
                writer.writerow(["E", *quad])
            for edge in sorted(protected_edges):
                writer.writerow(["F", *edge])
        mode = ("Frame-conforming refined circular-hole fallback" if selected_factor is None and frames else
                "Structured square-block O-grids" if selected_factor is None else "Polygon with circular O-grids")
        print(f"{mode}: {len(corners)} edges; holes: {len(holes)}; protected chords: {len(protected_edges)}")
        print(f"Elements: {len(quads)} quadrilaterals, 0 triangles; nodes: {len(nodes)}")
        if selected_factor is not None:
            print(f"Selected base factor: {selected_factor:.2f}")
        print(f"Edge length: {diagnostics[0]:.6g}..{diagnostics[1]:.6g}; max aspect ratio: {diagnostics[2]:.3f}; "
              f"angles: {diagnostics[3]:.3f}..{diagnostics[4]:.3f}; skew: {diagnostics[5]:.3f}; min Jsc: {diagnostics[6]:.3f}")
        return
    if frames:
        candidates = []
        failures = []
        attempts = [(8, factor) for factor in (2.0, 1.8, 1.6, 1.5, 1.4, 1.3, 1.2, 1.1, 1.0, 0.9, 0.8, 0.7, 0.6, 0.5)]
        attempts.extend((5, factor) for factor in (1.0, 0.75, 0.5))
        for algorithm, factor in attempts:
            if candidates:
                break
            try:
                candidate_nodes, candidate_quads, protected_edges = generate_with_frames(
                    corners, edges, interior, frames, max_size, factor, stress_refinement, algorithm
                )
                diagnostics = quad_diagnostics(candidate_nodes, candidate_quads)
                if diagnostics[1] > allowed_max * 1.001 or diagnostics[7] <= 1e-4:
                    failures.append(f"algorithm {algorithm}, factor {factor:.2f}: max edge {diagnostics[1]:.6g} "
                                    f"(allowed {allowed_max:.6g}), minimum oriented Jacobian {diagnostics[7]:.6g}")
                    continue
                penalty = max(diagnostics[2] / 3, diagnostics[5] / 45, 0.5 / diagnostics[6])
                candidates.append((penalty, len(candidate_quads), factor, candidate_nodes,
                                   candidate_quads, diagnostics, protected_edges))
                if (diagnostics[2] <= 3 and diagnostics[5] <= 47.5 and diagnostics[6] >= 0.5
                        and diagnostics[3] >= 42.5 and diagnostics[4] <= 137.5):
                    break
            except Exception as exception:
                failures.append(f"algorithm {algorithm}, factor {factor:.2f}: {exception}")
                continue
        if not candidates:
            detail = "; ".join(failures[-3:])
            raise RuntimeError("Unable to generate a full-quad mesh conforming to the selected frames" +
                               (f". Last attempts: {detail}" if detail else ""))
        _, _, selected_factor, nodes, quads, diagnostics, protected_edges = min(
            candidates, key=lambda candidate: (candidate[0], candidate[1])
        )
        node_keys = {tuple(round(value, 8) for value in xyz) for xyz in nodes.values()}
        missing_constraints = sum(tuple(round(value, 8) for value in point) not in node_keys for point in interior)
        if missing_constraints:
            raise RuntimeError(f"{missing_constraints} constrained interior points were not embedded")
        with open(output_path, "w", newline="", encoding="ascii") as stream:
            writer = csv.writer(stream)
            for tag, xyz in nodes.items():
                writer.writerow(["N", tag, *[f"{value:.17g}" for value in xyz]])
            for quad in quads:
                writer.writerow(["E", *quad])
            for edge in sorted(protected_edges):
                writer.writerow(["F", *edge])
        print(f"Polygon with frames: {len(corners)} edges; constraining frames: {len(frames)}; meshed frame segments: {len(protected_edges)}")
        print(f"Elements: {len(quads)} quadrilaterals, 0 triangles; nodes: {len(nodes)}")
        print(f"Selected base factor: {selected_factor:.2f}")
        print(f"Edge length: {diagnostics[0]:.6g}..{diagnostics[1]:.6g}; max aspect ratio: {diagnostics[2]:.3f}; "
              f"angles: {diagnostics[3]:.3f}..{diagnostics[4]:.3f}; skew: {diagnostics[5]:.3f}; min Jsc: {diagnostics[6]:.3f}")
        return

    best_mixed = None
    best_mixed_factor = None
    selected = None
    selected_factor = None
    selected_full_quad = False
    for factor in (0.75, 0.70, 0.65, 0.60, 0.55, 0.50):
        try:
            candidate_nodes, candidate_quads, candidate_triangles = generate(
                corners, edges, interior, max_size, factor, full_quad_mode=False, force_refinement=force_refinement
            )
            candidate_metrics = element_metrics(candidate_nodes, candidate_quads, candidate_triangles)
            if candidate_metrics[1] > allowed_max * 1.001:
                continue
            candidate = (candidate_nodes, candidate_quads, candidate_triangles, candidate_metrics)
            if best_mixed is None or len(candidate_triangles) < len(best_mixed[2]):
                best_mixed = candidate
                best_mixed_factor = factor
            if not candidate_triangles:
                selected, selected_factor = candidate, factor
                break
        except Exception:
            continue
    if selected is None and all(len(edge) == 2 for edge in edges.values()):
        candidate_nodes, candidate_quads, candidate_triangles = generate(
            corners, edges, interior, max_size, 0.75, full_quad_mode=True, force_refinement=force_refinement
        )
        candidate_metrics = element_metrics(candidate_nodes, candidate_quads, candidate_triangles)
        if candidate_metrics[1] <= allowed_max * 1.001 and not candidate_triangles:
            selected, selected_factor = (candidate_nodes, candidate_quads, candidate_triangles, candidate_metrics), 0.75
            selected_full_quad = True
    if selected is None:
        selected = best_mixed
        selected_factor = best_mixed_factor
    if selected is None:
        raise RuntimeError(f"Unable to generate a mesh within the maximum size compatible with constrained edges: {allowed_max:.6g}")
    nodes, quads, triangles, metrics = selected

    node_keys = {tuple(round(value, 8) for value in xyz) for xyz in nodes.values()}
    missing_constraints = sum(tuple(round(value, 8) for value in point) not in node_keys for point in interior)
    if missing_constraints:
        raise RuntimeError(f"{missing_constraints} constrained interior points were not embedded")

    with open(output_path, "w", newline="", encoding="ascii") as stream:
        writer = csv.writer(stream)
        for tag, xyz in nodes.items():
            writer.writerow(["N", tag, *[f"{value:.17g}" for value in xyz]])
        for element in quads:
            writer.writerow(["E", *element])
        for element in triangles:
            writer.writerow(["E", *element])
    full_quad = selected_full_quad
    target_size = max_size * (selected_factor if selected_factor is not None else 0.5)
    boundary_intervals = sum(
        1 if len(edge) > 2 else (
            lambda divisions: divisions + divisions % 2 if full_quad else divisions
        )(max(1, math.ceil(math.dist(a[1], b[1]) / target_size - 1e-9)))
        for edge in edges.values() for a, b in zip(edge[:-1], edge[1:])
    )
    print(f"Polygon: {len(corners)} edges; boundary intervals: {boundary_intervals}; interior constraints: {len(interior)}")
    print(f"Elements: {len(quads)} quadrilaterals, {len(triangles)} triangles; nodes: {len(nodes)}")
    if selected_factor is not None:
        print(f"Selected interior size: {selected_factor * max_size:.6g} ({selected_factor:.2f} times the requested size).")
    print(f"Edge length: {metrics[0]:.6g}..{metrics[1]:.6g}; max aspect ratio: {metrics[2]:.3f}; angles: {metrics[3]:.3f}..{metrics[4]:.3f}")
    if allowed_max > max_size * 1.001:
        print(f"Note: requested limit {max_size:.6g} exceeded on constrained edges; only selected points were retained (maximum interval {allowed_max:.6g}).")


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
