# SAP2000 Quad Mesher

Lo scopo principale di questo progetto e **mostrare, con un esempio funzionante, come integrare SAP2000 con altri programmi per rendere piu efficace il proprio lavoro**. Il plugin collega C#/.NET, l'API di SAP2000 e Python/Gmsh per automatizzare la creazione di mesh quad-dominant su aree piane. Illustra metodi, procedure e potenzialita dell'integrazione tra software di terze parti: il suo valore prevalente e didattico.

La **1.0.79 è stata la prima versione destinata agli utenti**; la 1.0.80 ha introdotto la congruenza dei bordi raffittiti e un solo import FAST multi-area, la 1.0.81 ha corretto i fallback regolari e i piccoli fori condivisi, e la 1.0.82 ha aggiunto annullamento e misure con suffissi `m`, `cm`, `mm`, `ft`, `in`. Dalla 1.0.83 FAST e preselezionato ma facoltativo; la 1.0.84 aggiunge automaticamente la voce del plugin nel menu Tools di SAP2000 27 durante l'installazione. La 1.0.85 corregge l'import FAST nei modelli con triangoli o shell poligonali preesistenti. La **1.0.87** aggiunge nodi congruenti sul bordo di mesh adiacenti, gestione FAST dei triangoli generati e candidati Gmsh multicore con numero di worker configurabile. La **1.0.88** evita maglie oblunghe su aree nulle sovrapposte; la **1.0.89** corregge Undo FAST per poligoni, aggiunge backup numerati e riduce il sovra-raffittimento della mesh su geometrie triangolari e poligonali. Le versioni prima della 1.0.79 erano build di sviluppo e di prova, anche quando temporaneamente scaricabili su GitHub. Il plugin è utilizzabile, ma risultati e modelli devono essere verificati dall'utente nel proprio contesto tecnico. Il progetto principale e in [`SapQuadTransitionPlugin`](SapQuadTransitionPlugin/README.md).

## Stato del progetto

La **1.0.97** mostra l'aggiornamento disponibile su due righe centrate nella finestra del plugin. La 1.0.96 ripristina l'opzione della dimensione massima vincolante dopo «Annulla mesh»; la 1.0.95 ha introdotto la fascia globale fitta sulle solette radiali, la memoria delle ultime opzioni e l'anteprima con SAP2000 utilizzabile. Il riconoscimento si basa sulla geometria, non sul nome del modello; la tolleranza esplicita sugli spigoli nuovi rimane configurabile. Tutti i 36 esempi di regressione SAP2000 sono passati nella build 1.0.95.

La **1.0.101** corregge le mesh di solette radiali a 60 e 70 cm, anche con dimensione massima vincolante. Rende selezionabile la mesh regolare nel profilo Acciaio: su `Nodo_2` produce 128 quadrilateri cartesiani di 10 cm, oppure 1.653 quadrilateri con passo vincolante di 30 mm, senza nodi sospesi sulle intersezioni ortogonali.

La build locale di prova **1.0.102** dispone tre comandi nella finestra: Genera/Applica, Qualita della mesh e Annulla mesh. Applica mantiene la finestra aperta per ispezionare o ingrandire la mesh in SAP2000 e consente di annullarla finche la finestra resta aperta.

La build locale di prova **1.0.103** applica subito la mesh eliminando gli originali dal modello in memoria; uno snapshot CSV locale conserva coordinate e assegnazioni per consentire **Annulla mesh** anche dopo Applica, mentre lo zoom SAP2000 rimane utilizzabile.

La build locale di prova **1.0.104** protegge la congruenza dei lati condivisi nelle mesh di `Multiple_Silo_Slab` a 0,5 m, mantenendo le stazioni prodotte dalle aree gia elaborate durante le transizioni rettangolari e le mesh con telai. La proposta di organizzazione delle opzioni e del report di qualita e in `docs/PROPOSTA_INTERFACCIA_E_QUALITA_MESH.md`; non modifica ancora l'interfaccia.

La build locale di prova **1.0.105** riordina le opzioni in **Mesh | Fori | Avanzate** con riepilogo della selezione e tre modalita radio esclusive. Se occorre confrontarla con la schermata precedente, il layout classico resta disponibile impostando `SAP_QUAD_OPTIONS_LAYOUT=legacy` prima dell'avvio di SAP2000. La proposta di report globale non e ancora applicata.

La build locale di prova **1.0.106** prova automaticamente strategie alternative quando quella richiesta non produce una mesh, preservando nodi, telai, fori e dimensione massima. Confronta numero di elementi, triangoli e qualita; dopo la generazione indica le opzioni effettivamente utilizzate e gli eventuali avvisi di qualita. Il modello SAP2000 aperto non viene modificato durante il confronto dei candidati.

La build locale di prova **1.0.107** estende la simmetria esatta alle strategie non regolari su selezioni di piu aree e presenta una qualita complessiva mediata per superficie su tutti gli elementi generati, lasciando dimensione e orientamento come controlli vincolanti. Le schede si chiamano **Opzioni della mesh | Fori e Aperture | Opzioni Avanzate** (con traduzioni inglesi). I testi italiani correnti da revisionare sono in [`docs/CATALOGO_OPZIONI_E_TOOLTIP_IT.md`](docs/CATALOGO_OPZIONI_E_TOOLTIP_IT.md); il criterio tecnico della qualita e in [`docs/QUALITA_MESH_AGGREGATA.md`](docs/QUALITA_MESH_AGGREGATA.md). Il profilo materiale conserva per ora il comportamento esistente.

La build locale di prova **1.0.108** applica alla finestra le correzioni italiane dell'autore registrate in [`docs/CATALOGO_OPZIONI_E_TOOLTIP_IT.md`](docs/CATALOGO_OPZIONI_E_TOOLTIP_IT.md) e aggiorna le etichette e i tooltip inglesi. Nell'interfaccia italiana gli oggetti frame sono chiamati "Frame"; le descrizioni delle strategie, della simmetria e della suddivisione degli spigoli con nodi selezionati sono piu esplicite.

La build locale di prova **1.0.109** aggiunge un **Report sugli elementi creati** con i totali effettivi del modello dopo la mesh: aree e tipo di area, frame, link e nodi. I conteggi dell'anteprima escludono gli originali conservati per Annulla; dopo Applica sono aggiornati e dopo Annulla torna la selezione iniziale.

Nella build locale **1.0.110** il report sostituisce la selezione nel medesimo riquadro, senza ridurre lo spazio delle schede. Il recupero automatico prova prima l'inserimento di nodi sugli spigoli con nodi selezionati e mostra l'opzione effettivamente utilizzata. Gli errori del generatore rispettano la lingua selezionata.

La build locale **1.0.111** rende la finestra del plugin richiamabile dalla barra delle applicazioni e prova a riabilitare la finestra SAP2000 durante l'anteprima; la navigazione SAP2000 restava comunque bloccata finché il comando del plugin era in corso. La raccolta locale dei modelli usati per i test si crea sul Desktop con `tools/CollectRegressionModels.ps1`.

La build locale **1.0.112** restituisce a SAP2000 il controllo del comando del plugin mentre l'anteprima resta aperta: questo consente al viewport di elaborare realmente zoom, pan e cambi di vista prima di Applica.

La build locale **1.0.113** mantiene la finestra del plugin in primo piano mentre si naviga nel viewport SAP2000 visibile intorno alla finestra, con l'anteprima ancora da confermare.

La build locale **1.0.114** chiude automaticamente il solo avviso nativo SAP2000 «Plugin completed successfully.» emesso quando il plugin restituisce il controllo al viewport, lasciando aperta l'anteprima della mesh.

La **1.0.115** distribuisce le modifiche verificate delle build locali 1.0.102–1.0.114 e rimuove i link esterni CUBIT e COMSOL dal report della qualita della mesh, mantenendo metriche e intervalli di riferimento.

La build locale di prova **1.0.116** abilita Annulla generazione appena parte l'operazione, anche prima dello snapshot, e offre un comando di annullamento indipendente e reattivo nelle elaborazioni multi-area lunghe.

La build locale di prova **1.0.117** aggiunge una guida offline illustrata in italiano e inglese: F1 o il pulsante ? della finestra aprono la lingua selezionata. La guida include schermate delle tre schede ed esempi SAP2000 prima/dopo in SVG con nodi e frame vincolanti evidenziati. Il plugin mostra un'icona Quad Mesher dedicata nella barra delle applicazioni.

La **1.0.118** recepisce le revisioni dell'autore alla guida italiana, le riporta nella guida inglese e allinea verticalmente i testi del piè di pagina del plugin. Le etichette e i documenti correnti mostrano solo il numero di versione.

Questa e la copia di progetto ripulita del workspace storico. Contiene il plugin, utility sperimentali, modelli SAP2000, fixture e risultati di test; build, cache e release storiche sono escluse dal controllo versione. Le fixture SAP2000 sono gestite con Git LFS.

Documentazione di continuita:

- [`docs/PROJECT_STATUS.md`](docs/PROJECT_STATUS.md): stato funzionale e tecnico verificato.
- [`docs/DEVELOPMENT.md`](docs/DEVELOPMENT.md): ambiente, build e strategia di test.
- [`docs/MIGRATION_AND_RELEASE.md`](docs/MIGRATION_AND_RELEASE.md): trasferimento, GitHub e packaging.
- [`docs/UPDATES.md`](docs/UPDATES.md): manifest GitHub, notifica aggiornamenti e procedura di pubblicazione.
- [`docs/MULTICORE_PERFORMANCE_1_0_87.md`](docs/MULTICORE_PERFORMANCE_1_0_87.md): 36 regressioni v1.0.87 e confronto controllato del backend multicore.
- [`SapQuadTransitionPlugin/README.md`](SapQuadTransitionPlugin/README.md): uso del plugin e comportamento delle mesh.

## Verifica rapida

Dal root del progetto:

```cmd
dotnet build SapQuadTransitionPlugin\SapQuadTransitionPlugin.csproj -c Release
python -c "import gmsh; print(gmsh.__version__)"
```

Verifica storica della fase di sviluppo, eseguita il 24 settembre 2026:

- compilazione Release completata con 0 warning e 0 errori;
- Python 3.12.7;
- Gmsh 4.15.2;
- SAP2000 27 interop disponibile localmente.

Il pacchetto binario include un runtime Python 3.12 privato e Gmsh 4.15.2. L'utente finale non deve installare Python, Gmsh o pacchetti `pip`.

## Avvertenza

`SAP2000v1.dll` non fa parte del progetto e non deve essere pubblicata o inclusa nei pacchetti. Le fixture SAP2000 presenti sono state dichiarate pubblicabili dal loro autore, ma sono escluse dal pacchetto binario del plugin.

## Licenza

Il [codice originale](LICENSE-APPLICATION.md) e GPL-2.0-or-later (`SPDX-License-Identifier: GPL-2.0-or-later`). `LICENSE` contiene GPLv2, `GPL-3.0.txt` GPLv3; per il backend binario combinato con OpenSSL 3 si sceglie l'opzione GPLv3. [Questa nota](SAP2000-LINKING-EXCEPTION.md) riguarda esclusivamente il codice C# dell'autore, **non concede diritti sull'API SAP2000 o su Gmsh**: i termini dei terzi sono in [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md). Gli archivi sorgenti sono allegati alla [release corrente](https://github.com/leonardobandini/sap2000-quad-mesher-updates/releases/latest) e conservati nell'[archivio pubblico dei sorgenti](https://github.com/leonardobandini/sap2000-quad-mesher-updates/tree/source-archive) dopo la sostituzione delle release di prova.
