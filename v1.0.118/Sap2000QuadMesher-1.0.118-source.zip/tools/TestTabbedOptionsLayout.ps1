# Copyright (C) 2026 Leonardo Bandini
# SPDX-License-Identifier: GPL-2.0-or-later
param(
    [string]$Plugin = (Join-Path (Split-Path -Parent $PSScriptRoot) 'SapQuadTransitionPlugin\bin\Release\net48\SapQuadTransitionPlugin.dll'),
    [ValidateSet('Modern','Legacy')][string]$Layout = 'Modern',
    [string]$ScreenshotPath = '',
    [ValidateSet('Mesh','Holes','Advanced')][string]$ScreenshotPage = 'Mesh',
    [ValidateSet('Italiano','English')][string]$ScreenshotLanguage = 'Italiano'
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -Path 'C:\Program Files\Computers and Structures\SAP2000 27\SAP2000v1.dll'
$priorSettings = $env:SAP_QUAD_SETTINGS_PATH
$priorLayout = $env:SAP_QUAD_OPTIONS_LAYOUT
$priorManifest = $env:SAP_QUAD_TEST_UPDATE_MANIFEST_JSON
$env:SAP_QUAD_SETTINGS_PATH = Join-Path $env:TEMP ('opencode\sqm-tab-layout-' + [Guid]::NewGuid().ToString('N') + '.json')
$env:SAP_QUAD_OPTIONS_LAYOUT = if ($Layout -eq 'Legacy') { 'legacy' } else { $null }
$env:SAP_QUAD_TEST_UPDATE_MANIFEST_JSON = '{}'
try {
    if (-not (Test-Path -LiteralPath (Split-Path -Parent $env:SAP_QUAD_SETTINGS_PATH))) { throw 'Missing temporary test directory.' }
    $assembly = [Reflection.Assembly]::LoadFrom((Resolve-Path -LiteralPath $Plugin).Path)
    $type = $assembly.GetType('SapQuadTransitionPlugin.cPlugin+MeshOptionsDialog', $true)
    $axis = $assembly.GetType('SapQuadTransitionPlugin.cPlugin+SymmetryAxis', $true)
    $constructor = @($type.GetConstructors([Reflection.BindingFlags]'Instance,Public,NonPublic') |
        Where-Object { $_.GetParameters().Count -eq 6 })[0]
    $dialog = $constructor.Invoke([object[]]@('m', $true, [string[]]@('FORO'),
        [string[]]@('APERTURA'), [Array]::CreateInstance($axis, 0), $true))
    try {
        $dialog.SetSelectionCounts(6, 4, 1, 1, 75, 2, 98)
        $dialog.Show()
        $pluginDirectory = Split-Path -Parent (Resolve-Path -LiteralPath $Plugin).Path
        if (-not $dialog.HelpButton -or -not (Test-Path (Join-Path $pluginDirectory 'img\quad-mesher.ico'))) {
            throw 'The title-bar help button or plugin taskbar icon is missing.'
        }
        $helpPath = $assembly.GetType('SapQuadTransitionPlugin.cPlugin').GetMethod(
            'HelpPath', [Reflection.BindingFlags]'Static,NonPublic')
        foreach ($italian in @($true, $false)) {
            $guide = [string]$helpPath.Invoke($null, [object[]]@($italian))
            if (-not (Test-Path -LiteralPath $guide) -or
                (Split-Path -Leaf $guide) -ne $(if ($italian) { 'index-it.html' } else { 'index-en.html' })) {
                throw "The bilingual help route is missing: $guide"
            }
        }
        $flags = [Reflection.BindingFlags]'Instance,NonPublic'
        function Field($name) { $type.GetField($name, $flags).GetValue($dialog) }
        (Field 'language').SelectedIndex = 1
        $profiles = Field 'profiles'
        $tabs = Field 'optionTabs'
        $buttons = @($dialog.Controls | Where-Object { $_ -is [Windows.Forms.Button] })
        $licenseFooter = @($dialog.Controls | Where-Object { $_.Tag -eq 'license-link' })[0]
        $versionFooter = @($dialog.Controls | Where-Object { $_.Tag -eq 'version' })[0]
        $noticeFooter = Field 'updateNotice'
        $footerCenters = @($licenseFooter, $versionFooter, $noticeFooter | ForEach-Object { $_.Top + $_.Height / 2 })
        $footerSpan = $footerCenters | Measure-Object -Maximum -Minimum
        if ($footerCenters.Count -ne 3 -or $footerSpan.Maximum - $footerSpan.Minimum -gt 1 -or
            $licenseFooter.TextAlign -ne [Drawing.ContentAlignment]::MiddleLeft -or
            $versionFooter.TextAlign -ne [Drawing.ContentAlignment]::MiddleRight -or
            $noticeFooter.TextAlign -ne [Drawing.ContentAlignment]::MiddleCenter -or
            $versionFooter.Text -match 'beta' -or (Field 'headerSubtitle').Text -match 'beta') {
            throw 'Footer labels are not vertically aligned or current interface still says beta.'
        }
        if ($buttons.Count -ne 3) { throw 'The persistent three-command footer changed.' }
        if ($Layout -eq 'Legacy') {
            if ($dialog.ModernLayout -or -not $profiles.Visible -or $tabs.Parent -ne $null -or
                (Field 'selectionSummary').Parent -ne $null -or
                (Field 'size').Parent -ne $dialog) { throw 'The reversible legacy layout changed.' }
            'LEGACY_OPTIONS_LAYOUT=PASS'
            return
        }
        $summary = Field 'selectionSummary'
        $areas = Field 'areaSelection'
        $objects = Field 'objectSelection'
        if (-not $dialog.ModernLayout -or $profiles.Visible -or -not $summary.Visible -or
            $tabs.TabPages.Count -ne 3 -or $tabs.SelectedIndex -ne 0 -or
            ($tabs.TabPages | ForEach-Object Text) -join ',' -ne 'Opzioni della mesh,Fori e Aperture,Opzioni Avanzate' -or
            $areas.Text -notmatch 'Aree: 6.*Quadrangolari: 4.*Triangolari: 1.*Poligonali: 1' -or
            $objects.Text -notmatch 'Frame: 75.*Link: 2.*Nodi: 98' -or
            [Windows.Forms.TextRenderer]::MeasureText($areas.Text, $areas.Font).Width -gt $areas.Width) {
            throw 'Selection summary or three task tabs missing or clipped.'
        }
        if ((Field 'size').Parent -ne $tabs.TabPages[0] -or
            (Field 'generateHoles').Parent -ne $tabs.TabPages[1] -or
            (Field 'fastMode').Parent -ne $tabs.TabPages[2]) { throw 'An option is on the wrong page.' }
        $tips = Field 'measurementToolTip'
        if ((Field 'strictMaximumSize').Text -ne 'Inserisci nodi di mesh anche negli spigoli con nodi selezionati' -or
            (Field 'regularMode').Text -ne 'Regolare/Allineata' -or
            (Field 'symmetric').Text -ne 'Imponi simmetria' -or
            (Field 'structuredSectorBands').Text -ne 'Prediligi elementi quadrangolari disposti a fasce radiali e pseudo-radiali' -or
            (Field 'generateHoles').Text -ne 'Genera aperture racchiuse da frame o bordi shell selezionati' -or
            $tips.GetToolTip((Field 'standardMode')) -notmatch 'senza allineamento forzato' -or
            $tips.GetToolTip((Field 'regularMode')) -notmatch 'assi preferenziali' -or
            $tips.GetToolTip((Field 'refinedMode')) -notmatch 'concentrazione di tensione' -or
            $tips.GetToolTip((Field 'symmetric')) -notmatch 'due assi selezionati' -or
            $tips.GetToolTip((Field 'edgeTolerance')) -notmatch 'restano presenti' -or
            $tips.GetToolTip((Field 'strictMaximumSize')) -notmatch 'vengono creati nuovi nodi' -or
            $tips.GetToolTip((Field 'structuredSectorBands')) -notmatch 'geometrie compatibili') {
            throw 'A revised Italian option label or tooltip is missing.'
        }
        foreach ($name in @('standardMode', 'regularMode', 'refinedMode', 'strictMaximumSize', 'structuredSectorBands')) {
            $control = Field $name
            if ([Windows.Forms.TextRenderer]::MeasureText($control.Text, $control.Font).Width + 24 -gt $control.Width) {
                throw "Option label clipped: $name"
            }
        }
        (Field 'language').SelectedIndex = 0
        if (($tabs.TabPages | ForEach-Object Text) -join ',' -ne 'Mesh Options,Holes and Openings,Advanced Options' -or
            (Field 'regularMode').Text -ne 'Regular / Aligned' -or
            (Field 'symmetric').Text -ne 'Enforce symmetry' -or
            (Field 'generateHoles').Text -ne 'Generate openings enclosed by selected frames or shell edges' -or
            $tips.GetToolTip((Field 'regularMode')) -notmatch 'preferred axes' -or
            $tips.GetToolTip((Field 'strictMaximumSize')) -notmatch 'selected joints') {
            throw 'Revised English option labels or tooltips did not update.'
        }
        (Field 'language').SelectedIndex = 1
        $inventoryType = $assembly.GetType('SapQuadTransitionPlugin.cPlugin+MeshInventory', $true)
        $after = $inventoryType.GetConstructors([Reflection.BindingFlags]'Instance,Public,NonPublic')[0].Invoke(
            [object[]]@(2320, 2300, 19, 1, 75, 2, 2500))
        $dialog.SetGeneratedInventory($after)
        $dialog.SetInsertEdgeNodes($true)
        if (-not (Field 'strictMaximumSize').Checked -or (Field 'edgeTolerance').Enabled) {
            throw 'Automatic edge-node fallback is not reflected in the visible option.'
        }
        if ((Field 'selectionHeader').Text -ne 'Report sugli elementi creati' -or
            $areas.Text -notmatch 'Aree: 2320.*Quadrangolari: 2300.*Triangolari: 19.*Poligonali: 1' -or
            $objects.Text -notmatch 'Frame: 75.*Link: 2.*Nodi: 2500' -or
            $summary.Height -ne 60 -or $tabs.Top -ne 153 -or $tabs.Height -ne 420 -or
            [Windows.Forms.TextRenderer]::MeasureText($areas.Text, $areas.Font).Width -gt $areas.Width -or
            $tips.GetToolTip($objects) -notmatch 'link presenti nel modello') {
            throw 'The post-mesh inventory did not replace the selection in the same space.'
        }
        (Field 'language').SelectedIndex = 0
        if ((Field 'selectionHeader').Text -ne 'Objects after meshing' -or
            $objects.Text -notmatch 'Frames: 75.*Links?: 2.*Joints: 2500') {
            throw 'The post-mesh inventory did not update its language.'
        }
        (Field 'language').SelectedIndex = 1
        $localizeError = $assembly.GetType('SapQuadTransitionPlugin.cPlugin').GetMethod(
            'LocalizeErrorMessage', [Reflection.BindingFlags]'Static,NonPublic')
        $localized = [string]$localizeError.Invoke($null, [object[]]@(
            'Area 8: Mesh generator: Traceback (most recent call last):' + "`n" +
            '  File "mesher.py", line 774' + "`n" +
            'RuntimeError: Regular aligned meshing requires a rectangular area'))
        if ($localized -ne "Area 8: Generatore mesh: La mesh regolare allineata richiede un'area rettangolare") {
            throw "The Italian generation error contains untranslated traceback: $localized"
        }
        $type.GetMethod('ResetReady', $flags).Invoke($dialog, @())
        if ((Field 'selectionHeader').Text -ne "Selezione all'apertura" -or $summary.Height -ne 60 -or
            $tabs.Top -ne 153 -or $tabs.Height -ne 420 -or
            $areas.Text -notmatch 'Aree: 6' -or $objects.Text -notmatch 'Nodi: 98') {
            throw 'Undo did not restore the original selection summary and layout.'
        }
        if (-not (Field 'standardMode').Checked) { throw 'Standard must represent the default unselected strategy.' }
        (Field 'refinedMode').Checked = $true
        if (-not (Field 'stressRefinement').Checked -or (Field 'preferRegular').Checked) { throw 'Refinement radio did not select only refinement.' }
        (Field 'standardMode').Checked = $true
        if ((Field 'stressRefinement').Checked -or (Field 'preferRegular').Checked) { throw 'Standard radio did not clear both optional strategies.' }
        (Field 'preset').SelectedIndex = 1
        if ($profiles.SelectedIndex -ne 1 -or -not (Field 'stressRefinement').Checked -or -not (Field 'regularMode').Enabled) {
            throw 'Steel preset did not retain its selectable defaults.'
        }
        (Field 'regularMode').Checked = $true
        if (-not (Field 'preferRegular').Checked -or (Field 'stressRefinement').Checked) { throw 'Regular radio did not clear refinement.' }
        (Field 'preset').SelectedIndex = 0
        if ((Field 'refinedMode').Enabled -or -not (Field 'preferRegular').Checked) { throw 'Concrete preset compatibility changed.' }
        (Field 'preset').SelectedIndex = 2
        (Field 'strictMaximumSize').Checked = $false
        (Field 'edgeTolerance').Value = 19
        (Field 'strictMaximumSize').Checked = $true
        if ((Field 'edgeTolerance').Value -ne 0 -or (Field 'edgeTolerance').Enabled) { throw 'Strict sizing did not zero tolerance.' }
        $tabs.SelectedIndex = 1
        (Field 'generateHoles').Checked = $true
        (Field 'generateCircularHoles').Checked = $true
        if (-not (Field 'openingGroup').Enabled -or -not (Field 'holeGroup').Enabled -or
            -not (Field 'holeDiameter').Enabled) { throw 'Hole-group dependencies changed.' }
        $tabs.SelectedIndex = 2
        (Field 'useMaximumCores').Checked = $false
        if (-not (Field 'workerLimit').Enabled -or -not (Field 'fastMode').Checked -or
            -not (Field 'createBackup').Checked -or (Field 'status').Parent -ne $dialog -or
            (Field 'createdElements').Parent -ne $dialog) { throw 'Advanced options or persistent status changed.' }
        $dialog.BeginWork('Generating and optimizing the mesh...')
        if ($tabs.Enabled -or -not (Field 'undo').Enabled) { throw 'Working-state cancellation is unavailable.' }
        $dialog.Cancelled()
        if (-not $tabs.Enabled -or -not (Field 'workerLimit').Enabled) { throw 'Tabs did not recover after cancellation.' }
        if ($ScreenshotPath) {
            if (-not (Test-Path -LiteralPath (Split-Path -Parent $ScreenshotPath))) { throw 'Screenshot parent missing.' }
            (Field 'language').SelectedIndex = if ($ScreenshotLanguage -eq 'Italiano') { 1 } else { 0 }
            $type.GetMethod('ApplyLanguage', $flags).Invoke($dialog, @()) | Out-Null
            (Field 'status').Text = if ($ScreenshotLanguage -eq 'Italiano') { 'Pronto.' } else { 'Ready.' }
            $tabs.SelectedIndex = @{ Mesh = 0; Holes = 1; Advanced = 2 }[$ScreenshotPage]
            $dialog.TopMost = $true
            $dialog.BringToFront()
            $dialog.Activate()
            [Windows.Forms.Application]::DoEvents()
            Start-Sleep -Milliseconds 500
            $image = New-Object System.Drawing.Bitmap($dialog.Bounds.Width, $dialog.Bounds.Height)
            try {
                $graphics = [Drawing.Graphics]::FromImage($image)
                try {
                    $graphics.CopyFromScreen($dialog.Bounds.Location, [Drawing.Point]::Empty, $image.Size)
                } finally { $graphics.Dispose() }
                $image.Save($ScreenshotPath, [Drawing.Imaging.ImageFormat]::Png)
            } finally { $image.Dispose() }
            "SCREENSHOT=$ScreenshotPath"
        }
        'MODERN_OPTIONS_LAYOUT=PASS SELECTION=PASS RADIOS=PASS HOLES=PASS ADVANCED=PASS'
    } finally { $dialog.Close(); $dialog.Dispose() }
} finally {
    $env:SAP_QUAD_SETTINGS_PATH = $priorSettings
    $env:SAP_QUAD_OPTIONS_LAYOUT = $priorLayout
    $env:SAP_QUAD_TEST_UPDATE_MANIFEST_JSON = $priorManifest
}
