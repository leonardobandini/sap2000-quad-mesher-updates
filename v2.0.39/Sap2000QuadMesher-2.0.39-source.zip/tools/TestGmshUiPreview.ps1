# Validate the single shipped V2 UI, saved preview controls and reset behavior.
param([string]$Plugin = (Join-Path (Split-Path -Parent $PSScriptRoot) 'SapQuadTransitionPlugin\bin\Release\net48\SapQuadTransitionPlugin.dll'),
       [string]$ScreenshotPath = '', [string]$GmshScreenshotPath = '',
       [string]$ItalianScreenshotPath = '')
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -Path 'C:\Program Files\Computers and Structures\SAP2000 27\CSiAPIv1.dll'
$oldSize = $env:SAP_QUAD_ATOMIC_SIZE
$oldSettings = $env:SAP_GMSH_V2_SETTINGS_PATH
$env:SAP_QUAD_ATOMIC_SIZE = '0.55m'
$env:SAP_GMSH_V2_SETTINGS_PATH = Join-Path $env:TEMP ('opencode\sqm-v2-ui-' + [Guid]::NewGuid().ToString('N') + '.json')
try {
    $assembly = [Reflection.Assembly]::LoadFrom((Resolve-Path -LiteralPath $Plugin).Path)
    $type = $assembly.GetType('SapQuadTransitionPlugin.cPlugin+MeshOptionsDialog', $true)
    $axis = $assembly.GetType('SapQuadTransitionPlugin.cPlugin+SymmetryAxis', $true)
    $ctor = @($type.GetConstructors([Reflection.BindingFlags]'Instance,Public,NonPublic') |
        Where-Object { $_.GetParameters().Count -eq 6 })[0]
    $flags = [Reflection.BindingFlags]'Instance,NonPublic'
    function Field($dialog, $name) { $type.GetField($name, $flags).GetValue($dialog) }
    function Assert($condition, $message) { if (-not $condition) { throw $message } }
    $dialog = $ctor.Invoke([object[]]@('mm', $true, [string[]]@('BOLT'),
        [string[]]@('ALL'), [Array]::CreateInstance($axis, 0), $true))
    try {
        $dialog.Show()
        [Windows.Forms.Application]::DoEvents()
        $tabs = Field $dialog 'gmshPreviewTabs'
        $page = Field $dialog 'gmshPreviewEmptyTab'
        $panel = Field $dialog 'gmshPreviewOptions'
        $panelType = $panel.GetType()
        function Preview($name) { $panelType.GetField($name, $flags).GetValue($panel) }
        Assert ($type.GetField('gmshTabs', $flags) -eq $null -and
            $type.GetField('gmshOptionTree', $flags) -eq $null -and
            $type.GetField('gmshStructureTab', $flags) -eq $null -and
            $tabs.Visible -and $tabs.TabPages.Count -eq 4 -and
            (@($tabs.TabPages | ForEach-Object Text) -join ',') -eq
            'Gmsh,Additional Options,Gmsh JSON,Transfer Options') 'Classic interface is still present or the four tabs changed.'
        foreach ($name in @('profiles','size','edgeTolerance','strictMaximumSize',
            'preferRegular','stressRefinement','structuredSectorBands','useMaximumCores','workerLimit')) {
            Assert ((Field $dialog $name).Parent -eq $null) "Hidden legacy control $name is still attached to the window."
        }
        Assert (-not $type.GetField('edgeToleranceLabel', $flags) -and
            -not (Field $dialog 'measurementToolTip').GetToolTip((Field $dialog 'edgeTolerance'))) `
            'Legacy tolerance still has an active label or tooltip.'
        $additional = Field $dialog 'gmshHolesTab'
        $tabs.SelectedTab = $additional
        $additional.AutoScrollPosition = [Drawing.Point]::Empty
        [Windows.Forms.Application]::DoEvents()
        $viewport = $additional.RectangleToScreen($additional.ClientRectangle)
        $symmetry = Field $dialog 'symmetric'
        $axisChoice = Field $dialog 'symmetryAxis'
        $hint = Field $dialog 'gmshSymmetryHint'
        $regular = Preview 'favorRegularGrid'
        $lastHint = Field $dialog 'gmshOpeningHint'
        Assert ($additional.AutoScroll -and -not $additional.VerticalScroll.Visible -and
            -not $additional.HorizontalScroll.Visible -and
            $regular.Parent -eq $additional -and -not $regular.Checked -and
            $symmetry.Parent -eq $additional -and $axisChoice.Parent -eq $additional -and
            $regular.Top -lt $symmetry.Top -and
            $symmetry.Top -lt (Field $dialog 'generateCircularHoles').Top -and
            $viewport.Contains($regular.RectangleToScreen($regular.ClientRectangle)) -and
            $viewport.Contains($symmetry.RectangleToScreen($symmetry.ClientRectangle)) -and
            $viewport.Contains($axisChoice.RectangleToScreen($axisChoice.ClientRectangle)) -and
            $viewport.Contains($hint.RectangleToScreen($hint.ClientRectangle)) -and
            $viewport.Contains($lastHint.RectangleToScreen($lastHint.ClientRectangle)) -and
            -not $symmetry.Enabled -and $hint.Text -match 'No symmetry axis') `
            'All Additional Options must fit without scrolling, including regular grid and symmetry.'
        $axisCtor = @($axis.GetConstructors([Reflection.BindingFlags]'Instance,Public,NonPublic') |
            Where-Object { $_.GetParameters().Count -eq 3 -and $_.GetParameters()[2].ParameterType -eq [int] })[0]
        $compatibleAxis = $axisCtor.Invoke([object[]]@([double[]]@(0,0,0), [double[]]@(1,0,0), [int]1))
        $axes = [Array]::CreateInstance($axis, 1)
        $axes.SetValue($compatibleAxis, 0)
        $dialog.UpdateLiveSelection(1, 1, 0, 0, 0, 0, 0, $false,
            [string[]]@(), [string[]]@(), $axes)
        $additional.AutoScrollPosition = [Drawing.Point]::Empty
        [Windows.Forms.Application]::DoEvents()
        Assert ($symmetry.Enabled -and $axisChoice.Items.Count -eq 1 -and
            $hint.Text -match 'Choose one detected axis' -and
            $viewport.Contains($symmetry.RectangleToScreen($symmetry.ClientRectangle))) `
            'Symmetry did not become visible and available for a compatible selection.'
        if ($ScreenshotPath) {
            Assert ((Test-Path (Split-Path -Parent $ScreenshotPath) -PathType Container) -and
                -not (Test-Path $ScreenshotPath)) 'Unsafe Additional Options screenshot destination.'
            $image = [Drawing.Bitmap]::new($dialog.Width, $dialog.Height)
            try {
                $dialog.DrawToBitmap($image, [Drawing.Rectangle]::new(0, 0, $image.Width, $image.Height))
                $image.Save($ScreenshotPath, [Drawing.Imaging.ImageFormat]::Png)
            } finally { $image.Dispose() }
        }
        $tabs.SelectedTab = $page
        $grid = Preview 'grid'
        $groups = @('general','generation','recombination','optimization') | ForEach-Object { Preview $_ }
        Assert ($grid.ColumnCount -eq 1 -and $groups.Count -eq 4 -and
            -not $page.Controls[0].VerticalScroll.Visible) 'Gmsh controls do not fit the single-column layout.'
        foreach ($i in 0..3) { Assert ($grid.GetPositionFromControl($groups[$i]).Row -eq $i) "Group $i is out of order." }
        $algorithm = Preview 'algorithm'
        Assert ($algorithm.Items.Count -eq 7 -and $algorithm.SelectedIndex -eq 5 -and
            -not @($algorithm.Items | Where-Object { $_ -match '^9\b' }).Count) 'Unsupported algorithm is selectable.'
        Assert ($regular.Parent -eq $additional -and -not $regular.Checked) `
            'Regular grid preference must be in Additional Options and off by default.'
        $regular.Checked = $true
        Assert (($dialog.GmshSettingsJson | ConvertFrom-Json).structured.mode -eq 'automatic') `
            'Enabling regular grid must activate Gmsh automatic transfinite meshing.'
        $topologySteps = Preview 'topologySteps'
        $topologySteps.Text = '0'
        Assert (($dialog.GmshSettingsJson | ConvertFrom-Json).options.'Mesh.RecombineOptimizeTopology' -eq 0) `
            'Recombination topology steps must allow zero.'
        if ($GmshScreenshotPath) {
            Assert ((Test-Path (Split-Path -Parent $GmshScreenshotPath) -PathType Container) -and
                -not (Test-Path $GmshScreenshotPath)) 'Unsafe Gmsh screenshot destination.'
            $image = [Drawing.Bitmap]::new($dialog.Width, $dialog.Height)
            try {
                $dialog.DrawToBitmap($image, [Drawing.Rectangle]::new(0, 0, $image.Width, $image.Height))
                $image.Save($GmshScreenshotPath, [Drawing.Imaging.ImageFormat]::Png)
            } finally { $image.Dispose() }
        }
        $maxSize = Preview 'maxSize'
        $minSize = Preview 'minSize'
        $maxSize.Text = '40mm'; $minSize.Text = '5mm'
        $algorithm.SelectedIndex = 0
        (Preview 'switchOnFailure').Checked = $false
        (Preview 'quality').Text = '0.6'
        (Field $dialog 'gmshExtra').Text = 'Mesh.RandomFactor = 0.123'
        (Field $dialog 'gmshOGrid').Checked = $true
        (Field $dialog 'generateCircularHoles').Checked = $true
        (Field $dialog 'fastMode').Checked = $false
        (Field $dialog 'createBackup').Checked = $false
        $reset = Field $dialog 'gmshResetDefault'
        $commands = @((Field $dialog 'generate'), (Field $dialog 'details'), (Field $dialog 'undo'), $reset)
        Assert ($reset.Parent -eq $dialog -and
            @($commands | Select-Object -ExpandProperty Width | Select-Object -Unique).Count -eq 1 -and
            @($commands | Select-Object -ExpandProperty Top | Select-Object -Unique).Count -eq 1 -and
            $reset.Right -le $dialog.ClientSize.Width) 'Four bottom commands are not aligned.'
        $captured = $panelType.GetMethod('Capture', $flags).Invoke($panel, [object[]]@([double]0.001))
        $reset.PerformClick()
        Assert (-not $regular.Checked) 'Reset must deselect the regular grid preference.'
        $panelType.GetMethod('Restore', $flags).Invoke($panel, [object[]]@($captured, $false)) | Out-Null
        Assert ($regular.Checked -and $topologySteps.Text -eq '0' -and
            ($dialog.GmshSettingsJson | ConvertFrom-Json).structured.mode -eq 'automatic') `
            'The regular grid preference was not restored from saved V2 settings.'
        $reset.PerformClick()
        $settings = $dialog.GmshSettingsJson | ConvertFrom-Json
        Assert ($maxSize.Text -eq '40mm' -and $minSize.Text -eq '5mm' -and
            $settings.previewMode -and $settings.algorithm -eq 8 -and $settings.optimize -and
            $settings.options.'Mesh.MeshSizeMin' -eq 5 -and
            $settings.options.'Mesh.RecombineMinimumQuality' -eq .01 -and
            $settings.options.'Mesh.RecombineOptimizeTopology' -eq 5 -and
            $settings.options.'Mesh.AlgorithmSwitchOnFailure' -eq 1 -and
            -not $settings.options.PSObject.Properties['Mesh.RandomFactor'] -and
            -not $settings.oGrid -and -not $settings.preserveSelectedEdges -and
            -not $regular.Checked -and $settings.structured.mode -eq 'unstructured' -and
            (Field $dialog 'fastMode').Checked -and (Field $dialog 'createBackup').Checked) 'Reset did not restore defaults or preserve sizes.'
        $dialog.SetProgress('Creating SAP2000 points...', 2, 4)
        Assert ((Field $dialog 'status').Text -match 'Phase progress: 2/4 \(50%\)' -and
            (Field $dialog 'progress').Value -eq 50) 'Point insertion did not identify its phase progress.'
        $dialog.SetProgress('Creating shell elements and transferring loads...', 1, 4)
        Assert ((Field $dialog 'status').Text -match 'Phase progress: 1/4 \(25%\)' -and
            (Field $dialog 'progress').Value -eq 25) 'A subsequent phase did not report its own progress.'
        $dialog.SetIndeterminate('Generating the mesh...')
        Assert ((Field $dialog 'status').Text -match 'Generating the mesh' -and
            (Field $dialog 'progress').Style -eq [Windows.Forms.ProgressBarStyle]::Marquee) `
            'Generation must display its activity without implying mesh optimization.'
        $dialog.SetSelectionCounts(1449, 1163, 286, 0, 176, 0, 1380)
        $summary = Field $dialog 'selectionSummary'
        $areas = Field $dialog 'areaSelection'
        $objects = Field $dialog 'objectSelection'
        Assert ($summary.Height -ge 64 -and $areas.Height -ge 19 -and
            $objects.Height -ge 19 -and $objects.Bottom -lt $summary.Height) 'Top summary clips its two rows.'
        foreach ($label in @($areas, $objects)) {
            Assert ($label.Width -ge [Windows.Forms.TextRenderer]::MeasureText($label.Text, $label.Font).Width) `
                "Top summary text is wider than its available space: $($label.Text)"
        }
        (Field $dialog 'generate').PerformClick()
        Assert ($dialog.StartRequested -and [Math]::Abs($dialog.MaxSize - 40) -lt 1e-9) 'Generate did not read the visible maximum.'
        (Field $dialog 'language').SelectedIndex = 1
        [Windows.Forms.Application]::DoEvents()
        Assert ((@($tabs.TabPages | ForEach-Object Text) -join ',') -eq
            'Gmsh,Opzioni aggiuntive,JSON Gmsh,Opzioni di trasferimento' -and
            $reset.Text -eq 'Ripristina default') 'Italian controls changed.'
        $tabs.SelectedTab = $page
        Assert ($regular.Text -match 'regolari allineate' -and
            [Windows.Forms.TextRenderer]::MeasureText($regular.Text, $regular.Font).Width -le $regular.Width) `
            'Italian regular-grid control is clipped.'
        $tabs.SelectedTab = $additional
        $additional.AutoScrollPosition = [Drawing.Point]::Empty
        [Windows.Forms.Application]::DoEvents()
        $viewport = $additional.RectangleToScreen($additional.ClientRectangle)
        Assert ($symmetry.Text -match 'Imponi simmetria' -and
            -not $additional.VerticalScroll.Visible -and
            $viewport.Contains($regular.RectangleToScreen($regular.ClientRectangle)) -and
            $viewport.Contains($symmetry.RectangleToScreen($symmetry.ClientRectangle)) -and
            $viewport.Contains($lastHint.RectangleToScreen($lastHint.ClientRectangle))) `
            'Italian additional options require scrolling or clip a control.'
        if ($ItalianScreenshotPath) {
            Assert ((Test-Path (Split-Path -Parent $ItalianScreenshotPath) -PathType Container) -and
                -not (Test-Path $ItalianScreenshotPath)) 'Unsafe Italian screenshot destination.'
            $image = [Drawing.Bitmap]::new($dialog.Width, $dialog.Height)
            try {
                $dialog.DrawToBitmap($image, [Drawing.Rectangle]::new(0, 0, $image.Width, $image.Height))
                $image.Save($ItalianScreenshotPath, [Drawing.Imaging.ImageFormat]::Png)
            } finally { $image.Dispose() }
        }
        Write-Host 'V2_UI=PASS CLASSIC_ABSENT=PASS FOUR_EQUAL_COMMANDS=PASS RESET_KEEP_SIZES=PASS EN_IT_LAYOUT=PASS'
    } finally { $dialog.Close(); $dialog.Dispose() }
    $empty = $ctor.Invoke([object[]]@('mm', $false, [string[]]@(),
        [string[]]@(), [Array]::CreateInstance($axis, 0), $false))
    try {
        $empty.Show()
        [Windows.Forms.Application]::DoEvents()
        $generate = Field $empty 'generate'
        Assert (-not $generate.Enabled -and (Field $empty 'status').Text -match 'aggiorna automaticamente|updates automatically') `
            "Opening without a selection must wait for SAP objects: enabled=$($generate.Enabled) status=$((Field $empty 'status').Text)"
        $empty.UpdateLiveSelection(1, 1, 0, 0, 0, 0, 0, $false,
            [string[]]@(), [string[]]@(), [Array]::CreateInstance($axis, 0))
        Assert ($generate.Enabled -and (Field $empty 'areaSelection').Text -match 'Areas: 1|Aree: 1') `
            'Selecting an area after opening did not enable Generate.'
        $empty.UpdateLiveSelection(0, 0, 0, 0, 0, 0, 0, $false,
            [string[]]@(), [string[]]@(), [Array]::CreateInstance($axis, 0))
        Assert (-not $generate.Enabled -and (Field $empty 'areaSelection').Text -match 'Areas: 0|Aree: 0') `
            'Clearing the SAP selection did not disable Generate.'
        $empty.UpdateLiveSelection(1, 1, 0, 0, 0, 0, 0, $false,
            [string[]]@(), [string[]]@(), [Array]::CreateInstance($axis, 0))
        $generate.PerformClick()
        Assert ($empty.StartRequested) 'Generate still uses the selection from dialog opening.'
        Write-Host 'LIVE_SELECTION_EMPTY_TO_AREA_TO_EMPTY_TO_GENERATE=PASS'
    } finally { $empty.Close(); $empty.Dispose() }
    $env:SAP_QUAD_ATOMIC_SIZE = $null
    [IO.File]::WriteAllText($env:SAP_GMSH_V2_SETTINGS_PATH,
        '{"Profile":0,"Tolerance":0,"Strict":true,"Regular":true,"Refined":true,"Bands":false,"MaximumCores":false,"Workers":1,"Fast":false,"Backup":false,"GmshPreview":{"MaxText":"40mm","MinText":"5mm","Algorithm":5,"Recombine":true,"Recombination":0,"Optimizer":0,"Optimize":true,"SwitchOnFailure":true,"NodeRepositioning":true}}')
    $migrated = $ctor.Invoke([object[]]@('mm', $true, [string[]]@('BOLT'),
        [string[]]@('ALL'), [Array]::CreateInstance($axis, 0), $true))
    try {
        $migrated.Show()
        [Windows.Forms.Application]::DoEvents()
        $v2 = Field $migrated 'gmshPreviewOptions'
        Assert (-not $migrated.StrictMaximumSize -and $migrated.EdgeTolerancePercent -eq 20 -and
            -not $migrated.PreferRegularMesh -and -not $migrated.StressRefinement -and
            $migrated.StructuredSectorBands -and (Field $migrated 'useMaximumCores').Checked -and
            (Field $migrated 'profiles').SelectedIndex -eq 2 -and
            $v2.GetType().GetField('maxSize',$flags).GetValue($v2).Text -eq '40mm' -and
            $v2.GetType().GetField('minSize',$flags).GetValue($v2).Text -eq '5mm' -and
            -not (Field $migrated 'fastMode').Checked -and -not (Field $migrated 'createBackup').Checked) `
            'Saved legacy settings still change hidden V2 meshing options or visible preferences were lost.'
        Write-Host 'LEGACY_PREFERENCES_IGNORED=PASS VISIBLE_PREFERENCES_RESTORED=PASS'
    } finally { $migrated.Close(); $migrated.Dispose() }
} finally {
    $env:SAP_QUAD_ATOMIC_SIZE = $oldSize
    if (Test-Path -LiteralPath $env:SAP_GMSH_V2_SETTINGS_PATH) { Remove-Item -LiteralPath $env:SAP_GMSH_V2_SETTINGS_PATH -Force }
    $env:SAP_GMSH_V2_SETTINGS_PATH = $oldSettings
}
