// Copyright (C) 2026 Leonardo Bandini
// SPDX-License-Identifier: GPL-2.0-or-later
using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Xml;
using Microsoft.Win32;

internal static class SQMPluginInstaller
{
    private const string Guid = "{D64E6254-E9B2-46C8-8C0E-C8A5C78D94AA}";
    private const string ProgId = "SapQuadTransitionPlugin.cPlugin";
    private const string ClassKey = @"Software\Classes\CLSID\" + Guid;
    private const string ProgIdKey = @"Software\Classes\" + ProgId;
    private const string DllName = "SapQuadTransitionPlugin.dll";
    private const string MenuName = "SapQuadTransitionPlugin";
    private const string MenuText = "SAP2000 Quad Mesher";

    private static int Main(string[] args)
    {
        try
        {
            if (args.Length < 1 || args.Length > 2 ||
                (args[0] != "install" && args[0] != "uninstall" && args[0] != "verify" &&
                 args[0] != "test-install" && args[0] != "test-menu") ||
                ((args[0] == "test-install" || args[0] == "test-menu") && args.Length != 2))
                throw new ArgumentException("Usage: SQMPluginInstaller.exe install|uninstall|verify [package directory], test-install TEST_ROOT or test-menu TEMP_PROFILE");

            if (args[0] == "test-menu")
            {
                string profile = Path.GetFullPath(args[1]);
                if (!profile.StartsWith(Path.GetTempPath(), StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(profile.TrimEnd('\\'), Path.GetTempPath().TrimEnd('\\'), StringComparison.OrdinalIgnoreCase))
                    throw new ArgumentException("Menu tests require a child folder of the temporary directory.");
                UpdateSapMenu(profile);
                return 0;
            }

            string source = Path.GetFullPath(args[0] == "test-install" ? AppDomain.CurrentDomain.BaseDirectory :
                args.Length == 2 ? args[1] : AppDomain.CurrentDomain.BaseDirectory);
            string root = args[0] == "test-install" ? Path.GetFullPath(args[1]) :
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "SAP2000QuadMesher");
            if (args[0] == "test-install" && (!root.StartsWith(Path.GetTempPath(), StringComparison.OrdinalIgnoreCase) ||
                string.Equals(root.TrimEnd('\\'), Path.GetTempPath().TrimEnd('\\'), StringComparison.OrdinalIgnoreCase)))
                throw new ArgumentException("The test installation must use a child directory of the temporary folder.");
            if (args[0] == "verify") { VerifyPackage(source); return 0; }
            if (args[0] == "test-install") { Install(source, root, false); return 0; }
            if (Process.GetProcessesByName("SAP2000").Length != 0)
                throw new InvalidOperationException("Close SAP2000 before installing or uninstalling the plugin. Save your model first if needed.");
            if (args[0] == "install") Install(source, root, true);
            else Uninstall(root);
            return 0;
        }
        catch (Exception error)
        {
            Console.Error.WriteLine("SQM Plugin: " + error);
            return 1;
        }
    }

    private static void VerifyPackage(string source)
    {
        foreach (string file in new[] { DllName, "install_plugin.cmd", "uninstall_plugin.cmd", "README.md" })
            if (!File.Exists(Path.Combine(source, file))) throw new FileNotFoundException("Package file missing: " + file);
        string backend = Path.Combine(source, "mesher", "SapQuadMesherBackend.exe");
        if (!File.Exists(backend)) throw new FileNotFoundException("Backend missing: " + backend);
        string version = FileVersionInfo.GetVersionInfo(Path.Combine(source, DllName)).FileVersion;
        if (string.IsNullOrEmpty(version)) throw new InvalidDataException("The plugin has no file version.");
        using (var process = Process.Start(new ProcessStartInfo(backend, "--self-test")
        {
            UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true,
            RedirectStandardError = true
        }))
        {
            if (!process.WaitForExit(60000)) { process.Kill(); throw new TimeoutException("Backend self-test timed out."); }
            if (process.ExitCode != 0) throw new InvalidOperationException("Backend self-test failed: " + process.StandardError.ReadToEnd());
        }
        Console.WriteLine("Verified SQM Plugin " + version + " in " + source);
    }

    private static void CopyDirectory(string source, string destination, bool overwrite = false)
    {
        Directory.CreateDirectory(destination);
        foreach (string file in Directory.GetFiles(source))
        {
            string target = Path.Combine(destination, Path.GetFileName(file));
            try { File.Copy(file, target, overwrite); }
            catch (IOException) when (overwrite && SameFile(file, target))
            {
                // An open documentation viewer may lock a PDF that has not
                // changed. No replacement is necessary in that case.
            }
        }
        foreach (string directory in Directory.GetDirectories(source))
            CopyDirectory(directory, Path.Combine(destination, Path.GetFileName(directory)), overwrite);
    }

    private static bool SameFile(string first, string second)
    {
        if (!File.Exists(second) || new FileInfo(first).Length != new FileInfo(second).Length) return false;
        using (var sha = SHA256.Create())
        using (var input = File.OpenRead(first))
        using (var existing = File.OpenRead(second))
        {
            byte[] left = sha.ComputeHash(input), right = sha.ComputeHash(existing);
            for (int i = 0; i < left.Length; i++) if (left[i] != right[i]) return false;
            return true;
        }
    }

    private static void MoveDirectory(string source, string destination)
    {
        for (int attempt = 0; ; attempt++)
        {
            try { Directory.Move(source, destination); return; }
            catch (Exception error) when ((error is IOException || error is UnauthorizedAccessException) && attempt < 11)
            { Thread.Sleep(250); }
        }
    }

    private static void Install(string source, string root, bool register)
    {
        if (string.Equals(source.TrimEnd('\\'), root.TrimEnd('\\'), StringComparison.OrdinalIgnoreCase))
        {
            VerifyPackage(root);
            if (register) Register(Path.Combine(root, DllName));
            return;
        }
        VerifyPackage(source);
        string parent = Path.GetDirectoryName(root);
        Directory.CreateDirectory(parent);
        string staging = Path.Combine(parent, "SAP2000QuadMesher.new-" + System.Guid.NewGuid().ToString("N"));
        string backup = Path.Combine(parent, "SAP2000QuadMesher.previous-" + System.Guid.NewGuid().ToString("N"));
        string oldCodeBase = register ? RegisteredCodeBase() : null;
        bool movedOld = false, movedNew = false, copiedOverOld = false;
        try
        {
            CopyDirectory(source, staging);
            VerifyPackage(staging);
            if (Directory.Exists(root))
            {
                try { MoveDirectory(root, backup); movedOld = true; }
                catch (IOException)
                {
                    // A process can hold the old directory handle even after
                    // SAP2000 exits. Retain a verified rollback copy, then
                    // replace individual files without renaming that handle.
                    CopyDirectory(root, backup);
                    copiedOverOld = true;
                }
            }
            if (copiedOverOld) { CopyDirectory(staging, root, true); VerifyPackage(root); }
            else { MoveDirectory(staging, root); movedNew = true; }
            if (register) Register(Path.Combine(root, DllName));
        }
        catch
        {
            if (movedNew) Directory.Delete(root, true);
            if (movedOld) MoveDirectory(backup, root);
            if (copiedOverOld) CopyDirectory(backup, root, true);
            if (register)
            {
                Unregister();
                if (!string.IsNullOrEmpty(oldCodeBase))
                {
                    Uri oldUri;
                    if (Uri.TryCreate(oldCodeBase, UriKind.Absolute, out oldUri) && oldUri.IsFile && File.Exists(oldUri.LocalPath))
                        Register(oldUri.LocalPath);
                }
            }
            throw;
        }
        finally { if (Directory.Exists(staging)) Directory.Delete(staging, true); }

        if (movedOld || copiedOverOld)
        {
            try { Directory.Delete(backup, true); }
            catch (IOException) { Console.WriteLine("Previous installation backup remains in " + backup); }
        }
        if (register)
        {
            try { UpdateSapMenu(SapProfileDirectory()); }
            catch (Exception error) when (error is IOException || error is UnauthorizedAccessException ||
                                          error is InvalidDataException || error is XmlException)
            {
                Console.WriteLine("SAP2000 plugin menu could not be updated automatically: " + error.Message);
                Console.WriteLine("In SAP2000 use Tools > Add/Show Plugins to add " + MenuName + " manually.");
            }
            string legacy = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Programs", "SQM_Plugin");
            if (Directory.Exists(legacy) && string.Equals(oldCodeBase,
                new Uri(Path.Combine(legacy, DllName)).AbsoluteUri, StringComparison.OrdinalIgnoreCase))
            {
                try { Directory.Delete(legacy, true); }
                catch (Exception error) when (error is IOException || error is UnauthorizedAccessException)
                { Console.WriteLine("Previous installation remains in " + legacy); }
            }
        }
        Console.WriteLine("SQM Plugin installed in " + root);
        Console.WriteLine("Restart SAP2000 to use the new version.");
    }

    private static string SapProfileDirectory()
    {
        return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "Computers and Structures", "SAP2000 27");
    }

    private static string AddIniMenuEntry(string contents, out bool changed)
    {
        Match section = Regex.Match(contents, @"(?ms)^\[PlugIn\]\r?\n.*?(?=^\[|\z)");
        if (!section.Success) throw new InvalidDataException("The SAP2000 INI has no [PlugIn] section.");
        Match number = Regex.Match(section.Value, @"(?m)^(?<prefix>[ \t]*NumberPlugIns=)(?<count>\d+)[ \t]*\r?$");
        if (!number.Success) throw new InvalidDataException("SAP2000 plugin count missing from the INI.");
        MatchCollection names = Regex.Matches(section.Value, @"(?m)^[ \t]*PlugInName=(?<name>[^\r\n]*)");
        MatchCollection labels = Regex.Matches(section.Value, @"(?m)^[ \t]*PlugInMenuText=[^\r\n]*");
        int count = int.Parse(number.Groups["count"].Value);
        if (count != names.Count || count != labels.Count)
            throw new InvalidDataException("The SAP2000 plugin INI has inconsistent name, label or count records.");
        foreach (Match name in names)
            if (string.Equals(name.Groups["name"].Value.Trim(), MenuName, StringComparison.OrdinalIgnoreCase))
            { changed = false; return contents; }

        string lineEnd = section.Value.Contains("\r\n") ? "\r\n" : "\n";
        string updated = section.Value.Substring(0, number.Groups["count"].Index) + (count + 1) +
            section.Value.Substring(number.Groups["count"].Index + number.Groups["count"].Length);
        updated = updated.TrimEnd('\r', '\n') + lineEnd + " PlugInName=" + MenuName +
            lineEnd + " PlugInMenuText=" + MenuText + lineEnd + lineEnd;
        changed = true;
        return contents.Substring(0, section.Index) + updated + contents.Substring(section.Index + section.Length);
    }

    private static byte[] UpdatedSettings(byte[] original, out bool changed)
    {
        var settings = new XmlDocument { PreserveWhitespace = true };
        using (var stream = new MemoryStream(original)) settings.Load(stream);
        XmlNode menu = settings.SelectSingleNode("/Settings/PlugIn");
        if (menu == null) throw new InvalidDataException("SAP2000 settings have no PlugIn field.");
        var entries = new XmlDocument { PreserveWhitespace = true };
        entries.LoadXml(menu.InnerText);
        XmlNode root = entries.SelectSingleNode("/ArrayOfString");
        if (root == null) throw new InvalidDataException("SAP2000 plugin settings are not an ArrayOfString.");
        changed = false;
        foreach (XmlNode item in root.SelectNodes("string"))
        {
            var record = new XmlDocument();
            string contents = item.InnerText;
            record.LoadXml(contents.TrimStart('\ufeff', ' ', '\r', '\n'));
            XmlNode name = record.SelectSingleNode("/PlugIn/m_name");
            if (name == null) throw new InvalidDataException("SAP2000 plugin entry has no m_name.");
            if (!string.Equals(name.InnerText, MenuName, StringComparison.OrdinalIgnoreCase)) continue;
            XmlNode hidden = record.SelectSingleNode("/PlugIn/m_Hide");
            if (hidden == null)
            {
                hidden = record.CreateElement("m_Hide");
                record.DocumentElement.AppendChild(hidden);
            }
            if (hidden.InnerText != "false")
            {
                hidden.InnerText = "false";
                item.InnerText = (contents.Length > 0 && contents[0] == '\ufeff' ? "\ufeff" : "") + record.OuterXml;
                changed = true;
            }
            return SerializeSettings(settings, menu, entries, original, changed);
        }

        XmlElement newItem = entries.CreateElement("string");
        newItem.InnerText = "\ufeff<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
            "<PlugIn><ClassID>S_PlugIn</ClassID><ClassVersion>2</ClassVersion>" +
            "<m_name>" + MenuName + "</m_name><m_Path /><m_Text>" + MenuText +
            "</m_Text><m_found>false</m_found><m_Info /><m_Hide>false</m_Hide></PlugIn>";
        root.AppendChild(newItem);
        changed = true;
        return SerializeSettings(settings, menu, entries, original, changed);
    }

    private static byte[] SerializeSettings(XmlDocument settings, XmlNode menu, XmlDocument entries,
        byte[] original, bool changed)
    {
        if (!changed) return original;
        menu.InnerText = entries.OuterXml;
        using (var stream = new MemoryStream())
        {
            settings.Save(stream);
            return stream.ToArray();
        }
    }

    private static void UpdateSapMenu(string profile)
    {
        string ini = Path.Combine(profile, "SAP2000v27.ini");
        string settings = Path.Combine(profile, "SAP2000v27.settings");
        if (!File.Exists(ini) || !File.Exists(settings))
        {
            Console.WriteLine("SAP2000 27 menu preferences are not initialized. Start and close SAP2000 once, then rerun the installer to add the menu entry.");
            return;
        }
        byte[] iniOriginal = File.ReadAllBytes(ini);
        byte[] settingsOriginal = File.ReadAllBytes(settings);
        bool utf8Bom = iniOriginal.Length >= 3 && iniOriginal[0] == 0xef && iniOriginal[1] == 0xbb && iniOriginal[2] == 0xbf;
        Encoding iniEncoding = utf8Bom ? new UTF8Encoding(true) : Encoding.Default;
        string iniText = iniEncoding.GetString(iniOriginal);
        bool iniChanged, settingsChanged;
        string iniUpdated = AddIniMenuEntry(iniText, out iniChanged);
        byte[] settingsUpdated = UpdatedSettings(settingsOriginal, out settingsChanged);
        if (!iniChanged && !settingsChanged)
        {
            Console.WriteLine("SAP2000 Tools plugin menu already contains " + MenuName + ".");
            return;
        }

        string token = System.Guid.NewGuid().ToString("N");
        string iniNew = ini + ".sqm-new-" + token, settingsNew = settings + ".sqm-new-" + token;
        string iniBackup = ini + ".sqm-backup-" + token, settingsBackup = settings + ".sqm-backup-" + token;
        bool iniReplaced = false, settingsReplaced = false, restored = true;
        try
        {
            if (iniChanged)
            {
                File.WriteAllBytes(iniNew, iniEncoding.GetBytes(iniUpdated));
                File.Replace(iniNew, ini, iniBackup);
                iniReplaced = true;
            }
            if (settingsChanged)
            {
                File.WriteAllBytes(settingsNew, settingsUpdated);
                File.Replace(settingsNew, settings, settingsBackup);
                settingsReplaced = true;
            }
            Console.WriteLine("SAP2000 Tools plugin menu added: " + MenuName + " (" + MenuText + ").");
        }
        catch (Exception failure)
        {
            try
            {
                if (settingsReplaced) File.Copy(settingsBackup, settings, true);
                if (iniReplaced) File.Copy(iniBackup, ini, true);
            }
            catch (Exception rollback)
            {
                restored = false;
                throw new IOException("SAP2000 menu rollback failed; original copies remain in " + profile +
                    ": " + rollback.Message, failure);
            }
            throw;
        }
        finally
        {
            foreach (string path in new[] { iniNew, settingsNew })
                if (File.Exists(path)) try { File.Delete(path); } catch { }
            if (restored)
                foreach (string path in new[] { iniBackup, settingsBackup })
                    if (File.Exists(path)) try { File.Delete(path); } catch { }
        }
    }

    private static string RegisteredCodeBase()
    {
        using (RegistryKey key = Registry.CurrentUser.OpenSubKey(ClassKey + @"\InprocServer32"))
            return key == null ? null : key.GetValue("CodeBase") as string;
    }

    private static void Register(string dll)
    {
        AssemblyName assembly = AssemblyName.GetAssemblyName(dll);
        string codeBase = new Uri(dll).AbsoluteUri;
        using (RegistryKey progId = Registry.CurrentUser.CreateSubKey(ProgIdKey))
            progId.SetValue(null, ProgId);
        using (RegistryKey progIdClass = Registry.CurrentUser.CreateSubKey(ProgIdKey + @"\CLSID"))
            progIdClass.SetValue(null, Guid);
        using (RegistryKey clsid = Registry.CurrentUser.CreateSubKey(ClassKey))
            clsid.SetValue(null, ProgId);
        using (RegistryKey inproc = Registry.CurrentUser.CreateSubKey(ClassKey + @"\InprocServer32"))
        {
            inproc.SetValue(null, "mscoree.dll");
            inproc.SetValue("ThreadingModel", "Both");
            SetAssemblyValues(inproc, assembly.FullName, codeBase);
        }
        using (RegistryKey version = Registry.CurrentUser.CreateSubKey(ClassKey + @"\InprocServer32\" + assembly.Version))
            SetAssemblyValues(version, assembly.FullName, codeBase);
        using (RegistryKey progId = Registry.CurrentUser.CreateSubKey(ClassKey + @"\ProgId"))
            progId.SetValue(null, ProgId);
        using (Registry.CurrentUser.CreateSubKey(ClassKey + @"\Implemented Categories\{62C8FE65-4EBB-45e7-b440-6e39b2cdbf29}")) { }
    }

    private static void SetAssemblyValues(RegistryKey key, string assembly, string codeBase)
    {
        key.SetValue("Class", ProgId);
        key.SetValue("Assembly", assembly);
        key.SetValue("RuntimeVersion", "v4.0.30319");
        key.SetValue("CodeBase", codeBase);
    }

    private static void Unregister()
    {
        Registry.CurrentUser.DeleteSubKeyTree(ClassKey, false);
        Registry.CurrentUser.DeleteSubKeyTree(ProgIdKey, false);
    }

    private static void Uninstall(string root)
    {
        string installedCodeBase = new Uri(Path.Combine(root, DllName)).AbsoluteUri;
        string activeCodeBase = RegisteredCodeBase();
        if (!string.IsNullOrEmpty(activeCodeBase) &&
            !string.Equals(activeCodeBase, installedCodeBase, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("A different plugin installation is registered; nothing was removed.");
        if (string.Equals(Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory).TrimEnd('\\'),
            Path.GetFullPath(root).TrimEnd('\\'), StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Run the uninstaller from the extracted ZIP, outside the installation folder.");
        if (Directory.Exists(root)) Directory.Delete(root, true);
        if (!string.IsNullOrEmpty(activeCodeBase)) Unregister();
        Console.WriteLine("SQM Plugin removed for the current user.");
    }
}
