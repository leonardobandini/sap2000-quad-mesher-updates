"""Local repair of overlong *unconstrained* sector-mesh edges."""
import csv
import math
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "SapQuadTransitionPlugin"))
from sap_general_polygon_mesher import read_input


def point_key(point):
    return tuple(round(v, 8) for v in point)


def key(a, b):
    return tuple(sorted((a, b)))


def polygon_area(vertices, nodes):
    xyz = [nodes[tag] for tag in vertices]
    return .5 * sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(xyz,xyz[1:]+xyz[:1]))


def valid(elements, nodes, sign):
    for element in elements:
        if polygon_area(element, nodes)*sign < 1e-8:
            return False
        if len(element) == 4:
            xyz = [nodes[tag] for tag in element]
            for index, p in enumerate(xyz):
                before, after = xyz[index-1], xyz[(index+1)%4]
                u = tuple(before[i]-p[i] for i in range(3))
                v = tuple(after[i]-p[i] for i in range(3))
                cosine = sum(u[i]*v[i] for i in range(3))/math.dist(before,p)/math.dist(after,p)
                if math.degrees(math.acos(max(-1,min(1,cosine)))) > 174.9:
                    return False
    return True


def split(element, a, b, midpoint, nodes, sign):
    index = next(i for i in range(len(element)) if key(element[i], element[(i+1)%len(element)]) == key(a,b))
    ring = list(element[:index+1]) + [midpoint] + list(element[index+1:])
    if len(ring) == 4:
        p = ring.index(midpoint)
        a, m, b, c = (ring[(p+offset)%4] for offset in (-1,0,1,2))
        result = [(a,m,c),(m,b,c)]
        return result if valid(result,nodes,sign) else None
    if len(ring) != 5:
        return None
    p = ring.index(midpoint)
    before,m,after,next_node,previous_node = (ring[(p+offset)%5] for offset in (-1,0,1,2,3))
    center = max(nodes)+1
    nodes[center] = tuple(sum(nodes[tag][axis] for tag in ring)/5 for axis in range(3))
    result = [(center,previous_node,before,m), (center,m,after,next_node),
              (center,next_node,previous_node)]
    if valid(result,nodes,sign):
        return result
    # Keep the unsplit fan if a paired quadrilateral would be distorted.
    result = [(center,ring[i],ring[(i+1)%5]) for i in range(5)]
    if valid(result,nodes,sign):
        return result
    del nodes[center]
    return None


def run(source, boundary, destination, size=.5):
    corners, edges, *_ = read_input(boundary)
    sign = 1 if polygon_area(tuple(corners),corners)>0 else -1
    nodes, elements = {}, []
    with source.open(newline='',encoding='ascii') as stream:
        for row in csv.reader(stream):
            if row[0]=='N': nodes[int(row[1])]=tuple(map(float,row[2:5]))
            elif row[0]=='E': elements.append(tuple(map(int,row[1:])))
    coord_to_id={point_key(xyz):tag for tag,xyz in nodes.items()}
    protected=set()
    for points in edges.values():
        for first,second in zip(points,points[1:]):
            a=coord_to_id.get(point_key(first[1]))
            b=coord_to_id.get(point_key(second[1]))
            if a is not None and b is not None:
                protected.add(key(a,b))
    for iteration in range(12):
        owners=defaultdict(list)
        for index,element in enumerate(elements):
            for a,b in zip(element,element[1:]+element[:1]):
                owners[key(a,b)].append(index)
        targets=sorted(((math.dist(nodes[a],nodes[b]),a,b) for (a,b),used in owners.items()
                        if (a,b) not in protected and len(used)==2 and
                        math.dist(nodes[a],nodes[b])>size+1e-6), reverse=True)
        if not targets:
            break
        replaced=set()
        updates={}
        for length,a,b in targets:
            first,second=owners[key(a,b)]
            if first in replaced or second in replaced:
                continue
            midpoint=max(nodes)+1
            nodes[midpoint]=tuple((nodes[a][i]+nodes[b][i])/2 for i in range(3))
            before=len(nodes)
            patch_a=split(elements[first],a,b,midpoint,nodes,sign)
            patch_b=split(elements[second],a,b,midpoint,nodes,sign)
            if patch_a is None or patch_b is None:
                for tag in range(midpoint,before+2):
                    nodes.pop(tag,None)
                continue
            updates[first]=patch_a
            updates[second]=patch_b
            replaced.update((first,second))
        if not replaced:
            break
        elements=[part for index,element in enumerate(elements)
                  for part in updates.get(index,[element])]
        print(f'pass={iteration+1} repaired_edges={len(replaced)//2} elements={len(elements)}')
    ownership=defaultdict(int)
    for element in elements:
        for a,b in zip(element,element[1:]+element[:1]):
            ownership[key(a,b)]+=1
    unlocked=[(math.dist(nodes[a],nodes[b]),a,b) for a,b in ownership if key(a,b) not in protected]
    unsized=[item for item in unlocked if item[0]>size+1e-6]
    print(f'quads={sum(len(e)==4 for e in elements)} triangles={sum(len(e)==3 for e in elements)} '
          f'max_unlocked={max(item[0] for item in unlocked):.4f} over_limit={len(unsized)} '
          f'nonmanifold={sum(owners>2 for owners in ownership.values())}')
    if unsized or any(count > 2 for count in ownership.values()):
        raise RuntimeError('Local sector repair did not meet the mesh size or manifold requirements')
    with destination.open('w',newline='',encoding='ascii') as stream:
        writer=csv.writer(stream)
        for tag,xyz in nodes.items():
            writer.writerow(['N',tag,*(f'{v:.17g}' for v in xyz)])
        for element in elements:
            writer.writerow(['E',*element])


if __name__=='__main__':
    run(Path(sys.argv[1]),Path(sys.argv[2]),Path(sys.argv[3]))
