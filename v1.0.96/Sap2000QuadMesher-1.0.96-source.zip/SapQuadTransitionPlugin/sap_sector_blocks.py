"""Conforming block mesh for guided annular sectors with preserved contours."""
import csv
import math
import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "SapQuadTransitionPlugin"))
import gmsh
import sap_general_polygon_mesher as polygon


def norm(a, b):
    return math.dist(a, b)


def lerp(a, b, t):
    return tuple((1 - t) * x + t * y for x, y in zip(a, b))


def polyline(points, t):
    count = len(points) - 1
    v = min(count - 1, int(max(0, min(count - 1e-12, t * count))))
    return lerp(points[v], points[v + 1], max(0, min(1, t * count - v)))


def read_sector(boundary, maximum=.5, verbose=True):
    corners, edges, interior, frames, _, _, _, _, _, _, _, locked_edges = polygon.read_input(boundary)
    n = len(corners)
    long_edges = sorted(range(1, n + 1),
                        key=lambda i: norm(corners[i], corners[i % n + 1]), reverse=True)[:2]
    start, end = sorted(long_edges)
    def chain(first, last):
        vertices = [corners[first % n + 1]]
        for index in range(first + 1, last):
            vertices.append(corners[index % n + 1])
        return vertices

    paths = (chain(start, end), chain(end, start + n))
    outer, inner = (paths[0], paths[1]) if len(paths[0]) > len(paths[1]) else (paths[1], paths[0])
    # Both are oriented with the polygon boundary; reverse the inner chain
    # to align its ends with those of the outer chain.
    inner = list(reversed(inner))
    if len(inner) < 2 or len(outer) < 3:
        raise RuntimeError("This polygon is not a radial sector")
    inner_target = float(os.environ.get('SECTOR_INNER_BOUNDARY_STEP', str(maximum)))
    refined_inner = [inner[0]]
    for first, second in zip(inner, inner[1:]):
        matched = next((edge for edge, points in edges.items()
                        if (norm(points[0][1], first) < 1e-7 and norm(points[-1][1], second) < 1e-7) or
                        (norm(points[-1][1], first) < 1e-7 and norm(points[0][1], second) < 1e-7)), None)
        if matched is None:
            raise RuntimeError("Central opening edge missing")
        subdivisions = 1 if matched in locked_edges else max(1, math.ceil(norm(first, second) / inner_target - 1e-9))
        refined_inner.extend(lerp(first, second, i / subdivisions)
                             for i in range(1, subdivisions + 1))
    inner = refined_inner
    def radial_points(from_point, to_point):
        for edge in edges.values():
            points = [xyz for _, xyz in edge]
            if norm(points[0], from_point) < 1e-7 and norm(points[-1], to_point) < 1e-7:
                return points
            if norm(points[-1], from_point) < 1e-7 and norm(points[0], to_point) < 1e-7:
                return list(reversed(points))
        raise RuntimeError("Radial sector side was not found")

    side0 = radial_points(inner[0], outer[0])
    side1 = radial_points(inner[-1], outer[-1])

    # Identify the chord by its endpoints, not an absolute length threshold.
    # Guide edges can be longer or shorter at a different model scale.
    def chord(a, b):
        return ((norm(a, outer[0]) < 1e-7 and norm(b, outer[-1]) < 1e-7) or
                (norm(a, outer[-1]) < 1e-7 and norm(b, outer[0]) < 1e-7))

    ring_segments = [(a, b) for a, b, _, _ in frames if not chord(a, b)]
    adjacency = {}
    for a, b in ring_segments:
        adjacency.setdefault(a, []).append(b)
        adjacency.setdefault(b, []).append(a)
    groups = []
    remaining = set(adjacency)
    while remaining:
        component = {remaining.pop()}
        pending = list(component)
        while pending:
            for neighbor in adjacency[pending.pop()]:
                if neighbor in remaining:
                    remaining.remove(neighbor)
                    component.add(neighbor)
                    pending.append(neighbor)
        groups.append(component)
    def endpoint_on(points, endpoint):
        return any(norm(point, endpoint) < 1e-7 for point in points)

    def bridges_sides(component):
        endpoints = [point for point in component if len([other for other in adjacency[point] if other in component]) == 1]
        return (len(endpoints) == 2 and
                ((endpoint_on(side0, endpoints[0]) and endpoint_on(side1, endpoints[1])) or
                 (endpoint_on(side0, endpoints[1]) and endpoint_on(side1, endpoints[0]))))

    candidates = [group for group in groups if bridges_sides(group)]
    if not candidates:
        raise RuntimeError('No selected guide chain connects the radial sides')

    def radial_position(side, point):
        distance = sum(norm(a, b) for a, b in zip(side, side[1:]))
        covered = 0
        for a, b in zip(side, side[1:]):
            if norm(point, b) < 1e-7:
                return (covered + norm(a, b)) / distance
            covered += norm(a, b)
        if norm(point, side[0]) < 1e-7:
            return 0
        raise RuntimeError('Guide endpoint is not on the radial side')

    def ring_score(group):
        endpoints = [p for p in group if len(adjacency[p]) == 1]
        first = next(p for p in endpoints if endpoint_on(side0, p))
        second = next(p for p in endpoints if endpoint_on(side1, p))
        return min(radial_position(side0, first), radial_position(side1, second))

    # Additional guide chains can also connect both sides. The main annulus
    # guide is the outermost one, irrespective of absolute frame length.
    candidates.sort(key=ring_score, reverse=True)
    if len(candidates) > 1 and abs(ring_score(candidates[0]) - ring_score(candidates[1])) < 1e-7:
        raise RuntimeError('Two outer guide chains are indistinguishable')
    main_ring = candidates[0]
    extra_frames = [(a, b, fixed, opening) for a, b, fixed, opening in frames
                    if a not in main_ring and b not in main_ring and not chord(a, b)]
    extra_guides = len(extra_frames)
    if verbose:
        print(f"additional guide-frame segments={extra_guides}")
    def ordered_guide(component):
        neighbors = {point: [other for other in adjacency[point] if other in component]
                     for point in component}
        endpoints = [point for point, adjacent in neighbors.items() if len(adjacent) == 1]
        if len(endpoints) != 2:
            raise RuntimeError('Guide frame chain must be simple and open')
        first = next(point for point in endpoints if endpoint_on(side0, point))
        chain = [first]
        while len(chain) == 1 or len(neighbors[chain[-1]]) != 1:
            next_points = [p for p in neighbors[chain[-1]] if len(chain) < 2 or p != chain[-2]]
            if len(next_points) != 1:
                raise RuntimeError('Guide frame chain branches')
            chain.append(next_points[0])
        if len(chain) != len(component):
            raise RuntimeError('Guide frame chain is incomplete')
        return chain

    ring = ordered_guide(main_ring)
    complete_guides = [ordered_guide(group) for group in reversed(candidates)]
    complete_points = set().union(*candidates)
    complete_guide_frames = all(a in complete_points and b in complete_points
                                for a, b, _, _ in extra_frames)

    def split_at_ring(side, ring_point):
        index = min(range(len(side)), key=lambda i: norm(side[i], ring_point))
        if norm(side[index], ring_point) > 1e-6:
            raise RuntimeError("Ring endpoint not present in the prescribed radial side")
        return side[:index + 1], side[index:]

    inner0, outer0 = split_at_ring(side0, ring[0])
    inner1, outer1 = split_at_ring(side1, ring[-1])
    step = float(os.environ.get('SECTOR_RADIAL_STEP', '.5'))
    if step < .5:
        def subdivide(points):
            result = [points[0]]
            for first, second in zip(points, points[1:]):
                divisions = max(1, math.ceil(norm(first, second) / step - 1e-9))
                result.extend(lerp(first, second, i/divisions)
                              for i in range(1, divisions+1))
            return result
        inner0, inner1 = subdivide(inner0), subdivide(inner1)
        outer0, outer1 = subdivide(outer0), subdivide(outer1)
    extra_layers = int(os.environ.get('SECTOR_REFINE_INNER_LAYERS', '0'))
    if extra_layers:
        def refine_near_square(points):
            result = [points[0]]
            for index, (first, second) in enumerate(zip(points, points[1:])):
                if index < extra_layers:
                    result.append(lerp(first, second, .5))
                result.append(second)
            return result
        inner0, inner1 = refine_near_square(inner0), refine_near_square(inner1)
    return inner, ring, outer, inner0, inner1, outer0, outer1, extra_frames, (
        complete_guides if complete_guide_frames else [])


def applicable(boundary, maximum):
    """Admit only planar annular sectors with a selected outer chord and guide.

    This is a geometric capability check, independent of the SAP model name.
    Unsupported polygons use the existing frame-constrained Gmsh backend.
    """
    corners, edges, interior, frames, holes, symmetry, symmetry2, _, _, _, _, locked = polygon.read_input(boundary)
    if maximum <= 0 or not frames or not locked or holes or symmetry or symmetry2 or any(frame[3] for frame in frames):
        return False
    points = list(corners.values()) + [p for stations in edges.values() for _, p in stations] + interior
    points += [p for first, second, _, _ in frames for p in (first, second)]
    z0 = points[0][2]
    if any(abs(p[2] - z0) > maximum * 1e-7 for p in points):
        return False  # The current block mapping uses a horizontal XY plane.
    try:
        inner, ring, outer, side0, side1, outer0, outer1, _, _ = read_sector(boundary, maximum, verbose=False)
    except (RuntimeError, ValueError, IndexError, StopIteration):
        return False
    if len(outer) != len(ring) or len(outer0) != len(outer1) or (
            len(side0) != len(side1) and not os.environ.get('SAP_QUAD_DENSE_BOUNDARIES')):
        return False
    if len(ring) < len(inner) or (len(ring) - len(inner) + 1) // 2 > len(side0) - 1:
        return False
    return any((norm(a, outer[0]) < 1e-7 and norm(b, outer[-1]) < 1e-7) or
               (norm(b, outer[0]) < 1e-7 and norm(a, outer[-1]) < 1e-7)
               for a, b, _, _ in frames)


def inner_mesh_with_guides(inner, ring, side0, side1, frames):
    boundary = ring + list(reversed(inner))
    corners = {i + 1: point for i, point in enumerate(boundary)}
    edges = {}
    locked = set()
    ring_end = len(ring)
    reversed_inner_start = ring_end + 1
    for i, first in corners.items():
        second = corners[i % len(corners) + 1]
        if i == ring_end:
            points = list(reversed(side1))
        elif i == len(corners):
            points = side0
        else:
            points = [first, second]
            locked.add(i)
        if norm(first, points[0]) > 1e-7 or norm(second, points[-1]) > 1e-7:
            raise RuntimeError(f"Guide-sector edge {i} has mismatched endpoints")
        edges[i] = [(j / (len(points) - 1), xyz) for j, xyz in enumerate(points)]
    best = None
    for factor in (1.2, 1.0, 0.9, 0.8, 0.7, 0.6):
        try:
            nodes, quads, triangles, protected = polygon.generate_with_frames(
                corners, edges, [], frames, .5, factor, locked_edges=locked)
            metrics = polygon.quad_diagnostics(nodes, quads)
            critical = metrics[4] > 175
            print(f"inner guide factor={factor} quads={len(quads)} triangles={len(triangles)} "
                  f"max_quad_angle={metrics[4]:.2f}")
            candidate = (int(critical), len(quads) + len(triangles), nodes, quads + triangles)
            if best is None or candidate[:2] < best[:2]:
                best = candidate
            if not critical:
                break
        except Exception as error:
            print(f"inner guide factor={factor} failed: {error}")
    if best is None:
        raise RuntimeError("Could not mesh the extra guide-frame constraints")
    return best[2:]


def transition_mesh(bottom, top, left, right, maximum):
    n0, n1 = len(bottom) - 1, len(top) - 1
    nleft, nright = len(left) - 1, len(right) - 1
    width = max(norm(top[0], top[-1]), norm(bottom[0], bottom[-1]))
    height = (sum(norm(a, b) for a, b in zip(left, left[1:])) +
              sum(norm(a, b) for a, b in zip(right, right[1:]))) / 2
    gmsh.initialize()
    try:
        gmsh.option.setNumber("General.Terminal", 0)
        gmsh.model.add("sector_transition")
        ps = [gmsh.model.geo.addPoint(x, y, 0, maximum) for x, y in
              ((0, 0), (width, 0), (width, height), (0, height))]
        lines = [gmsh.model.geo.addLine(ps[i], ps[(i + 1) % 4]) for i in range(4)]
        surface = gmsh.model.geo.addPlaneSurface([gmsh.model.geo.addCurveLoop(lines)])
        gmsh.model.geo.synchronize()
        for line, intervals in zip(lines, (n0, nright, n1, nleft)):
            gmsh.model.mesh.setTransfiniteCurve(line, intervals + 1)
        gmsh.model.mesh.setRecombine(2, surface)
        gmsh.option.setNumber("Mesh.MeshSizeMin", maximum * .5)
        gmsh.option.setNumber("Mesh.MeshSizeMax", maximum)
        gmsh.option.setNumber("Mesh.Algorithm", int(os.environ.get('SECTOR_TRANSITION_ALGORITHM', '6')))
        gmsh.option.setNumber("Mesh.RecombinationAlgorithm", int(os.environ.get('SECTOR_TRANSITION_RECOMB', '1')))
        gmsh.model.mesh.generate(2)
        tags, coordinates, _ = gmsh.model.mesh.getNodes()
        local = {int(tag): (coordinates[i], coordinates[i + 1]) for tag, i in
                 zip(tags, range(0, len(coordinates), 3))}
        nodes = {}
        for tag, (x, y) in local.items():
            u, v = x / width, y / height
            base = polyline(bottom, u)
            crown = polyline(top, u)
            lpoint = polyline(left, v)
            rpoint = polyline(right, v)
            nodes[tag] = tuple((1-v)*base[k] + v*crown[k] + (1-u)*lpoint[k] + u*rpoint[k] -
                               ((1-u)*(1-v)*bottom[0][k] + u*(1-v)*bottom[-1][k] +
                                (1-u)*v*top[0][k] + u*v*top[-1][k]) for k in range(3))
        kinds, _, connectivity = gmsh.model.mesh.getElements(2)
        elements = [tuple(int(v) for v in values[i:i+count])
                    for kind, values in zip(kinds, connectivity)
                    for count in [3 if kind == 2 else 4]
                    for i in range(0, len(values), count)]
        return nodes, elements
    finally:
        gmsh.finalize()


def structured_growth_mesh(bottom, top, left, right, maximum):
    """Prototype: pairwise column growth, preserving radial-side stations.

    A 2->4 strip has eight boundary edges and admits a three-quad transition
    around an interior node. Each added pair is inserted on one radial row,
    with unchanged column counts on the other rows. With an odd difference,
    parity forces one triangle unless an extra shared-side station is planned.
    """
    if len(left) != len(right):
        raise RuntimeError('Opposite radial sides have different stations')
    rows = len(left) - 1
    initial, final = len(bottom) - 1, len(top) - 1
    difference = final - initial
    increments = (difference + 1) // 2
    if final < initial or increments > rows:
        raise RuntimeError('Column growth needs at least one radial row per transition')

    def point(u, v):
        base, crown = polyline(bottom, u), polyline(top, u)
        a, b = polyline(left, v), polyline(right, v)
        return tuple((1-v)*base[k]+v*crown[k]+(1-u)*a[k]+u*b[k] -
                     ((1-u)*(1-v)*bottom[0][k]+u*(1-v)*bottom[-1][k] +
                      (1-u)*v*top[0][k]+u*v*top[-1][k]) for k in range(3))

    nodes, elements, pool = {}, [], {}

    def tag(p):
        key = tuple(round(value, 9) for value in p)
        if key not in pool:
            pool[key] = len(pool) + 1
            nodes[pool[key]] = p
        return pool[key]

    count = initial
    # A transition on the first row moves the long immutable opening segments
    # into smaller interior intervals without inserting vertices on the hole.
    grow_rows = {int(i * rows / increments):
                 (1 if difference % 2 and i == increments // 2 else 2)
                 for i in range(increments)} if increments else {}
    for row in range(rows):
        next_count = count + grow_rows.get(row, 0)
        low = [tag(point(i/count, row/rows)) for i in range(count+1)]
        high = [tag(point(i/next_count, (row+1)/rows)) for i in range(next_count+1)]
        if next_count == count:
            elements.extend((low[i], low[i+1], high[i+1], high[i]) for i in range(count))
        else:
            k = count // 2
            for i in range(k):
                elements.append((low[i], low[i+1], high[i+1], high[i]))
            if next_count == count + 1:
                for i in range(k+1, count):
                    elements.append((low[i], low[i+1], high[i+2], high[i+1]))
                # A five-sided patch cannot consist entirely of quadrangles.
                elements.extend(((low[k], low[k+1], high[k+2], high[k+1]),
                                 (low[k], high[k+1], high[k])))
            else:
                for i in range(k+1, count):
                    elements.append((low[i], low[i+1], high[i+3], high[i+2]))
                # The six-sided patch has a central node and exactly three quads.
                ring = (low[k], low[k+1], high[k+3], high[k+2], high[k+1], high[k])
                center = tag(tuple(sum(nodes[t][axis] for t in ring)/6 for axis in range(3)))
                elements.extend(((center, ring[0], ring[1], ring[2]),
                                 (center, ring[2], ring[3], ring[4]),
                                 (center, ring[4], ring[5], ring[0])))
        count = next_count
    print(f'structured growth: {initial}->{final} columns, {rows} rows, '
          f'{len(elements)} quad patches', flush=True)
    return nodes, elements


def build(boundary, output):
    corners, edges, interior, frames, *_ = polygon.read_input(boundary)
    inner, ring, outer, inner0, inner1, outer0, outer1, extra_frames, complete_guides = read_sector(boundary)
    print(f"inner={len(inner)-1} ring={len(ring)-1} outer={len(outer)-1} "
          f"radial inner={len(inner0)-1}/{len(inner1)-1} outer={len(outer0)-1}/{len(outer1)-1}")
    # Full guide chains are internal cross-sections of the structured block.
    # Partial guide curves instead need a locally constrained Gmsh patch.
    method = (transition_mesh if os.environ.get('SECTOR_STRUCTURED_TRANSITION') == '0'
              else structured_growth_mesh)
    inner_size = float(os.environ.get('SECTOR_INNER_SIZE', '.5'))
    if extra_frames and len(complete_guides) > 1:
        nodes, elements = {}, []
        start0 = start1 = 0
        previous = inner
        for guide in complete_guides:
            index0 = next(i for i in range(start0, len(inner0)) if norm(inner0[i], guide[0]) < 1e-7)
            index1 = next(i for i in range(start1, len(inner1)) if norm(inner1[i], guide[-1]) < 1e-7)
            local_nodes, local_elements = method(previous, guide, inner0[start0:index0+1],
                                                 inner1[start1:index1+1], inner_size)
            offset = len(nodes)
            nodes.update({tag + offset: point for tag, point in local_nodes.items()})
            elements.extend(tuple(tag + offset for tag in element) for element in local_elements)
            previous, start0, start1 = guide, index0, index1
        if previous != ring or start0 != len(inner0) - 1 or start1 != len(inner1) - 1:
            raise RuntimeError('Structured guide chains do not cover the inner annulus')
    elif extra_frames:
        nodes, elements = inner_mesh_with_guides(inner, ring, inner0, inner1, extra_frames)
    else:
        nodes, elements = method(inner, ring, inner0, inner1,
                                 inner_size)
    pool = {}
    result_nodes = {}
    result_elements = []

    def tag(point):
        key = tuple(round(float(v), 9) for v in point)
        if key not in pool:
            pool[key] = len(pool) + 1
            result_nodes[pool[key]] = tuple(float(v) for v in point)
        return pool[key]

    for element in elements:
        result_elements.append(tuple(tag(nodes[n]) for n in element))

    # The circular guide to the selected outer-sector chord has matching
    # tangential stations; all prescribed radial stations are retained.
    chord = [lerp(outer[0], outer[-1], i/(len(ring)-1)) for i in range(len(ring))]
    if len(outer0) != len(outer1):
        raise RuntimeError("Opposite radial sides require the same interval count")
    rows = len(outer0) - 1
    for row in range(rows):
        a, b = row/rows, (row+1)/rows
        for col in range(len(ring)-1):
            def mapped(u, v):
                r = polyline(ring, u)
                c = polyline(chord, u)
                return lerp(r, c, v)
            result_elements.append(tuple(tag(mapped(u, v)) for u, v in
                ((col/(len(ring)-1), a), ((col+1)/(len(ring)-1), a),
                 ((col+1)/(len(ring)-1), b), (col/(len(ring)-1), b))))

    # Arc-to-chord cap: the endpoints coincide. Use additional *interior*
    # radial layers where the chord sagitta exceeds the target; never add
    # stations along the explicitly selected outer circular chords.
    if len(outer) != len(chord):
        raise RuntimeError("Outer arc and frame chord need matching stations")
    cap_layers = max(1, math.ceil(max(norm(a, b) for a, b in zip(chord, outer)) / .5 - 1e-9))
    for layer in range(cap_layers):
        low, high = layer/cap_layers, (layer+1)/cap_layers
        for col in range(len(outer)-1):
            vertices = [lerp(chord[col], outer[col], low),
                        lerp(chord[col+1], outer[col+1], low),
                        lerp(chord[col+1], outer[col+1], high),
                        lerp(chord[col], outer[col], high)]
            distinct = []
            for point in vertices:
                if all(norm(point, old) > 1e-8 for old in distinct):
                    distinct.append(point)
            result_elements.append(tuple(tag(point) for point in distinct))

    def worst_angle(element):
        points = [result_nodes[node] for node in element]
        angles = []
        for index, point in enumerate(points):
            before = points[(index-1) % len(points)]
            after = points[(index+1) % len(points)]
            a = tuple(before[axis]-point[axis] for axis in range(3))
            b = tuple(after[axis]-point[axis] for axis in range(3))
            cosine = sum(a[axis]*b[axis] for axis in range(3)) / math.dist(before, point) / math.dist(after, point)
            angles.append(math.degrees(math.acos(max(-1, min(1, cosine)))))
        return max(range(len(angles)), key=angles.__getitem__), max(angles)

    # A near-straight vertex of a constrained polyline can make a quad fail
    # an angle criterion even when both diagonals lie safely inside it.
    # Split only that exceptional quad; do not globally refine the mesh.
    repaired = []
    for element in result_elements:
        if len(element) == 4:
            pivot, angle = worst_angle(element)
            if angle > 175:
                a, b, c, d = (element[(pivot + offset) % 4] for offset in range(4))
                repaired.extend(((a, b, c), (a, c, d)))
                continue
        repaired.append(element)
    result_elements = repaired

    def area(points):
        return .5 * sum(p[0] * q[1] - q[0] * p[1]
                          for p, q in zip(points, points[1:] + points[:1]))

    source_area = area([corners[i] for i in sorted(corners)])
    result_elements = [tuple(reversed(element)) if area([result_nodes[node] for node in element]) * source_area < 0
                       else element for element in result_elements]
    signed = [area([result_nodes[node] for node in element]) for element in result_elements]
    inverse = sum(value * source_area <= 1e-8 for value in signed)
    total_area = sum(abs(value) for value in signed)
    valid = {tuple(round(v, 7) for v in xyz) for xyz in result_nodes.values()}
    missing_boundary = sum(tuple(round(v, 7) for v in xyz) not in valid
                           for points in edges.values() for _, xyz in points)
    missing_interior = sum(tuple(round(v, 7) for v in xyz) not in valid for xyz in interior)
    metrics = polygon.element_metrics(result_nodes,
        [element for element in result_elements if len(element) == 4],
        [element for element in result_elements if len(element) == 3])
    longest = max((math.dist(result_nodes[a], result_nodes[b]), result_nodes[a], result_nodes[b], len(element))
                  for element in result_elements for a, b in zip(element, element[1:] + element[:1]))
    fixed_segments = {tuple(sorted((tuple(round(v, 7) for v in a[1]),
                                    tuple(round(v, 7) for v in b[1]))))
                      for points in edges.values() for a, b in zip(points, points[1:])}
    free_edges = [math.dist(result_nodes[a], result_nodes[b]) for element in result_elements
                  for a, b in zip(element, element[1:] + element[:1])
                  if tuple(sorted((tuple(round(v, 7) for v in result_nodes[a]),
                                   tuple(round(v, 7) for v in result_nodes[b])))) not in fixed_segments]
    print(f"source_area={abs(source_area):.5g} sum_area={total_area:.5g} "
          f"inverted={inverse} missing_boundary={missing_boundary} "
          f"missing_interior={missing_interior} max_edge={metrics[1]:.4g} "
          f"max_aspect={metrics[2]:.4g} max_unlocked={max(free_edges):.4g} "
          f"oversize_unlocked={sum(value > .500001 for value in free_edges)} longest_edge="
          f"{tuple(tuple(round(value, 3) for value in point[:2]) for point in longest[1:3])} "
          f"element_vertices={longest[3]}")
    if inverse or missing_boundary or missing_interior or abs(total_area / abs(source_area) - 1) > .01:
        raise RuntimeError("Prototype sector failed geometric validation")

    with open(output, "w", newline="", encoding="ascii") as stream:
        writer = csv.writer(stream)
        for node, xyz in result_nodes.items():
            writer.writerow(["N", node, *(f"{x:.17g}" for x in xyz)])
        for element in result_elements:
            writer.writerow(["E", *element])
    triangles = sum(len(item) == 3 for item in result_elements)
    quads = sum(len(item) == 4 for item in result_elements)
    print(f"quads={quads} triangles={triangles} nodes={len(result_nodes)}")


if __name__ == "__main__":
    build(sys.argv[1], sys.argv[2])


def generate_checked(boundary, output, maximum):
    """Try a sector block mesh; reject incomplete or over-size candidates."""
    import sap_sector_collar
    import sap_sector_repair
    import sap_sector_smoothing

    source = Path(boundary)
    destination = Path(output)
    if maximum <= 0:
        raise ValueError('Sector maximum edge must be positive')
    tolerance = polygon.edge_tolerance_percent()
    permitted = .5 * (1 + tolerance / 100)
    corners, edges, interior, frames, holes, symmetry, symmetry2, *_ = polygon.read_input(boundary)
    if holes or symmetry or symmetry2 or not frames or any(frame[3] for frame in frames):
        raise RuntimeError('Sector-block meshing is not applicable to holes, reflection or selected openings')

    factor = .5 / maximum
    with tempfile.TemporaryDirectory(prefix='sector-block-', dir=str(destination.parent)) as temporary:
        folder = Path(temporary)
        normalized = folder / 'boundary.csv'
        clipped = folder / 'clipped.csv'
        coarse = folder / 'blocks.csv'
        smoothed = folder / 'smoothed.csv'
        repaired = folder / 'repaired.csv'
        stitched = folder / 'stitched.csv'
        with source.open(newline='', encoding='ascii') as stream, normalized.open('w', newline='', encoding='ascii') as target:
            writer = csv.writer(target)
            for row in csv.reader(stream):
                if row[0] in ('CORNER', 'EDGE', 'INTERIOR', 'REGULAR_POINT'):
                    row[4:7] = [format(float(value) * factor, '.17g') for value in row[4:7]]
                elif row[0] == 'FRAME':
                    row[4:10] = [format(float(value) * factor, '.17g') for value in row[4:10]]
                writer.writerow(row)
        collars = sap_sector_collar.write_clipped(normalized, clipped, .5)
        build(clipped, coarse)
        sap_sector_smoothing.run(coarse, clipped, smoothed, permitted)
        sap_sector_repair.run(smoothed, clipped, repaired, permitted)
        nodes, elements = sap_sector_collar.stitch(repaired, stitched, collars)
        count, longest_free = sap_sector_collar.validate(normalized, nodes, elements, permitted)
        with destination.open('w', newline='', encoding='ascii') as stream:
            writer = csv.writer(stream)
            for tag, point in nodes.items():
                writer.writerow(['N', tag, *(format(value / factor, '.17g') for value in point)])
            for element in elements:
                writer.writerow(['E', *element])
        print(f'Structured annular sector: {sum(len(element)==4 for element in elements)} quads, '
               f'{sum(len(element)==3 for element in elements)} triangles; '
              f'{len(collars)} opening collars; longest free edge {longest_free / factor:.4f}; '
              f'permitted {permitted / factor:.4f} ({tolerance:g}% tolerance); '
              'selected contour and frame guides preserved')
        return True
