"""Constrained node relaxation for sector-block meshes."""
import csv
import math
import os
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "SapQuadTransitionPlugin"))
from sap_general_polygon_mesher import read_input


def distance_to_segment(point, a, b):
    direction = tuple(b[i] - a[i] for i in range(3))
    size = sum(v*v for v in direction)
    t = max(0, min(1, sum((point[i]-a[i])*direction[i] for i in range(3))/size))
    return math.dist(point, tuple(a[i]+t*direction[i] for i in range(3)))


def run(source, boundary, destination, size=.5):
    corners, edges, interior, frames, *_ = read_input(boundary)
    with source.open(newline="", encoding="ascii") as stream:
        rows = list(csv.reader(stream))
    nodes = {int(row[1]): tuple(map(float, row[2:5])) for row in rows if row[0] == 'N'}
    elements = [tuple(map(int, row[1:])) for row in rows if row[0] == 'E']
    fixed = set()
    prescribed = [xyz for points in edges.values() for _, xyz in points] + interior
    boundary_segments = [(a[1], b[1]) for points in edges.values()
                         for a, b in zip(points, points[1:])]
    for tag, point in nodes.items():
        if any(math.dist(point, xyz) < 1e-7 for xyz in prescribed) or any(
                distance_to_segment(point, a, b) < 1e-7 for a, b in boundary_segments) or any(
                distance_to_segment(point, a, b) < 1e-7 for a, b, _, _ in frames):
            fixed.add(tag)
    node_by_coordinate = {tuple(round(v, 8) for v in point): tag for tag, point in nodes.items()}
    locked_edges = set()
    for points in edges.values():
        for first, second in zip(points, points[1:]):
            tags = [node_by_coordinate.get(tuple(round(v, 8) for v in item[1]))
                    for item in (first, second)]
            if None not in tags:
                locked_edges.add(tuple(sorted(tags)))
    neighbors, incident = defaultdict(set), defaultdict(list)
    for element in elements:
        for index, tag in enumerate(element):
            neighbors[tag].update((element[index-1], element[(index+1) % len(element)]))
            incident[tag].append(element)

    source_sign = 1 if sum(corners[i][0]*corners[i % len(corners)+1][1] -
                           corners[i % len(corners)+1][0]*corners[i][1]
                           for i in corners) > 0 else -1
    def score(element):
        xyz = [nodes[tag] for tag in element]
        signed = .5 * sum(a[0]*b[1]-b[0]*a[1]
                            for a, b in zip(xyz, xyz[1:] + xyz[:1]))
        if signed * source_sign <= 1e-8:
            return 1e10
        lengths = [math.dist(a,b) for a,b in zip(xyz,xyz[1:]+xyz[:1])]
        penalty = 0
        for i, length in enumerate(lengths):
            # An original selected contour segment can already exceed the target.
            a,b = element[i],element[(i+1)%len(element)]
            locked = tuple(sorted((a,b))) in locked_edges
            if not locked:
                penalty += float(os.environ.get('SECTOR_EDGE_WEIGHT', '100')) * max(0, length/size - 1)**2
        aspect = max(lengths)/min(lengths)
        penalty += 3*max(0,aspect-4)**2
        for i, point in enumerate(xyz):
            prev, nxt = xyz[i-1],xyz[(i+1)%len(xyz)]
            v = tuple(prev[k]-point[k] for k in range(3))
            w = tuple(nxt[k]-point[k] for k in range(3))
            angle = math.degrees(math.acos(max(-1,min(1,sum(v[k]*w[k] for k in range(3)) /
                math.dist(prev,point)/math.dist(nxt,point)))))
            penalty += .05*max(0,angle-(155 if len(element)==4 else 105))**2
        return penalty

    def unlocked_stats():
        values = [math.dist(nodes[a], nodes[b]) for e in elements
                  for a,b in zip(e,e[1:]+e[:1]) if tuple(sorted((a,b))) not in locked_edges]
        return max(values), sum(v > size + 1e-6 for v in values)
    before = max(math.dist(nodes[a],nodes[b]) for e in elements for a,b in zip(e,e[1:]+e[:1]))
    free_before = unlocked_stats()
    changes = 0
    for iteration in range(35):
        moved = 0
        for tag in nodes:
            if tag in fixed or not neighbors[tag]:
                continue
            old = nodes[tag]
            baseline = sum(score(e) for e in incident[tag])
            average = tuple(sum(nodes[n][i] for n in neighbors[tag])/len(neighbors[tag]) for i in range(3))
            best, best_score = old, baseline
            for alpha in (.2,.4,.7,1):
                nodes[tag] = tuple((1-alpha)*old[i]+alpha*average[i] for i in range(3))
                result = sum(score(e) for e in incident[tag])
                if result < best_score - 1e-8:
                    best, best_score = nodes[tag], result
            nodes[tag] = best
            if best != old:
                moved += 1
        changes += moved
        if not moved:
            break
    after = max(math.dist(nodes[a],nodes[b]) for e in elements for a,b in zip(e,e[1:]+e[:1]))
    free_after = unlocked_stats()
    inverted = sum(score(e) >= 1e10 for e in elements)
    with destination.open('w',newline='',encoding='ascii') as stream:
        writer = csv.writer(stream)
        for tag,xyz in nodes.items():
            writer.writerow(['N',tag,*(f'{v:.17g}' for v in xyz)])
        for element in elements:
            writer.writerow(['E',*element])
    print(f'fixed={len(fixed)} moved={changes} max_edge={before:.4f}->{after:.4f} '
          f'unlocked_max={free_before[0]:.4f}->{free_after[0]:.4f} '
          f'oversize_edges={free_before[1]}->{free_after[1]} inverted={inverted}')
    if free_after[1] and free_after[1] <= 20:
        observed = set()
        for element in elements:
            for a, b in zip(element, element[1:] + element[:1]):
                name = tuple(sorted((a, b)))
                if name not in observed and name not in locked_edges and math.dist(nodes[a],nodes[b]) > size + 1e-6:
                    observed.add(name)
                    print(f'  oversize={math.dist(nodes[a],nodes[b]):.4f} '
                          f'a={tuple(round(v,3) for v in nodes[a][:2])} '
                          f'b={tuple(round(v,3) for v in nodes[b][:2])}')
    if inverted:
        raise RuntimeError('Smoothing inverted an element')


if __name__ == '__main__':
    run(Path(sys.argv[1]),Path(sys.argv[2]),Path(sys.argv[3]))
