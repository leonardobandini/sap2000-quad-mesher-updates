import csv
import math
import sys
from pathlib import Path

# Copyright (C) 2026 Leonardo Bandini
# SPDX-License-Identifier: GPL-2.0-or-later
import gmsh
sys.path.insert(0, str(Path(__file__).resolve().parent))
from sap_general_polygon_mesher import permitted_size


def read_boundary(path):
    corners = {}
    edges = {1: [], 2: [], 3: [], 4: []}
    with open(path, newline="", encoding="ascii") as stream:
        for row in csv.reader(stream):
            if row[0] == "CORNER":
                corners[int(row[1])] = tuple(float(value) for value in row[4:7])
            elif row[0] == "EDGE":
                edges[int(row[1])].append((float(row[3]), tuple(float(value) for value in row[4:7])))
    for points in edges.values():
        points.sort()
    if len(corners) != 4 or len(edges[1]) < 3 or len(edges[3]) < 3:
        raise RuntimeError("Rectangular transition meshing requires selected points on two opposite edges")
    return corners, edges


def refine_edge(points, max_size):
    if len(points) > 2:
        return [point for _, point in points]
    refined = []
    for (_, first), (_, second) in zip(points[:-1], points[1:]):
        if not refined:
            refined.append(first)
        divisions = max(1, math.ceil(math.dist(first, second) / max_size - 1e-9))
        for index in range(1, divisions + 1):
            refined.append(interpolate(first, second, index / divisions))
    return refined


def generate(width, height, bottom_segments, top_segments, right_segments, left_segments, max_size,
             recombination_algorithm=2, mesh_algorithm=8):
    gmsh.initialize()
    try:
        gmsh.option.setNumber("General.Terminal", 0)
        gmsh.model.add("rectangular_transition")
        p1 = gmsh.model.geo.addPoint(-width / 2, height, 0, max_size * 0.7)
        p2 = gmsh.model.geo.addPoint(width / 2, height, 0, max_size * 0.7)
        p3 = gmsh.model.geo.addPoint(width / 2, 2 * height, 0, max_size * 0.7)
        p4 = gmsh.model.geo.addPoint(-width / 2, 2 * height, 0, max_size * 0.7)
        curves = [
            gmsh.model.geo.addLine(p1, p2), gmsh.model.geo.addLine(p2, p3),
            gmsh.model.geo.addLine(p3, p4), gmsh.model.geo.addLine(p4, p1),
        ]
        surface = gmsh.model.geo.addPlaneSurface([gmsh.model.geo.addCurveLoop(curves)])
        gmsh.model.geo.synchronize()
        for curve, segments in zip(curves, (bottom_segments, right_segments, top_segments, left_segments)):
            gmsh.model.mesh.setTransfiniteCurve(curve, segments + 1)
        gmsh.model.mesh.setRecombine(2, surface)
        gmsh.option.setNumber("Mesh.MeshSizeMin", max_size * 0.20)
        gmsh.option.setNumber("Mesh.MeshSizeMax", max_size * 0.50)
        gmsh.option.setNumber("Mesh.MeshSizeExtendFromBoundary", 0)
        gmsh.option.setNumber("Mesh.Algorithm", mesh_algorithm)
        gmsh.option.setNumber("Mesh.RecombinationAlgorithm", recombination_algorithm)
        gmsh.option.setNumber("Mesh.RecombineAll", 1)
        gmsh.option.setNumber("Mesh.Smoothing", 100)
        gmsh.model.mesh.generate(2)
        tags, coordinates, _ = gmsh.model.mesh.getNodes()
        nodes = {int(tag): (float(coordinates[i]), float(coordinates[i + 1])) for tag, i in zip(tags, range(0, len(coordinates), 3))}
        quads = []
        element_count = 0
        types, _, connectivity = gmsh.model.mesh.getElements(2)
        for element_type, values in zip(types, connectivity):
            _, _, _, count, _, _ = gmsh.model.mesh.getElementProperties(element_type)
            element_count += len(values) // count
            if element_type == 3:
                quads.extend(tuple(int(value) for value in values[i:i + 4]) for i in range(0, len(values), 4))
        if len(quads) != element_count:
            raise RuntimeError("Il candidato non e interamente quadrangolare")
        return nodes, quads
    finally:
        gmsh.finalize()


def interpolate(a, b, t):
    return tuple((1 - t) * x + t * y for x, y in zip(a, b))


def curve_point(points, parameter):
    scaled = max(0, min(1, parameter)) * (len(points) - 1)
    index = min(int(math.floor(scaled)), len(points) - 2)
    return interpolate(points[index], points[index + 1], scaled - index)


def map_mesh(corners, bottom, top, local_nodes, local_quads, width, height):
    nodes = {}
    for tag, (x, y) in local_nodes.items():
        u, v = (x + width / 2) / width, (y - height) / height
        nodes[tag] = interpolate(curve_point(bottom, u), curve_point(top, u), v)
    return nodes, local_quads


def build_structured(bottom, top, side_segments):
    horizontal_segments = len(bottom) - 1
    nodes = {}
    grid = []
    for row in range(side_segments + 1):
        v = row / side_segments
        grid_row = []
        for column in range(horizontal_segments + 1):
            u = column / horizontal_segments
            tag = len(nodes) + 1
            nodes[tag] = interpolate(curve_point(bottom, u), curve_point(top, u), v)
            grid_row.append(tag)
        grid.append(grid_row)
    quads = []
    for row in range(side_segments):
        for column in range(horizontal_segments):
            quads.append((grid[row][column], grid[row][column + 1], grid[row + 1][column + 1], grid[row + 1][column]))
    return nodes, quads


def metrics(nodes, quads):
    min_edge, max_edge, max_aspect = float("inf"), 0, 0
    min_angle, max_angle, max_skew, min_jacobian = 180, 0, 0, 1
    for quad in quads:
        points = [nodes[tag] for tag in quad]
        lengths = [math.dist(points[i], points[(i + 1) % 4]) for i in range(4)]
        min_edge, max_edge = min(min_edge, min(lengths)), max(max_edge, max(lengths))
        max_aspect = max(max_aspect, max(lengths) / min(lengths))
        for i in range(4):
            previous, current, following = points[(i - 1) % 4], points[i], points[(i + 1) % 4]
            a = tuple(previous[j] - current[j] for j in range(3))
            b = tuple(following[j] - current[j] for j in range(3))
            la, lb = math.dist(previous, current), math.dist(following, current)
            cosine = sum(a[j] * b[j] for j in range(3)) / (la * lb)
            angle = math.degrees(math.acos(max(-1, min(1, cosine))))
            cross = (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])
            jacobian = math.sqrt(sum(value * value for value in cross)) / (la * lb)
            min_angle, max_angle = min(min_angle, angle), max(max_angle, angle)
            max_skew, min_jacobian = max(max_skew, abs(angle - 90)), min(min_jacobian, jacobian)
    return min_edge, max_edge, max_aspect, min_angle, max_angle, max_skew, min_jacobian


def subtract(a, b):
    return tuple(a[i] - b[i] for i in range(3))


def dot(a, b):
    return sum(a[i] * b[i] for i in range(3))


def cross(a, b):
    return a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]


def norm(vector):
    return math.sqrt(dot(vector, vector))


def polygon_normal(points):
    vector = cross(subtract(points[1], points[0]), subtract(points[2], points[0]))
    length = norm(vector)
    return tuple(value / length for value in vector)


def minimum_oriented_jacobian(nodes, quads):
    reference = polygon_normal([nodes[tag] for tag in quads[0]])
    minimum = 1
    for quad in quads:
        points = [nodes[tag] for tag in quad]
        for i in range(4):
            previous = subtract(points[(i - 1) % 4], points[i])
            following = subtract(points[(i + 1) % 4], points[i])
            oriented = dot(cross(following, previous), reference) / (norm(previous) * norm(following))
            minimum = min(minimum, oriented)
    return minimum


def main():
    if len(sys.argv) != 4:
        raise RuntimeError("Usage: mesher.py boundary.csv mesh.csv max_size")
    input_path, output_path, max_size = sys.argv[1], sys.argv[2], float(sys.argv[3])
    corners, edges = read_boundary(input_path)
    bottom = refine_edge(edges[1], max_size)
    top = list(reversed(refine_edge(edges[3], max_size)))
    bottom_segments, top_segments = len(bottom) - 1, len(top) - 1
    constrained_lengths = [
        math.dist(first[1], second[1])
        for edge in (edges[1], edges[3]) if len(edge) > 2
        for first, second in zip(edge[:-1], edge[1:])
    ]
    allowed_max = max([permitted_size(max_size)] + constrained_lengths)
    width = 0.5 * (math.dist(corners[1], corners[2]) + math.dist(corners[4], corners[3]))
    height = 0.5 * (math.dist(corners[1], corners[4]) + math.dist(corners[2], corners[3]))
    best = None
    best_relaxed = None
    best_constrained = None
    best_valid = None
    relaxed_transition = False
    constrained_transition = False
    general_fallback = False
    general_search_start = None
    if bottom_segments == top_segments:
        horizontal_size = max(
            max(math.dist(bottom[i], bottom[i + 1]), math.dist(top[i], top[i + 1]))
            for i in range(bottom_segments)
        )
        vertical_target = min(max_size, horizontal_size)
        side_segments = max(1, math.ceil(height / vertical_target - 1e-9))
        nodes, quads = build_structured(bottom, top, side_segments)
        quality = metrics(nodes, quads)
        penalty = max(quality[1] / allowed_max, quality[2] / 3, quality[5] / 45, 0.5 / quality[6])
        best = penalty, nodes, quads, quality, side_segments, side_segments
        oriented_jacobian = minimum_oriented_jacobian(nodes, quads)
        if quality[1] <= allowed_max * 1.001 and oriented_jacobian > 1e-4:
            valid_penalty = max(quality[2] / 4, quality[5] / 45, 0.5 / oriented_jacobian)
            best_valid = valid_penalty, nodes, quads, quality, side_segments, side_segments
    else:
        odd_transition = (bottom_segments + top_segments) % 2 != 0
        first_side = max(2, math.ceil(height / (max_size * (1.0 if odd_transition else 0.5)) - 1e-9))
        general_search_start = max(2, math.ceil(height / allowed_max - 1e-9))
        found = False
        for side_segments in range(first_side, first_side + 13):
            # An odd difference between the constrained edges requires different
            # counts on the two free sides to keep the perimeter even.
            offsets = (0,) if (bottom_segments + top_segments) % 2 == 0 else (-1, 1)
            for offset in offsets:
                right_segments, left_segments = side_segments, side_segments + offset
                if left_segments < 1:
                    continue
                for recombination_algorithm in (2, 1):
                    try:
                        local_nodes, local_quads = generate(width, height, bottom_segments, top_segments,
                                                            right_segments, left_segments, max_size,
                                                            recombination_algorithm)
                        nodes, quads = map_mesh(corners, bottom, top, local_nodes, local_quads, width, height)
                        quality = metrics(nodes, quads)
                        penalty = max(quality[1] / allowed_max, quality[2] / 3, quality[5] / 45, 0.5 / quality[6])
                        candidate = penalty, nodes, quads, quality, right_segments, left_segments
                        if best is None or candidate[0] < best[0]:
                            best = candidate
                        relaxed_penalty = max(quality[1] / (allowed_max * 1.001), quality[2] / 3,
                                              quality[5] / 60, 0.5 / quality[6])
                        relaxed_candidate = relaxed_penalty, nodes, quads, quality, right_segments, left_segments
                        if best_relaxed is None or relaxed_candidate[0] < best_relaxed[0]:
                            best_relaxed = relaxed_candidate
                        constrained_penalty = max(quality[1] / (allowed_max * 1.001), quality[2] / 5,
                                                  quality[5] / 70, 0.3 / quality[6])
                        constrained_candidate = constrained_penalty, nodes, quads, quality, right_segments, left_segments
                        if best_constrained is None or constrained_candidate[0] < best_constrained[0]:
                            best_constrained = constrained_candidate
                        oriented_jacobian = minimum_oriented_jacobian(nodes, quads)
                        if quality[1] <= allowed_max * 1.001 and oriented_jacobian > 1e-4:
                            valid_penalty = max(quality[2] / 4, quality[5] / 45, 0.5 / oriented_jacobian)
                            valid_candidate = valid_penalty, nodes, quads, quality, right_segments, left_segments
                            if best_valid is None or valid_candidate[0] < best_valid[0]:
                                best_valid = valid_candidate
                        if penalty <= 1 + 1e-7:
                            found = True
                            break
                    except Exception:
                        continue
                if found:
                    break
            if found:
                break
    if (best is None or best[0] > 1 + 1e-7) and best_relaxed is not None and best_relaxed[0] <= 1 + 1e-7:
        best = best_relaxed
        relaxed_transition = True
    if ((best is None or best[0] > 1 + 1e-7) and allowed_max > max_size * 1.001 and
            best_constrained is not None and best_constrained[0] <= 1 + 1e-7):
        best = best_constrained
        constrained_transition = True
    if ((best is None or best[0] > 1 + 1e-7) and general_search_start is not None and
            general_search_start < first_side):
        offsets = (0,) if (bottom_segments + top_segments) % 2 == 0 else (-1, 1)
        for side_segments in range(general_search_start, first_side):
            for offset in offsets:
                right_segments, left_segments = side_segments, side_segments + offset
                if left_segments < 1:
                    continue
                for recombination_algorithm in (2, 1):
                    try:
                        local_nodes, local_quads = generate(width, height, bottom_segments, top_segments,
                                                            right_segments, left_segments, max_size,
                                                            recombination_algorithm)
                        nodes, quads = map_mesh(corners, bottom, top, local_nodes, local_quads, width, height)
                        quality = metrics(nodes, quads)
                        oriented_jacobian = minimum_oriented_jacobian(nodes, quads)
                        if quality[1] > allowed_max * 1.001 or oriented_jacobian <= 1e-4:
                            continue
                        valid_penalty = max(quality[2] / 4, quality[5] / 45, 0.5 / oriented_jacobian)
                        valid_candidate = valid_penalty, nodes, quads, quality, right_segments, left_segments
                        if best_valid is None or valid_candidate[0] < best_valid[0]:
                            best_valid = valid_candidate
                    except Exception:
                        continue
    if (best is None or best[0] > 1 + 1e-7) and best_valid is not None:
        best = best_valid
        general_fallback = True
    if best is None or (best[0] > 1 + 1e-7 and not general_fallback):
        raise RuntimeError("Nessuna transizione rettangolare soddisfa lato massimo, aspect ratio, skew e Jacobiano")

    _, nodes, quads, quality, right_segments, left_segments = best
    with open(output_path, "w", newline="", encoding="ascii") as stream:
        writer = csv.writer(stream)
        for tag, xyz in nodes.items():
            writer.writerow(["N", tag, *[f"{value:.17g}" for value in xyz]])
        for quad in quads:
            writer.writerow(["E", *quad])
    print(f"Rectangular transition: {bottom_segments} -> {top_segments}; "
          f"side edges: {right_segments}/{left_segments}")
    print(f"Elements: {len(quads)} quadrilaterals; nodes: {len(nodes)}")
    print(f"Edge length: {quality[0]:.6g}..{quality[1]:.6g}; max AR: {quality[2]:.3f}; "
          f"angles: {quality[3]:.3f}..{quality[4]:.3f}; skew: {quality[5]:.3f}; min Jsc: {quality[6]:.3f}")
    if relaxed_transition:
        print("Note: odd transition topology; the controlled 60-degree skew limit was applied.")
    if constrained_transition:
        print("Note: the prescribed edge spacing is incompatible with the standard limits; "
              "the controlled fallback with AR 5, 70-degree skew, and Jsc 0.3 was applied.")
    if general_fallback:
        print("Note: no candidate satisfies the quality thresholds; the best valid full-quad mesh was selected "
              "with a positive oriented Jacobian. Review the metrics in the mesh details.")
    if allowed_max > max_size * 1.001:
        print(f"Note: requested limit {max_size:.6g} exceeded on constrained edges; only selected points were retained (maximum interval {allowed_max:.6g}).")


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
