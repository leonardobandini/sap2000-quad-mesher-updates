"""Complete a tapered sector's selected transverse guide with an internal band.

The input is a single sector. Geometry, not the area label or model name,
determines the similarity between the existing cross-section and main ring.
"""
import csv
import math
import os
from pathlib import Path

import sap_sector_blocks as blocks
import sap_general_polygon_mesher as polygon


def shared_guide(folder, maximum):
    """Fit the complete/partial transverse guides of a selection together."""
    information = []
    for path in Path(folder).glob('area-*-boundary.csv'):
        if not blocks.applicable(path, maximum):
            return None
        inner, ring, _, side0, side1, _, _, extras, complete = blocks.read_sector(path, maximum, verbose=False)
        information.append((ring, (side0, side1), extras, complete))
    if len(information) < 2:
        return None
    seeds = []
    for ring, sides, extras, complete in information:
        if len(complete) > 1 and extras:
            guide = complete[0]
            seeds.extend((blocks.polyline(ring, i/(len(guide)-1)), point)
                         for i, point in enumerate(guide))
    if len(seeds) < 2:
        for ring, sides, extras, complete in information:
            for point in {p for a, b, _, _ in extras for p in (a, b)}:
                for ring_end, side in zip((ring[0], ring[-1]), sides):
                    if any(math.dist(point, x) < 1e-7 for x in side):
                        seeds.append((ring_end, point))
    if len(seeds) < 3:
        return None

    def fit(pairs):
        px = sum(p[0][0] for p in pairs)/len(pairs)
        py = sum(p[0][1] for p in pairs)/len(pairs)
        qx = sum(p[1][0] for p in pairs)/len(pairs)
        qy = sum(p[1][1] for p in pairs)/len(pairs)
        denominator = sum((p[0][0]-px)**2+(p[0][1]-py)**2 for p in pairs)
        if denominator < 1e-10:
            return None
        a = sum((p[0][0]-px)*(p[1][0]-qx)+(p[0][1]-py)*(p[1][1]-qy) for p in pairs)/denominator
        b = sum((p[0][0]-px)*(p[1][1]-qy)-(p[0][1]-py)*(p[1][0]-qx) for p in pairs)/denominator
        return lambda p: (qx+a*(p[0]-px)-b*(p[1]-py),
                          qy+b*(p[0]-px)+a*(p[1]-py), p[2])

    preliminary = fit(seeds)
    if preliminary is None:
        return None
    pairs = {}
    rows = []
    for ring, sides, extras, complete in information:
        for point in {p for a, b, _, _ in extras for p in (a, b)}:
            index = min(range(len(ring)), key=lambda i: math.dist(point, preliminary(ring[i])))
            pairs[tuple(round(v, 8) for v in point)] = (ring[index], point)
            for side in sides:
                rows.extend(i for i, x in enumerate(side) if math.dist(x, point) < 1e-7)
    if len(pairs) < 3 or len(set(rows)) != 1:
        return None
    mapped = fit(list(pairs.values()))
    if mapped is None or max(math.dist(mapped(p), q) for p, q in pairs.values()) > maximum*.08:
        return None
    row = rows[0]
    if any(row < 2 or row >= min(len(side) for side in sides)-1 for _, sides, _, _ in information):
        return None
    return mapped, row


def prepare(source, destination, maximum):
    inner, ring, _, side0, side1, _, _, extras, complete = blocks.read_sector(source, maximum, verbose=False)
    if len(ring) < 3 or len(inner) < 2:
        return False
    shared = (shared_guide(os.environ['SAP_QUAD_DENSE_BOUNDARIES'], maximum)
              if os.environ.get('SAP_QUAD_DENSE_BOUNDARIES') else None)
    if os.environ.get('SAP_QUAD_DENSE_BOUNDARIES') and shared is None:
        return False
    if shared:
        mapped, row = shared
        anchors = (min(side0, key=lambda x: math.dist(x, mapped(ring[0]))),
                   min(side1, key=lambda x: math.dist(x, mapped(ring[-1]))))
        if any(math.dist(a, mapped(r)) > maximum*.08 for a, r in zip(anchors, (ring[0], ring[-1]))):
            return False
        if any(math.dist(mapped(ring[i]), complete[0][i]) > maximum*.08
               for i in range(len(ring))) if len(complete) > 1 else False:
            return False
    # Without selection-wide guide data, do not choose independent transverse
    # stations: adjacent sectors would otherwise become nonconforming.
    elif len(complete) > 1:
        anchors = (complete[0][0], complete[0][-1])
    elif extras:
        endpoints = {point for a, b, _, _ in extras for point in (a, b)}
        left = [point for point in endpoints if any(math.dist(point, x) < 1e-7 for x in side0)]
        right = [point for point in endpoints if any(math.dist(point, x) < 1e-7 for x in side1)]
        if len(left) != 1 or len(right) != 1:
            return False
        anchors = left[0], right[0]
    else:
        return False
    left, right = anchors
    rows = [i for i, point in enumerate(side0) if math.dist(point, left) < 1e-7]
    if len(rows) != 1 or rows[0] < 2 or rows[0] >= len(side0)-1 or right not in side1:
        return False
    row = rows[0]
    p, q = ring[0], ring[-1]
    dx, dy = q[0]-p[0], q[1]-p[1]
    denominator = dx*dx+dy*dy
    if denominator < 1e-12:
        return False
    ex, ey = right[0]-left[0], right[1]-left[1]
    a, b = (dx*ex+dy*ey)/denominator, (dx*ey-dy*ex)/denominator
    def local_map(point):
        x, y = point[0]-p[0], point[1]-p[1]
        return (left[0]+a*x-b*y, left[1]+b*x+a*y, left[2]+point[2]-p[2])
    mapped = shared[0] if shared else local_map

    n = len(ring)-1
    prescribed = {0: left, n: right}
    original = {tuple(sorted((tuple(round(v, 8) for v in x), tuple(round(v, 8) for v in y))))
                for x, y, _, _ in extras}
    for x, y, _, _ in extras:
        for point in (x, y):
            index = min(range(n+1), key=lambda i: math.dist(mapped(ring[i]), point))
            if math.dist(mapped(ring[index]), point) > maximum*.08:
                return False
            if index in prescribed and math.dist(prescribed[index], point) > 1e-7:
                return False
            prescribed[index] = point
    if len(complete) > 1:
        guide = complete[0]
        if len(guide) != n+1 or any(math.dist(mapped(x), y) > maximum*.08 for x, y in zip(ring, guide)):
            return False
        prescribed.update(enumerate(guide))
    def point(index):
        if index in prescribed:
            return prescribed[index]
        lower = max(i for i in prescribed if i < index)
        upper = min(i for i in prescribed if i > index)
        t = (index-lower)/(upper-lower)
        base = mapped(ring[index])
        delta0 = tuple(prescribed[lower][k]-mapped(ring[lower])[k] for k in range(3))
        delta1 = tuple(prescribed[upper][k]-mapped(ring[upper])[k] for k in range(3))
        return tuple(base[k]+(1-t)*delta0[k]+t*delta1[k] for k in range(3))
    guide = [point(index) for index in range(n+1)]
    if any(math.dist(x, y) > maximum+1e-7 for x, y in zip(guide, guide[1:])):
        return False
    # The same midpoint of the same prescribed side segment is shared by
    # adjacent sectors. The extra radial row permits the 3->18 transition.
    corners, edges, *_ = polygon.read_input(source)
    with Path(source).open(newline='', encoding='ascii') as stream:
        rows = list(csv.reader(stream))
    if shared:
        area = next(record[1] for record in rows if record[0] == 'AREA')
        original_boundary = Path(os.environ['SAP_QUAD_DENSE_BOUNDARIES']) / f'area-{area}-boundary.csv'
        _, original_edges, *_ = polygon.read_input(original_boundary)
    else:
        original_edges = edges
    radial = sorted(range(1, len(corners)+1),
                    key=lambda i: math.dist(corners[i], corners[i % len(corners)+1]), reverse=True)[:2]
    additions = []
    for edge in radial:
        stations = original_edges[edge]
        first_is_inner = min(math.dist(stations[0][1], inner[0]), math.dist(stations[0][1], inner[-1])) < 1e-7
        before, after = (stations[1], stations[2]) if first_is_inner else (stations[-3], stations[-2])
        middle = tuple((x+y)/2 for x, y in zip(before[1], after[1]))
        if not any(math.dist(point, middle) < 1e-7 for _, point in edges[edge]):
            additions.append(['EDGE', edge, 'QT_BAND', format((before[0]+after[0])/2, '.17g'),
                              *(format(v, '.17g') for v in middle)])
    frame_id = max(int(record[1]) for record in rows if record[0] == 'FRAME')
    rows.extend(additions)
    for x, y in zip(guide, guide[1:]):
        key = tuple(sorted((tuple(round(v, 8) for v in x), tuple(round(v, 8) for v in y))))
        if key not in original:
            frame_id += 1
            rows.append(['FRAME', frame_id, 'QT_VIRTUAL', 0,
                         *(format(v, '.17g') for v in (*x, *y)), 0, 0])
    with Path(destination).open('w', newline='', encoding='ascii') as stream:
        csv.writer(stream).writerows(rows)
    return True
