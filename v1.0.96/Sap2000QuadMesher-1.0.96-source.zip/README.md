# SAP2000 Quad Mesher — beta didattica

Lo scopo principale di questo progetto e **mostrare, con un esempio funzionante, come integrare SAP2000 con altri programmi per rendere piu efficace il proprio lavoro**. Il plugin collega C#/.NET, l'API di SAP2000 e Python/Gmsh per automatizzare la creazione di mesh quad-dominant su aree piane. Illustra metodi, procedure e potenzialita dell'integrazione tra software di terze parti: il suo valore prevalente e didattico.

La **1.0.79 e stata la prima beta destinata agli utenti**; la 1.0.80 ha introdotto la congruenza dei bordi raffittiti e un solo import FAST multi-area, la 1.0.81 ha corretto i fallback regolari e i piccoli fori condivisi, e la 1.0.82 ha aggiunto annullamento e misure con suffissi `m`, `cm`, `mm`, `ft`, `in`. Dalla 1.0.83 FAST e preselezionato ma facoltativo; la 1.0.84 aggiunge automaticamente la voce del plugin nel menu Tools di SAP2000 27 durante l'installazione. La 1.0.85 corregge l'import FAST nei modelli con triangoli o shell poligonali preesistenti. La **1.0.87** aggiunge nodi congruenti sul bordo di mesh adiacenti, gestione FAST dei triangoli generati e candidati Gmsh multicore con numero di worker configurabile. La **1.0.88** evita maglie oblunghe su aree nulle sovrapposte; la **1.0.89** corregge Undo FAST per poligoni, aggiunge backup numerati e riduce il sovra-raffittimento della mesh su geometrie triangolari e poligonali. Le versioni prima della 1.0.79 erano build di sviluppo e di prova, anche quando temporaneamente scaricabili su GitHub. La beta e utilizzabile, ma risultati e modelli devono essere verificati dall'utente nel proprio contesto tecnico. Il progetto principale e in [`SapQuadTransitionPlugin`](SapQuadTransitionPlugin/README.md).

## Stato del progetto

La **1.0.96** ripristina l'opzione della dimensione massima vincolante dopo «Annulla mesh». La 1.0.95 ha introdotto la fascia globale fitta sulle solette radiali con guide compatibili, la memoria delle ultime opzioni usate e l'anteprima della mesh con SAP2000 utilizzabile. Il riconoscimento si basa sulla geometria, non sul nome del modello; la tolleranza esplicita sugli spigoli nuovi rimane configurabile. Tutti i 36 esempi di regressione SAP2000 sono passati nella build 1.0.95.

Questa e la copia di progetto ripulita del workspace storico. Contiene il plugin, utility sperimentali, modelli SAP2000, fixture e risultati di test; build, cache e release storiche sono escluse dal controllo versione. Le fixture SAP2000 sono gestite con Git LFS.

Documentazione di continuita:

- [`docs/PROJECT_STATUS.md`](docs/PROJECT_STATUS.md): stato funzionale e tecnico verificato.
- [`docs/DEVELOPMENT.md`](docs/DEVELOPMENT.md): ambiente, build e strategia di test.
- [`docs/MIGRATION_AND_RELEASE.md`](docs/MIGRATION_AND_RELEASE.md): trasferimento, GitHub e packaging.
- [`docs/UPDATES.md`](docs/UPDATES.md): manifest GitHub, notifica aggiornamenti e procedura di pubblicazione.
- [`docs/MULTICORE_PERFORMANCE_1_0_87.md`](docs/MULTICORE_PERFORMANCE_1_0_87.md): 36 regressioni v1.0.87 e confronto controllato del backend multicore.
- [`SapQuadTransitionPlugin/README.md`](SapQuadTransitionPlugin/README.md): uso del plugin e comportamento delle mesh.

## Verifica rapida

Dal root del progetto:

```cmd
dotnet build SapQuadTransitionPlugin\SapQuadTransitionPlugin.csproj -c Release
python -c "import gmsh; print(gmsh.__version__)"
```

Verifica storica della fase di sviluppo, eseguita il 24 settembre 2026:

- compilazione Release completata con 0 warning e 0 errori;
- Python 3.12.7;
- Gmsh 4.15.2;
- SAP2000 27 interop disponibile localmente.

Il pacchetto binario include un runtime Python 3.12 privato e Gmsh 4.15.2. L'utente finale non deve installare Python, Gmsh o pacchetti `pip`.

## Avvertenza

`SAP2000v1.dll` non fa parte del progetto e non deve essere pubblicata o inclusa nei pacchetti. Le fixture SAP2000 presenti sono state dichiarate pubblicabili dal loro autore, ma sono escluse dal pacchetto binario del plugin.

## Licenza

Il [codice originale](LICENSE-APPLICATION.md) e GPL-2.0-or-later (`SPDX-License-Identifier: GPL-2.0-or-later`). `LICENSE` contiene GPLv2, `GPL-3.0.txt` GPLv3; per il backend binario combinato con OpenSSL 3 si sceglie l'opzione GPLv3. [Questa nota](SAP2000-LINKING-EXCEPTION.md) riguarda esclusivamente il codice C# dell'autore, **non concede diritti sull'API SAP2000 o su Gmsh**: i termini dei terzi sono in [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md). Gli archivi sorgenti sono allegati alla [release corrente](https://github.com/leonardobandini/sap2000-quad-mesher-updates/releases/latest) e conservati nell'[archivio pubblico dei sorgenti](https://github.com/leonardobandini/sap2000-quad-mesher-updates/tree/source-archive) dopo la sostituzione delle release di prova.
