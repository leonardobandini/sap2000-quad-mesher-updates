// Copyright (C) 2026 Leonardo Bandini
// SPDX-License-Identifier: GPL-2.0-or-later
// Additional permission for the separately installed SAP2000 API:
// see SAP2000-LINKING-EXCEPTION.md.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using SAP2000v1;

namespace SapQuadTransitionPlugin
{
    // The CSV contains every nonempty editable SAP model table before meshing,
    // including area/joint assignments, loads, patterns, constraints and
    // overwrites. Base64 fields allow arbitrary SAP text inside a CSV record.
    internal sealed class ModelCsvSnapshot
    {
        private sealed class Table
        {
            internal string Key;
            internal int Version;
            internal string[] Fields;
            internal string[] Data;
            internal int Records { get { return Data.Length / Fields.Length; } }
        }

        private sealed class SnapshotData
        {
            internal List<Table> Tables;
            internal Dictionary<string, double[]> JointCoordinates;
        }

        internal readonly string Path;
        private readonly string modelPath;
        private readonly byte[] digest;
        internal bool WasApplied { get; private set; }
        internal bool RestoreAttempted { get; private set; }

        internal void MarkApplied() { WasApplied = true; }

        private ModelCsvSnapshot(string path, string modelPath, byte[] digest)
        {
            Path = path;
            this.modelPath = modelPath;
            this.digest = digest;
        }

        private static void Check(int result, string operation)
        {
            if (result != 0) throw new InvalidOperationException(operation + " (SAP2000 code " + result + ")");
        }

        private static string B64(string value)
        {
            return Convert.ToBase64String(Encoding.UTF8.GetBytes(value ?? ""));
        }

        private static string UnB64(string value)
        {
            return Encoding.UTF8.GetString(Convert.FromBase64String(value));
        }

        private static byte[] Hash(string path)
        {
            using (var sha = SHA256.Create())
            using (var input = File.OpenRead(path)) return sha.ComputeHash(input);
        }

        private static Table Read(cSapModel model, string key)
        {
            int version = 0, records = 0;
            string[] fields = null, data = null;
            Check(model.DatabaseTables.GetTableForEditingArray(key, "", ref version, ref fields, ref records, ref data), "reading snapshot table " + key);
            if (fields == null || fields.Length == 0 || data == null || data.Length != records * fields.Length)
                throw new InvalidDataException("Invalid SAP table shape: " + key);
            return new Table { Key = key, Version = version, Fields = fields, Data = data };
        }

        internal static ModelCsvSnapshot Capture(cSapModel model)
        {
            int count = 0;
            string[] keys = null, names = null;
            int[] importTypes = null;
            bool[] isEmpty = null;
            Check(model.DatabaseTables.GetAllTables(ref count, ref keys, ref names, ref importTypes, ref isEmpty), "listing snapshot tables");
            var tables = new List<Table>();
            for (int index = 0; index < count; index++)
            {
                if (importTypes[index] == 0 || isEmpty[index]) continue;
                Table table = Read(model, keys[index]);
                if (table.Records > 0) tables.Add(table);
            }
            foreach (string required in new[] { "Joint Coordinates", "Connectivity - Area", "Area Section Assignments" })
                if (!tables.Any(table => table.Key == required))
                    throw new InvalidDataException("The model snapshot is missing " + required);
            Table originalJoints = tables.First(table => table.Key == "Joint Coordinates");
            int jointName = Array.IndexOf(originalJoints.Fields, "Joint");
            if (jointName < 0) throw new InvalidDataException("The joint table lacks point names.");
            var jointCoordinates = new Dictionary<string, double[]>();
            for (int record = 0; record < originalJoints.Records; record++)
            {
                string name = originalJoints.Data[record * originalJoints.Fields.Length + jointName];
                double x = 0, y = 0, z = 0;
                Check(model.PointObj.GetCoordCartesian(name, ref x, ref y, ref z, "Global"), "reading snapshot point " + name);
                jointCoordinates.Add(name, new[] { x, y, z });
            }

            string filename = model.GetModelFilename(true) ?? "";
            string directory = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "SAP2000QuadMesher", "snapshots");
            Directory.CreateDirectory(directory);
            string path = System.IO.Path.Combine(directory, "quadmesh-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture) +
                "-" + Guid.NewGuid().ToString("N") + ".csv");
            try
            {
                using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                using (var writer = new StreamWriter(stream, new UTF8Encoding(false)))
                {
                    writer.WriteLine("SQM_CSV_SNAPSHOT,1," + B64(filename) + "," + ((int)model.GetPresentUnits()).ToString(CultureInfo.InvariantCulture));
                    writer.WriteLine("TABLE_COUNT," + tables.Count.ToString(CultureInfo.InvariantCulture));
                    foreach (Table table in tables)
                    {
                        writer.WriteLine("TABLE," + B64(table.Key) + "," + table.Version.ToString(CultureInfo.InvariantCulture) +
                            "," + table.Fields.Length.ToString(CultureInfo.InvariantCulture) + "," + table.Records.ToString(CultureInfo.InvariantCulture));
                        writer.WriteLine("FIELDS," + string.Join(",", table.Fields.Select(B64)));
                        for (int record = 0; record < table.Records; record++)
                            writer.WriteLine("ROW," + string.Join(",", table.Data.Skip(record * table.Fields.Length).Take(table.Fields.Length).Select(B64)));
                    }
                    writer.WriteLine("JOINT_COUNT," + jointCoordinates.Count.ToString(CultureInfo.InvariantCulture));
                    foreach (KeyValuePair<string, double[]> joint in jointCoordinates)
                        writer.WriteLine("JOINT," + B64(joint.Key) + "," + string.Join(",", joint.Value
                            .Select(value => value.ToString("R", CultureInfo.InvariantCulture))));
                    writer.Flush();
                    stream.Flush(true);
                }
                return new ModelCsvSnapshot(path, filename, Hash(path));
            }
            catch
            {
                try { File.Delete(path); } catch (IOException) { }
                throw;
            }
        }

        private SnapshotData Load(cSapModel model)
        {
            if (!File.Exists(Path) || !Hash(Path).SequenceEqual(digest))
                throw new InvalidDataException("The original model CSV snapshot was changed or is missing: " + Path);
            using (var reader = new StreamReader(Path, Encoding.UTF8))
            {
                string[] header = (reader.ReadLine() ?? "").Split(',');
                if (header.Length != 4 || header[0] != "SQM_CSV_SNAPSHOT" || header[1] != "1" ||
                    UnB64(header[2]) != modelPath || model.GetModelFilename(true) != modelPath ||
                    header[3] != ((int)model.GetPresentUnits()).ToString(CultureInfo.InvariantCulture))
                    throw new InvalidDataException("The model does not match its original CSV snapshot.");
                string[] total = (reader.ReadLine() ?? "").Split(',');
                int count;
                if (total.Length != 2 || total[0] != "TABLE_COUNT" || !int.TryParse(total[1], out count) || count < 3)
                    throw new InvalidDataException("Invalid model snapshot table count.");
                var result = new List<Table>();
                for (int tableIndex = 0; tableIndex < count; tableIndex++)
                {
                    string[] tableHeader = (reader.ReadLine() ?? "").Split(',');
                    int version, width, rows;
                    if (tableHeader.Length != 5 || tableHeader[0] != "TABLE" ||
                        !int.TryParse(tableHeader[2], out version) || !int.TryParse(tableHeader[3], out width) ||
                        !int.TryParse(tableHeader[4], out rows) || width < 1 || rows < 1)
                        throw new InvalidDataException("Invalid model snapshot table header.");
                    string[] fields = (reader.ReadLine() ?? "").Split(',');
                    if (fields.Length != width + 1 || fields[0] != "FIELDS")
                        throw new InvalidDataException("Invalid model snapshot fields.");
                    var values = new List<string>();
                    for (int record = 0; record < rows; record++)
                    {
                        string[] row = (reader.ReadLine() ?? "").Split(',');
                        if (row.Length != width + 1 || row[0] != "ROW")
                            throw new InvalidDataException("Invalid model snapshot record.");
                        values.AddRange(row.Skip(1).Select(UnB64));
                    }
                    result.Add(new Table { Key = UnB64(tableHeader[1]), Version = version,
                        Fields = fields.Skip(1).Select(UnB64).ToArray(), Data = values.ToArray() });
                }
                string[] jointHeader = (reader.ReadLine() ?? "").Split(',');
                int jointCount;
                if (jointHeader.Length != 2 || jointHeader[0] != "JOINT_COUNT" ||
                    !int.TryParse(jointHeader[1], out jointCount) || jointCount < 1)
                    throw new InvalidDataException("Invalid snapshot joint coordinate count.");
                var joints = new Dictionary<string, double[]>();
                for (int joint = 0; joint < jointCount; joint++)
                {
                    string[] row = (reader.ReadLine() ?? "").Split(',');
                    double x, y, z;
                    if (row.Length != 5 || row[0] != "JOINT" ||
                        !double.TryParse(row[2], NumberStyles.Float, CultureInfo.InvariantCulture, out x) ||
                        !double.TryParse(row[3], NumberStyles.Float, CultureInfo.InvariantCulture, out y) ||
                        !double.TryParse(row[4], NumberStyles.Float, CultureInfo.InvariantCulture, out z))
                        throw new InvalidDataException("Invalid snapshot joint coordinates.");
                    joints.Add(UnB64(row[1]), new[] { x, y, z });
                }
                if (reader.ReadLine() != null || result.Select(item => item.Key).Distinct().Count() != result.Count ||
                    joints.Count != result.First(item => item.Key == "Joint Coordinates").Records)
                    throw new InvalidDataException("Unexpected trailing or repeated snapshot records.");
                return new SnapshotData { Tables = result, JointCoordinates = joints };
            }
        }

        private static void Stage(cSapModel model, Table table)
        {
            if (Environment.GetEnvironmentVariable("SAP_QUAD_DEBUG_SNAPSHOT") == "1")
                Console.WriteLine("csv-snapshot-stage=" + table.Key + " records=" + table.Records);
            int version = table.Version;
            string[] fields = table.Fields.ToArray(), values = table.Data.ToArray();
            Check(model.DatabaseTables.SetTableForEditingArray(table.Key, ref version, ref fields, table.Records, ref values),
                "restoring CSV snapshot table " + table.Key);
        }

        private static bool ExpectedBlankJointErrors(string log, int errors, Table areas)
        {
            if (errors == 0) return true;
            if (areas == null) return false;
            int areaIndex = Array.IndexOf(areas.Fields, "Area");
            int firstIndex = Array.IndexOf(areas.Fields, "Joint1");
            if (areaIndex < 0 || firstIndex < 0) return false;
            var names = new HashSet<string>();
            var expected = new HashSet<string>();
            for (int row = 0; row < areas.Records; row++)
            {
                int offset = row * areas.Fields.Length;
                string area = areas.Data[offset + areaIndex];
                bool continuation = !string.IsNullOrEmpty(area) && names.Contains(area) &&
                    !string.IsNullOrEmpty(areas.Data[offset + firstIndex]);
                for (int joint = continuation ? 2 : 4; joint <= 16; joint++)
                {
                    int field = Array.IndexOf(areas.Fields, "Joint" + joint);
                    if (field >= 0 && string.IsNullOrEmpty(areas.Data[offset + field]))
                        expected.Add((row + 1) + ":JOINT" + joint);
                }
                if (!string.IsNullOrEmpty(area)) names.Add(area);
            }
            if (errors != expected.Count) return false;
            string[] blocks = (log ?? "").Split(new[] { "*** Error Message" }, StringSplitOptions.None).Skip(1).ToArray();
            if (blocks.Length != expected.Count) return false;
            foreach (string block in blocks)
            {
                Match match = Regex.Match(block,
                    @"(?is)Table name:\s*CONNECTIVITY - AREA\s+Field name:\s*(JOINT\d+)\s+Record:\s*(\d+)\s+Invalid Joint name, joint\s+not found; joint skipped");
                if (!match.Success || !expected.Remove(match.Groups[2].Value + ":" + match.Groups[1].Value.ToUpperInvariant()))
                    return false;
            }
            return expected.Count == 0;
        }

        private static Table PadExistingTriangles(Table source)
        {
            var restored = new Table { Key = source.Key, Version = source.Version,
                Fields = source.Fields.ToArray(), Data = source.Data.ToArray() };
            int areaIndex = Array.IndexOf(restored.Fields, "Area");
            int third = Array.IndexOf(restored.Fields, "Joint3");
            int fourth = Array.IndexOf(restored.Fields, "Joint4");
            int count = Array.IndexOf(restored.Fields, "NumJoints");
            if (areaIndex < 0 || third < 0 || fourth < 0) return restored;
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int row = 0; row < restored.Records; row++)
            {
                int offset = row * restored.Fields.Length;
                string name = restored.Data[offset + areaIndex];
                if (!string.IsNullOrEmpty(name) && seen.Add(name) &&
                    (count < 0 || string.IsNullOrEmpty(restored.Data[offset + count]) || restored.Data[offset + count] == "3") &&
                    !string.IsNullOrEmpty(restored.Data[offset + third]) && string.IsNullOrEmpty(restored.Data[offset + fourth]))
                    restored.Data[offset + fourth] = restored.Data[offset + third];
            }
            return restored;
        }

        private static void Apply(cSapModel model, string phase, Table originalAreas = null)
        {
            int fatal = 0, errors = 0, warnings = 0, information = 0;
            string log = "";
            int applied = model.DatabaseTables.ApplyEditedTables(true, ref fatal, ref errors, ref warnings, ref information, ref log);
            if (Environment.GetEnvironmentVariable("SAP_QUAD_DEBUG_SNAPSHOT") == "1")
                Console.WriteLine("csv-snapshot-apply-" + phase + "=" + applied + " locked=" + model.GetModelIsLocked());
            string[] lines = (log ?? "").Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            if (applied != 0 || fatal != 0 || warnings != 0 || !ExpectedBlankJointErrors(log, errors, originalAreas))
                throw new InvalidOperationException("Original CSV snapshot " + phase + " restore reported fatal=" + fatal +
                    ", errors=" + errors + ", warnings=" + warnings + ", code=" + applied + ": " +
                    string.Join(" ", lines.Skip(Math.Max(0, lines.Length - 30))));
        }

        private static bool IsObjectAssignment(Table table)
        {
            if (table.Key == "Groups 2 - Assignments") return true;
            return table.Fields.Any(field => string.Equals(field, "Area", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(field, "Joint", StringComparison.OrdinalIgnoreCase));
        }

        internal void Restore(cSapModel model, IEnumerable<string> generatedAreas, IEnumerable<string> generatedPoints)
        {
            SnapshotData snapshot = Load(model);
            RestoreAttempted = true;
            List<Table> tables = snapshot.Tables;
            // After Apply SAP has deleted the original shell objects. Generated
            // joints can occupy their coordinates and SAP may silently merge
            // original joint names back into those joints during table import.
            // Remove only objects owned by this mesh before replaying the CSV.
            int areaCount = 0;
            string[] areaNames = null;
            Check(model.AreaObj.GetNameList(ref areaCount, ref areaNames), "listing applied mesh areas");
            var presentAreas = new HashSet<string>(areaNames ?? new string[0]);
            foreach (string area in generatedAreas.Distinct())
                if (presentAreas.Contains(area))
                    Check(model.AreaObj.Delete(area, eItemType.Objects), "removing applied mesh area " + area);
            int pointCount = 0;
            string[] pointNames = null;
            Check(model.PointObj.GetNameList(ref pointCount, ref pointNames), "listing applied mesh joints");
            var presentPoints = new HashSet<string>(pointNames ?? new string[0]);
            foreach (string point in generatedPoints.Distinct())
                if (presentPoints.Contains(point))
                {
                    Check(model.PointObj.SetSpecialPoint(point, true, eItemType.Objects), "preparing applied mesh joint removal " + point);
                    Check(model.PointObj.DeleteSpecialPoint(point, eItemType.Objects), "removing applied mesh joint " + point);
                }
            Check(model.PointObj.GetNameList(ref pointCount, ref pointNames), "listing joints for CSV reconstruction");
            presentPoints = new HashSet<string>(pointNames ?? new string[0]);
            foreach (KeyValuePair<string, double[]> joint in snapshot.JointCoordinates)
            {
                if (presentPoints.Contains(joint.Key)) continue;
                string restoredName = "";
                Check(model.PointObj.AddCartesian(joint.Value[0], joint.Value[1], joint.Value[2],
                    ref restoredName, joint.Key, "Global", true, 0), "recreating original joint " + joint.Key);
                if (restoredName != joint.Key)
                    throw new InvalidDataException("SAP2000 merged original joint " + joint.Key + " with " + restoredName);
            }
            var primary = new[] { "Joint Coordinates", "Connectivity - Area", "Area Section Assignments" };
            model.DatabaseTables.CancelTableEditing();
            foreach (string key in primary)
            {
                Table table = tables.FirstOrDefault(item => item.Key == key);
                if (table == null) throw new InvalidDataException("Missing CSV snapshot table: " + key);
                Stage(model, key == "Connectivity - Area" ? PadExistingTriangles(table) : table);
            }
            Apply(model, "geometry", tables.First(item => item.Key == "Connectivity - Area"));
            if (Environment.GetEnvironmentVariable("SAP_QUAD_DEBUG_SNAPSHOT") == "1")
            {
                Table jointsNow = Read(model, "Joint Coordinates");
                Table areasNow = Read(model, "Connectivity - Area");
                Console.WriteLine("csv-snapshot-after-geometry joints=" + string.Join(",", jointsNow.Data.Where((value, index) =>
                    index % jointsNow.Fields.Length == Array.IndexOf(jointsNow.Fields, "Joint"))) +
                    " areas=" + string.Join(",", areasNow.Data.Where((value, index) =>
                    index % areasNow.Fields.Length == Array.IndexOf(areasNow.Fields, "Area"))));
            }
            bool assignmentsChanged = false;
            foreach (Table table in tables.Where(item => !primary.Contains(item.Key) && IsObjectAssignment(item)))
            {
                Table current;
                try { current = Read(model, table.Key); }
                catch (InvalidOperationException) { current = null; } // An assigned table may be empty after Apply.
                if (current == null || !table.Fields.SequenceEqual(current.Fields) || !table.Data.SequenceEqual(current.Data))
                {
                    Stage(model, table);
                    assignmentsChanged = true;
                }
            }
            if (assignmentsChanged) Apply(model, "assignments");
            foreach (string key in primary)
            {
                Table expected = tables.First(item => item.Key == key), actual = Read(model, key);
                if (actual.Records != expected.Records)
                {
                    int column = Array.IndexOf(expected.Fields, key == "Joint Coordinates" ? "Joint" : "Area");
                    string[] original = column < 0 ? new string[0] : expected.Data.Where((value, index) => index % expected.Fields.Length == column).ToArray();
                    string[] restored = column < 0 ? new string[0] : actual.Data.Where((value, index) => index % actual.Fields.Length == column).ToArray();
                    throw new InvalidDataException("Original model record count not restored in " + key +
                        ": expected " + expected.Records + ", actual " + actual.Records +
                        ", missing " + string.Join(",", original.Except(restored).Take(8)) +
                        ", extra " + string.Join(",", restored.Except(original).Take(8)));
                }
                int name = Array.IndexOf(expected.Fields, key == "Joint Coordinates" ? "Joint" : "Area");
                if (name >= 0 && !expected.Data.Where((value, index) => index % expected.Fields.Length == name)
                    .SequenceEqual(actual.Data.Where((value, index) => index % actual.Fields.Length == name)))
                    throw new InvalidDataException("Original model object names not restored in " + key);
            }
            foreach (Table expected in tables.Where(IsObjectAssignment))
            {
                Table actual = Read(model, expected.Key);
                if (!actual.Fields.SequenceEqual(expected.Fields) || !actual.Data.SequenceEqual(expected.Data))
                    throw new InvalidDataException("Original object assignments not restored in " + expected.Key);
            }
        }

        internal void Delete()
        {
            try { File.Delete(Path); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }
    }
}
