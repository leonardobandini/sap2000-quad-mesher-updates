# Voci e tooltip dell'interfaccia — italiano

Testi italiani aggiornati in base alle correzioni dell'utente. Dove non esiste un tooltip è indicato «—». `{unità}` è l'unità di lunghezza corrente di SAP2000; `{CPU}` è il numero di CPU logiche rilevate. I messaggi dinamici e il report della qualità non sono opzioni della finestra.

## Selezione all'apertura

| Voce | Tooltip attuale |
| --- | --- |
| Selezione all'apertura | — |
| Aree: … \| Quadrangolari: … \| Triangolari: … \| Poligonali: … | — |
| Frame: … \| Link: … \| Nodi: … | I link selezionati sono conteggiati ma non costituiscono vincoli di mesh. |

## Report sugli elementi creati (dopo Genera)

| Voce | Tooltip attuale |
| --- | --- |
| Report sugli elementi creati | — |
| Aree: … \| Quadrangolari: … \| Triangolari: … \| Poligonali: … | — |
| Frame: … \| Link: … \| Nodi: … | I link presenti nel modello sono conteggiati ma non costituiscono vincoli di mesh. |

Sono i totali degli oggetti effettivi nel modello dopo la mesh, non solo quelli appena creati. L'anteprima esclude le aree originali temporaneamente conservate per Annulla; il report si aggiorna dopo Applica e scompare dopo Annulla.

## Opzioni della mesh

| Voce | Tooltip attuale |
| --- | --- |
| Profilo: | — |
| Calcestruzzo armato | — |
| Strutture in acciaio | — |
| Uso generale | — |
| Dimensione massima ({unità}): | Sul campo: Inserire un numero nell'unita SAP2000 corrente ({unità}) oppure aggiungere m, cm, mm, ft, in; per esempio 25mm o 2,5ft. Le unita esplicite sono convertite automaticamente. |
| Toll. (%): | Tolleranza sulla dimensione della mesh utilizzata. I nodi selezionati restano presenti e costituiscono vincoli di meshatura. |
| Inserisci nodi di mesh anche negli spigoli con nodi selezionati | Aggiunge nodi negli spigoli con nodi selezionati quando la dimensione della mesh specificata lo rende necessario. Se i nodi selezionati presenti all'interno di spigoli sono a una distanza maggiore della dimensione specificata, vengono creati nuovi nodi su tali spigoli. |
| Distribuzione della mesh | — |
| Standard | Distribuzione di mesh prevalentemente quadrangolare con modalità standard, senza allineamento forzato agli assi principali né raffinamento locale previsto. |
| Regolare/Allineata | Predilige una mesh con nodi allineati secondo gli assi preferenziali (griglie, assi globali, assi locali). |
| Raffinamento | Raffina la mesh in prossimità di punti di possibile concentrazione di tensione (cambi di forma, vincoli geometrici da rispettare, variazioni di direzione...). |
| Imponi simmetria | Impone la simmetria della meshatura secondo uno o due assi selezionati. È un vincolo molto forte nella creazione della mesh e non sempre può essere applicato, anche quando la geometria iniziale è simmetrica. |
| Asse di simmetria (Asse 1: direzione (…); oppure Doppia simmetria: assi principali (…) / (…)) | — |
| Prediligi elementi quadrangolari disposti a fasce radiali e pseudo-radiali | Predilige distribuzioni radiali di elementi quadrangolari. Su geometrie compatibili, come forme circolari, ellittiche o a sviluppo radiale, può migliorare il numero e la forma degli elementi creati. |
| Scegliere una sola strategia. Simmetria e fasce radiali ordinate sono vincoli geometrici aggiuntivi. | — |

## Fori e Aperture

| Voce | Tooltip attuale |
| --- | --- |
| Genera aperture racchiuse da frame o bordi shell selezionati | — |
| Gruppo contorno aperture: | — |
| Genera fori circolari O-grid | — |
| Gruppo centri dei fori: | — |
| Diametro foro ({unità}): | Sul campo: Inserire un numero nell'unita SAP2000 corrente ({unità}) oppure aggiungere m, cm, mm, ft, in; per esempio 25mm o 2,5ft. Le unita esplicite sono convertite automaticamente. |
| Le aperture seguono frame o bordi shell selezionati; i fori O-grid usano i nodi del gruppo scelto. | — |
## Opzioni Avanzate

| Voce | Tooltip attuale |
| --- | --- |
| FAST - inserimento massivo tramite tabelle SAP2000 | — |
| Usa il massimo dei worker CPU disponibili ({CPU} CPU logiche) | Se disattivato, scegliere da 1 a {CPU} worker. I worker effettivi dipendono dai candidati indipendenti e dalla RAM libera. |
| Numero di worker (campo numerico, senza etichetta separata) | Se disattivato, scegliere da 1 a {CPU} worker. I worker effettivi dipendono dai candidati indipendenti e dalla RAM libera. |
| Crea copia numerata del modello salvato prima della mesh | Copia l'ultimo .sdb salvato prima di ogni generazione. Salvare prima in SAP2000 le modifiche non salvate. |
| FAST inserisce tramite le tabelle SAP2000. Il backup numerato copia l'ultimo modello salvato prima della generazione. | — |

## Comandi e avvisi della finestra

| Voce | Tooltip attuale |
| --- | --- |
| Lingua della finestra: English / Italiano (selettore senza etichetta) | — |
| Esempi verificati | — |
| Genera (diventa Applica) | — |
| Qualita della mesh | — |
| Annulla mesh (diventa Annulla generazione durante il lavoro) | Quando è disponibile uno snapshot, sul pulsante appare: `Snapshot CSV del modello originale: {percorso}`. |
| Elementi creati: … | — |
| Genera sostituisce le aree selezionate; proprieta e carichi vengono trasferiti. | — |
| Stato della generazione | Quando è disponibile uno snapshot, il tooltip mostra `{percorso}`. |
| Collegamento all'aggiornamento disponibile (testo variabile) | — |

**Profilo (promemoria per la revisione futura):** la selezione attuale imposta principalmente Regolare per Calcestruzzo armato e Raffinamento per Strutture in acciaio. La richiesta futura è trasformare il profilo in un vero insieme di opzioni predefinite ottimizzate; questa revisione non ne cambia il funzionamento.
