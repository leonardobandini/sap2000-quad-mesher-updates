# SPDX-License-Identifier: GPL-2.0-or-later
# In-place V2-only upgrade. Preserve the installed backend and all other files;
# replace the DLL/script and ship the local bilingual help with rollback.
param([string]$Destination = (Join-Path $env:LOCALAPPDATA 'Programs\SAP2000GmshMesh'))
$ErrorActionPreference = 'Stop'
$parent = Split-Path -Parent $Destination
$source = Join-Path $PSScriptRoot 'bin\Release\net48'
if (-not (Test-Path -LiteralPath $parent -PathType Container) -or
    -not (Test-Path -LiteralPath $Destination -PathType Container)) {
    throw "Existing V2 installation and its parent directory required: $Destination"
}
$activeSap = @(Get-Process -Name SAP2000 -ErrorAction SilentlyContinue)
if ($activeSap.Count -gt 0) {
    throw "Chiudere SAP2000 prima di aggiornare la V2 (PID: $($activeSap.Id -join ',')). Il modello utente non viene chiuso dallo script."
}
foreach ($file in @('SapGmshPlugin.dll','sap_gmsh_mesher.py','README-GMSH-V2.md',
                   'img\logo.png',
                   'docs\help-gmsh-v2\index-it.html','docs\help-gmsh-v2\index-en.html',
                   'docs\help-gmsh-v2\style.css','docs\help-gmsh-v2\assets\examples.json')) {
    if (-not (Test-Path -LiteralPath (Join-Path $source $file) -PathType Leaf)) {
        throw "Build Release incompleta: $file"
    }
}
$registered = Get-ItemProperty -LiteralPath 'HKCU:\Software\Classes\CLSID\{724078D7-35A4-4D91-A181-2B55F42FD39B}\InprocServer32' -ErrorAction Stop
$expected = Join-Path $Destination 'SapGmshPlugin.dll'
if (([Uri]$registered.CodeBase).LocalPath -ne $expected -or
    $registered.Class -ne 'SapQuadTransitionPlugin.cPlugin') {
    throw 'Registrazione COM V2 diversa dalla cartella in aggiornamento.'
}
$profile = Join-Path $env:LOCALAPPDATA 'Computers and Structures\SAP2000 27'
$ini = Join-Path $profile 'SAP2000v27.ini'
$settings = Join-Path $profile 'SAP2000v27.settings'
if (-not (Test-Path -LiteralPath $ini -PathType Leaf) -or
    -not (Test-Path -LiteralPath $settings -PathType Leaf)) {
    throw 'SAP2000 27 menu preferences are missing.'
}

# SAP2000 can rewrite its INI on shutdown and mark a previously installed COM
# plugin hidden in the companion settings file. Repair both stores in one step.
$iniBytes = [IO.File]::ReadAllBytes($ini)
$bom = $iniBytes.Length -ge 3 -and $iniBytes[0] -eq 239 -and $iniBytes[1] -eq 187 -and $iniBytes[2] -eq 191
$encoding = if ($bom) { New-Object Text.UTF8Encoding($true) } else { [Text.Encoding]::Default }
$text = $encoding.GetString($iniBytes)
$section = [regex]::Match($text, '(?ms)^\[PlugIn\]\r?\n.*?(?=^\[|\z)')
if (-not $section.Success) { throw 'SAP2000v27.ini has no [PlugIn] section.' }
$count = [regex]::Match($section.Value, '(?m)^(?<prefix>[ \t]*NumberPlugIns=)(?<count>\d+)[ \t]*\r?$')
$names = [regex]::Matches($section.Value, '(?m)^[ \t]*PlugInName=(?<name>[^\r\n]*)')
$labels = [regex]::Matches($section.Value, '(?m)^[ \t]*PlugInMenuText=[^\r\n]*')
if (-not $count.Success -or [int]$count.Groups['count'].Value -ne $names.Count -or $names.Count -ne $labels.Count) {
    throw 'SAP2000 plugin INI contains inconsistent name/label counts.'
}
if (-not @($names | Where-Object { $_.Groups['name'].Value.Trim() -eq 'SapGmshPlugin' }).Count) {
    $lineEnd = if ($section.Value.Contains("`r`n")) { "`r`n" } else { "`n" }
    $new = $section.Value.Substring(0,$count.Groups['count'].Index) +
        ([int]$count.Groups['count'].Value + 1) +
        $section.Value.Substring($count.Groups['count'].Index + $count.Groups['count'].Length)
    $new = $new.TrimEnd([char]13,[char]10) + $lineEnd +
        ' PlugInName=SapGmshPlugin' + $lineEnd +
        ' PlugInMenuText=SAP2000 Gmsh Mesh 2.0' + $lineEnd + $lineEnd
    $text = $text.Substring(0,$section.Index) + $new + $text.Substring($section.Index+$section.Length)
}
$preferences = New-Object System.Xml.XmlDocument
$preferences.PreserveWhitespace = $true
$preferences.Load($settings)
$pluginNode = $preferences.SelectSingleNode('/Settings/PlugIn')
if (-not $pluginNode) { throw 'SAP2000 settings do not contain a PlugIn field.' }
$records = New-Object System.Xml.XmlDocument
$records.LoadXml($pluginNode.InnerText)
$entries = $records.SelectSingleNode('/ArrayOfString')
if (-not $entries) { throw 'SAP2000 plugin settings have an unexpected format.' }
$found = $false
foreach ($item in $entries.SelectNodes('string')) {
    $record = New-Object System.Xml.XmlDocument
    $record.LoadXml($item.InnerText.TrimStart([char]0xfeff,[char]' ',[char]13,[char]10))
    if ($record.SelectSingleNode('/PlugIn/m_name').InnerText -ne 'SapGmshPlugin') { continue }
    $hidden = $record.SelectSingleNode('/PlugIn/m_Hide')
    if (-not $hidden) { $hidden = $record.CreateElement('m_Hide'); [void]$record.DocumentElement.AppendChild($hidden) }
    $hidden.InnerText = 'false'
    $item.InnerText = ([char]0xfeff).ToString() + $record.OuterXml
    $found = $true
    break
}
if (-not $found) {
    $item = $records.CreateElement('string')
    $item.InnerText = ([char]0xfeff).ToString() + '<?xml version="1.0" encoding="utf-8"?>' +
        '<PlugIn><ClassID>S_PlugIn</ClassID><ClassVersion>2</ClassVersion>' +
        '<m_name>SapGmshPlugin</m_name><m_Path /><m_Text>SAP2000 Gmsh Mesh 2.0</m_Text>' +
        '<m_found>false</m_found><m_Info /><m_Hide>false</m_Hide></PlugIn>'
    [void]$entries.AppendChild($item)
}
$pluginNode.InnerText = $records.OuterXml
$menuToken = [Guid]::NewGuid().ToString('N')
$iniPrevious = $ini + '.gmshv2-previous-' + $menuToken
$settingsPrevious = $settings + '.gmshv2-previous-' + $menuToken
$iniReplaced = $ini + '.gmshv2-replaced-' + $menuToken
$settingsReplaced = $settings + '.gmshv2-replaced-' + $menuToken
$iniNew = $ini + '.gmshv2-new-' + $menuToken
$settingsNew = $settings + '.gmshv2-new-' + $menuToken
$stage = Join-Path $parent ('SAP2000GmshMesh.update-' + [Guid]::NewGuid().ToString('N'))
$backup = Join-Path $parent ('SAP2000GmshMesh.rollback-' + [Guid]::NewGuid().ToString('N'))
$oldMoved = $false; $newMoved = $false
$finished = $false
$menuStarted = $false
$menuRestored = $false
$targetVersion = [Diagnostics.FileVersionInfo]::GetVersionInfo((Join-Path $source 'SapGmshPlugin.dll')).FileVersion
try {
    Copy-Item -LiteralPath $Destination -Destination $stage -Recurse
    foreach ($file in @('SapGmshPlugin.dll','sap_gmsh_mesher.py','README-GMSH-V2.md')) {
        Copy-Item -LiteralPath (Join-Path $source $file) -Destination (Join-Path $stage $file) -Force
    }
    $images = Join-Path $stage 'img'
    if (-not (Test-Path -LiteralPath $images -PathType Container)) { New-Item -ItemType Directory -Path $images | Out-Null }
    Copy-Item -LiteralPath (Join-Path $source 'img\logo.png') -Destination $images -Force
    $helpRoot = Join-Path $stage 'docs\help-gmsh-v2'
    if (-not (Test-Path -LiteralPath $helpRoot)) { New-Item -ItemType Directory -Path $helpRoot -Force | Out-Null }
    Copy-Item -Path (Join-Path $source 'docs\help-gmsh-v2\*') -Destination $helpRoot -Recurse -Force
    $backend = Join-Path $stage 'mesher\SapQuadMesherBackend.exe'
    if (-not (Test-Path -LiteralPath $backend -PathType Leaf)) { throw 'Runtime Gmsh V2 non trovato.' }
    & $backend --self-test
    if ($LASTEXITCODE -ne 0) { throw 'Autotest Gmsh V2 fallito.' }
    Move-Item -LiteralPath $Destination -Destination $backup
    $oldMoved = $true
    Move-Item -LiteralPath $stage -Destination $Destination
    $newMoved = $true
    $version = [Diagnostics.FileVersionInfo]::GetVersionInfo((Join-Path $Destination 'SapGmshPlugin.dll')).FileVersion
    if ($version -ne $targetVersion -or -not (Test-Path -LiteralPath (Join-Path $Destination 'docs\help-gmsh-v2\assets\nTEST014-result.svg')) -or
        -not (Test-Path -LiteralPath (Join-Path $Destination 'img\logo.png'))) {
        throw "Aggiornamento incompleto: versione $version o esempi mancanti."
    }
    Copy-Item -LiteralPath $ini -Destination $iniPrevious
    Copy-Item -LiteralPath $settings -Destination $settingsPrevious
    $menuStarted = $true
    [IO.File]::WriteAllBytes($iniNew, $encoding.GetBytes($text))
    $preferences.Save($settingsNew)
    [IO.File]::Replace($iniNew, $ini, $iniReplaced)
    [IO.File]::Replace($settingsNew, $settings, $settingsReplaced)
    $finished = $true
    "V2_VERSION=$version"
    "V2_INSTALLED=$Destination"
    'SAP2000 Gmsh Mesh aggiornato. Riavviare SAP2000 per caricare la DLL aggiornata.'
} catch {
    if ($menuStarted) {
        Copy-Item -LiteralPath $iniPrevious -Destination $ini -Force
        Copy-Item -LiteralPath $settingsPrevious -Destination $settings -Force
        $menuRestored = $true
    }
    if ($newMoved -and (Test-Path -LiteralPath $Destination)) {
        Remove-Item -LiteralPath $Destination -Recurse -Force
    }
    if ($oldMoved -and (Test-Path -LiteralPath $backup)) {
        Move-Item -LiteralPath $backup -Destination $Destination
    }
    throw
} finally {
    if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
    foreach ($path in @($iniNew,$settingsNew,$iniReplaced,$settingsReplaced)) {
        if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force }
    }
    if ($finished -or $menuRestored -or -not $menuStarted) {
        foreach ($path in @($iniPrevious,$settingsPrevious)) {
            if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force }
        }
    }
    if ($finished -and (Test-Path -LiteralPath $backup)) {
        try { Remove-Item -LiteralPath $backup -Recurse -Force }
        catch { Write-Warning "Previous V2 installation backup remains in $backup" }
    }
}
