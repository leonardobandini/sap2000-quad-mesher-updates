# SPDX-License-Identifier: GPL-2.0-or-later
"""Small end-to-end fixtures for the SAP CSV -> Gmsh -> SAP CSV adapter."""
import csv
import json
import math
import os
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from sap_gmsh_mesher import check_settings, main, read_boundary, validate_constraints


class GmshV2Tests(unittest.TestCase):
    def test_preview_settings_reach_gmsh_with_optional_optimizer(self):
        fixed = {"Mesh.MeshSizeFactor": 1, "Mesh.MeshSizeFromPoints": 0,
                 "Mesh.MeshSizeExtendFromBoundary": 0, "Mesh.MeshSizeFromCurvature": 0,
                 "Mesh.MeshSizeFromParametricPoints": 0, "Mesh.SubdivisionAlgorithm": 0,
                 "Mesh.MeshSizeMin": 0, "Mesh.AlgorithmSwitchOnFailure": 1,
                 "Mesh.RecombineMinimumQuality": .01, "Mesh.RecombineOptimizeTopology": 5,
                 "Mesh.RecombineNodeRepositioning": 1}
        settings = dict(previewMode=True, algorithm=8, recombine=True, recombination=0,
                        optimize=True, optimizeMethod="Laplace2D", optimizeIterations=1,
                        smoothing=1, options=fixed)
        check_settings(settings, .2)
        with tempfile.TemporaryDirectory() as directory:
            boundary = os.path.join(directory, "preview.csv")
            output = os.path.join(directory, "mesh.csv")
            config = os.path.join(directory, "settings.json")
            with open(boundary, "w", newline="") as stream:
                writer = csv.writer(stream)
                writer.writerow(("AREA", "A1", "Shell"))
                for index, point in enumerate(((0, 0, 0), (.4, 0, 0), (.4, .4, 0), (0, .4, 0)), 1):
                    writer.writerow(("CORNER", index, str(index), 0, *point))
            for optimize in (False, True):
                settings["optimize"] = optimize
                with open(config, "w") as stream:
                    json.dump(settings, stream)
                from sap_gmsh_mesher import gmsh
                real_optimize = gmsh.model.mesh.optimize
                with patch.object(gmsh.model.mesh, "optimize", wraps=real_optimize) as called:
                    main(boundary, output, .2, config)
                self.assertEqual(called.call_count, int(optimize))
                if optimize:
                    self.assertEqual(called.call_args.kwargs, {"force": 0, "niter": 1})
                    self.assertEqual(called.call_args.args, ("Laplace2D",))
                with open(output, newline="") as stream:
                    self.assertTrue(any(row[0] == "E" for row in csv.reader(stream)))
        settings["options"]["Mesh.MeshSizeMin"] = .2
        with self.assertRaisesRegex(ValueError, "Min Mesh Size"):
            check_settings(settings, .2)
        settings["options"]["Mesh.MeshSizeMin"] = 0
        settings["options"]["Mesh.MeshSizeFromPoints"] = 1
        with self.assertRaisesRegex(ValueError, "fixed mesh options"):
            check_settings(settings, .2)
        settings["options"]["Mesh.MeshSizeFromPoints"] = 0
        settings["algorithm"] = 11
        with self.assertRaisesRegex(ValueError, "disable recombination"):
            check_settings(settings, .2)
        settings["algorithm"] = 9
        settings["recombine"] = False
        with self.assertRaisesRegex(ValueError, "Unsupported Gmsh 2D algorithm"):
            check_settings(settings, .2)

    def test_triangle_quad_and_embedded_node(self):
        corners = [(0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0)]
        with tempfile.TemporaryDirectory() as directory:
            boundary = os.path.join(directory, "boundary.csv")
            output = os.path.join(directory, "mesh.csv")
            settings = os.path.join(directory, "settings.json")
            with open(boundary, "w", newline="") as stream:
                writer = csv.writer(stream)
                writer.writerow(("AREA", "A1", "Shell"))
                for i, corner in enumerate(corners, 1):
                    writer.writerow(("CORNER", i, str(i), 0, *corner))
                writer.writerow(("INTERIOR", 0, "center", 0, 0.5, 0.5, 0))
            for recombine in (False, True):
                with open(settings, "w") as stream:
                    json.dump(dict(algorithm=6, recombine=recombine, recombination=1,
                                   optimize=False, smoothing=1, options={}), stream)
                main(boundary, output, 0.25, settings)
                with open(output, newline="") as stream:
                    rows = list(csv.reader(stream))
                nodes = {int(row[1]): tuple(map(float, row[2:])) for row in rows if row[0] == "N"}
                elements = [list(map(int, row[1:])) for row in rows if row[0] == "E"]
                self.assertTrue(elements)
                self.assertTrue(all(len(element) in (3, 4) for element in elements))
                self.assertTrue(any(node == (0.5, 0.5, 0) for node in nodes.values()))
                self.assertTrue(any((0.5, 0.5, 0) in [nodes[tag] for tag in element] for element in elements))
                if recombine:
                    self.assertTrue(any(len(element) == 4 for element in elements))
            initial_count = len(elements)
            with open(boundary, "a", newline="") as stream:
                csv.writer(stream).writerow(("EXPLICIT_POINT", 0, "center", 0, .5, .5, 0))
            with open(settings, "w") as stream:
                json.dump(dict(algorithm=6, recombine=True, recombination=1,
                               optimize=False, smoothing=1,
                               options={"Mesh.MeshSizeFromPoints": 0,
                                        "Mesh.MeshSizeExtendFromBoundary": 0},
                               localField={"target": "joints", "sizeNear": .04, "sizeFar": .25,
                                           "distanceNear": .01, "distanceFar": .2}), stream)
            main(boundary, output, .25, settings)
            with open(output, newline="") as stream:
                refined = sum(row[0] == "E" for row in csv.reader(stream))
            self.assertGreater(refined, initial_count, "Selected SAP joints should drive the Gmsh Distance field")

    def test_tilted_triangle_and_invalid_hole(self):
        with tempfile.TemporaryDirectory() as directory:
            boundary = os.path.join(directory, "boundary.csv")
            output = os.path.join(directory, "mesh.csv")
            settings = os.path.join(directory, "settings.json")
            with open(settings, "w") as stream:
                json.dump(dict(algorithm=5, recombine=False, recombination=0,
                               optimize=True, smoothing=0, options={"Mesh.MeshSizeMin": 0.05}), stream)
            with open(boundary, "w", newline="") as stream:
                writer = csv.writer(stream)
                writer.writerow(("AREA", "A1", "Shell"))
                for i, coords in enumerate(((0, 0, 0), (1, 0, 1), (0, 1, 1)), 1):
                    writer.writerow(("CORNER", i, str(i), 0, *coords))
            main(boundary, output, 0.3, settings)
            with open(output, newline="") as stream:
                rows = list(csv.reader(stream))
            nodes = {int(row[1]): tuple(map(float, row[2:])) for row in rows if row[0] == "N"}
            self.assertTrue(all(abs(x + y - z) < 1e-8 for x, y, z in nodes.values()))
            self.assertTrue(any(row[0] == "E" and len(row) == 4 for row in rows))
            with open(boundary, "a", newline="") as stream:
                csv.writer(stream).writerow(("HOLE", 1, "", -0.2, 0.2, 0.2, 0.4))
            with self.assertRaisesRegex(ValueError, "Invalid SAP2000 circular hole"):
                read_boundary(boundary)

    def test_circular_holes_remove_material_and_keep_shared_seams(self):
        with tempfile.TemporaryDirectory() as directory:
            settings = os.path.join(directory, "settings.json")
            with open(settings, "w") as stream:
                json.dump(dict(algorithm=8, recombine=True, recombination=0,
                               optimize=False, smoothing=1, options={}), stream)
            for count, holes in ((1, [(.5, .5, .12), (.25, .25, .08)]),
                                 (2, [(1., .5, .18)])):
                items = []
                for index in range(count):
                    left = index if count == 2 else 0
                    boundary = os.path.join(directory, f"hole-{count}-{index}.csv")
                    output = os.path.join(directory, f"result-{count}-{index}.csv")
                    with open(boundary, "w", newline="") as stream:
                        writer = csv.writer(stream)
                        writer.writerow(("AREA", index, "Shell"))
                        for edge, coords in enumerate(((left, 0, 0), (left + 1, 0, 0),
                                                       (left + 1, 1, 0), (left, 1, 0)), 1):
                            writer.writerow(("CORNER", edge, str(edge), 0, *coords))
                        for hole_id, (x, y, radius) in enumerate(holes, 1):
                            if left - radius <= x <= left + 1 + radius:
                                writer.writerow(("HOLE", hole_id, "", 2 * radius, x, y, 0))
                    items.append((boundary, output))
                from sap_gmsh_mesher import mesh_areas
                with open(settings) as stream:
                    mesh_areas(items, .08, json.load(stream))
                seams = []
                for boundary, output in items:
                    with open(output, newline="") as stream:
                        rows = list(csv.reader(stream))
                    nodes = {int(row[1]): tuple(map(float, row[2:])) for row in rows if row[0] == "N"}
                    elements = [tuple(map(int, row[1:])) for row in rows if row[0] == "E"]
                    self.assertTrue(elements)
                    for x, y, radius in holes:
                        self.assertTrue(all(math.dist(nodes[tag][:2], (x, y)) >= radius - 1e-6
                                            for element in elements for tag in element))
                    if count == 2:
                        seams.append({tuple(sorted((a, b))) for element in elements
                                      for a, b in zip(element, element[1:] + element[:1])
                                      if abs(nodes[a][0] - 1) < 1e-8 and abs(nodes[b][0] - 1) < 1e-8})
                if count == 2:
                    self.assertTrue(seams[0])
                    self.assertEqual(seams[0], seams[1])
                    with open(settings, "w") as stream:
                        json.dump(dict(algorithm=8, recombine=True, recombination=0,
                                       optimize=False, smoothing=1, oGrid=True, options={}), stream)
                    with open(settings) as stream:
                        mesh_areas(items, .08, json.load(stream))
                    for _, output in items:
                        with open(output, newline="") as stream:
                            rows = list(csv.reader(stream))
                        nodes = {int(row[1]): tuple(map(float, row[2:]))
                                 for row in rows if row[0] == "N"}
                        ring = [row for row in rows if row[0] == "E" and all(
                            .18 - 1e-7 <= math.dist(nodes[int(tag)][:2], (1., .5)) <= .3 + 1e-7
                            for tag in row[1:])]
                        self.assertGreaterEqual(len(ring), 16)
                        self.assertTrue(all(len(row) == 5 for row in ring))

    def test_opt_in_circular_ogrid_has_radial_quadrilateral_layers(self):
        with tempfile.TemporaryDirectory() as directory:
            boundary = os.path.join(directory, 'area.csv')
            output = os.path.join(directory, 'mesh.csv')
            config = os.path.join(directory, 'settings.json')
            with open(boundary, 'w', newline='') as stream:
                writer = csv.writer(stream)
                writer.writerow(('AREA', 'A1', 'Shell'))
                for i, corner in enumerate(((0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0)), 1):
                    writer.writerow(('CORNER', i, str(i), 0, *corner))
                writer.writerow(('HOLE', 1, '', .24, .5, .5, 0))
            settings = dict(algorithm=8, recombine=True, recombination=0, optimize=False,
                            smoothing=1, oGrid=True, options={})
            with open(config, 'w') as stream:
                json.dump(settings, stream)
            main(boundary, output, .08, config)
            with open(output, newline='') as stream:
                rows = list(csv.reader(stream))
            nodes = {int(row[1]): tuple(map(float, row[2:])) for row in rows if row[0] == 'N'}
            elements = [tuple(map(int, row[1:])) for row in rows if row[0] == 'E']
            self.assertTrue(elements)
            ring = [element for element in elements if all(
                .12 * math.cos(math.pi / 24) - 1e-7 <= math.dist(nodes[tag][:2], (.5, .5)) <= .216 + 1e-7
                for tag in element)]
            self.assertGreaterEqual(len(ring), 32)
            self.assertTrue(all(len(element) == 4 for element in ring))
            self.assertTrue(any(len(element) == 4 and any(
                abs(math.dist(nodes[tag][:2], (.5, .5)) - .12) < 1e-7 for tag in element)
                for element in ring))

    def test_ogrid_ignores_non_coplanar_projected_area(self):
        from sap_gmsh_mesher import mesh_areas
        with tempfile.TemporaryDirectory() as directory:
            areas = []
            polygons = (
                ((0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0)),
                ((.75, 0, 0), (.75, 1, 0), (.75, 1, 1), (.75, 0, 1)),
            )
            for index, polygon in enumerate(polygons):
                boundary = os.path.join(directory, f'area-{index}.csv')
                output = os.path.join(directory, f'mesh-{index}.csv')
                with open(boundary, 'w', newline='') as stream:
                    writer = csv.writer(stream)
                    writer.writerow(('AREA', index, 'Shell'))
                    for edge, corner in enumerate(polygon, 1):
                        writer.writerow(('CORNER', edge, str(edge), 0, *corner))
                    if index == 0:
                        writer.writerow(('HOLE', 1, '', .2, .25, .5, 0))
                areas.append((boundary, output))
            settings = dict(algorithm=8, recombine=True, recombination=0,
                            smoothing=1, optimize=False, oGrid=True, options={})
            mesh_areas(areas, .08, settings)
            for _, output in areas:
                with open(output, newline='') as stream:
                    elements = [row for row in csv.reader(stream) if row[0] == 'E']
                self.assertTrue(elements)

    def test_four_shell_junction_ogrid_keeps_quadrants_and_seams(self):
        from sap_gmsh_mesher import mesh_areas
        with tempfile.TemporaryDirectory() as directory:
            areas = []
            for index, (x, y) in enumerate(((-1, -1), (0, -1), (0, 0), (-1, 0))):
                boundary = os.path.join(directory, f'area-{index}.csv')
                output = os.path.join(directory, f'mesh-{index}.csv')
                with open(boundary, 'w', newline='') as stream:
                    writer = csv.writer(stream)
                    writer.writerow(('AREA', index, 'Shell'))
                    for edge, corner in enumerate(((x, y, 0), (x+1, y, 0),
                                                   (x+1, y+1, 0), (x, y+1, 0)), 1):
                        writer.writerow(('CORNER', edge, str(edge), 0, *corner))
                    writer.writerow(('HOLE', 1, '', .24, 0, 0, 0))
                areas.append((boundary, output))
            settings = dict(algorithm=8, recombine=True, recombination=0,
                            smoothing=1, optimize=False, oGrid=True, options={})
            mesh_areas(areas, .08, settings)
            joined = []
            for _, output in areas:
                with open(output, newline='') as stream:
                    rows = list(csv.reader(stream))
                nodes = {int(row[1]): tuple(map(float, row[2:])) for row in rows if row[0] == 'N'}
                elements = [tuple(map(int, row[1:])) for row in rows if row[0] == 'E']
                self.assertTrue(elements)
                self.assertTrue(all(math.dist(nodes[tag][:2], (0, 0)) >= .12 * math.cos(math.pi / 24) - 1e-7
                                    for element in elements for tag in element),
                                min(math.dist(nodes[tag][:2], (0, 0)) for element in elements for tag in element))
                ring = [element for element in elements if all(
                    .12 * math.cos(math.pi / 24) - 1e-7 <= math.dist(nodes[tag][:2], (0, 0)) <= .216 + 1e-7
                    for tag in element)]
                self.assertGreaterEqual(len(ring), 8)
                self.assertTrue(all(len(element) == 4 for element in ring))
                joined.append((nodes, elements))
            for axis in (0, 1):
                negative, positive = set(), set()
                for nodes, elements in joined:
                    for element in elements:
                        for first, second in zip(element, element[1:] + element[:1]):
                            a, b = nodes[first], nodes[second]
                            if abs(a[axis]) < 1e-8 and abs(b[axis]) < 1e-8:
                                (negative if sum(nodes[tag][axis] for tag in element) < 0
                                 else positive).add(tuple(sorted((first, second))))
                self.assertTrue(negative)
                self.assertEqual(negative, positive)

    def test_exact_single_and_double_symmetry_with_optional_ogrid(self):
        with tempfile.TemporaryDirectory() as directory:
            boundary = os.path.join(directory, 'symmetric.csv')
            output = os.path.join(directory, 'symmetric-mesh.csv')
            config = os.path.join(directory, 'settings.json')
            for double_axis, ogrid in ((False, False), (True, False), (True, True)):
                with open(boundary, 'w', newline='') as stream:
                    writer = csv.writer(stream)
                    writer.writerow(('AREA', 'A1', 'Shell'))
                    for edge, point in enumerate(((0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0)), 1):
                        writer.writerow(('CORNER', edge, str(edge), 0, *point))
                    writer.writerow(('SYMMETRY', .5, .5, 0, 0, 1, 0))
                    if double_axis:
                        writer.writerow(('SYMMETRY2', .5, .5, 0, 1, 0, 0))
                    if ogrid:
                        writer.writerow(('HOLE', 1, '', .24, .5, .5, 0))
                with open(config, 'w') as stream:
                    json.dump(dict(algorithm=8, recombine=True, recombination=0,
                                   optimize=False, smoothing=1, exactSymmetry=True,
                                   oGrid=ogrid, options={}), stream)
                main(boundary, output, .08, config)
                with open(output, newline='') as stream:
                    rows = list(csv.reader(stream))
                nodes = {int(row[1]): tuple(map(float, row[2:])) for row in rows if row[0] == 'N'}
                elements = [tuple(map(int, row[1:])) for row in rows if row[0] == 'E']
                self.assertTrue(elements)
                signatures = {tuple(sorted(tuple(round(value, 7) for value in nodes[tag])
                                           for tag in element)) for element in elements}
                for axis in ((0, 1) if double_axis else (0,)):
                    for element in elements:
                        reflected = tuple(sorted(tuple(round(1 - nodes[tag][i] if i == axis else
                                                           nodes[tag][i], 7) for i in range(3))
                                                 for tag in element))
                        self.assertIn(reflected, signatures, f'axis={axis} oGrid={ogrid}')
                if ogrid:
                    inner = [.12 * math.cos(math.pi / 24) - 1e-7 <=
                             math.dist(nodes[tag][:2], (.5, .5)) <= .216 + 1e-7
                             for element in elements for tag in element]
                    self.assertGreater(sum(inner), 100)

    def test_grouped_frame_opening_requires_closed_eligible_loop(self):
        corners = ((0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0))
        loop = ((.3, .3, 0), (.7, .3, 0), (.7, .7, 0), (.3, .7, 0))
        with tempfile.TemporaryDirectory() as directory:
            boundary = os.path.join(directory, "boundary.csv")
            output = os.path.join(directory, "mesh.csv")
            config = os.path.join(directory, "settings.json")
            with open(config, "w") as stream:
                json.dump(dict(algorithm=8, recombine=True, recombination=0,
                               optimize=False, smoothing=1, options={}), stream)
            for enabled in (False, True):
                with open(boundary, "w", newline="") as stream:
                    writer = csv.writer(stream)
                    writer.writerow(("AREA", "A1", "Shell"))
                    for i, corner in enumerate(corners, 1):
                        writer.writerow(("CORNER", i, str(i), 0, *corner))
                    for i, start in enumerate(loop):
                        end = loop[(i + 1) % 4]
                        writer.writerow(("FRAME", i, str(i), 0, *start, *end, 0, int(enabled)))
                main(boundary, output, .08, config)
                with open(output, newline="") as stream:
                    rows = list(csv.reader(stream))
                nodes = {int(row[1]): tuple(map(float, row[2:])) for row in rows if row[0] == "N"}
                elements = [tuple(map(int, row[1:])) for row in rows if row[0] == "E"]
                centers = [tuple(sum(nodes[tag][axis] for tag in element) / len(element) for axis in (0, 1))
                           for element in elements]
                self.assertEqual(any(.31 < x < .69 and .31 < y < .69 for x, y in centers), not enabled)
            with open(boundary, "w", newline="") as stream:
                writer = csv.writer(stream)
                writer.writerow(("AREA", "A1", "Shell"))
                for i, corner in enumerate(corners, 1):
                    writer.writerow(("CORNER", i, str(i), 0, *corner))
                for i in range(3):
                    writer.writerow(("FRAME", i, str(i), 0, *loop[i], *loop[i + 1], 0, 1))
            with self.assertRaisesRegex(ValueError, "no closed"):
                main(boundary, output, .08, config)

    def test_grouped_opening_crosses_unprotected_shared_area_seam(self):
        from sap_gmsh_mesher import mesh_areas
        with tempfile.TemporaryDirectory() as directory:
            outputs = []
            for index in (0, 1):
                boundary = os.path.join(directory, f"area{index}.csv")
                output = os.path.join(directory, f"mesh{index}.csv")
                with open(boundary, "w", newline="") as stream:
                    writer = csv.writer(stream)
                    writer.writerow(("AREA", index, "Shell"))
                    for edge, corner in enumerate(((index, 0, 0), (index + 1, 0, 0),
                                                   (index + 1, 1, 0), (index, 1, 0)), 1):
                        writer.writerow(("CORNER", edge, str(edge), 0, *corner))
                    for station in (.3, .7):
                        writer.writerow(("EDGE", 2 if index == 0 else 4, "shared", station,
                                         1, station, 0))
                    segments = (
                        [((.7, .3, 0), (1, .3, 0)), ((1, .7, 0), (.7, .7, 0)),
                         ((.7, .7, 0), (.7, .3, 0))] if index == 0 else
                        [((1, .3, 0), (1.3, .3, 0)), ((1.3, .3, 0), (1.3, .7, 0)),
                         ((1.3, .7, 0), (1, .7, 0))])
                    for number, (first, last) in enumerate(segments, 1):
                        writer.writerow(("FRAME", number, str(number), 0, *first, *last, 0, 1))
                outputs.append((boundary, output))
            settings = dict(algorithm=8, recombine=True, recombination=0,
                            optimize=False, smoothing=1, options={})
            mesh_areas(outputs, .08, settings)
            seams = []
            for _, output in outputs:
                with open(output, newline="") as stream:
                    rows = list(csv.reader(stream))
                nodes = {int(row[1]): tuple(map(float, row[2:])) for row in rows if row[0] == "N"}
                elements = [tuple(map(int, row[1:])) for row in rows if row[0] == "E"]
                self.assertTrue(elements)
                self.assertFalse(any(.71 < sum(nodes[tag][0] for tag in element) / len(element) < 1.29
                                     and .31 < sum(nodes[tag][1] for tag in element) / len(element) < .69
                                     for element in elements))
                seams.append({tuple(sorted((a, b))) for element in elements
                              for a, b in zip(element, element[1:] + element[:1])
                              if abs(nodes[a][0] - 1) < 1e-8 and abs(nodes[b][0] - 1) < 1e-8})
            self.assertTrue(seams[0])
            self.assertEqual(*seams)

    def test_selected_frames_are_conforming_shell_edges(self):
        with tempfile.TemporaryDirectory() as directory:
            boundary = os.path.join(directory, "boundary.csv")
            output = os.path.join(directory, "mesh.csv")
            settings = os.path.join(directory, "settings.json")
            with open(settings, "w") as stream:
                json.dump(dict(algorithm=6, recombine=True, recombination=1,
                               optimize=True, smoothing=1, options={}), stream)
            for frames in (
                    [("crossing", (0, 0.5, 0), (1, 0.5, 0))],
                    [("ending inside", (0, 0.5, 0), (0.5, 0.5, 0))],
                    [("crossing", (0, 0.5, 0), (1, 0.5, 0)),
                     ("perpendicular", (0.5, 0, 0), (0.5, 1, 0))]):
                with open(boundary, "w", newline="") as stream:
                    writer = csv.writer(stream)
                    writer.writerow(("AREA", "A1", "Shell"))
                    for i, coords in enumerate(((0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0)), 1):
                        writer.writerow(("CORNER", i, str(i), 0, *coords))
                    writer.writerow(("EDGE", 4, "left-frame-end", .5, 0, .5, 0))
                    if frames[0][2] == (1, .5, 0):
                        writer.writerow(("EDGE", 2, "right-frame-end", .5, 1, .5, 0))
                    writer.writerow(("INTERIOR", 0, "joint", 0, .5, .5, 0))
                    for i, (name, a, b) in enumerate(frames, 1):
                        writer.writerow(("FRAME", i, name, 0, *a, *b, 0, 0))
                main(boundary, output, 0.2, settings)
                with open(output, newline="") as stream:
                    rows = list(csv.reader(stream))
                nodes = {int(row[1]): tuple(map(float, row[2:])) for row in rows if row[0] == "N"}
                elements = [tuple(map(int, row[1:])) for row in rows if row[0] == "E"]
                self.assertTrue(elements)
                validate_constraints(nodes, elements, [(.5, .5, 0)], frames)
                self.assertTrue(any((.5, .5, 0) in [nodes[tag] for tag in element]
                                    for element in elements))

    def test_missing_constraints_are_rejected(self):
        nodes = {1: (0, 0, 0), 2: (1, 0, 0), 3: (1, 1, 0), 4: (0, 1, 0)}
        elements = [(1, 2, 3), (1, 3, 4)]
        with self.assertRaisesRegex(ValueError, "joint"):
            validate_constraints(nodes, elements, [(.5, .25, 0)], [])
        with self.assertRaisesRegex(ValueError, "frame"):
            validate_constraints(nodes, elements, [], [("diagonal not in mesh", (0, 1, 0), (1, 0, 0))])

    def test_selected_interior_edge_joint_prevents_new_boundary_nodes(self):
        with tempfile.TemporaryDirectory() as directory:
            boundary = os.path.join(directory, "boundary.csv")
            output = os.path.join(directory, "mesh.csv")
            config = os.path.join(directory, "settings.json")
            with open(boundary, "w", newline="") as stream:
                writer = csv.writer(stream)
                writer.writerow(("AREA", "A1", "Shell"))
                for index, point in enumerate(((0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0)), 1):
                    writer.writerow(("CORNER", index, str(index), 0, *point))
                writer.writerow(("EDGE", 1, "M", .5, .5, 0, 0))
                writer.writerow(("EXPLICIT_POINT", 0, "M", 0, .5, 0, 0))
                writer.writerow(("PRESERVE_SELECTED_EDGE", 1))
            settings = dict(algorithm=8, recombine=True, recombination=0,
                            optimize=False, smoothing=1, preserveSelectedEdges=True, options={})
            with open(config, "w") as stream:
                json.dump(settings, stream)
            main(boundary, output, .2, config)
            with open(output, newline="") as stream:
                rows = list(csv.reader(stream))
            edge = {round(float(row[2]), 7) for row in rows if row[0] == "N" and
                    abs(float(row[3])) < 1e-8 and 0 <= float(row[2]) <= 1}
            self.assertEqual(edge, {0, .5, 1}, "The selected point must remain without inserted edge stations")
            settings["preserveSelectedEdges"] = False
            with open(config, "w") as stream:
                json.dump(settings, stream)
            main(boundary, output, .2, config)
            with open(output, newline="") as stream:
                rows = list(csv.reader(stream))
            self.assertGreater(sum(row[0] == "N" and abs(float(row[3])) < 1e-8 for row in rows), 3)
            settings["preserveSelectedEdges"] = True
            settings["options"] = {"Mesh.SubdivisionAlgorithm": 1}
            with open(config, "w") as stream:
                json.dump(settings, stream)
            with self.assertRaisesRegex(ValueError, "bisects prescribed"):
                main(boundary, output, .2, config)

    def test_selectable_2d_optimizers_and_invalid_3d_subdivision(self):
        with tempfile.TemporaryDirectory() as directory:
            boundary = os.path.join(directory, "boundary.csv")
            output = os.path.join(directory, "mesh.csv")
            settings_path = os.path.join(directory, "settings.json")
            with open(boundary, "w", newline="") as stream:
                writer = csv.writer(stream)
                writer.writerow(("AREA", "A1", "Shell"))
                for i, corner in enumerate(((0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0)), 1):
                    writer.writerow(("CORNER", i, str(i), 0, *corner))
            for method in ("Relocate2D", "QuadQuasiStructured", "Laplace2D"):
                settings = dict(algorithm=8, recombine=True, recombination=1,
                                optimize=True, optimizeMethod=method, optimizeIterations=2,
                                smoothing=1, options={})
                with open(settings_path, "w") as stream:
                    json.dump(settings, stream)
                main(boundary, output, .25, settings_path)
                with open(output, newline="") as stream:
                    rows = list(csv.reader(stream))
                self.assertTrue(any(row[0] == "E" and len(row) == 5 for row in rows), method)
            settings["options"] = {"Mesh.SubdivisionAlgorithm": 2}
            with open(settings_path, "w") as stream:
                json.dump(settings, stream)
            with self.assertRaisesRegex(ValueError, "3D volume"):
                main(boundary, output, .25, settings_path)
            settings["options"] = {}
            settings["optimizeMethod"] = "UntangleMeshGeometry"
            with open(settings_path, "w") as stream:
                json.dump(settings, stream)
            with self.assertRaisesRegex(ValueError, "Unsupported 2D optimizer"):
                main(boundary, output, .25, settings_path)

    def test_adjacent_sap_areas_share_gmsh_seam_and_frame_nodes(self):
        with tempfile.TemporaryDirectory() as directory:
            paths = []
            for index, x in enumerate((0, 1), 1):
                path = os.path.join(directory, f"area-{index}.csv")
                with open(path, "w", newline="") as stream:
                    writer = csv.writer(stream)
                    writer.writerow(("AREA", index, "Shell"))
                    corners = ((x, 0, 0), (x + 1, 0, 0), (x + 1, 1, 0), (x, 1, 0))
                    for edge, point in enumerate(corners, 1):
                        writer.writerow(("CORNER", edge, str(edge), 0, *point))
                    writer.writerow(("INTERIOR", 0, "selected-joint", 0, x + .5, .5, 0))
                    writer.writerow(("FRAME", 1, "F" + str(index), 0, x, .5, 0, x + 1, .5, 0, 0, 0))
                    writer.writerow(("EDGE", 2 if x == 0 else 4, "shared-joint", .5, 1, .5, 0))
                paths.append(path)
            manifest = os.path.join(directory, "batch.json")
            with open(manifest, "w") as stream:
                json.dump({"areas": [{"boundary": f"area-{i}.csv", "mesh": f"mesh-{i}.csv"}
                                     for i in (1, 2)]}, stream)
            settings = os.path.join(directory, "settings.json")
            with open(settings, "w") as stream:
                json.dump(dict(algorithm=8, recombine=True, recombination=0,
                               optimize=False, smoothing=1, options={}), stream)
            main(manifest, directory, .25, settings)
            seams = []
            for index in (1, 2):
                with open(os.path.join(directory, f"mesh-{index}.csv"), newline="") as stream:
                    rows = list(csv.reader(stream))
                nodes = {int(row[1]): tuple(map(float, row[2:])) for row in rows if row[0] == "N"}
                elements = [tuple(map(int, row[1:])) for row in rows if row[0] == "E"]
                self.assertTrue(elements)
                self.assertTrue(any(abs(nodes[tag][0] - (index - .5)) < 1e-8 for element in elements for tag in element))
                seam = set()
                for element in elements:
                    for a, b in zip(element, element[1:] + element[:1]):
                        if abs(nodes[a][0] - 1) < 1e-8 and abs(nodes[b][0] - 1) < 1e-8:
                            seam.add(tuple(sorted((a, b))))
                seams.append(seam)
            self.assertTrue(seams[0])
            self.assertEqual(seams[0], seams[1], "Adjacent SAP surfaces must share the exact Gmsh seam")
            settings_data = dict(algorithm=8, recombine=True, recombination=0,
                                 optimize=False, smoothing=1,
                                 options={"Mesh.MeshSizeFromPoints": 0, "Mesh.MeshSizeExtendFromBoundary": 0},
                                 localField={"target": "frames", "sizeNear": .06, "sizeFar": .25,
                                             "distanceNear": .02, "distanceFar": .3})
            with open(settings, "w") as stream:
                json.dump(settings_data, stream)
            main(manifest, directory, .25, settings)
            refined_seams = []
            for index in (1, 2):
                with open(os.path.join(directory, f"mesh-{index}.csv"), newline="") as stream:
                    rows = list(csv.reader(stream))
                nodes = {int(row[1]): tuple(map(float, row[2:])) for row in rows if row[0] == "N"}
                elements = [tuple(map(int, row[1:])) for row in rows if row[0] == "E"]
                seam = {tuple(sorted((a, b))) for element in elements
                        for a, b in zip(element, element[1:] + element[:1])
                        if abs(nodes[a][0] - 1) < 1e-8 and abs(nodes[b][0] - 1) < 1e-8}
                refined_seams.append(seam)
            self.assertTrue(refined_seams[0])
            self.assertEqual(refined_seams[0], refined_seams[1], "Local fields must preserve shared SAP seams")

    def test_transfinite_methods_and_local_frame_sizing(self):
        with tempfile.TemporaryDirectory() as directory:
            boundary = os.path.join(directory, "boundary.csv")
            output = os.path.join(directory, "mesh.csv")
            settings_path = os.path.join(directory, "settings.json")
            with open(boundary, "w", newline="") as stream:
                writer = csv.writer(stream)
                writer.writerow(("AREA", "A1", "Shell"))
                for i, point in enumerate(((0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0)), 1):
                    writer.writerow(("CORNER", i, str(i), 0, *point))
            settings = dict(algorithm=6, recombine=True, recombination=1,
                            optimize=False, smoothing=1, options={})
            for structured in ({"mode": "manual", "nodes": 5, "distribution": "Progression",
                                "coefficient": 1, "arrangement": "Left"},
                               {"mode": "automatic", "cornerAngle": 2.35}):
                settings["structured"] = structured
                with open(settings_path, "w") as stream:
                    json.dump(settings, stream)
                main(boundary, output, .25, settings_path)
                with open(output, newline="") as stream:
                    rows = list(csv.reader(stream))
                self.assertTrue(any(row[0] == "E" and len(row) == 5 for row in rows))
                if structured["mode"] == "manual":
                    self.assertEqual(sum(row[0] == "E" for row in rows), 16)

            with open(boundary, "a", newline="") as stream:
                csv.writer(stream).writerow(("FRAME", 1, "selected", 0, 0, .5, 0, 1, .5, 0, 0, 0))
            settings["structured"] = {"mode": "unstructured"}
            with open(settings_path, "w") as stream:
                json.dump(settings, stream)
            main(boundary, output, .25, settings_path)
            with open(output, newline="") as stream:
                without_field = sum(row[0] == "E" for row in csv.reader(stream))
            settings["localField"] = {"target": "frames", "sizeNear": .06, "sizeFar": .25,
                                      "distanceNear": .02, "distanceFar": .28}
            settings["options"] = {"Mesh.MeshSizeFromPoints": 0, "Mesh.MeshSizeExtendFromBoundary": 0}
            with open(settings_path, "w") as stream:
                json.dump(settings, stream)
            main(boundary, output, .25, settings_path)
            with open(output, newline="") as stream:
                with_field = sum(row[0] == "E" for row in csv.reader(stream))
            self.assertGreater(with_field, without_field, "The Distance/Threshold field must actually refine near selected frames")
            settings.pop("localField")
            settings["fieldGraph"] = [
                {"id": "edge", "type": "Distance", "options": {"CurvesList": "$selectedFrames"}},
                {"type": "Threshold", "options": {"InField": "edge", "SizeMin": .06,
                                                     "SizeMax": .25, "DistMin": .02, "DistMax": .28},
                 "background": True}]
            with open(settings_path, "w") as stream:
                json.dump(settings, stream)
            main(boundary, output, .25, settings_path)
            with open(output, newline="") as stream:
                graph_elements = sum(row[0] == "E" for row in csv.reader(stream))
            self.assertGreater(graph_elements, without_field,
                               "Advanced Gmsh field graphs must reach the size-field API")

    def test_installed_backend_when_requested(self):
        backend = os.environ.get("SAP_GMSH_V2_BACKEND")
        if not backend:
            self.skipTest("Set SAP_GMSH_V2_BACKEND to test the packaged runtime")
        with tempfile.TemporaryDirectory() as directory:
            boundary = os.path.join(directory, "boundary.csv")
            output = os.path.join(directory, "mesh.csv")
            settings = os.path.join(directory, "settings.json")
            with open(boundary, "w", newline="") as stream:
                writer = csv.writer(stream)
                writer.writerow(("AREA", "A1", "Shell"))
                for i, coords in enumerate(((0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0)), 1):
                    writer.writerow(("CORNER", i, str(i), 0, *coords))
                writer.writerow(("INTERIOR", 0, "joint", 0, .5, .5, 0))
                writer.writerow(("FRAME", 1, "selected-frame", 0, 0, .5, 0, 1, .5, 0, 0, 0))
            with open(settings, "w") as stream:
                json.dump(dict(algorithm=6, recombine=True, recombination=1,
                               optimize=False, smoothing=1, options={}), stream)
            script = os.path.join(os.path.dirname(backend), "..", "sap_gmsh_mesher.py")
            if not os.path.isfile(script):
                script = os.path.join(os.path.dirname(__file__), "sap_gmsh_mesher.py")
            process = subprocess.run([backend, script, boundary, output, "0.25", settings],
                                     capture_output=True, text=True, timeout=90)
            self.assertEqual(process.returncode, 0, process.stderr)
            with open(output, newline="") as stream:
                rows = list(csv.reader(stream))
            self.assertTrue(any(row[0] == "E" and len(row) == 5 for row in rows))
            nodes = {int(row[1]): tuple(map(float, row[2:])) for row in rows if row[0] == "N"}
            elements = [tuple(map(int, row[1:])) for row in rows if row[0] == "E"]
            validate_constraints(nodes, elements, [(.5, .5, 0)],
                                  [("selected-frame", (0, .5, 0), (1, .5, 0))])
            # Exercise the shipped worker with the new V2 features, not just
            # the pre-existing rectangle path used by the self-test.
            with open(boundary, "w", newline="") as stream:
                writer = csv.writer(stream)
                writer.writerow(("AREA", "A1", "Shell"))
                for i, point in enumerate(((0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0)), 1):
                    writer.writerow(("CORNER", i, str(i), 0, *point))
                writer.writerow(("HOLE", 1, "", .24, .5, .5, 0))
                writer.writerow(("SYMMETRY", .5, .5, 0, 0, 1, 0))
                writer.writerow(("SYMMETRY2", .5, .5, 0, 1, 0, 0))
            with open(settings, "w") as stream:
                json.dump(dict(algorithm=8, recombine=True, recombination=0,
                               optimize=False, smoothing=1, exactSymmetry=True,
                               oGrid=True, options={}), stream)
            process = subprocess.run([backend, script, boundary, output, "0.08", settings],
                                     capture_output=True, text=True, timeout=90)
            self.assertEqual(process.returncode, 0, process.stderr)
            with open(output, newline="") as stream:
                rows = list(csv.reader(stream))
            nodes = {int(row[1]): tuple(map(float, row[2:])) for row in rows if row[0] == "N"}
            elements = [tuple(map(int, row[1:])) for row in rows if row[0] == "E"]
            self.assertGreaterEqual(sum(len(element) == 4 and all(
                .12 * math.cos(math.pi / 24) - 1e-7 <= math.dist(nodes[tag][:2], (.5, .5)) <= .216 + 1e-7
                for tag in element) for element in elements), 32)


if __name__ == "__main__":
    unittest.main()
