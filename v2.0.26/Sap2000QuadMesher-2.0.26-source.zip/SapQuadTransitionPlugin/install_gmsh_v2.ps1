# SPDX-License-Identifier: GPL-2.0-or-later
# Installs the Gmsh v2 plugin per user, alongside the existing v1 installation.
param(
    [string] $Destination = (Join-Path $env:LOCALAPPDATA 'Programs\SAP2000GmshMesh')
)
$ErrorActionPreference = 'Stop'
$guid = '{724078D7-35A4-4D91-A181-2B55F42FD39B}'
$progId = 'SapGmshPlugin.cPlugin'
$className = 'SapQuadTransitionPlugin.cPlugin' # Namespace/type in the shared C# source, distinct from the COM ProgID.
$menuName = 'SapGmshPlugin'
$menuText = 'SAP2000 Gmsh Mesh 2.0'
$source = Join-Path $PSScriptRoot 'bin\Release\net48'
$v2Runtime = Join-Path $PSScriptRoot '..\packaging\dist-v2\SapQuadMesherBackend'
$sapProfile = Join-Path $env:LOCALAPPDATA 'Computers and Structures\SAP2000 27'
$ini = Join-Path $sapProfile 'SAP2000v27.ini'
$settings = Join-Path $sapProfile 'SAP2000v27.settings'
$classKey = 'HKCU:\Software\Classes\CLSID\' + $guid
$progKey = 'HKCU:\Software\Classes\' + $progId

if (Get-Process SAP2000 -ErrorAction SilentlyContinue) {
    throw 'Chiudere SAP2000 prima di installare la v2 (salvare prima il modello aperto).'
}
foreach ($path in @((Join-Path $source 'SapGmshPlugin.dll'),
                    (Join-Path $source 'sap_gmsh_mesher.py'),
                    (Join-Path $source 'README-GMSH-V2.md'),
                    (Join-Path $v2Runtime 'SapQuadMesherBackend.exe'), $ini, $settings)) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "File richiesto non trovato: $path" }
}
$existing = Get-ItemProperty -LiteralPath ($classKey + '\InprocServer32') -ErrorAction SilentlyContinue
if ($existing -and $existing.CodeBase) {
    $old = ([uri]$existing.CodeBase).LocalPath
    if ($old -ne (Join-Path $Destination 'SapGmshPlugin.dll')) {
        throw "Esiste gia una registrazione della v2 in un percorso differente: $old"
    }
}
if (Test-Path -LiteralPath $Destination) {
    throw "La directory di installazione esiste gia: $Destination. Verificare prima di sostituirla."
}

# Prepare a complete private runtime before touching the SAP2000 profile or COM registry.
$parent = Split-Path -Parent $Destination
if (-not (Test-Path -LiteralPath $parent -PathType Container)) { throw "Directory principale non trovata: $parent" }
$stage = Join-Path $parent ('SAP2000GmshMesh.stage-' + [guid]::NewGuid().ToString('N'))
$iniBackup = $ini + '.gmsh-v2-backup'
$settingsBackup = $settings + '.gmsh-v2-backup'
if ((Test-Path $iniBackup) -or (Test-Path $settingsBackup)) {
    throw 'Backup precedente del profilo SAP2000 presente: controllarlo prima di procedere.'
}
$menuChanged = $false
$registered = $false
try {
    New-Item -ItemType Directory -Path $stage | Out-Null
    Copy-Item -LiteralPath (Join-Path $source 'SapGmshPlugin.dll') -Destination $stage
    Copy-Item -LiteralPath (Join-Path $source 'sap_gmsh_mesher.py') -Destination $stage
    Copy-Item -LiteralPath (Join-Path $source 'README-GMSH-V2.md') -Destination $stage
    New-Item -ItemType Directory -Path (Join-Path $stage 'img') | Out-Null
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot '..\img\quad-mesher.ico') -Destination (Join-Path $stage 'img')
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot '..\img\logo.png') -Destination (Join-Path $stage 'img')
    Copy-Item -LiteralPath $v2Runtime -Destination (Join-Path $stage 'mesher') -Recurse
    $backend = Join-Path $stage 'mesher\SapQuadMesherBackend.exe'
    & $backend --self-test
    if ($LASTEXITCODE -ne 0) { throw 'Autotest del runtime Gmsh v2 non riuscito.' }

    # Make the exact per-user COM registration that the v1 installer makes, with a different GUID.
    $assembly = [System.Reflection.AssemblyName]::GetAssemblyName((Join-Path $stage 'SapGmshPlugin.dll'))
    $codeBase = ([uri](Join-Path $Destination 'SapGmshPlugin.dll')).AbsoluteUri
    New-Item -Path $progKey -Force | Out-Null
    Set-Item -Path $progKey -Value $progId
    New-Item -Path ($progKey + '\CLSID') -Force | Out-Null
    Set-Item -Path ($progKey + '\CLSID') -Value $guid
    New-Item -Path $classKey -Force | Out-Null
    Set-Item -Path $classKey -Value $progId
    foreach ($key in @(($classKey + '\InprocServer32'), ($classKey + '\InprocServer32\' + $assembly.Version))) {
        New-Item -Path $key -Force | Out-Null
        Set-Item -Path $key -Value 'mscoree.dll'
        New-ItemProperty -Path $key -Name 'ThreadingModel' -Value 'Both' -Force | Out-Null
        New-ItemProperty -Path $key -Name 'Class' -Value $className -Force | Out-Null
        New-ItemProperty -Path $key -Name 'Assembly' -Value $assembly.FullName -Force | Out-Null
        New-ItemProperty -Path $key -Name 'RuntimeVersion' -Value 'v4.0.30319' -Force | Out-Null
        New-ItemProperty -Path $key -Name 'CodeBase' -Value $codeBase -Force | Out-Null
    }
    New-Item -Path ($classKey + '\ProgId') -Force | Out-Null
    Set-Item -Path ($classKey + '\ProgId') -Value $progId
    New-Item -Path ($classKey + '\Implemented Categories\{62C8FE65-4EBB-45e7-b440-6e39b2cdbf29}') -Force | Out-Null
    $registered = $true

    # Update both SAP2000 27 menu stores, preserving all existing entries.
    [xml]$document = Get-Content -LiteralPath $settings -Raw
    $menu = $document.SelectSingleNode('/Settings/PlugIn')
    if (-not $menu) { throw 'Campo PlugIn assente nelle impostazioni SAP2000.' }
    $records = New-Object System.Xml.XmlDocument
    $records.LoadXml($menu.InnerText)
    $array = $records.SelectSingleNode('/ArrayOfString')
    if (-not $array) { throw 'Formato del menu plugin SAP2000 non riconosciuto.' }
    $found = $false
    foreach ($item in $array.SelectNodes('string')) {
        $record = New-Object System.Xml.XmlDocument
        $record.LoadXml($item.InnerText.TrimStart([char]0xfeff, [char]' ', [char]13, [char]10))
        if ($record.SelectSingleNode('/PlugIn/m_name').InnerText -eq $menuName) {
            $found = $true
            $record.SelectSingleNode('/PlugIn/m_Hide').InnerText = 'false'
            $item.InnerText = ([char]0xfeff).ToString() + $record.OuterXml
            break
        }
    }
    if (-not $found) {
        $item = $records.CreateElement('string')
        $item.InnerText = ([char]0xfeff).ToString() + '<?xml version="1.0" encoding="utf-8"?>' +
            '<PlugIn><ClassID>S_PlugIn</ClassID><ClassVersion>2</ClassVersion>' +
            '<m_name>' + $menuName + '</m_name><m_Path /><m_Text>' + $menuText +
            '</m_Text><m_found>false</m_found><m_Info /><m_Hide>false</m_Hide></PlugIn>'
        [void]$array.AppendChild($item)
    }
    $menu.InnerText = $records.OuterXml

    $raw = [IO.File]::ReadAllBytes($ini)
    $bom = $raw.Length -ge 3 -and $raw[0] -eq 239 -and $raw[1] -eq 187 -and $raw[2] -eq 191
    $encoding = if ($bom) { New-Object System.Text.UTF8Encoding($true) } else { [Text.Encoding]::Default }
    $text = $encoding.GetString($raw)
    $section = [regex]::Match($text, '(?ms)^\[PlugIn\]\r?\n.*?(?=^\[|\z)')
    if (-not $section.Success) { throw 'Sezione [PlugIn] assente in SAP2000v27.ini.' }
    $count = [regex]::Match($section.Value, '(?m)^(?<prefix>[ \t]*NumberPlugIns=)(?<count>\d+)[ \t]*\r?$')
    $names = [regex]::Matches($section.Value, '(?m)^[ \t]*PlugInName=(?<name>[^\r\n]*)')
    $labels = [regex]::Matches($section.Value, '(?m)^[ \t]*PlugInMenuText=[^\r\n]*')
    if (-not $count.Success -or [int]$count.Groups['count'].Value -ne $names.Count -or $names.Count -ne $labels.Count) {
        throw 'Conteggio delle voci plugin incoerente nel profilo SAP2000.'
    }
    $inIni = @($names | Where-Object { $_.Groups['name'].Value.Trim() -eq $menuName }).Count -gt 0
    if (-not $inIni) {
        $eol = if ($section.Value.Contains("`r`n")) { "`r`n" } else { "`n" }
        $updated = $section.Value.Substring(0, $count.Groups['count'].Index) +
            ([int]$count.Groups['count'].Value + 1) +
            $section.Value.Substring($count.Groups['count'].Index + $count.Groups['count'].Length)
        $updated = $updated.TrimEnd([char]13, [char]10) + $eol +
            ' PlugInName=' + $menuName + $eol + ' PlugInMenuText=' + $menuText + $eol + $eol
        $text = $text.Substring(0, $section.Index) + $updated + $text.Substring($section.Index + $section.Length)
    }
    Copy-Item -LiteralPath $ini -Destination $iniBackup
    Copy-Item -LiteralPath $settings -Destination $settingsBackup
    $menuChanged = $true
    [IO.File]::WriteAllBytes($ini, $encoding.GetBytes($text))
    $document.Save($settings)
    Move-Item -LiteralPath $stage -Destination $Destination
    Remove-Item -LiteralPath $iniBackup, $settingsBackup
    Write-Output "SAP2000 Gmsh Mesh 2.0 installato in $Destination"
    Write-Output "Menu Tools: $menuText (riavviare SAP2000)."
}
catch {
    if ($menuChanged) {
        if (Test-Path $iniBackup) { Copy-Item -LiteralPath $iniBackup -Destination $ini -Force }
        if (Test-Path $settingsBackup) { Copy-Item -LiteralPath $settingsBackup -Destination $settings -Force }
    }
    if ($registered) {
        Remove-Item -LiteralPath $classKey, $progKey -Recurse -Force -ErrorAction SilentlyContinue
    }
    throw
}
finally {
    if (Test-Path $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
}
