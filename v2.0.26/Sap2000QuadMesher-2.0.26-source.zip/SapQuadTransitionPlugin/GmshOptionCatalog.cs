// SPDX-License-Identifier: GPL-2.0-or-later
using System;
using System.Collections.Generic;

namespace SapQuadTransitionPlugin
{
    // Numeric options documented by Gmsh 4.15.2. The explicit list is also
    // the schema used by the V2 WinForms tree: no option name is inferred from
    // a translated label. Advanced options remain available separately.
    internal sealed class GmshOptionDefinition
    {
        internal readonly string Name, CategoryEn, CategoryIt, LabelEn, LabelIt, HelpEn, HelpIt;
        internal readonly decimal Default, Minimum, Maximum, Increment;
        internal readonly int Decimals;
        internal readonly bool Length;

        internal GmshOptionDefinition(string name, string categoryEn, string categoryIt,
            string labelEn, string labelIt, string helpEn, string helpIt,
            decimal initial, decimal minimum, decimal maximum, decimal increment = 1,
            int decimals = 0, bool length = false)
        {
            Name = name; CategoryEn = categoryEn; CategoryIt = categoryIt;
            LabelEn = labelEn; LabelIt = labelIt; HelpEn = helpEn; HelpIt = helpIt;
            Default = initial; Minimum = minimum; Maximum = maximum;
            Increment = increment; Decimals = decimals; Length = length;
        }

        internal static readonly IReadOnlyList<GmshOptionDefinition> All = new[]
        {
            new GmshOptionDefinition("Mesh.MeshSizeMin", "Element size", "Dimensione elementi",
                "Minimum size", "Dimensione minima",
                "Computed from Maximum size and its percentage in Algorithms. It bounds Gmsh's target size, not real element edges.",
                "Calcolata dal massimo e dalla percentuale nella scheda Algoritmi. Limita la taglia obiettivo Gmsh, non gli spigoli reali.",
                0, 0, 100000000, .01m, 6, true),
            new GmshOptionDefinition("Mesh.MeshSizeFactor", "Element size", "Dimensione elementi",
                "Global size factor", "Fattore globale",
                "Scales the target sizes: a factor below 1 increases element density even if maximum size stays unchanged.",
                "Scala le dimensioni desiderate: un fattore sotto 1 aumenta la densita anche se la dimensione massima resta invariata.",
                1, .01m, 100, .01m, 3),
            new GmshOptionDefinition("Mesh.MeshSizeFromPoints", "Element size", "Dimensione elementi",
                "Size from points", "Taglia dai nodi",
                "Use sizing values at geometric points (0 off, 1 on). Selected SAP2000 joints remain geometric constraints when this is off.",
                "Usa le dimensioni indicate ai punti geometrici (0 spento, 1 attivo). I nodi SAP2000 selezionati rimangono vincoli geometrici anche a 0.",
                1, 0, 1),
            new GmshOptionDefinition("Mesh.MeshSizeExtendFromBoundary", "Element size", "Dimensione elementi",
                "Extend from boundary", "Estendi dal bordo",
                "1 propagates the boundary target size into surfaces; 0 does not. Gmsh also accepts -2 (surfaces only), -3 (volumes only) and 2.",
                "1 propaga la dimensione dal bordo nelle superfici; 0 no. Gmsh accetta anche -2 (solo superfici), -3 (solo volumi) e 2.",
                1, -3, 2),
            new GmshOptionDefinition("Mesh.MeshSizeFromCurvature", "Element size", "Dimensione elementi",
                "Curvature sizing", "Taglia da curvatura",
                "Target elements per full turn of a CAD curve. The SAP2000 source arcs in Circular_Floor are polygonal segments.",
                "Elementi desiderati per giro di una curva CAD. Gli archi SAP2000 di Circular_Floor sono segmenti poligonali.",
                0, 0, 10000),
            new GmshOptionDefinition("Mesh.RecombineOptimizeTopology", "Quadrilaterals", "Quadrilateri",
                "Topology passes", "Passaggi topologici",
                "Passes for removing diamonds and improving recombined mesh topology.",
                "Passaggi per eliminare configurazioni a diamante e migliorare la topologia della mesh ricomposta.",
                5, 0, 100),
            new GmshOptionDefinition("Mesh.RecombineNodeRepositioning", "Quadrilaterals", "Quadrilateri",
                "Move nodes", "Sposta nodi",
                "Allow node repositioning while recombining triangles into quadrilaterals (0/1).",
                "Consente di spostare i nodi durante la ricomposizione dei triangoli in quadrilateri (0/1).",
                1, 0, 1),
            new GmshOptionDefinition("Mesh.RecombineMinimumQuality", "Quadrilaterals", "Quadrilateri",
                "Minimum quad quality", "Qualita minima quad",
                "Reject quadrangles below this Gmsh recombination-quality threshold; more triangles may remain.",
                "Scarta i quadrilateri sotto la soglia di qualita Gmsh; possono rimanere piu triangoli.",
                .01m, 0, 1, .01m, 3),
            new GmshOptionDefinition("Mesh.SubdivisionAlgorithm", "Post-processing", "Post-elaborazione",
                "Subdivision", "Suddivisione",
                "0 none, 1 all quadrangles, 2 all hexahedra (3D), 3 barycentric. Subdivision can split SAP2000 boundary edges.",
                "0 nessuna, 1 tutti quad, 2 tutti esaedri (3D), 3 baricentrica. Puo suddividere i bordi SAP2000.",
                0, 0, 3),
            new GmshOptionDefinition("Mesh.AlgorithmSwitchOnFailure", "Post-processing", "Post-elaborazione",
                "Algorithm fallback", "Fallback algoritmo",
                "0 keeps the selected algorithm on failure; 1 allows Gmsh to switch to MeshAdapt for some 2D algorithms.",
                "0 mantiene l'algoritmo scelto in caso di errore; 1 consente a Gmsh di passare a MeshAdapt per alcuni algoritmi 2D.",
                1, 0, 1),
            new GmshOptionDefinition("Mesh.QuadqsSizemapMethod", "Quasi-structured", "Quasi-strutturata",
                "QuadQS size map", "Mappa taglie QuadQS",
                "Size-map strategy (0-4) for algorithm 11; meaningful only with Quasi-structured Quad.",
                "Strategia per la dimensione (0-4) dell'algoritmo 11; significativa solo con Quasi-structured Quad.",
                3, 0, 4),
            new GmshOptionDefinition("Mesh.QuadqsScalingOnTriangulation", "Quasi-structured", "Quasi-strutturata",
                "QuadQS tri/quad ratio", "Rapporto tri/quad",
                "Ratio between background triangulation and quadrangulation edge lengths for algorithm 11.",
                "Rapporto fra le lunghezze degli spigoli della triangolazione di fondo e della quadrangolazione nell'algoritmo 11.",
                .75m, .05m, 2, .05m, 3),
        };
    }
}
