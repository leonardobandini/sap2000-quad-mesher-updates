# Run one disjoint portion of the V2 atomic SAP catalog in an owned SAP process.
param([Parameter(Mandatory=$true)][string]$Ids,
      [Parameter(Mandatory=$true)][string]$PluginPath,
      [Parameter(Mandatory=$true)][string]$RunDirectory,
      [int]$CaseTimeoutSeconds = 480,
      [switch]$StandardCircularHoles)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$parent = Join-Path $env:TEMP 'opencode'
if (-not (Test-Path -LiteralPath $parent -PathType Container) -or
    -not $RunDirectory.StartsWith($parent, [StringComparison]::OrdinalIgnoreCase) -or
    (Test-Path -LiteralPath $RunDirectory) -or
    -not (Test-Path -LiteralPath $PluginPath -PathType Leaf)) { throw 'Unsafe or existing regression destination/plugin.' }
$runner = Join-Path $root 'bin\Release\net48\RunTest01Fast.dll'
if (-not (Test-Path -LiteralPath $runner -PathType Leaf)) { throw 'Build RunTest01Fast.csproj first.' }
$manifest = Get-Content -LiteralPath (Join-Path $root 'examples\atomic\manifest.json') -Raw | ConvertFrom-Json
New-Item -ItemType Directory -Path $RunDirectory | Out-Null
$results = [Collections.Generic.List[object]]::new()
$old = @{}
foreach ($key in @('SAP_GMSH_V2_ATOMIC_EXAMPLES','SAP_GMSH_V2_ATOMIC_OGRID',
    'SAP_GMSH_V2_ATOMIC_UI_PREVIEW','SAP_GMSH_V2_ATOMIC_UI_SCREENSHOT',
    'SAP_GMSH_V2_SETTINGS_TRACE_DIR','SAP_QUAD_COMPLETION_TRACE',
    'SAP_GMSH_V2_ATOMIC_UI_PAUSE_MS','SAP_GMSH_V2_SETTINGS_PATH')) {
    $old[$key] = [Environment]::GetEnvironmentVariable($key)
}
[Reflection.Assembly]::LoadFrom($runner) | Out-Null
$started = $false
try {
    [RunTest01Fast]::StartIsolatedPersistentSap()
    $started = $true
    foreach ($id in $Ids.Split(',')) {
        $entry = @($manifest | Where-Object id -eq $id)[0]
        if (-not $entry) { throw "Unknown atomic SAP fixture: $id" }
        $folder = Join-Path $RunDirectory $id
        New-Item -ItemType Directory -Path $folder | Out-Null
        $env:SAP_GMSH_V2_ATOMIC_EXAMPLES = '1'
        $env:SAP_GMSH_V2_ATOMIC_UI_PREVIEW = '1'
        $env:SAP_GMSH_V2_ATOMIC_OGRID = if ($entry.circularGroup -and -not $StandardCircularHoles) { '1' } else { $null }
        $env:SAP_GMSH_V2_ATOMIC_UI_PAUSE_MS = '100'
        $env:SAP_GMSH_V2_ATOMIC_UI_SCREENSHOT = Join-Path $folder 'new-ui.png'
        $env:SAP_GMSH_V2_SETTINGS_TRACE_DIR = $folder
        $env:SAP_QUAD_COMPLETION_TRACE = Join-Path $folder 'completed.txt'
        $env:SAP_GMSH_V2_SETTINGS_PATH = Join-Path $folder 'isolated-settings.json'
        $points = if ($entry.points) { [string[]]$entry.points } else { [string[]]@() }
        $frames = if ($entry.frames) { [string[]]$entry.frames } else { [string[]]@() }
        $size = ([double]$entry.maxSize).ToString([Globalization.CultureInfo]::InvariantCulture) + 'm'
        $diameter = if ($entry.diameter) { ([double]$entry.diameter).ToString([Globalization.CultureInfo]::InvariantCulture) + 'm' } else { '0.05m' }
        $fast = if ($null -eq $entry.fast) { $true } else { [bool]$entry.fast }
        $failure = ''
        try {
            [RunTest01Fast]::RunAtomicExampleWithTimeout(
                (Join-Path $root "examples\atomic\models\$id.sdb"),
                (Join-Path $folder "$id-meshed.sdb"), $PluginPath,
                [string[]]$entry.areas, $points, $frames, $size,
                [string]$entry.circularGroup, $diameter, [string]$entry.openingGroup,
                [bool]$entry.symmetry, $fast, [string]$entry.profile, [string]$entry.view,
                (Join-Path $folder "$id-result.svg"), $CaseTimeoutSeconds)
        }
        catch { $failure = $_.Exception.ToString() }
        if ($failure) { [IO.File]::WriteAllText((Join-Path $folder 'failure.txt'), $failure) }
        $traces = @(Get-ChildItem -LiteralPath $folder -Filter '*-settings.json' -File)
        $results.Add([pscustomobject]@{
            id = $id; status = if ($failure) { 'FAIL' } else { 'PASS' }
            backendJson = $traces.Count; screenshot = Test-Path -LiteralPath (Join-Path $folder 'new-ui.png')
            model = Test-Path -LiteralPath (Join-Path $folder "$id-meshed.sdb")
            failure = if ($failure) { $failure.Split([Environment]::NewLine)[0] } else { '' }
        })
        $results | Export-Csv -LiteralPath (Join-Path $RunDirectory 'summary.csv') -NoTypeInformation -Encoding UTF8
        Write-Host ("ATOMIC=$id STATUS=" + $(if ($failure) { 'FAIL' } else { 'PASS' }) + " JSON=$($traces.Count)")
        if ($failure -match 'exceeded the timeout') { break }
    }
}
finally {
    foreach ($key in $old.Keys) { [Environment]::SetEnvironmentVariable($key, $old[$key]) }
    if ($started) { [RunTest01Fast]::StopIsolatedPersistentSap() }
}
"REGRESSION_DIR=$RunDirectory"
"TOTAL=$($results.Count) PASS=$(@($results | Where-Object status -eq 'PASS').Count)"
