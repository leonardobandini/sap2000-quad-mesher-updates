"""Package only SAP-verified New UI screenshots and source/result SVGs."""
import hashlib
import json
import re
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'docs' / 'help-gmsh-v2' / 'assets'
TEMP = Path.home() / 'AppData' / 'Local' / 'Temp' / 'opencode'
MANIFEST = {item['id']: item for item in json.loads(
    (ROOT / 'examples' / 'atomic' / 'manifest.json').read_text(encoding='utf-8'))}
RUNS = [
    ('nTEST001', 'nTEST001', 'sqm-v226-help-new-group-1'),
    ('nTEST003', 'nTEST003', 'sqm-v226-help-new-group-1'),
    ('nTEST010', 'nTEST010', 'sqm-v226-help-new-group-1'),
    ('nTEST011', 'nTEST011', 'sqm-v226-help-new-group-1'),
    ('nTEST012', 'nTEST012', 'sqm-v226-help-new-group-1'),
    ('nTEST014', 'nTEST014', 'sqm-v226-help-new-group-1'),
    ('nTEST005-standard', 'nTEST005', 'sqm-v226-help-final-group-2'),
    ('nTEST017-standard', 'nTEST017', 'sqm-v226-help-final-group-2'),
    ('nTEST024-standard', 'nTEST024', 'sqm-v226-help-final-group-2'),
    ('nTEST007', 'nTEST007', 'sqm-v226-help-final-group-2'),
    ('nTEST008', 'nTEST008', 'sqm-v226-help-final-group-2'),
    ('nTEST013', 'nTEST013', 'sqm-v226-help-final-group-2'),
    ('nTEST018', 'nTEST018', 'sqm-v226-help-final-group-2'),
    ('nTEST019', 'nTEST019', 'sqm-v226-help-final-group-2'),
    ('nTEST020', 'nTEST020', 'sqm-v226-help-final-group-2'),
    ('nTEST028', 'nTEST028', 'sqm-v226-help-final-group-2'),
    ('nTEST035', 'nTEST035', 'sqm-v226-help-final-group-2'),
    ('nTEST005-ogrid', 'nTEST005', 'sqm-v226-help-final-group-3'),
    ('nTEST006-ogrid', 'nTEST006', 'sqm-v226-help-final-group-3'),
    ('nTEST015-symmetry', 'nTEST015', 'sqm-v226-help-final-group-3'),
    ('nTEST025-ogrid', 'nTEST025', 'sqm-v226-help-final-group-3'),
    ('nTEST027-ogrid', 'nTEST027', 'sqm-v226-help-final-group-3'),
    ('nTEST034-symmetry', 'nTEST034', 'sqm-v226-help-final-group-3'),
]


def build(replace_verified=False):
    if not ASSETS.is_dir() or not TEMP.is_dir():
        raise FileNotFoundError('Help assets or approved temporary test directory missing')
    dest = ASSETS / 'new-ui-examples.json'
    if dest.exists() and not replace_verified:
        raise FileExistsError('Refusing to overwrite existing New UI catalog: ' + str(dest))
    staged = []
    data = []
    for label, case, run in RUNS:
        folder = TEMP / run / case
        original = ROOT / 'examples' / 'atomic' / 'models' / (case + '.sdb')
        completed = folder / 'completed.txt'
        raw = completed.read_text(encoding='utf-8')
        match = re.search(r'after_mesh_areas=(\d+) quads=(\d+) triangles=(\d+)', raw)
        if not match or int(match[1]) != int(match[2]) + int(match[3]):
            raise ValueError('No verified generated shells for ' + label)
        settings_files = list(folder.glob('*-settings.json'))
        if len(settings_files) != 1:
            raise ValueError('Missing or ambiguous backend JSON for ' + label)
        options = json.loads(settings_files[0].read_text(encoding='utf-8-sig'))
        if options.get('previewMode') is not True or options.get('algorithm') == 9:
            raise ValueError('New UI was not active for ' + label)
        setting = MANIFEST[case]
        invocation_files = list(folder.glob('*-invocation.json'))
        if len(invocation_files) != 1:
            raise ValueError('Missing exact max-size invocation for ' + label)
        invocation = json.loads(invocation_files[0].read_text(encoding='utf-8-sig'))
        if abs(invocation['maxSize'] - float(setting['maxSize'])) > 1e-8:
            raise ValueError('Gmsh size differs from manifest on ' + label)
        assets = {}
        for source_name, extension in (('new-ui.png', 'options.png'),
                                       ('new-ui-additional.png', 'additional.png'),
                                       ('new-ui-symmetry.png', 'symmetry.png'),
                                       ('new-ui-json.png', 'json.png'),
                                       ('new-ui-transfer.png', 'transfer.png'),
                                       (case + '-source.svg', 'source.svg'),
                                       (case + '-result.svg', 'result.svg'),
                                       (settings_files[0].name, 'settings.json')):
            source = folder / source_name
            target = ASSETS / ('new-ui-' + label + '-' + extension)
            if not source.is_file() or (target.exists() and not replace_verified):
                raise FileExistsError('Source missing or help asset already exists: ' + str(target))
            assets[extension] = target.name
            staged.append((source, target))
        data.append(dict(id=label, sourceId=case,
                         sourceModel=str(original.relative_to(ROOT)).replace('\\', '/'),
                         sourceSha256=hashlib.sha256(original.read_bytes()).hexdigest(),
                         selectedAreas=setting['areas'], selectedPoints=setting.get('points', []),
                         selectedFrames=setting.get('frames', []),
                         circularGroup=setting.get('circularGroup'),
                         openingGroup=setting.get('openingGroup'), diameter=setting.get('diameter'),
                         maxSize=invocation['maxSize'],
                         backendSettings=assets['settings.json'],
                         screenshot=assets['options.png'],
                         uiScreenshots={section: assets[section + '.png'] for section in
                                        ('options','additional','symmetry','json','transfer')},
                         sourceSvg=assets['source.svg'], resultSvg=assets['result.svg'],
                         settings=options, generated=dict(areas=int(match[1]), quads=int(match[2]),
                             triangles=int(match[3])),
                         qualityPassed='quality_passed=True' in raw,
                         qualitySummary=next((s.partition('=')[2] for s in raw.splitlines()
                             if s.startswith('quality_summary=')), ''),
                         runFolder=str(folder)))
    if replace_verified:
        existing = json.loads(dest.read_text(encoding='utf-8'))
        if len(existing) != len(RUNS) or {item['id'] for item in existing} != {item[0] for item in RUNS}:
            raise ValueError('Existing New UI catalog is not the expected generated set')
        backup = dest.with_name('new-ui-examples.before-2.0.26.json')
        if backup.exists():
            raise FileExistsError('Existing documentation backup must not be overwritten')
        shutil.copy2(dest, backup)
    for source, target in staged:
        shutil.copy2(source, target)
    dest.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(f'NEW_UI_HELP_EXAMPLES={len(data)} PASS={sum(item["qualityPassed"] for item in data)} ASSETS={ASSETS}')


if __name__ == '__main__':
    import sys
    build('--refresh-verified' in sys.argv[1:])
