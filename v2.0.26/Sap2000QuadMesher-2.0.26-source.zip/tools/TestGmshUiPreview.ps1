# Verify the installed-default New UI; Classic remains developer-only.
param([string]$Plugin = (Join-Path (Split-Path -Parent $PSScriptRoot) 'SapQuadTransitionPlugin\bin\Release\net48\SapGmshPlugin.dll'),
      [string]$ScreenshotPath = '')

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -Path 'C:\Program Files\Computers and Structures\SAP2000 27\CSiAPIv1.dll'
$oldSize = $env:SAP_QUAD_ATOMIC_SIZE
$oldClassic = $env:SAP_GMSH_V2_USE_CLASSIC_UI
$oldSettings = $env:SAP_GMSH_V2_SETTINGS_PATH
$env:SAP_QUAD_ATOMIC_SIZE = '0.55m'
$env:SAP_GMSH_V2_USE_CLASSIC_UI = $null
$env:SAP_GMSH_V2_SETTINGS_PATH = Join-Path $env:TEMP ('opencode\sqm-new-default-' + [Guid]::NewGuid().ToString('N') + '.json')
try {
    $assembly = [Reflection.Assembly]::LoadFrom((Resolve-Path -LiteralPath $Plugin).Path)
    $type = $assembly.GetType('SapQuadTransitionPlugin.cPlugin+MeshOptionsDialog', $true)
    $axis = $assembly.GetType('SapQuadTransitionPlugin.cPlugin+SymmetryAxis', $true)
    $constructor = @($type.GetConstructors([Reflection.BindingFlags]'Instance,Public,NonPublic') |
        Where-Object { $_.GetParameters().Count -eq 6 })[0]
    $flags = [Reflection.BindingFlags]'Instance,NonPublic'
    function Field($dialog, $name) { $type.GetField($name, $flags).GetValue($dialog) }
    function Assert($condition, $message) { if (-not $condition) { throw $message } }
    $dialog = $constructor.Invoke([object[]]@('mm', $true, [string[]]@('BOLT'),
        [string[]]@('ALL'), [Array]::CreateInstance($axis, 0), $true))
    try {
        $dialog.Show()
        [Windows.Forms.Application]::DoEvents()
        $classic = Field $dialog 'gmshTabs'
        $preview = Field $dialog 'gmshPreviewTabs'
        $page = Field $dialog 'gmshPreviewEmptyTab'
        $panel = Field $dialog 'gmshPreviewOptions'
        $panelType = $panel.GetType()
        function Preview($name) { $panelType.GetField($name, $flags).GetValue($panel) }
        Assert ($type.GetField('gmshUiPreviewSelector', $flags) -eq $null) 'A UI mode selector still exists.'
        Assert ($dialog.ClientSize.Width -eq 570 -and $preview.Visible -and -not $classic.Visible -and
            $preview.SelectedTab -eq $page -and $preview.TabPages.Count -eq 4 -and
            (@($preview.TabPages | ForEach-Object Text) -join ',') -eq 'Gmsh,Additional Options,Gmsh JSON,Transfer Options') 'New tab names/order are incorrect.'
        Assert ((Field $dialog 'language').Visible -and
            (Field $dialog 'language').Parent -eq (Field $dialog 'headerTitle').Parent) 'Language selector disappeared with the UI switch.'
        $additional = Field $dialog 'gmshHolesTab'
        $transfer = Field $dialog 'gmshSapTab'
        $symmetry = Field $dialog 'symmetric'
        $symmetryAxis = Field $dialog 'symmetryAxis'
        Assert ($symmetry.Parent -eq $additional -and $symmetryAxis.Parent -eq $additional -and
            $additional.AutoScroll -and (Field $dialog 'fastMode').Parent -eq $transfer -and
            (Field $dialog 'createBackup').Parent -eq $transfer) 'Symmetry/transfer controls were not reparented.'
        $preview.SelectedTab = $additional
        $additional.ScrollControlIntoView((Field $dialog 'gmshSymmetryHint'))
        [Windows.Forms.Application]::DoEvents()
        $viewport = $additional.RectangleToScreen($additional.ClientRectangle)
        Assert ($symmetryAxis.Visible -and $additional.VerticalScroll.Visible -and
            -not $additional.HorizontalScroll.Visible -and
            $viewport.Contains($symmetryAxis.RectangleToScreen($symmetryAxis.ClientRectangle)) -and
            $viewport.Contains($symmetry.RectangleToScreen($symmetry.ClientRectangle))) 'Symmetry or its axis is clipped in Additional Options.'
        $preview.SelectedTab = $page
        $grid = Preview 'grid'
        $groups = @('general','generation','recombination','optimization') | ForEach-Object { Preview $_ }
        Assert ($grid.ColumnCount -eq 1 -and $groups.Count -eq 4 -and
            -not $page.Controls[0].VerticalScroll.Visible) 'The four groups do not fit in the single-column layout.'
        foreach ($i in 0..3) { Assert ($grid.GetPositionFromControl($groups[$i]).Row -eq $i) "Group $i is out of order." }
        $algorithm = Preview 'algorithm'
        Assert ($algorithm.Items.Count -eq 7 -and $algorithm.SelectedIndex -eq 5 -and
            -not @($algorithm.Items | Where-Object { $_ -match '^9\b' }).Count -and
            $algorithm.Items[6] -match '^11\b') 'Algorithm 9 is still selectable in New.'
        $savedType = $assembly.GetType('SapQuadTransitionPlugin.GmshPreviewPanel+Values', $true)
        $saved = [Activator]::CreateInstance($savedType, $true)
        $saved.Recombine = $saved.Optimize = $saved.SwitchOnFailure = $saved.NodeRepositioning = $true
        $restore = $panelType.GetMethod('Restore', [Reflection.BindingFlags]'Instance,NonPublic')
        $saved.Algorithm = 6 # Algorithm 9 in pre-2.0.25 saved settings.
        $null = $restore.Invoke($panel, [object[]]@($saved, $true))
        Assert ($algorithm.SelectedIndex -eq 5) 'Old saved algorithm 9 must become algorithm 8.'
        $saved.Algorithm = 7 # Algorithm 11 before removal of 9.
        $null = $restore.Invoke($panel, [object[]]@($saved, $true))
        Assert ($algorithm.SelectedIndex -eq 6) 'Old saved algorithm 11 was not migrated.'
        $algorithm.SelectedIndex = 5
        $algorithmSettings = Preview 'algorithmSettings'
        foreach ($index in 0..6) {
            $algorithm.SelectedIndex = $index
            Assert ($algorithmSettings.Enabled -eq ($index -in @(0,4))) 'Algorithm settings availability changed.'
        }
        $recombine = Preview 'enableRecombination'
        Assert (-not $recombine.Checked -and -not $recombine.Enabled -and
            ($dialog.GmshSettingsJson | ConvertFrom-Json).algorithm -eq 11) 'Algorithm 11 did not disable recombination.'
        $algorithm.SelectedIndex = 5
        Assert ($recombine.Checked -and $recombine.Enabled) 'Recombination state was not restored.'
        $maxSize = Preview 'maxSize'
        $minSize = Preview 'minSize'
        Assert ($maxSize.Text -eq '100' -and $minSize.Text -eq '0') 'Preview mesh size defaults changed.'
        $settings = $dialog.GmshSettingsJson | ConvertFrom-Json
        Assert ($settings.previewMode -and $settings.algorithm -eq 8 -and $settings.optimize -and
            $settings.options.'Mesh.MeshSizeFromPoints' -eq 0 -and
            $settings.options.'Mesh.MeshSizeExtendFromBoundary' -eq 0 -and
            $settings.options.'Mesh.MeshSizeFactor' -eq 1 -and
            $settings.options.'Mesh.AlgorithmSwitchOnFailure' -eq 1) 'The New Gmsh settings are not sent to Generate.'
        $maxSize.Text = '40mm'
        $minSize.Text = '5mm'
        (Field $dialog 'generate').PerformClick()
        Assert ($dialog.StartRequested -and [Math]::Abs($dialog.MaxSize - 40) -lt 1e-9 -and
            (Field $dialog 'size').Text -ne '40') 'Generate did not read the New fields.'
        $dialog.SetSelectionCounts(4, 4, 0, 0, 2, 0, 26)
        Assert ((Field $dialog 'areaSelection').Text -match '4' -and
            (Field $dialog 'objectSelection').Text -match '26') 'Shared object summary was lost.'
        if ($ScreenshotPath) {
            Assert (Test-Path -LiteralPath (Split-Path -Parent $ScreenshotPath) -PathType Container) 'Screenshot directory missing.'
            $image = New-Object Drawing.Bitmap($dialog.Width, $dialog.Height)
            try {
                $dialog.DrawToBitmap($image, (New-Object Drawing.Rectangle(0, 0, $image.Width, $image.Height)))
                $image.Save($ScreenshotPath, [Drawing.Imaging.ImageFormat]::Png)
            } finally { $image.Dispose() }
        }
        (Field $dialog 'language').SelectedIndex = 1
        [Windows.Forms.Application]::DoEvents()
        Assert (-not $page.Controls[0].VerticalScroll.Visible -and
            (@($preview.TabPages | ForEach-Object Text) -join ',') -eq
            'Gmsh,Opzioni aggiuntive,JSON Gmsh,Opzioni di trasferimento') 'Italian labels or Gmsh layout changed.'
        Write-Host 'NEW_DEFAULT=PASS NO_UI_SELECTOR=PASS ALGORITHM_9_ABSENT=PASS QUASI_11=PASS GENERATE=PASS EN_IT_LAYOUT=PASS'
    } finally { $dialog.Close(); $dialog.Dispose() }

    $env:SAP_GMSH_V2_USE_CLASSIC_UI = '1'
    $legacy = $constructor.Invoke([object[]]@('mm', $false, [string[]]@(),
        [string[]]@(), [Array]::CreateInstance($axis, 0), $true))
    try {
        $legacy.Show()
        [Windows.Forms.Application]::DoEvents()
        $algorithms = Field $legacy 'gmshAlgorithm'
        Assert ((Field $legacy 'gmshTabs').Visible -and -not (Field $legacy 'gmshPreviewTabs').Visible -and
            $algorithms.Items.Count -eq 8 -and
            -not @($algorithms.Items | Where-Object { $_ -match '^9\b' }).Count -and
            -not ($legacy.GmshSettingsJson | ConvertFrom-Json).PSObject.Properties['previewMode']) 'Classic is missing or algorithm 9 remains in the developer-only UI.'
        Write-Host 'CLASSIC_DEVELOPER_ONLY=PASS'
    } finally { $legacy.Close(); $legacy.Dispose() }
} finally {
    $env:SAP_QUAD_ATOMIC_SIZE = $oldSize
    $env:SAP_GMSH_V2_USE_CLASSIC_UI = $oldClassic
    $env:SAP_GMSH_V2_SETTINGS_PATH = $oldSettings
}
