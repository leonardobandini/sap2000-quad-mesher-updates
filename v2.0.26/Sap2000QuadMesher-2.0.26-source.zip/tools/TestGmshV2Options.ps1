# SPDX-License-Identifier: GPL-2.0-or-later
# Verify that V2 tree edits become real backend JSON. No SAP model is opened.
param([string]$Plugin = (Join-Path (Split-Path -Parent $PSScriptRoot) 'SapQuadTransitionPlugin\bin\Release\net48\SapGmshPlugin.dll'),
      [string]$ScreenshotPath = '',
       [ValidateSet('Options','Algorithms','Holes')][string]$ScreenshotPage = 'Options')
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -Path 'C:\Program Files\Computers and Structures\SAP2000 27\SAP2000v1.dll'
$old = $env:SAP_QUAD_ATOMIC_SIZE
$oldLayout = $env:SAP_QUAD_OPTIONS_LAYOUT
$oldClassicUi = $env:SAP_GMSH_V2_USE_CLASSIC_UI
$oldV2Settings = $env:SAP_GMSH_V2_SETTINGS_PATH
$testV2Settings = Join-Path $env:TEMP ('opencode\v2-options-' + [Guid]::NewGuid().ToString('N') + '.json')
if (-not (Test-Path -LiteralPath (Split-Path -Parent $testV2Settings) -PathType Container)) {
    throw 'Temporary settings parent directory missing.'
}
$env:SAP_GMSH_V2_SETTINGS_PATH = $testV2Settings
$env:SAP_QUAD_ATOMIC_SIZE = '0.55m' # Ignore a user's last-options.json during this probe.
$env:SAP_QUAD_OPTIONS_LAYOUT = $null
$env:SAP_GMSH_V2_USE_CLASSIC_UI = '1'
try {
    $assembly = [Reflection.Assembly]::LoadFrom((Resolve-Path -LiteralPath $Plugin).Path)
    $type = $assembly.GetType('SapQuadTransitionPlugin.cPlugin+MeshOptionsDialog', $true)
    $helpPath = $assembly.GetType('SapQuadTransitionPlugin.cPlugin').GetMethod(
        'HelpPath', [Reflection.BindingFlags]'Static,NonPublic')
    $italianHelp = [string]$helpPath.Invoke($null, [object[]]@($true))
    $englishHelp = [string]$helpPath.Invoke($null, [object[]]@($false))
    foreach ($file in @($italianHelp, $englishHelp,
        (Join-Path (Split-Path -Parent $italianHelp) 'style.css'),
        (Join-Path (Split-Path -Parent $italianHelp) 'geometry.svg'))) {
        if (-not (Test-Path -LiteralPath $file)) { throw "Local bilingual help file missing: $file" }
    }
    if ((Get-Content -LiteralPath $italianHelp -Raw) -notmatch 'MeshSizeFromPoints' -or
        (Get-Content -LiteralPath $englishHelp -Raw) -notmatch 'Transfinite') {
        throw 'The shipped V2 help has no parameter or algorithm descriptions.'
    }
    $assets = Join-Path (Split-Path -Parent $italianHelp) 'assets'
    $examplesPath = Join-Path $assets 'examples.json'
    if (-not (Test-Path -LiteralPath $examplesPath)) { throw 'V2 example settings missing from packaged help.' }
    $examples = Get-Content -LiteralPath $examplesPath -Raw | ConvertFrom-Json
    if ($examples.Count -ne 24) { throw 'The 24 verified V2 examples were not packaged.' }
    foreach ($example in $examples) {
        if ($example.actualGmshSettings.algorithm -ne 8 -or
            $example.generated.areas -ne $example.generated.quads + $example.generated.triangles -or
            -not (Test-Path -LiteralPath (Join-Path $assets "$($example.id)-source.svg")) -or
            -not (Test-Path -LiteralPath (Join-Path $assets "$($example.id)-result.svg"))) {
            throw "Missing SVG or inconsistent Gmsh settings for $($example.id)"
        }
    }
    $axis = $assembly.GetType('SapQuadTransitionPlugin.cPlugin+SymmetryAxis', $true)
    $constructor = @($type.GetConstructors([Reflection.BindingFlags]'Instance,Public,NonPublic') |
        Where-Object { $_.GetParameters().Count -eq 6 })[0]
    $dialog = $constructor.Invoke([object[]]@('m', $false, [string[]]@(), [string[]]@(),
        [Array]::CreateInstance($axis, 0), $true))
    try {
        $flags = [Reflection.BindingFlags]'Instance,NonPublic'
        function Field($name) { $type.GetField($name, $flags).GetValue($dialog) }
        $dialog.Show()
        [Windows.Forms.Application]::DoEvents()
        $version = $assembly.GetType('SapQuadTransitionPlugin.cPlugin').GetField('PluginVersion',
            [Reflection.BindingFlags]'Static,NonPublic').GetRawConstantValue()
        if ($dialog.Text -ne "SAP2000 Quad Transition Mesh $version" -or
            @($dialog.Controls | Where-Object { $_ -is [Windows.Forms.PictureBox] }).Count -lt 1) {
            throw 'V2 title or the V1 CSi Italia image logo is missing.'
        }
        if ((Field 'gmshTabs').TabPages.Count -ne 7 -or (Field 'gmshOptionNodes').Count -lt 10) {
            throw 'The algorithms/options/structured/fields/holes/advanced/SAP tabs or the typed option tree are missing.'
        }
        (Field 'gmshTabs').SelectedTab = Field 'gmshHolesTab'
        [Windows.Forms.Application]::DoEvents()
        if ((Field 'gmshHolesTab').Text -ne 'Holes' -or
            -not (Field 'generateCircularHoles').Visible -or
            -not (Field 'holeGroup').Visible -or -not (Field 'holeDiameter').Visible -or
            -not (Field 'generateHoles').Visible -or -not (Field 'openingGroup').Visible) {
            throw 'The grouped hole and frame-opening controls are not accessible from the V2 tab.'
        }
        (Field 'generateCircularHoles').Checked = $true
        if (-not $dialog.GenerateCircularHoles) { throw 'V2 circular holes still depend on the hidden V1 material profile.' }
        (Field 'generateCircularHoles').Checked = $false
        (Field 'generateHoles').Checked = $true
        if (-not $dialog.GenerateHoles) { throw 'V2 grouped frame openings are not enabled by their checkbox.' }
        (Field 'generateHoles').Checked = $false
        (Field 'gmshTabs').SelectedIndex = 0
        [Windows.Forms.Application]::DoEvents()
        if (@((Field 'gmshMeshTab').Controls | Where-Object { $_.Text -match 'Quality tolerance|Tolleranza qualita' }).Count -ne 0 -or
            $type.GetField('gmshSizeTolerance', $flags) -ne $null) {
            throw 'The V2 quality-tolerance control must not be displayed or load saved overrides.'
        }
        $base = $dialog.GmshSettingsJson | ConvertFrom-Json
        if ($base.algorithm -ne 8 -or -not $base.recombine -or $base.recombination -ne 0 -or
            $base.smoothing -ne 1 -or $base.optimize -or
            $base.options.'Mesh.MeshSizeMin' -ne .44 -or
            $base.options.'Mesh.MeshSizeFactor' -ne 1 -or
            $base.options.'Mesh.SubdivisionAlgorithm' -ne 0 -or
            $base.options.'Mesh.AlgorithmSwitchOnFailure' -ne 0 -or
            (Field 'size').Text -notmatch '0[,.]55' -or
            (Field 'gmshMinimumPercent').Value -ne 80 -or
            $base.qualityTolerancePercent -ne 20) {
            throw 'The named Default preset does not send the intended Gmsh settings.'
        }
        $nodes = Field 'gmshOptionNodes'
        $tree = Field 'gmshOptionTree'
        function ResetOptions {
            (Field 'gmshTabs').SelectedIndex = 0
            [Windows.Forms.Application]::DoEvents()
            (Field 'gmshResetDefault').PerformClick()
            (Field 'gmshTabs').SelectedIndex = 1
            [Windows.Forms.Application]::DoEvents()
        }
        (Field 'gmshTabs').SelectedIndex = 1
        [Windows.Forms.Application]::DoEvents()
        if ($nodes['Mesh.MeshSizeMin'].Parent.ToolTipText -notmatch 'Partially|parziale') {
            throw 'A partially selected Gmsh option group needs the mixed checkbox state.'
        }
        $group = $nodes['Mesh.MeshSizeMin'].Parent
        $toggle = $type.GetMethod('ToggleGmshNode', $flags)
        $null = $toggle.Invoke($dialog, [object[]]@($group))
        if (@($group.Nodes | Where-Object { -not $_.Checked }).Count -ne 0 -or -not $group.Checked) {
            throw 'Enabling an option group failed.'
        }
        $null = $toggle.Invoke($dialog, [object[]]@($group))
        if (@($group.Nodes | Where-Object Checked).Count -ne 0 -or $group.Checked) {
            throw 'Disabling an option group failed.'
        }
        ResetOptions
        $tree.SelectedNode = $nodes['Mesh.MeshSizeFromPoints']
        $tree.SelectedNode.Checked = $true
        (Field 'gmshOptionValue').Value = 0
        $updated = $dialog.GmshSettingsJson | ConvertFrom-Json
        if ($updated.options.'Mesh.MeshSizeFromPoints' -ne 0) {
            throw 'Checking/editing an option did not reach backend JSON.'
        }
        if ((Field 'gmshEffectivePreview').Text -notmatch 'MeshSizeFromPoints') {
            throw 'The user cannot inspect the effective Gmsh settings.'
        }
        (Field 'gmshExtra').Text = 'Mesh.MeshSizeFromPoints = 1'
        $duplicateRejected = $false
        try { $null = $type.GetProperty('GmshSettingsJson').GetValue($dialog) } catch { $duplicateRejected = $true }
        if (-not $duplicateRejected) { throw 'Conflicting advanced and tree values were silently accepted.' }
        ResetOptions
        (Field 'gmshStructureMode').SelectedIndex = 2
        (Field 'gmshCurveNodes').Value = 7
        $structured = $dialog.GmshSettingsJson | ConvertFrom-Json
        if ($structured.structured.mode -ne 'manual' -or $structured.structured.nodes -ne 7) {
            throw 'Manual transfinite controls did not reach the backend JSON.'
        }
        $dialog.SetSelectionCounts(1, 1, 0, 0, 1, 0, 1)
        (Field 'gmshLocalField').Checked = $true
        $clamped = $false
        try { $null = $type.GetProperty('GmshSettingsJson').GetValue($dialog) } catch { $clamped = $true }
        if (-not $clamped) { throw 'Default MeshSizeMin would silently cancel the 0.25m local refinement.' }
        (Field 'gmshMinimumPercent').Value = 40
        $local = $dialog.GmshSettingsJson | ConvertFrom-Json
        if ($local.localField.target -ne 'frames' -or $local.localField.sizeNear -ne .25 -or
            $local.localField.distanceFar -ne 1) { throw 'Distance/Threshold controls did not reach Gmsh.' }
        ResetOptions
        $advancedFields = '[{"id":"box","type":"Box","options":{"VIn":0.1,"VOut":0.55},"background":true}]'
        $type.GetField('gmshFieldGraphJson', $flags).SetValue($dialog, $advancedFields)
        $graph = $dialog.GmshSettingsJson | ConvertFrom-Json
        if ($graph.fieldGraph[0].type -ne 'Box' -or $graph.fieldGraph[0].options.VIn -ne .1) {
            throw 'The advanced Gmsh field graph was not serialized.'
        }
        (Field 'gmshLocalField').Checked = $true
        $graphConflict = $false
        try { $null = $type.GetProperty('GmshSettingsJson').GetValue($dialog) } catch { $graphConflict = $true }
        if (-not $graphConflict) { throw 'Two background size fields were silently accepted.' }
        ResetOptions
        $reset = $dialog.GmshSettingsJson | ConvertFrom-Json
        if ($null -ne $reset.options.'Mesh.MeshSizeFromPoints' -or $reset.algorithm -ne 8 -or
            $reset.options.'Mesh.MeshSizeMin' -ne .44 -or
            (Field 'gmshMinimumPercent').Value -ne 80) { throw 'Default reset failed.' }
        (Field 'size').Text = '0.6m'
        ResetOptions
        if ((Field 'size').Text -ne '0.6m' -or (Field 'gmshMinimumPercent').Value -ne 80 -or
            ($dialog.GmshSettingsJson | ConvertFrom-Json).options.'Mesh.MeshSizeMin' -ne .48) {
            throw 'Default options changed the maximum or failed to set its 80% minimum.'
        }
        (Field 'gmshMinimumPercent').Value = 60
        if (($dialog.GmshSettingsJson | ConvertFrom-Json).options.'Mesh.MeshSizeMin' -ne .36) {
            throw 'Changing the minimum percentage did not update MeshSizeMin.'
        }
        if (($dialog.GmshSettingsJson | ConvertFrom-Json).qualityTolerancePercent -ne 20 -or
            $dialog.GmshMaximumSizeTolerancePercent -ne 20) {
            throw 'The hidden quality tolerance must remain 20% in both the report and settings trace.'
        }
        ResetOptions
        (Field 'size').Text = '0.3m'
        if (($dialog.GmshSettingsJson | ConvertFrom-Json).options.'Mesh.MeshSizeMin' -ne .24) {
            throw 'Reducing maximum size did not automatically recalculate the minimum.'
        }
        (Field 'size').Text = '550mm'
        if (($dialog.GmshSettingsJson | ConvertFrom-Json).options.'Mesh.MeshSizeMin' -ne .44) {
            throw 'Minimum-size calculation lost the units of the typed maximum.'
        }
        (Field 'size').Text = '0.55m'
        (Field 'gmshOptimize').Checked = $true
        (Field 'gmshOptimizer').SelectedItem = 'Relocate2D'
        (Field 'gmshOptimizeIterations').Value = 2
        $optimization = $dialog.GmshSettingsJson | ConvertFrom-Json
        if (-not $optimization.optimize -or $optimization.optimizeMethod -ne 'Relocate2D' -or
            $optimization.optimizeIterations -ne 2) {
            throw 'Optimizer selection and iteration count were not sent to Gmsh.'
        }
        ResetOptions
        $tree.SelectedNode = $nodes['Mesh.SubdivisionAlgorithm']
        (Field 'gmshOptionValue').Value = 2
        $hexRejected = $false
        try { $null = $type.GetProperty('GmshSettingsJson').GetValue($dialog) } catch { $hexRejected = $true }
        if (-not $hexRejected) { throw '3D-only hexahedral subdivision was accepted for SAP shell objects.' }
        ResetOptions
        (Field 'language').SelectedIndex = 1
        if ((Field 'gmshOptionsTab').Text -ne 'Opzioni Gmsh') { throw 'V2 option tree is not localized.' }
        $millimetres = $constructor.Invoke([object[]]@('mm', $false, [string[]]@(), [string[]]@(),
            [Array]::CreateInstance($axis, 0), $true))
        try {
            $scaled = $millimetres.GmshSettingsJson | ConvertFrom-Json
            if ($scaled.options.'Mesh.MeshSizeMin' -ne 440 -or
                $type.GetField('size', $flags).GetValue($millimetres).Text -notmatch '550') {
                throw 'The Default preset did not convert 80% of 0.55 m to the current SAP2000 unit.'
            }
        } finally { $millimetres.Dispose() }
        $tree.SelectedNode = $nodes['Mesh.MeshSizeFromPoints']
        $tree.SelectedNode.Checked = $true
        (Field 'gmshOptionValue').Value = 0
        $env:SAP_QUAD_ATOMIC_SIZE = $null
        $type.GetMethod('RememberOptions', $flags).Invoke($dialog, @()) | Out-Null
        if (-not (Test-Path -LiteralPath $testV2Settings)) { throw 'Typed Gmsh options were not persisted.' }
        $saved = Get-Content -LiteralPath $testV2Settings -Raw | ConvertFrom-Json
        $saved.GmshSizeTolerancePercent = 5
        [IO.File]::WriteAllText($testV2Settings, ($saved | ConvertTo-Json -Depth 100))
        $restored = $constructor.Invoke([object[]]@('m', $false, [string[]]@(), [string[]]@(),
            [Array]::CreateInstance($axis, 0), $true))
        try {
            $restoredJson = $restored.GmshSettingsJson | ConvertFrom-Json
            if ($restoredJson.options.'Mesh.MeshSizeFromPoints' -ne 0 -or
                $restoredJson.qualityTolerancePercent -ne 20 -or
                $restored.GmshMaximumSizeTolerancePercent -ne 20) {
                throw 'A saved Gmsh tree override or hidden quality tolerance was restored incorrectly.'
            }
        } finally { $restored.Dispose() }
        $env:SAP_QUAD_ATOMIC_SIZE = '0.55m'
        ResetOptions
        if ($ScreenshotPath) {
            if (-not (Test-Path -LiteralPath (Split-Path -Parent $ScreenshotPath) -PathType Container)) {
                throw 'Screenshot parent missing.'
            }
            (Field 'gmshTabs').SelectedTab = if ($ScreenshotPage -eq 'Algorithms') {
                Field 'gmshMeshTab'
            } elseif ($ScreenshotPage -eq 'Holes') {
                Field 'gmshHolesTab'
            } else { Field 'gmshOptionsTab' }
            $dialog.TopMost = $true
            $dialog.BringToFront()
            $dialog.Activate()
            [Windows.Forms.Application]::DoEvents()
            Start-Sleep -Milliseconds 450
            $bitmap = New-Object Drawing.Bitmap($dialog.Bounds.Width,$dialog.Bounds.Height)
            try {
                $graphics = [Drawing.Graphics]::FromImage($bitmap)
                try { $graphics.CopyFromScreen($dialog.Bounds.Location,[Drawing.Point]::Empty,$bitmap.Size) }
                finally { $graphics.Dispose() }
                $bitmap.Save($ScreenshotPath,[Drawing.Imaging.ImageFormat]::Png)
            } finally { $bitmap.Dispose() }
            "SCREENSHOT=$ScreenshotPath"
        }
        'GMSH_V2_TREE_DEFAULT=PASS EDIT_TO_BACKEND=PASS DUPLICATE_REJECTED=PASS SIZE_PERCENT=PASS MIXED_GROUP=PASS 2D_OPTIMIZER=PASS 3D_REJECTED=PASS TRANSFINITE=PASS FIELDS=PASS FIELD_GRAPH=PASS RESET=PASS ITALIAN=PASS UNITS=PASS SETTINGS=PASS HELP=PASS GROUPED_OPENINGS=PASS HIDDEN_QUALITY_20=PASS 24_V2_EXAMPLES=PASS'
    } finally { $dialog.Close(); $dialog.Dispose() }
} finally {
    $env:SAP_QUAD_ATOMIC_SIZE = $old
    $env:SAP_QUAD_OPTIONS_LAYOUT = $oldLayout
    $env:SAP_GMSH_V2_USE_CLASSIC_UI = $oldClassicUi
    $env:SAP_GMSH_V2_SETTINGS_PATH = $oldV2Settings
    if (Test-Path -LiteralPath $testV2Settings) { Remove-Item -LiteralPath $testV2Settings -Force }
}
