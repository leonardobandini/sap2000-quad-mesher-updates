"""Build the bilingual 2.0.26 guide from genuinely verified New UI examples."""
import html
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HELP = ROOT / 'docs' / 'help-gmsh-v2'
ASSETS = HELP / 'assets'

TEXT = {
    'en': {
        'title': 'SAP2000 Quad Mesher — Gmsh New interface',
        'summary': 'Select planar SAP2000 shells, optional joints and frames. Gmsh creates a 2D shell mesh; Generate shows a preview, Apply commits it and Undo restores the saved original state. SAP2000 does not save the SDB automatically.',
        'nav': ['Workflow', 'Gmsh', 'Additional Options', 'Gmsh JSON', 'Transfer Options', 'Verified examples', 'Historic Classic'],
        'language': '<a href="index-it.html" lang="it">Italiano</a><strong>English</strong>',
        'flow': '<p>Open a saved model, select at least one planar area and launch <strong>Tools → SAP2000 Quad Mesher</strong>. The upper panel shows selected areas (quads/triangles/polygons), frames, links and joints; after Generate it shows the resulting objects. Select only the joints and frames that must constrain the mesh. Links are counted but do not constrain Gmsh. Use F1 or ? to reopen this offline guide in the selected language.</p><p>The New interface is the only visible layout in 2.0.26. The lower status, progress, created-element counter, Generate/Apply, Mesh quality and Undo controls remain available. Inspect the mesh and quality report before applying it. Exact symmetry requires an eligible axis from the selected geometry.</p>',
        'gmsh_intro': '<p>One-column native GroupBoxes configure the same Generate command as every other tab. All sizes use the effective SAP2000 length unit (SAP 27.2+ temporarily normalizes API units to the model database units). Bare numbers use the displayed unit; m, cm, mm, ft and in suffixes are accepted. The maximum is a Gmsh target, not a strict guarantee on final edge lengths.</p>',
        'additional': '<p><strong>Cut circular holes at grouped SAP2000 joints:</strong> check the option, choose a point-object group and enter a strictly positive hole diameter. <strong>Structured O-grid around circular holes:</strong> when checked, the hole collar is built with radial quadrangular sectors; outside it triangles may remain. With it unchecked, Gmsh makes a standard polygonal circular cut. Hole disks must fit the selected coplanar shells without overlapping other holes or protected frames.</p><p><strong>Cut openings bounded by grouped frames or shell edges:</strong> select the group that contains eligible frames or incident shell objects. Only completely closed eligible cells are removed. Open chains stay mesh constraints; SAP2000 frame objects themselves are not physically subdivided.</p><p><strong>Enforce exact symmetry about the chosen axis/axes:</strong> choose one detected axis or two perpendicular axes when available. The option is enabled only for eligible geometry; holes need mirrored counterparts or on-axis centres. Reflected topology and shared seams are checked before import. This option now belongs to Additional Options, not Transfer Options.</p>',
        'json': '<p><strong>Other numeric Gmsh options:</strong> one line per option, <code>Mesh.Option = number</code> using a dot for decimals. This text area is <em>not</em> a JSON editor. Duplicate tree overrides and controlled shell-only options are checked; preview-controlled/fixed settings retain their declared values. The read-only box below displays the <strong>effective JSON sent to the Python/Gmsh backend</strong>. <code>Mesh.MeshSizeMax</code> is passed separately as the numeric command argument and recorded with that JSON in test traces. Invalid values stop before model import.</p>',
        'transfer': '<p><strong>FAST — bulk insertion via SAP2000 editable tables:</strong> transfers generated nodes and shells in bulk when the model/table schema permits it. Uncheck it for Standard object-API insertion; both methods consume the same Gmsh result. <strong>Create numbered model backup:</strong> copies the last saved SDB before generation. Unsaved SAP2000 changes are not included in that disk backup. The CSV snapshot and Undo restore captured model data while the plugin remains open. Apply removes original areas from the in-memory model; inspect transferred properties and loads.</p>',
        'examples_intro': '<p>The following results were <strong>rerun with the New UI on isolated SAP2000 model copies</strong>. Each entry links the actual configured interface image, SVG of the original geometry, SVG of the resulting mesh, and the backend JSON. Counts and quality status come from the same completed SAP run. A completed mesh can have quality warnings. The former Classic-only selected-edge-lock case stays in the historical archive because that option is not exposed by New.</p>',
        'old': '<p><a href="legacy-en.html">Classic UI historical guide and its original 24 examples</a>. These earlier settings and SVG results are retained for reference; they are not presented as New-interface output. The former separate Transfinite Structured/Fields and option-tree controls are accessible only in developer Classic mode <code>SAP_GMSH_V2_USE_CLASSIC_UI=1</code>, not through this four-tab window. Algorithm 9 was removed after two native Gmsh worker crashes on the one-shell test fixture; it is no longer accepted by the backend.</p>',
        'labels': ('Selected options · New UI', 'Original SAP geometry', 'Generated SAP mesh', 'Quality passed', 'Quality warnings'),
        'footer': 'SAP2000 Quad Transition Mesh 2.0.26 · Offline help; inspect engineering quality and source-to-child assignments on your model.',
    },
    'it': {
        'title': 'SAP2000 Quad Mesher — nuova interfaccia Gmsh',
        'summary': 'Seleziona shell piane SAP2000, eventualmente nodi e frame. Gmsh genera la mesh 2D: Genera mostra l’anteprima, Applica conferma, Annulla mesh ripristina lo stato originale acquisito. Il file SDB non viene salvato automaticamente.',
        'nav': ['Procedura', 'Gmsh', 'Opzioni aggiuntive', 'JSON Gmsh', 'Opzioni di trasferimento', 'Esempi verificati', 'Archivio Classic'],
        'language': '<strong>Italiano</strong><a href="index-en.html" lang="en">English</a>',
        'flow': '<p>Apri un modello salvato, seleziona almeno un’area piana e avvia <strong>Tools → SAP2000 Quad Mesher</strong>. Il riquadro superiore mostra aree (quad/triangoli/poligoni), frame, link e nodi selezionati; dopo Genera riporta gli oggetti risultanti. Seleziona solo nodi e frame che devono vincolare la mesh. I link sono conteggiati ma non vincolano Gmsh. F1 oppure ? riapre questa guida offline nella lingua scelta.</p><p>La nuova interfaccia è l’unica visibile nella 2.0.26. Stato, progressione, elementi creati e pulsanti Genera/Applica, Qualità della mesh e Annulla restano in basso. Esamina anteprima e qualità prima di Applica. La simmetria esatta richiede un asse compatibile con la geometria selezionata.</p>',
        'gmsh_intro': '<p>Quattro GroupBox nativi, in una colonna, configurano lo stesso comando Genera delle altre schede. Le dimensioni usano l’unità di lunghezza SAP2000 effettiva (da SAP 27.2+ l’API usa temporaneamente le unità database del modello). I numeri senza suffisso usano l’unità mostrata; sono accettati m, cm, mm, ft, in. Il massimo è un obiettivo Gmsh, non una garanzia rigida sugli spigoli finali.</p>',
        'additional': '<p><strong>Crea fori circolari ai nodi SAP2000 del gruppo:</strong> attiva la casella, scegli il gruppo di point object e inserisci un diametro strettamente positivo. <strong>O-grid strutturata attorno ai fori:</strong> se attiva forma settori quad radiali attorno al foro; fuori dall’anello possono restare triangoli. Se disattiva ritaglia un foro circolare poligonale ordinario. I dischi devono stare nelle aree complanari selezionate, senza sovrapporsi ad altri fori o frame protetti.</p><p><strong>Ritaglia aperture delimitate da frame o spigoli del gruppo:</strong> scegli il gruppo dei frame o delle shell incidenti idonee. Sono rimosse soltanto celle completamente chiuse; catene aperte restano vincoli di mesh. Gli oggetti frame SAP2000 non sono fisicamente suddivisi.</p><p><strong>Imponi simmetria esatta:</strong> scegli un asse rilevato oppure due assi ortogonali se disponibili. L’opzione è disponibile soltanto con geometria idonea; fori in asse o in coppie speculari. Topologia riflessa e cuciture sono controllate prima dell’import. Ora la simmetria è in Opzioni aggiuntive, non in Opzioni di trasferimento.</p>',
        'json': '<p><strong>Altre opzioni numeriche Gmsh:</strong> una riga per opzione <code>Mesh.Option = numero</code> con decimali separati dal punto. Il campo testo <em>non</em> è un editor JSON. Duplicati nell’albero e opzioni controllate per le shell sono verificati; i parametri fissi/controllati della nuova UI conservano i valori dichiarati. Il riquadro di sola lettura sotto mostra il <strong>JSON effettivo inviato al backend Python/Gmsh</strong>. <code>Mesh.MeshSizeMax</code> viene passato separatamente come argomento numerico e registrato insieme al JSON nelle prove. Valori non validi interrompono prima dell’import.</p>',
        'transfer': '<p><strong>FAST — inserimento in blocco tramite tabelle editabili SAP2000:</strong> trasferisce nodi e shell in blocco quando schema e modello lo consentono. Disattiva FAST per il trasferimento Standard tramite API a oggetti: entrambi usano la stessa mesh Gmsh. <strong>Backup numerato del modello:</strong> copia l’ultimo SDB salvato prima di Genera, non le modifiche SAP2000 non salvate. Lo snapshot CSV e Annulla ripristinano i dati acquisiti finché la finestra resta aperta. Applica elimina le aree originali dal modello in memoria: controlla proprietà e carichi trasferiti.</p>',
        'examples_intro': '<p>I risultati seguenti sono stati <strong>rigenerati con la nuova UI su copie isolate di modelli SAP2000</strong>. Ogni caso collega screenshot delle opzioni realmente selezionate, SVG della geometria iniziale, SVG della mesh risultante e JSON backend. Conteggi ed esito qualità derivano dalla stessa esecuzione SAP. Una mesh completata può avere avvisi qualità. Il vecchio caso con bordi selezionati bloccati resta nell’archivio storico Classic: questa opzione non è esposta dalla nuova UI.</p>',
        'old': '<p><a href="legacy-it.html">Guida storica Classic con i suoi 24 esempi originali</a>. Le precedenti impostazioni e mesh SVG restano disponibili per confronto, non sono attribuite alla nuova UI. I controlli separati Strutturata/Campi e l’albero numerico sono accessibili soltanto in modalità sviluppatore <code>SAP_GMSH_V2_USE_CLASSIC_UI=1</code>, non nella finestra a quattro schede. L’algoritmo 9 è stato rimosso dopo due crash nativi del worker Gmsh sulla shell minima; anche il backend non lo accetta più.</p>',
        'labels': ('Opzioni selezionate · nuova UI', 'Geometria SAP originale', 'Mesh SAP generata', 'Qualità superata', 'Avvisi qualità'),
        'footer': 'SAP2000 Quad Transition Mesh 2.0.26 · Guida offline; verifica qualità e proprietà padre→figli sul modello reale.',
    },
}

GENERAL = [
    ('Max Mesh Size', 'Dimensione max', 'Mesh.MeshSizeMax (argv)', '0.1 m', '> 0', 'Input text; Gmsh target size, not strict edge bound.'),
    ('Min Mesh Size', 'Dimensione min', 'Mesh.MeshSizeMin', '0 m', '0 ≤ min < max', 'Input text; explicit length suffixes accepted.'),
]
GENERATION = [
    ('Mesh Algorithm', 'Algoritmo di mesh', 'Mesh.Algorithm', '8 Frontal-Delaunay for Quads', '1,2,5,6,7,8,11', 'All seven codes are available. 11 forces recombination off; code 9 is unavailable.'),
    ('MeshAdapt Settings: Refinement Steps', 'MeshAdapt: Passaggi di raffinamento', 'Mesh.RefineSteps', '10', 'integer > 0', 'Settings button enabled only for code 1.'),
    ('BAMG Settings: Maximum Anisotropy', 'BAMG: Anisotropia massima', 'Mesh.AnisoMax', '1E33', '≥ 1', 'Settings button enabled only for code 7.'),
    ('BAMG Settings: Smooth Ratio', 'BAMG: Rapporto regolarizzazione', 'Mesh.SmoothRatio', '1.8', '> 0', 'Only with BAMG.'),
    ('Automatic Algorithm Switch in Case of Failure', 'Cambio automatico se fallisce', 'Mesh.AlgorithmSwitchOnFailure', 'on / 1', '0 or 1', 'Gmsh internal fallback, not a plugin candidate search.'),
]
RECOMB = [
    ('Enable Recombination', 'Attiva ricomposizione', 'Mesh.RecombineAll', 'on / 1', '0 or 1', 'Algorithm 11 forces 0 and disables the whole group.'),
    ('Recombination Method', 'Metodo ricomposizione', 'Mesh.RecombinationAlgorithm', '0 Simple', '0 Simple, 1 Blossom, 2 Simple Full-Quad, 3 Blossom Full-Quad', 'Method and child fields disabled when recombination is off.'),
    ('Minimum Quad Quality', 'Qualità minima quad', 'Mesh.RecombineMinimumQuality', '0.01', '[0, 1]', 'Disabled when recombination is off.'),
    ('Optimization Steps', 'Passaggi topologici', 'Mesh.RecombineOptimizeTopology', '5', 'integer > 0', 'Disabled when recombination is off.'),
    ('Allow Node Repositioning', 'Riposiziona nodi', 'Mesh.RecombineNodeRepositioning', 'on / 1', '0 or 1', 'Disabled when recombination is off.'),
]
OPTIMIZE = [
    ('Optimize Mesh', 'Ottimizza mesh', 'gmsh.model.mesh.optimize', 'on', 'on/off', 'When off, no optimize API call; child controls disabled.'),
    ('Optimization Method', 'Metodo ottimizzazione', 'optimize(method)', 'Laplace2D', 'Laplace2D, Relocate2D, QuadQuasiStructured', 'Called without DimTags, with force=0.'),
    ('Optimization Iterations', 'Iterazioni', 'optimize(niter)', '1', 'integer > 0', 'Only when Optimize Mesh is on.'),
    ('QuadQS Size Map Method', 'QuadQS: Metodo mappa', 'Mesh.QuadqsSizemapMethod', '3 (Gmsh 4.15.2)', '0 Default; 1 Cross Field; 2 Cross Field + CAD; 3 Background Mesh; 4 Cross Field + CAD + Background', 'Settings button only for QuadQuasiStructured.'),
    ('QuadQS Mesh Topology Optimization', 'QuadQS: Ottimizzazione topologia', 'Mesh.QuadqsTopologyOptimizationMethods', '0 (Gmsh 4.15.2)', '0, 100, 10, 1, 110, 101, 11', '0 All; 100 Pattern; 10 Disk; 1 Cavity; combinations 110/101/11.'),
    ('QuadQS Remeshing Boldness', 'QuadQS: Intensità remesh', 'Mesh.QuadqsRemeshingBoldness', '0.66', '[0, 1]', 'QuadQuasiStructured only.'),
    ('QuadQS Scaling on Triangulation', 'QuadQS: Scala triangolazione', 'Mesh.QuadqsScalingOnTriangulation', '0.75', '> 0', 'QuadQuasiStructured only.'),
]
FIXED = [('Mesh.MeshSizeFactor', '1'), ('Mesh.MeshSizeFromPoints', '0'),
         ('Mesh.MeshSizeExtendFromBoundary', '0'), ('Mesh.MeshSizeFromCurvature', '0'),
         ('Mesh.MeshSizeFromParametricPoints', '0'), ('Mesh.SubdivisionAlgorithm', '0'),
         ('Mesh.ElementOrder', '1')]


def esc(value):
    return html.escape(str(value), quote=True)


def option_table(rows, lang):
    head = ('Control', 'Backend parameter', 'Default', 'Validation', 'Behaviour') if lang == 'en' else (
        'Controllo', 'Parametro backend', 'Predefinito', 'Validazione', 'Comportamento')
    body = ['<div class="scroll"><table><thead><tr>' + ''.join(f'<th>{esc(x)}</th>' for x in head) + '</tr></thead><tbody>']
    for english, italian, parameter, default, valid, explanation in rows:
        name = english if lang == 'en' else italian
        body.append('<tr>' + ''.join(f'<td>{esc(x)}</td>' for x in
            (name, parameter, default, valid, explanation)) + '</tr>')
    body.append('</tbody></table></div>')
    return '\n'.join(body)


def examples(entries, lang):
    captions = TEXT[lang]['labels']
    markup = []
    for item in entries:
        status = captions[3] if item['qualityPassed'] else captions[4]
        title = esc(item['id'])
        caption = f"{item['generated']['areas']} shell = {item['generated']['quads']} quad + {item['generated']['triangles']} triangles" if lang == 'en' else (
            f"{item['generated']['areas']} shell = {item['generated']['quads']} quad + {item['generated']['triangles']} triangoli")
        settings = item['settings']
        synopsis = (f"Mesh.MeshSizeMax={item['maxSize']}; Mesh.MeshSizeMin={settings['options']['Mesh.MeshSizeMin']}; "
                    f"Mesh.Algorithm={settings['algorithm']}; RecombineAll={int(settings['recombine'])}; "
                    f"recombination={settings['recombination']}; optimize={int(settings['optimize'])}; "
                    f"FAST={'on' if item['sourceId'] != 'nTEST003' and item['sourceId'] != 'nTEST035' else 'off'}; ") + (
            f"{status}. {item['qualitySummary']}")
        screenshots = item.get('uiScreenshots', {})
        related = []
        if item['circularGroup'] or item['openingGroup']:
            related.append(('additional', 'Additional Options' if lang == 'en' else 'Opzioni aggiuntive'))
        if settings.get('exactSymmetry'):
            related.append(('symmetry', 'Symmetry options' if lang == 'en' else 'Opzioni di simmetria'))
        if item['sourceId'] in ('nTEST028', 'nTEST035'):
            related.append(('transfer', 'Transfer Options' if lang == 'en' else 'Opzioni di trasferimento'))
        extra = ''.join(f'<figure><a href="assets/{esc(screenshots[kind])}">'
                        f'<img loading="lazy" src="assets/{esc(screenshots[kind])}" alt="{title}: {esc(caption)}"></a>'
                        f'<figcaption>{esc(caption)}</figcaption></figure>' for kind, caption in related)
        markup.append(f'<article class="example"><h3>{title}</h3><p class="parameters">{esc(synopsis)} '
                      f'<a href="assets/{esc(item["backendSettings"])}">JSON backend</a></p>'
                      f'<figure><a href="assets/{esc(item["screenshot"])}">'
                      f'<img loading="lazy" src="assets/{esc(item["screenshot"])}" alt="{title}: {esc(captions[0])}"></a>'
                      f'<figcaption>{esc(captions[0])}</figcaption></figure>'
                      + extra +
                      f'<p><a href="assets/{esc(screenshots["json"])}">{esc("Effective JSON window" if lang == "en" else "Finestra JSON effettivo")}</a>'
                      f' · <a href="assets/{esc(screenshots["transfer"])}">{esc("Transfer settings" if lang == "en" else "Impostazioni di trasferimento")}</a></p>'
                      '<div class="pair">'
                      f'<figure><a href="assets/{esc(item["sourceSvg"])}"><img loading="lazy" src="assets/{esc(item["sourceSvg"])}" alt="{title}: source geometry"></a><figcaption>{esc(captions[1])}</figcaption></figure>'
                      f'<figure><a href="assets/{esc(item["resultSvg"])}"><img loading="lazy" src="assets/{esc(item["resultSvg"])}" alt="{title}: meshed result"></a><figcaption>{esc(captions[2])}</figcaption></figure>'
                      '</div></article>')
    return '\n'.join(markup)


def page(lang, entries):
    t = TEXT[lang]
    ids = ['iniziare', 'gmsh', 'aggiuntive', 'json', 'trasferimento', 'esempi', 'storico']
    nav = ''.join(f'<a href="#{identifier}">{esc(name)}</a>' for identifier, name in zip(ids, t['nav']))
    head = (f'<!doctype html><html lang="{lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
            f'<title>{esc(t["title"])}</title><link rel="stylesheet" href="style.css"></head><body><div class="layout">'
            f'<aside><strong>SAP2000 Quad<br>Transition Mesh</strong><small>2.0.26 · {"Offline help" if lang == "en" else "Guida offline"}</small><hr>'
            f'<nav aria-label="Contents">{nav}</nav><hr><div>{t["language"]}</div></aside><main id="inizio">'
            f'<div class="hero"><h1>{esc(t["title"])}</h1><p>{esc(t["summary"])}</p></div>')
    parts = [head,
        f'<section id="iniziare"><h2>{t["nav"][0]}</h2>{t["flow"]}</section>',
        f'<section id="gmsh"><h2>Gmsh</h2>{t["gmsh_intro"]}'
        f'<h3>General mesh parameters</h3>{option_table(GENERAL, lang)}'
        f'<h3>Mesh Generation</h3>{option_table(GENERATION, lang)}'
        f'<h3>Triangle Recombination</h3>{option_table(RECOMB, lang)}'
        f'<h3>Mesh Optimization</h3>{option_table(OPTIMIZE, lang)}'
        '<h3>Fixed, hidden backend options</h3><div class="scroll"><table><thead><tr><th>Mesh.*</th><th>Value</th></tr></thead><tbody>' +
        ''.join(f'<tr><td><code>{esc(name)}</code></td><td>{value}</td></tr>' for name, value in FIXED) +
        '</tbody></table></div></section>',
        f'<section id="aggiuntive"><h2>{t["nav"][2]}</h2>{t["additional"]}</section>',
        f'<section id="json"><h2>{t["nav"][3]}</h2>{t["json"]}</section>',
        f'<section id="trasferimento"><h2>{t["nav"][4]}</h2>{t["transfer"]}</section>',
        f'<section id="esempi"><h2>{t["nav"][5]} · {len(entries)}</h2>{t["examples_intro"]}'
        '<p><a href="assets/new-ui-examples.json">new-ui-examples.json</a></p>' + examples(entries, lang) + '</section>',
        f'<section id="storico"><h2>{t["nav"][6]}</h2>{t["old"]}</section>',
        f'<footer>{t["footer"]}</footer></main></div></body></html>']
    return '\n'.join(parts) + '\n'


def build(replace_verified=False):
    entries = json.loads((ASSETS / 'new-ui-examples.json').read_text(encoding='utf-8'))
    if len(entries) != 23:
        raise ValueError('Expected 23 independently verified new-interface examples')
    for lang in ('it', 'en'):
        target = HELP / f'index-{lang}.html'
        if target.exists():
            current = target.read_text(encoding='utf-8')
            if not replace_verified or 'SAP2000 Quad Transition Mesh' not in current or 'new-ui-examples.json' not in current:
                raise FileExistsError('Refusing to overwrite an unrecognized main help page: ' + str(target))
            backup = target.with_name(f'index-{lang}.before-v2.0.26.html')
            if backup.exists():
                raise FileExistsError('Existing help backup must not be overwritten: ' + str(backup))
            import shutil
            shutil.copy2(target, backup)
        target.write_text(page(lang, entries), encoding='utf-8')
        print('BUILT_HELP=' + str(target))


if __name__ == '__main__':
    import sys
    build('--refresh-verified' in sys.argv[1:])
