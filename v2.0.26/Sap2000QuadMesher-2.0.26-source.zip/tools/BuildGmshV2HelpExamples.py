"""Package genuinely verified V2 atomic diagrams and effective settings for help."""
import argparse
import json
import re
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'docs' / 'help-gmsh-v2' / 'assets'
MANIFEST = ROOT / 'examples' / 'atomic' / 'manifest.json'
IDS = ('nTEST001', 'nTEST003', 'nTEST010', 'nTEST011', 'nTEST012', 'nTEST014')


def build(runs, replace=False, locked_run=None, circular_runs=None, opening_runs=None,
          seam_runs=None, feature_runs=None):
    if not ASSETS.is_dir() or not MANIFEST.is_file():
        raise FileNotFoundError('Help assets or atomic manifest missing')
    selections = {entry['id']: entry for entry in json.loads(MANIFEST.read_text(encoding='utf-8'))}
    output = []
    copies = []
    if feature_runs:
        cases = [(name + ('-ogrid' if name in ('nTEST005', 'nTEST006', 'nTEST025', 'nTEST027')
                          else '-symmetry'), name, feature_runs)
                 for name in ('nTEST005', 'nTEST006', 'nTEST015', 'nTEST025', 'nTEST027', 'nTEST034')]
        existing = json.loads((ASSETS / 'examples.json').read_text(encoding='utf-8'))
        if len(existing) != 18 or any(item['id'] in {case[0] for case in cases} for item in existing):
            raise ValueError('Expected 18 original verified V2 examples before appending feature trials')
        output.extend(existing)
    elif circular_runs or opening_runs or seam_runs:
        cases = [(name, name, circular_runs) for name in ('nTEST005', 'nTEST017', 'nTEST024')] if circular_runs else [
            (name, name, opening_runs) for name in ('nTEST007', 'nTEST008', 'nTEST013',
                                                    'nTEST018', 'nTEST019', 'nTEST020')] if opening_runs else [
            (name, name, seam_runs) for name in ('nTEST028', 'nTEST035')]
        existing = json.loads((ASSETS / 'examples.json').read_text(encoding='utf-8'))
        expected = 7 if circular_runs else 10 if opening_runs else 16
        if len(existing) != expected or any(item['id'] in {case[0] for case in cases} for item in existing):
            raise ValueError(f'Expected {expected} verified V2 examples before appending new results')
        output.extend(existing)
    else:
        cases = [(name, name, runs) for name in IDS]
        if locked_run:
            cases.append(('nTEST010-locked', 'nTEST010', [locked_run]))
    for title, case, source_runs in cases:
        folders = [run / case for run in source_runs
                   if (run / case / 'completed.txt').is_file() and
                   (run / case / f'{case}-result.svg').is_file() and
                   'after_mesh_areas=' in (run / case / 'completed.txt').read_text(encoding='utf-8')]
        if len(folders) != 1:
            raise ValueError(f'Expected one verified V2 run for {case}; found {len(folders)}')
        folder = folders[0]
        options = list(folder.glob('*-settings.json'))
        if len(options) != 1:
            raise ValueError(f'Actual backend configuration is missing or ambiguous for {case}')
        actual = json.loads(options[0].read_text(encoding='utf-8-sig'))
        completion = (folder / 'completed.txt').read_text(encoding='utf-8')
        count = re.search(r'after_mesh_areas=(\d+) quads=(\d+) triangles=(\d+)', completion)
        if not count or int(count[1]) != int(count[2]) + int(count[3]):
            raise ValueError(f'Inconsistent SAP2000 V2 result for {case}')
        for state in ('source', 'result'):
            source = folder / f'{case}-{state}.svg'
            target = ASSETS / f'{title}-{state}.svg'
            if not source.is_file() or (target.exists() and not replace):
                raise FileExistsError(f'Help diagram missing or destination already contains {title}-{state}')
            if '<svg ' not in source.read_text(encoding='utf-8-sig'):
                raise ValueError(f'Invalid source diagram for {case}')
            copies.append((source, target))
        selection = selections[case]
        output.append(dict(id=title, sourceModel=f'examples/atomic/models/{case}.sdb',
            selectedAreas=selection['areas'], selectedPoints=selection.get('points', []),
            selectedFrames=selection.get('frames', []), profileFromV1Manifest=selection['profile'],
            presentLengthUnit='m', maximumSize=selection['maxSize'], fast=selection.get('fast', True),
            circularGroup=selection.get('circularGroup'), holeDiameter=selection.get('diameter'),
            exactSymmetry=bool(actual.get('exactSymmetry')), oGrid=bool(actual.get('oGrid')),
            actualGmshSettings=actual, generated=dict(areas=int(count[1]),
                quads=int(count[2]), triangles=int(count[3])),
            qualityPassed='quality_passed=True' in completion,
            qualitySummary=next((line.partition('=')[2] for line in completion.splitlines()
                                  if line.startswith('quality_summary=')), '')))
    if (ASSETS / 'examples.json').exists() and not replace and not (circular_runs or opening_runs or seam_runs or feature_runs):
        raise FileExistsError('The verified V2 examples.json already exists')
    for source, target in copies:
        shutil.copyfile(source, target)
    (ASSETS / 'examples.json').write_text(json.dumps(output, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(f'PACKAGED {len(output)} VERIFIED V2 EXAMPLES in {ASSETS}')
    for entry in output:
        print(entry['id'], entry['generated'], 'quality_passed=' + str(entry['qualityPassed']))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, action='append',
                        help='One %TEMP%/opencode/gmsh-v2-examples-* directory (repeat as needed)')
    parser.add_argument('--locked-run', type=Path, help='Separate nTEST010 run with selected-edge protection')
    parser.add_argument('--circular-run', type=Path, action='append',
                        help='Append three verified SAP2000 circular-hole runs to the existing seven examples')
    parser.add_argument('--openings-run', type=Path, action='append',
                        help='Append six verified SAP2000 grouped-opening runs to the existing ten examples')
    parser.add_argument('--seam-run', type=Path, action='append',
                         help='Append the FAST and standard four-area seam regressions to the sixteen examples')
    parser.add_argument('--feature-run', type=Path, action='append',
                        help='Append verified 2.0.11 symmetry and O-grid examples to the eighteen examples')
    parser.add_argument('--replace-verified', action='store_true',
                        help='Replace only previously generated V2 help assets with freshly verified V2 runs')
    args = parser.parse_args()
    if not any((args.circular_run, args.openings_run, args.seam_run, args.feature_run, args.run)):
        parser.error('Provide a verified example run')
    build(args.run, args.replace_verified, args.locked_run, args.circular_run,
          args.openings_run, args.seam_run, args.feature_run)
