"""Check both shipped help languages, local links and V2-verified examples."""
import json
import re
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HELP = ROOT / 'docs' / 'help-gmsh-v2'


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
        self.ids = set()

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if values.get('id'):
            self.ids.add(values['id'])
        for name in ('href', 'src'):
            if values.get(name):
                self.links.append(values[name])


def main():
    option_names = set(re.findall(r'new GmshOptionDefinition\("(Mesh\.[A-Za-z0-9]+)"',
                                  (ROOT / 'SapQuadTransitionPlugin' / 'GmshOptionCatalog.cs').read_text(encoding='utf-8')))
    if len(option_names) != 12:
        raise ValueError('Gmsh option catalog changed; review help coverage')
    entries = json.loads((HELP / 'assets' / 'examples.json').read_text(encoding='utf-8'))
    if len(entries) != 24 or any(item['generated']['areas'] !=
                                item['generated']['quads'] + item['generated']['triangles'] for item in entries):
        raise ValueError('Missing or inconsistent verified example metadata')
    expected = {'nTEST001': True, 'nTEST003': False, 'nTEST010': True,
                'nTEST011': False, 'nTEST012': True, 'nTEST014': True, 'nTEST010-locked': False,
                'nTEST005': False, 'nTEST017': False, 'nTEST024': True,
                'nTEST007': True, 'nTEST008': True, 'nTEST013': False,
                'nTEST018': False, 'nTEST019': True, 'nTEST020': True,
                 'nTEST028': False, 'nTEST035': False,
                 'nTEST005-ogrid': True, 'nTEST006-ogrid': True,
                 'nTEST015-symmetry': True, 'nTEST025-ogrid': True,
                 'nTEST027-ogrid': True, 'nTEST034-symmetry': False}
    for item in entries:
        settings = item['actualGmshSettings']
        if (item['id'] not in expected or item['qualityPassed'] != expected[item['id']] or
                 settings['qualityTolerancePercent'] != 20 or
                 settings['preserveSelectedEdges'] != (item['id'] == 'nTEST010-locked') or
                 abs(settings['options']['Mesh.MeshSizeMin'] - item['maximumSize'] * .8) > 1e-8):
            raise ValueError('Incorrect quality report, minimum percentage or edge-lock setting: ' + item['id'])
        if item['id'].endswith(('-ogrid', '-symmetry')):
            if (item['oGrid'] != item['id'].endswith('-ogrid') or
                    item['exactSymmetry'] != item['id'].startswith(('nTEST006', 'nTEST015', 'nTEST025', 'nTEST027', 'nTEST034')) or
                    item['oGrid'] != bool(settings['oGrid']) or
                    item['exactSymmetry'] != bool(settings['exactSymmetry'])):
                raise ValueError('Feature flags differ from effective Gmsh settings: ' + item['id'])
    for name in ('index-it.html', 'index-en.html'):
        parser = Links()
        parser.feed((HELP / name).read_text(encoding='utf-8'))
        for url in parser.links:
            if url.startswith('#'):
                if url[1:] not in parser.ids:
                    raise FileNotFoundError(name + ': missing section ' + url)
            elif '://' not in url and not (HELP / url).is_file():
                raise FileNotFoundError(name + ': missing local resource ' + url)
        text = (HELP / name).read_text(encoding='utf-8')
        for item in entries:
            if item['id'] not in text:
                raise ValueError(name + ': missing example ' + item['id'])
        for marker in ('2.0.17', 'id="simmetria"', 'id="esempi-simmetria"', 'id="trasferimento"',
                        'Mesh.MeshSizeMin', 'Mesh.AlgorithmSwitchOnFailure',
                        'Distance', 'Threshold', 'FAST', 'Standard', 'O-grid', '🟢', '🟡', '🔴'):
            if marker not in text:
                raise ValueError(name + ': undocumented feature ' + marker)
        if any(option not in text for option in option_names):
            raise ValueError(name + ': missing numeric tree option')
    print('GMSH_V2_HELP=PASS LANGUAGES=2 VERIFIED_EXAMPLES=' + str(len(entries)))


if __name__ == '__main__':
    main()
