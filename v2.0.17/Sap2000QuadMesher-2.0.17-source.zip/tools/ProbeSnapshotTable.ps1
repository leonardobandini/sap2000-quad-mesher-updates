# SPDX-License-Identifier: GPL-2.0-or-later
# Inspect table capabilities on an isolated SAP2000 copy; do not save the source.
param([Parameter(Mandatory=$true)][string]$Source,
      [string]$Key='Analysis Options Advanced')
$ErrorActionPreference='Stop'
$parent=Join-Path $env:TEMP 'opencode'
if (-not (Test-Path -LiteralPath $parent -PathType Container)) { throw 'Temporary parent missing.' }
if (-not (Test-Path -LiteralPath $Source -PathType Leaf)) { throw "Source missing: $Source" }
$trial=Join-Path $parent ('snapshot-table-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $trial | Out-Null
$copy=Join-Path $trial 'source-copy.sdb'
Copy-Item -LiteralPath $Source -Destination $copy
$api='C:\Program Files\Computers and Structures\SAP2000 27\SAP2000v1.dll'
Add-Type -Path $api
$sap=$null
try {
    $sap=(New-Object SAP2000v1.Helper).CreateObject('C:\Program Files\Computers and Structures\SAP2000 27\SAP2000.exe')
    if ($null -eq $sap) { throw 'SAP2000 helper returned no application object.' }
    $started=$sap.ApplicationStart([SAP2000v1.eUnits]::kN_m_C,$false,'')
    "APPLICATION_START_CODE=$started"
    if ($started -ne 0) { throw "Isolated SAP2000 start failed with code $started" }
    $opened=$sap.SapModel.File.OpenFile($copy)
    "MODEL_OPEN_CODE=$opened"
    if ($opened -ne 0) { throw "Cannot open isolated SAP2000 copy (code $opened)" }
    $m=$sap.SapModel
    $count=0; [string[]]$keys=@(); [string[]]$names=@(); [int[]]$imports=@(); [bool[]]$empty=@()
    $all=$m.DatabaseTables.GetAllTables([ref]$count,[ref]$keys,[ref]$names,[ref]$imports,[ref]$empty)
    if ($all -ne 0) { throw "GetAllTables code=$all" }
    $index=[array]::IndexOf($keys,$Key)
    if ($index -lt 0) {
        "TABLE_NOT_PRESENT=$Key"
        foreach ($i in 0..($count - 1)) {
            if ($keys[$i] -like '*Analysis*Options*') {
                "OTHER_TABLE=$($keys[$i]) IMPORT_TYPE=$($imports[$i]) EMPTY=$($empty[$i])"
            }
        }
        return
    }
    "TABLE=$Key IMPORT_TYPE=$($imports[$index]) EMPTY=$($empty[$index])"
    $version=0; $records=0; [string[]]$fields=$null; [string[]]$data=$null
    $edit=$m.DatabaseTables.GetTableForEditingArray($Key,'',[ref]$version,[ref]$fields,[ref]$records,[ref]$data)
    "EDIT_CODE=$edit EDIT_FIELDS=$(@($fields).Count) EDIT_RECORDS=$records"
    $version=0; $records=0; [string[]]$requested=$null; [string[]]$included=$null; [string[]]$data=$null
    $display=$m.DatabaseTables.GetTableForDisplayArray($Key,[ref]$requested,'',[ref]$version,[ref]$included,[ref]$records,[ref]$data)
    "DISPLAY_CODE=$display DISPLAY_FIELDS=$(@($included).Count) DISPLAY_RECORDS=$records"
} finally {
    if ($sap -ne $null) {
        try { $null=$sap.ApplicationExit($false) }
        catch { "SAP_EXIT_DIAGNOSTIC=$($_.Exception.Message)" }
    }
    if (Test-Path -LiteralPath $trial) { Remove-Item -LiteralPath $trial -Recurse -Force }
}
