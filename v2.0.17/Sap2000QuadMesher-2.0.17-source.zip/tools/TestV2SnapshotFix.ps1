# SPDX-License-Identifier: GPL-2.0-or-later
# Run an isolated SAP model copy through the candidate DLL, never the installed plugin.
param([string]$Source = 'C:\Users\leona\Desktop\Modelli_SAP2000_Quad_Mesher\06_Soletta_circolare\Circular_Floor.sdb',
      [switch]$UsePackaged)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$parent = Join-Path $env:TEMP 'opencode'
if (-not (Test-Path -LiteralPath $parent -PathType Container)) { throw 'Missing temporary parent.' }
$run = Join-Path $parent ('sqm-v2-snapshot-fix-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $run | Out-Null
try {
    $package = Join-Path $run 'plugin'
    if ($UsePackaged) {
        Copy-Item -LiteralPath (Join-Path $root 'artifacts\Sap2000QuadMesher-2.0.12') -Destination $package -Recurse
    } else {
        $build = Join-Path $run 'build'
        & dotnet build (Join-Path $root 'SapQuadTransitionPlugin\SapGmshReplacement.csproj') -c Release -o $build
        if ($LASTEXITCODE -ne 0) { throw 'Replacement V2 build failed.' }
        Copy-Item -LiteralPath (Join-Path $root 'artifacts\Sap2000QuadMesher-2.0.11') -Destination $package -Recurse
        Copy-Item -LiteralPath (Join-Path $build 'SapQuadTransitionPlugin.dll') -Destination $package -Force
    }
    $probe = Join-Path $PSScriptRoot 'ProbeCircularFloor.ps1'
    $completion = Join-Path $run 'completed.txt'
    & $probe -Source $Source -Plugin (Join-Path $package 'SapQuadTransitionPlugin.dll') -TraceDir $run `
        -Size '0.5m' -TolerancePercent 20 -Undo -AllowNewExposedNodes -CompletionTrace $completion
    if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) { throw "Probe failed with code $LASTEXITCODE" }
    if (-not (Test-Path -LiteralPath $completion -PathType Leaf)) {
        throw 'No completion trace: generation may have failed before Undo.'
    }
    [IO.File]::ReadAllText($completion)
    "SNAPSHOT_FIX_TRIAL=$run"
} finally {
    # .NET keeps the test assembly loaded until this PowerShell process exits.
    # Preserve this isolated diagnostic trial rather than trying to delete an
    # in-use DLL in finally (never touch the user's model or installation).
}
