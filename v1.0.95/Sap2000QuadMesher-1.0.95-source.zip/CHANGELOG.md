# Changelog

Le modifiche rilevanti saranno documentate in questo file seguendo [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

**Storia di sviluppo:** tutte le versioni fino alla 1.0.78 inclusa erano build di sviluppo o di prova. Le precedenti pagine di download temporanee non costituivano una distribuzione agli utenti. La **1.0.79 e la prima beta destinata agli utenti**; le voci precedenti restano come storico tecnico.

## [Unreleased]

## [1.0.95] - 2026-10-02

- Keep the modeless plugin dialog in front of SAP2000, including after the immediate Generate refresh, while SAP2000 remains enabled for inspecting the preview mesh.
- Pass all 36 isolated SAP2000 atomic regressions on the 1.0.95 package, including FAST and standard insertion, multi-area seams, symmetry, framed openings, circular holes and immutable selected nodes. Verify the circular-floor dense-band mesh preview (1,956 shell elements) and FAST Undo against the unmodified source model.

## [1.0.94] - 2026-10-01 (build locale di prova)

- Refresh the SAP2000 viewport immediately after Generate so the preview mesh is visible before Apply. Keep the SAP2000 window enabled and open the plugin as an independent modeless taskbar window, allowing the user to switch between mesh inspection and Apply/Undo.

## [1.0.93] - 2026-10-01 (build locale di prova)

- Integrate the geometry-fitted dense global band for compatible multi-sector radial slabs, preserving original frames, exterior joints and conforming seams; fall back to the previous structured mesher when the guide fit fails. The original circular-floor SAP trial at 0.5 m and 25% tolerance imports 1,848 quads and 108 triangles (1,956 shells); FAST Undo restores the source model.
- Remember validated generation settings per user across plugin launches (including explicit lengths converted across model units); keep automated regression settings separate.
- Defer the SAP2000 view refresh until the dialog closes, and localize additional model, mesh and FAST error messages.
- Allow local installer replacement when an existing installation directory cannot be renamed because an unchanged PDF is open; preserve rollback and skip only byte-identical locked files. Include the new dense-band module in the corresponding-source archive.

## [1.0.92] - 2026-09-30

- Expose the automatically geometry-selected radial quad bands as a default-on dialog option, "Prefer structured quad bands in framed radial slabs" / "Preferisci fasce quad ordinate nelle solette radiali con telai". Unchecking it retains the prior mesher. The option is routed to the backend for every generation, without model-name or test-ID exceptions.
- Preserve the separate v1.0.91 comparison report outside the installable and source archives. All 36 atomic SAP2000 regressions pass with the option checked by default, with identical saved meshes and diagrams to v1.0.91. On the original circular slab, checking the option generates 1,823 shells (138 triangles), versus 2,439 shells (364 triangles) when unchecked; FAST Undo restores all original objects. Verify the same outputs using the installed build.

## [1.0.91] - 2026-09-30 (build comparativa locale, non pubblicata)

- Automatically select the structured radial-sector route by geometry: a horizontal annular sector, a selected outer chord, compatible radial sides and guide chains. Other framed polygons keep the existing Gmsh path. `SAP_QUAD_SECTOR_BLOCKS=0` disables the route for controlled comparisons without any file or test ID branches.
- Compare the existing 36-example SAP regression baseline with a separate run and store the graphical comparison outside the distributable archive; do not modify the public update manifest or installed v1.0.90 during the experiment.

## [1.0.90] - 2026-09-30 (build locale, non pubblicata)

- Add an explicit, default-zero maximum-edge tolerance percentage (0–50%) in the mesh dialog. It keeps the nominal mesh spacing unchanged while permitting the stated excess on newly generated edges; strict meshing between selected nodes disables the tolerance.
- Build topologically graded quadrilateral bands across compatible radial sectors and complete selected guide chains, with a local first collar where immutable opening edges exceed two nominal steps. Preserve frame coverage, fixed boundary stations, conformity and FAST Undo; the sector-block route was initially opt-in pending wider validation.
- On the isolated `Circular_Floor` selection at 500 mm with 25% tolerance, generate 1,685 quadrilaterals and 138 triangles (1,823 total); measure a maximum free edge of 615.6 mm below the explicit 625 mm limit, without local edge-splitting repairs. Retain the 120 original outer-circle stations and every selected hole station.

## [1.0.89] - 2026-09-29

- Restore polygon GUIDs correctly after FAST Undo: SAP2000 continuation rows must not replace the area's primary connectivity row during verification. Exercise the actual Undo action on `tt.sdb` (two triangles, a quadrilateral and a seven-sided polygon), on the triangle and polygon individually, and in standard COM mode; compare original area and joint identities after the rollback.
- Before each interactive mesh, offer an enabled-by-default numbered copy of the last saved `.sdb` in the same directory; preserve previous backups, fail before changing the model if the copy fails, and explain that unsaved changes must first be saved in SAP2000. Test two successive numbered copies on an isolated test model.
- Favor size-compliant, less over-refined Gmsh candidates when reducing a few remaining triangles would otherwise multiply shell count. On `tt` at a strict 1000 mm edge limit, reduce 1017 elements to 563 (17 triangles in both cases); the SAP2000 reference has 303 all-quadrilateral shells but a measured maximum edge of approximately 1184 mm.
- Indicate when the installed version is up to date and highlight an available update with a blinking, prominent download link. Network failures still leave a manual retry link.

## [1.0.88] - 2026-09-29

- Do not treat the coarse edges of an unselected coplanar shell fully contained in a selected null-property area as immutable shared seams. Such overlapping shells must remain untouched, while the selected null area can respect the requested mesh size in both directions. Actual neighboring seams remain constrained.
- Reproduced the defect on the pre-fix package: area 294 alone at 500 mm generated eight elongated quads with 2340 mm edges. The final v1.0.88 package generated 36 quads with maximum edge 455 mm and maximum aspect ratio 1.72; the structural shells 86 and 87 retained their original vertices and section `N.ParetiSp40`. The original SAP2000 model was not saved. All 36 atomic SAP2000 regressions passed with three parallel persistent instances after the fix; the rebuilt installable package passed its backend and installer checks and the specific 294 test.

## [1.0.87] - 2026-09-29

- Preserve actual joint segments from unselected neighboring triangles, quadrilaterals and polygons when meshing an area; on TEST02b, area 2 at 600 mm reuses all 16 SAP joints and shared-edge segments of its already meshed triangular neighbor.
- Import generated triangles through FAST without exhausting SAP2000's 20-error limit by repeating Joint3 in the Joint4 table field, which SAP2000 reads back as a three-node area. Keep exact diagnostic checks for pre-existing triangles and polygon continuation records.
- Add bounded parallel Gmsh candidate processes for constrained general polygons, with cancellation of the whole process tree, per-candidate and total time limits, boundary and quality checks. Default to the maximum available workers; allow 1 through the machine's logical CPU count, capped at runtime by the nine independent candidates and available memory. Gmsh remains CPU-based.
- Generate conforming 400 mm meshes of TEST02 areas 1 and 2 in FAST with regular, refined and no optional mode, preserving their shared edge. Confirm on reopened copies of TEST03 that areas 1 and 3 at 500 mm preserve the 300 unselected areas. All 36 atomic regressions passed sequentially in one monitored persistent SAP2000 instance; the new v1.0.87 report documents their times and an identical-geometry, one-worker versus maximum-worker backend comparison.

## [1.0.85] - 2026-09-28

- Accept only the expected SAP2000 blank-joint import diagnostics for pre-existing triangular areas and continuation rows of polygons in FAST table imports and restores. Match the original record and joint field exactly; errors in generated connectivity remain fatal. Include the relevant detailed log in unexpected FAST import failures.
- Reproduce the error on area 294 of a mixed-shell model at 600 mm, then verify general, regular and refined FAST meshes and preservation of its three triangles; verify a five-node polygon retained while another area is meshed. Mesh areas 294, 296, 298 and 74 successively on reopened copies without changing prior areas, with all new edges below 600 mm. All 36 atomic regressions passed using three persistent monitored SAP2000 instances.

## [1.0.84] - 2026-09-28

- Add `SapQuadTransitionPlugin` to the current user's SAP2000 27 Tools menu automatically after installation, retaining other plugin names and their order. Unhide an existing menu record instead of duplicating it; repeat installation remains idempotent.
- Update both SAP2000 plugin preference files using staged replacements with rollback on error. If preferences have not yet been initialized, explain how to add the menu entry manually after starting SAP2000.
- Confirm the menu appears in SAP2000 with a local v1.0.83 installer trial; verify normal, repeated, hidden and locked-preference scenarios on separate test profiles.

## [1.0.83] - 2026-09-28

- Preselect the existing FAST bulk-import option when the plugin dialog opens. Users can still turn FAST off to use the standard COM path.

## [1.0.82] - 2026-09-28

- Enable **Cancel generation / Annulla generazione** while meshing. Stop the owned Python/Gmsh backend promptly, or wait for the current indivisible SAP2000 API call to return, then undo imported COM/FAST objects and restore the original selection before allowing another attempt. Keep UI pumping limited to the existing backend wait and infrequent, time-gated checks when assembling large tables.
- Accept explicit `m`, `cm`, `mm`, `ft` and `in` in maximum-mesh-size and circular-hole-diameter inputs; bare values still use the current SAP2000 length unit. Show both options in bilingual tooltips and display the converted value before meshing.
- Verify cancellation during the backend, single-area FAST, multi-area FAST after import and standard COM insertion on separate SAP2000 copies. Check the five length units, implicit units and invalid values, and compare explicit-unit meshes to the same numeric settings.
- Run all 36 atomic integrations to PASS with three controlled persistent SAP2000 workers on the corrected code, without changing the historical development PDF.

## [1.0.81] - 2026-09-27

- Keep automatically refined seams conforming when **Prefer regular meshes** falls back to the general mesher for inclined surfaces or skew frames. Revalidate the selected-area shared edges before any FAST import.
- Allow a small corner-centered circular hole to preserve all prescribed boundary nodes: adapt the quarter O-grid radial layers when the hole diameter is much smaller than the requested maximum size. Verify the 0.03 m hole on four selected nTEST006 areas, 0.10 m maximum size and FAST.
- Verify nTEST026 with three intersecting areas, regular preference, 0.05 m maximum size and twelve holes of diameter 0.02 m. All 36 examples passed in a full regression with three controlled persistent SAP2000 instances; the independent small-hole nTEST006 check confirmed an empty 0.03 m opening and both reflection axes.

## [1.0.80] - 2026-09-27

- Generate all selected-area meshes in sequence while propagating shared-edge constraints, then use one FAST table import for their points, quadrilaterals and sections; preserve per-area loads, the full-selection preview and undo.
- Prevent Gmsh's global refinement from subdividing already-refined shared edges a second time. Verify coincident segments before importing: fixes non-conforming MODO plate/wall intersections in refined mode and the shared seams of four-area framed openings, including nTEST028 and nTEST036.
- Recheck regular MODO geometry and properties against v1.0.79, refined MODO, 3D perforated intersections, symmetric multi-area holes and FAST multi-area undo. The recorded timings are single development comparisons with another SAP2000 instance open, not performance guarantees.

## [1.0.79] - 2026-09-26

- First downloadable educational beta intended for users: demonstrate C# and Python/Gmsh integration with SAP2000 through a working quadrilateral mesher.
- Clarify development-only history and report provenance; simplify authorship/licensing explanations without attributing any rights in third-party software to the author.
- Preserve source archives at stable public URLs while retaining only the newest binary release.

## [1.0.78] - 2026-09-26

- License the original code under GPL-2.0-or-later, with a narrowly scoped additional permission for the separately installed SAP2000 API; preserve separate third-party licenses and elect the GPLv3 option for the combined binary backend.
- Publish matching source archives for the C# plugin, installer, Python backend and Gmsh 4.15.2 alongside the binary release.
- Validate that the bundled Gmsh DLL and Python binding match the official Windows wheel before packaging.

## [1.0.77] - 2026-09-26

- Fix the CMD installer launcher: derive the package directory from the executable instead of passing a quoted path ending in `\`, which .NET interprets as an invalid path.

## [1.0.76] - 2026-09-26

- Restore the single per-user installation directory name `SAP2000QuadMesher` and retain staged replacement/rollback.
- Center the update link in the footer and add a bilingual "Verified examples" link above the language selector to the bundled atomic-report PDF.
- Label the historical PDF with the tested plugin version (0.0.57) and clarify that its durations cover complete SAP2000 regressions, not current mesh-generation speed.

## [1.0.75] - 2026-09-26

- Install from the extracted release into `%LOCALAPPDATA%\Programs\SQM_Plugin`, replacing the previous installation only after validating the new package; downloaded files are not the runtime location.
- Bundle a native .NET installer invoked by `install_plugin.cmd` without PowerShell execution-policy bypass; preserve per-user COM registration and migrate the former installation directory after success.

## [1.0.74] - 2026-09-26

- Development build introducing the `MAJOR.MINOR.BUILD` scheme; carries forward the tested regular-mesh and TLS update fixes from 0.5.11.
- Future internal builds increment the third component; important features increment the second, radical changes the first.

## [0.5.11] - 2026-09-26

- Move the update link into the right-hand footer beside the plugin version.
- Negotiate TLS 1.2 explicitly for update checks when hosted inside SAP2000.

## [0.5.10] - 2026-09-26

- Propagate generated plate intersection edges to subsequent selected areas so the regular FAST mesh of MODO with a 30 mm maximum size and 30 mm holes shares nodes and edges with adjacent vertical shells.
- Link available updates directly to the public release ZIP, with instructions to extract it and run the bundled installer after closing SAP2000; validate the versioned download URL from the manifest.

## [0.5.9] - 2026-09-25

- Open the options dialog without selected areas, with generation and dependent options disabled until an area is selected and the dialog reopened.
- Replace the CSi Italia footer text with the bundled logo, retaining the website link.
- Check a GitHub-hosted version manifest asynchronously and offer a release link when a newer version is available.
- Preserve the user's SAP2000 plugin menu during parallel showcase runs.

## [0.0.59] - 2026-09-25

- Generate O-grid candidates before expensive clipped-hole fallbacks; run the fallback only if no O-grid candidate passes existing quality checks.
- On MODO with ten holes and three frame constraints, the backend fell from 250.3 s to 15.1 s (94% faster), while all 7,312 quads, section assignments, and pixels of the rendered mesh remained identical.
- Added optional per-process backend timing and an automated three-instance MODO showcase with before/after SVGs and a dedicated DOCX/PDF report.

## [0.0.58] - 2026-09-25

- Convert the default maximum mesh size (0.1 m) and O-grid hole diameter (0.05 m) to the active SAP2000 length unit when opening the dialog.
- Display elapsed generation time alongside the number of completed area elements.

## [0.0.57] - 2026-09-25

- Added a refined all-quad circular-hole fallback when a structured O-grid cannot fit between frame or incident-shell constraints.
- Preserved exact circular-boundary nodes and required every frame/incident constraint segment to coincide with shell edges in the fallback mesh.
- Clipped selected frames to the union of selected areas, allowing constraints to extend beyond the remeshed region.
- Fixed frame coverage across shared area boundaries by partitioning each constraint against the complete selected-area union.
- Added focused verification for a 0.20 m circular hole at a four-area intersection with four skew frame constraints.

## [0.0.56] - 2026-09-25

- Reworked regular unequal-edge transitions to create a large Cartesian region aligned with the rectangular area edges.
- Confined unavoidable topology changes to the smallest transition band that satisfies edge-length, aspect, skew, and Jacobian limits.
- Strengthened nTEST034 to require at least 80 percent of internal edges to align with the two principal area axes.

## [0.0.55] - 2026-09-25

- Added runtime English/Italian localization for the complete plugin interface, including progress, validation, and quality reporting.
- Renamed the post-generation close action to Apply/Applica to clarify when the generated mesh is committed.
- Added regular horizontal-chain alignment to exact-symmetry transitions with unequal immutable opposite-edge discretizations.
- Extended nTEST034 to combine regular alignment, exact symmetry, and preservation of all 46 selected edge nodes.

## [0.0.54] - 2026-09-25

### Added

- `nTEST034` verifies that exact symmetry preserves the immutable 11-node and 35-node opposite-edge discretizations.
- Symmetric transition meshes are geometrically revalidated before insertion into SAP2000.

### Fixed

- Exact-symmetry generation for rectangular opposite-edge transitions no longer inserts midpoint nodes between explicitly selected boundary nodes.

## [0.0.53] - 2026-09-25

### Added

- The options and mesh-quality dialogs now use the report visual language, with a white canvas, Segoe UI typography, navy headers, blue actions, and light borders.
- Both dialogs include a footer link to CSi Italia and the current plugin version.
- Atomic regressions now compare actual SAP point names and segment sets across the shared edges of four-area meshes in general, stress-refined FAST, and standard COM modes.

### Fixed

- Frame-constrained macro areas no longer apply geometry-dependent extra global refinement that could create hanging nodes on only one side of a shared edge.
- Standard COM insertion now explicitly reuses the common coordinate index, matching FAST insertion and preventing coincident duplicate joints.

## [0.0.52] - 2026-09-25

### Fixed

- Multi-area exact-symmetry O-grids are no longer rejected by the regular-mesh guard.

## [0.0.51] - 2026-09-25

### Fixed

- Atomic regression startup now attaches by SAP2000 process and rejects launcher instances without a valid model.
- Atomic batches can skip report regeneration while the Word report is open.

## [0.0.50] - 2026-09-25

### Fixed

- Restored full-solution compilation by declaring the WinForms and drawing references in the duplicate FAST test project.

## [0.0.49] - 2026-09-25

### Changed

- Final validation build for the combined TEST10 and TEST11 symmetry, refinement, frame-opening, and circular O-grid workflows.

## [0.0.48] - 2026-09-25

### Added

- Circular O-grid holes can coexist with selected frame and shell-edge mesh constraints.
- Double-symmetric quarter-domain O-grid generation mirrors holes, frame constraints, and protected opening edges.
- The framed region can independently remain meshed or be removed through the selected opening group.

## [0.0.47] - 2026-09-25

### Changed

- Selecting regular meshing disables stress refinement, and selecting stress refinement disables regular meshing.

## [0.0.46] - 2026-09-25

### Fixed

- Persisted the mandatory combined-axis selection whenever two principal symmetry axes are available.

## [0.0.45] - 2026-09-25

### Changed

- Enabling symmetry on geometry with two valid principal axes now always enforces the combined double-axis mode.

## [0.0.44] - 2026-09-25

### Fixed

- The options dialog now keeps a dedicated reference to the double-axis selection instead of relying on ComboBox item casting.

## [0.0.43] - 2026-09-25

### Fixed

- Preserved the explicit double-symmetry selection mapping in the compiled plugin source.

## [0.0.42] - 2026-09-25

### Fixed

- The selected double-symmetry UI entry now always serializes both principal axes to the mesher input.

## [0.0.41] - 2026-09-25

### Fixed

- Double-axis symmetry with stress refinement for the `TEST10` framed opening.
- Exact-symmetry requests no longer fall back silently to a non-symmetric mesh.

## [0.0.40] - 2026-09-25

### Added

- Exact symmetry for geometries with symmetric frame constraints.
- Deterministic regular rectangular meshes invariant between single-area and 2x2 source subdivisions.
- Double symmetry about both principal axes when both axes are detected.

### Changed

- Regular-mesh preference and local refinement are mutually exclusive.

## [0.0.39] - 2026-09-24

### Added

- Exact-symmetric circular O-grids for holes centered on the reflection axis.
- Automated SAP2000 coverage for `TEST06`, including constrained-edge preservation and circular-boundary checks.

### Fixed

- Full-quad generation for small axis-centered holes using the default `0.05` diameter.

## [0.0.38] - 2026-09-24

### Added

- Many-to-many conforming constraints for complete and partial shell edges crossing one or more selected areas.
- Graded local refinement around automatic shell-edge constraints using Gmsh distance and threshold fields.
- Hole generation for closed regions bounded by selected frames, incident shell edges or both.
- Automated SAP2000 coverage for the multi-area `TEST02` and `TEST03` models.

### Changed

- Constraint curves are clipped in each host plane, split at crossings and propagated back to every source edge.
- FAST uses short alphanumeric temporary labels, scale-aware point reuse and targeted object rollback.
- Known SAP2000 continuation-row diagnostics for polygonal areas are validated without hiding unrelated import errors.
- Test automation always closes SAP2000 after success, failure or timeout.

## [0.0.37] - 2026-09-23

### Added

- Maximum-size label using only the SAP2000 length unit active when the plugin opens.
- Final area-element count in the main plugin window.

### Changed

- Entire plugin UI, progress text, quality report and error messages translated to English.
- Undo restores the original object selection and returns the dialog to a reusable ready state.
- Geometry contexts are rebuilt for every retry so changed options are applied from a clean state.

## [0.0.36] - 2026-09-23

### Added

- Runtime autonomo Python 3.12 e Gmsh 4.15.2 prodotto con PyInstaller.
- Installer e disinstaller COM per-utente senza privilegi amministrativi.
- Smoke test automatici dei tre backend durante il packaging.
- Licenze Python/Gmsh e sorgente Gmsh pubblicati con la release.

### Changed

- Il plugin usa esclusivamente il backend incluso e non dipende piu dal `PATH`.
- `AssemblyVersion` COM stabilizzata a `1.0.0.0` per evitare registrazioni storiche concorrenti.

### Repository

- Documentazione dello stato tecnico, dello sviluppo e del processo di rilascio.
- Configurazione portabile del percorso dell'API SAP2000.
- Dichiarazione riproducibile della dipendenza Python/Gmsh.
- Regole Git LFS per le fixture SAP2000.
- Script iniziale per creare pacchetti di release controllati.
- Licenza open source MIT.

## [0.0.35] - 2026-09-23

### Added

- Mesh quad-dominant generale per poligoni piani.
- Transizioni rettangolari automatiche e simmetriche.
- Vincoli per point object e frame interni, inclusa generazione di aperture.
- Elaborazione multi-area con congruenza di bordi e intersezioni.
- Inserimento standard COM e FAST tramite tabelle SAP2000.
- Anteprima e rollback transazionale.
- Trasferimento delle principali proprieta e dei carichi area.
- Report interattivo della qualita geometrica.
