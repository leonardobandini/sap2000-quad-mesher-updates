# SPDX-License-Identifier: GPL-2.0-or-later
# Verify that the ZIP is self-contained after extraction, without repository paths.
param([string]$Zip = (Join-Path (Split-Path -Parent $PSScriptRoot) 'artifacts\Sap2000QuadMesher-2.0.30.zip'))
$ErrorActionPreference = 'Stop'
$tempParent = Join-Path $env:TEMP 'opencode'
if (-not (Test-Path -LiteralPath $tempParent -PathType Container)) { throw 'Temporary parent missing.' }
$trial = Join-Path $tempParent ('sqm-v2-standalone-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $trial | Out-Null
try {
    $unpacked = Join-Path $trial 'extracted'
    Expand-Archive -LiteralPath $Zip -DestinationPath $unpacked
    $installer = Join-Path $unpacked 'SQMPluginInstaller.exe'
    & $installer verify $unpacked
    if ($LASTEXITCODE -ne 0) { throw 'Extracted installer failed verification.' }
    & (Join-Path $unpacked 'install_plugin.cmd') verify
    if ($LASTEXITCODE -ne 0) { throw 'Extracted CMD launcher failed verification.' }
    $destination = Join-Path $trial 'installed'
    & $installer test-install $destination
    if ($LASTEXITCODE -ne 0) { throw 'Standalone test installation failed.' }
    & $installer test-install $destination
    if ($LASTEXITCODE -ne 0) { throw 'Standalone replacement failed.' }
    $dll = Join-Path $destination 'SapQuadTransitionPlugin.dll'
    if ((Get-Item $dll).VersionInfo.FileVersion -ne '2.0.30.0' -or
        -not (Test-Path (Join-Path $destination 'docs\help-gmsh-v2\assets\nTEST027-ogrid-result.svg'))) {
        throw 'Installed version or V2 help example missing.'
    }
    "V2_STANDALONE=PASS VERSION=$((Get-Item $dll).VersionInfo.FileVersion)"
} finally {
    if (Test-Path -LiteralPath $trial) { Remove-Item -LiteralPath $trial -Recurse -Force }
}
