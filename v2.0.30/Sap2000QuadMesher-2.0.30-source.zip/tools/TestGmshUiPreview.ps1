# Validate the single shipped V2 UI, saved preview controls and reset behavior.
param([string]$Plugin = (Join-Path (Split-Path -Parent $PSScriptRoot) 'SapQuadTransitionPlugin\bin\Release\net48\SapQuadTransitionPlugin.dll'))
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -Path 'C:\Program Files\Computers and Structures\SAP2000 27\CSiAPIv1.dll'
$oldSize = $env:SAP_QUAD_ATOMIC_SIZE
$oldSettings = $env:SAP_GMSH_V2_SETTINGS_PATH
$env:SAP_QUAD_ATOMIC_SIZE = '0.55m'
$env:SAP_GMSH_V2_SETTINGS_PATH = Join-Path $env:TEMP ('opencode\sqm-v2-ui-' + [Guid]::NewGuid().ToString('N') + '.json')
try {
    $assembly = [Reflection.Assembly]::LoadFrom((Resolve-Path -LiteralPath $Plugin).Path)
    $type = $assembly.GetType('SapQuadTransitionPlugin.cPlugin+MeshOptionsDialog', $true)
    $axis = $assembly.GetType('SapQuadTransitionPlugin.cPlugin+SymmetryAxis', $true)
    $ctor = @($type.GetConstructors([Reflection.BindingFlags]'Instance,Public,NonPublic') |
        Where-Object { $_.GetParameters().Count -eq 6 })[0]
    $flags = [Reflection.BindingFlags]'Instance,NonPublic'
    function Field($dialog, $name) { $type.GetField($name, $flags).GetValue($dialog) }
    function Assert($condition, $message) { if (-not $condition) { throw $message } }
    $dialog = $ctor.Invoke([object[]]@('mm', $true, [string[]]@('BOLT'),
        [string[]]@('ALL'), [Array]::CreateInstance($axis, 0), $true))
    try {
        $dialog.Show()
        [Windows.Forms.Application]::DoEvents()
        $tabs = Field $dialog 'gmshPreviewTabs'
        $page = Field $dialog 'gmshPreviewEmptyTab'
        $panel = Field $dialog 'gmshPreviewOptions'
        $panelType = $panel.GetType()
        function Preview($name) { $panelType.GetField($name, $flags).GetValue($panel) }
        Assert ($type.GetField('gmshTabs', $flags) -eq $null -and
            $type.GetField('gmshOptionTree', $flags) -eq $null -and
            $type.GetField('gmshStructureTab', $flags) -eq $null -and
            $tabs.Visible -and $tabs.TabPages.Count -eq 4 -and
            (@($tabs.TabPages | ForEach-Object Text) -join ',') -eq
            'Gmsh,Additional Options,Gmsh JSON,Transfer Options') 'Classic interface is still present or the four tabs changed.'
        $additional = Field $dialog 'gmshHolesTab'
        $tabs.SelectedTab = $additional
        $additional.ScrollControlIntoView((Field $dialog 'gmshSymmetryHint'))
        [Windows.Forms.Application]::DoEvents()
        $viewport = $additional.RectangleToScreen($additional.ClientRectangle)
        Assert ($additional.AutoScroll -and $additional.VerticalScroll.Visible -and
            -not $additional.HorizontalScroll.Visible -and
            $viewport.Contains((Field $dialog 'symmetryAxis').RectangleToScreen(
                (Field $dialog 'symmetryAxis').ClientRectangle))) 'Additional Options clips the symmetry controls.'
        $tabs.SelectedTab = $page
        $grid = Preview 'grid'
        $groups = @('general','generation','recombination','optimization') | ForEach-Object { Preview $_ }
        Assert ($grid.ColumnCount -eq 1 -and $groups.Count -eq 4 -and
            -not $page.Controls[0].VerticalScroll.Visible) 'Gmsh controls do not fit the single-column layout.'
        foreach ($i in 0..3) { Assert ($grid.GetPositionFromControl($groups[$i]).Row -eq $i) "Group $i is out of order." }
        $algorithm = Preview 'algorithm'
        Assert ($algorithm.Items.Count -eq 7 -and $algorithm.SelectedIndex -eq 5 -and
            -not @($algorithm.Items | Where-Object { $_ -match '^9\b' }).Count) 'Unsupported algorithm is selectable.'
        $maxSize = Preview 'maxSize'
        $minSize = Preview 'minSize'
        $maxSize.Text = '40mm'; $minSize.Text = '5mm'
        $algorithm.SelectedIndex = 0
        (Preview 'switchOnFailure').Checked = $false
        (Preview 'quality').Text = '0.6'
        (Field $dialog 'gmshExtra').Text = 'Mesh.RandomFactor = 0.123'
        (Field $dialog 'gmshOGrid').Checked = $true
        (Field $dialog 'generateCircularHoles').Checked = $true
        (Field $dialog 'fastMode').Checked = $false
        (Field $dialog 'createBackup').Checked = $false
        $reset = Field $dialog 'gmshResetDefault'
        $commands = @((Field $dialog 'generate'), (Field $dialog 'details'), (Field $dialog 'undo'), $reset)
        Assert ($reset.Parent -eq $dialog -and
            @($commands | Select-Object -ExpandProperty Width | Select-Object -Unique).Count -eq 1 -and
            @($commands | Select-Object -ExpandProperty Top | Select-Object -Unique).Count -eq 1 -and
            $reset.Right -le $dialog.ClientSize.Width) 'Four bottom commands are not aligned.'
        $reset.PerformClick()
        $settings = $dialog.GmshSettingsJson | ConvertFrom-Json
        Assert ($maxSize.Text -eq '40mm' -and $minSize.Text -eq '5mm' -and
            $settings.previewMode -and $settings.algorithm -eq 8 -and $settings.optimize -and
            $settings.options.'Mesh.MeshSizeMin' -eq 5 -and
            $settings.options.'Mesh.RecombineMinimumQuality' -eq .01 -and
            $settings.options.'Mesh.AlgorithmSwitchOnFailure' -eq 1 -and
            -not $settings.options.PSObject.Properties['Mesh.RandomFactor'] -and
            -not $settings.oGrid -and -not $settings.preserveSelectedEdges -and
            (Field $dialog 'fastMode').Checked -and (Field $dialog 'createBackup').Checked) 'Reset did not restore defaults or preserve sizes.'
        (Field $dialog 'generate').PerformClick()
        Assert ($dialog.StartRequested -and [Math]::Abs($dialog.MaxSize - 40) -lt 1e-9) 'Generate did not read the visible maximum.'
        (Field $dialog 'language').SelectedIndex = 1
        [Windows.Forms.Application]::DoEvents()
        Assert ((@($tabs.TabPages | ForEach-Object Text) -join ',') -eq
            'Gmsh,Opzioni aggiuntive,JSON Gmsh,Opzioni di trasferimento' -and
            $reset.Text -eq 'Ripristina default') 'Italian controls changed.'
        Write-Host 'V2_UI=PASS CLASSIC_ABSENT=PASS FOUR_EQUAL_COMMANDS=PASS RESET_KEEP_SIZES=PASS EN_IT_LAYOUT=PASS'
    } finally { $dialog.Close(); $dialog.Dispose() }
} finally {
    $env:SAP_QUAD_ATOMIC_SIZE = $oldSize
    $env:SAP_GMSH_V2_SETTINGS_PATH = $oldSettings
}
