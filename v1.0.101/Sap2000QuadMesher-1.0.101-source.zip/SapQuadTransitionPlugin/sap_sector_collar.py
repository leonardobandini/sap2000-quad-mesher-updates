"""Constrained first ring for long, immutable opening segments in framed sectors.

The original long segment is the outside edge of a single trapezoid. Its other
three edges are at most the requested size; Gmsh meshes the remainder against
those three edges. No selected boundary vertex is moved or subdivided.
"""
import csv
import math
import sys
from collections import Counter
from pathlib import Path

import sap_general_polygon_mesher as polygon


def point_key(point):
    return tuple(round(value, 8) for value in point)


def clipped_sector(corners, edges, locked, size):
    order = sorted(corners)
    area = sum(corners[i][0] * corners[order[(k + 1) % len(order)]][1] -
               corners[order[(k + 1) % len(order)]][0] * corners[i][1]
               for k, i in enumerate(order))
    orientation = 1 if area > 0 else -1
    new_corners, new_edges, new_locked, collars = {}, {}, set(), []

    def append(point, next_point, stations, immutable):
        index = len(new_corners) + 1
        new_corners[index] = point
        new_edges[index] = stations
        if immutable:
            new_locked.add(index)

    for index in order:
        stations = edges[index]
        a, b = stations[0][1], stations[-1][1]
        length = math.dist(a, b)
        # The ordinary first row can bridge moderately long opening edges;
        # above 1.8 steps the free edges beside them become overlong and
        # need a local collar without splitting the selected interval.
        if index not in locked or len(stations) != 2 or length <= 1.8 * size + 1e-8:
            append(a, b, stations, index in locked)
            continue
        # For the circular-floor opening L=1.172 m and h=.5 m, an inward
        # shift of ~.37 m and normal offset of ~.30 m keep all three new
        # edges below h, while the 1.172 m selected edge stays untouched.
        shift = (length - .85 * size) / 2
        offset = .72 * math.sqrt(size * size - shift * shift)
        if shift >= size or offset <= 0:
            raise ValueError('Locked interval is too long for a one-cell collar')
        tangent = ((b[0] - a[0]) / length, (b[1] - a[1]) / length)
        normal = (-orientation * tangent[1], orientation * tangent[0])
        near_a = (a[0] + shift * tangent[0] + offset * normal[0],
                  a[1] + shift * tangent[1] + offset * normal[1], a[2])
        near_b = (b[0] - shift * tangent[0] + offset * normal[0],
                  b[1] - shift * tangent[1] + offset * normal[1], b[2])
        append(a, near_a, [(0, a), (1, near_a)], True)
        append(near_a, near_b, [(0, near_a), (1, near_b)], True)
        append(near_b, b, [(0, near_b), (1, b)], True)
        collars.append((a, b, near_b, near_a))
    return new_corners, new_edges, new_locked, collars


def write_clipped(source, destination, size):
    corners, edges, interior, frames, holes, symmetry, symmetry2, _, _, _, _, locked = polygon.read_input(source)
    if holes or symmetry or symmetry2 or not frames:
        raise ValueError('This block collar requires a framed sector without holes')
    new_corners, new_edges, new_locked, collars = clipped_sector(corners, edges, locked, size)
    with Path(destination).open('w', newline='', encoding='ascii') as stream:
        writer = csv.writer(stream)
        writer.writerow(['AREA', 'clipped-sector', 'slab'])
        for index, point in new_corners.items():
            writer.writerow(['CORNER', index, 'CLIP', 0, *point])
        for index, stations in new_edges.items():
            if index in new_locked:
                writer.writerow(['LOCK_EDGE', index])
            for t, point in stations:
                writer.writerow(['EDGE', index, 'CLIP', t, *point])
        for index, (a, b, fixed, opening) in enumerate(frames, 1):
            writer.writerow(['FRAME', index, 'GUIDE', 0, *a, *b, int(fixed), int(opening)])
        for point in interior:
            writer.writerow(['INTERIOR', 'GUIDE', 0, 0, *point])
    return collars


def stitch(source, destination, collars):
    nodes, elements = {}, []
    with Path(source).open(newline='', encoding='ascii') as stream:
        for row in csv.reader(stream):
            if row[0] == 'N':
                nodes[int(row[1])] = tuple(map(float, row[2:5]))
            elif row[0] == 'E':
                elements.append(tuple(map(int, row[1:])))
    tags = {point_key(point): tag for tag, point in nodes.items()}
    for collar in collars:
        element = []
        for point in collar:
            key = point_key(point)
            if key not in tags:
                tags[key] = max(nodes) + 1
                nodes[tags[key]] = point
            element.append(tags[key])
        elements.append(tuple(element))
    with Path(destination).open('w', newline='', encoding='ascii') as stream:
        writer = csv.writer(stream)
        for tag, point in nodes.items():
            writer.writerow(['N', tag, *(format(value, '.17g') for value in point)])
        for element in elements:
            writer.writerow(['E', *element])
    return nodes, elements


def validate(boundary, nodes, elements, size):
    """Reject nonconforming candidates before they reach SAP's import tables."""
    corners, edges, interior, frames, _, _, _, _, _, _, _, locked = polygon.read_input(boundary)
    expected = Counter(tuple(sorted((point_key(a[1]), point_key(b[1]))))
                       for stations in edges.values() for a, b in zip(stations, stations[1:]))
    prescribed = ({point_key(point) for stations in edges.values() for _, point in stations} |
                  {point_key(point) for point in interior})
    actual_nodes = {point_key(point) for point in nodes.values()}
    if prescribed - actual_nodes:
        raise RuntimeError('Selected contour vertices were omitted')
    protected = {tuple(sorted((point_key(a[1]), point_key(b[1]))))
                 for index, stations in edges.items() if index in locked
                 for a, b in zip(stations, stations[1:])}
    counts = Counter(tuple(sorted((point_key(nodes[a]), point_key(nodes[b]))))
                     for element in elements for a, b in zip(element, element[1:] + element[:1]))
    if protected - counts.keys() or any(count > 2 for count in counts.values()):
        raise RuntimeError('Nonconforming or subdivided locked sector edge')
    free = [math.dist(a, b) for a, b in counts if (a, b) not in protected]
    if not free or max(free) > size + 1e-6:
        raise RuntimeError(f'Unprotected edge exceeds size {size}: {max(free):.6g}')
    original_area = .5 * sum(corners[i][0] * corners[i % len(corners) + 1][1] -
                             corners[i % len(corners) + 1][0] * corners[i][1] for i in corners)
    mesh_area = 0
    for element in elements:
        points = [nodes[tag] for tag in element]
        signed = .5 * sum(a[0]*b[1]-b[0]*a[1] for a, b in zip(points, points[1:] + points[:1]))
        if signed * original_area <= 1e-8:
            raise RuntimeError('Inverted or degenerate sector element')
        mesh_area += signed
    if abs(mesh_area - original_area) > abs(original_area) * 1e-5:
        raise RuntimeError('Sector element area differs from original polygon')
    exterior = {edge for edge, owners in counts.items() if owners == 1}
    for edge in exterior:
        if not any(all(polygon.point_segment_distance(point, *source) < 1e-6 for point in edge)
                   for source in expected):
            raise RuntimeError('Sector has an exposed edge off the original contour')
    for a, b, _, _ in frames:
        length = math.dist(a, b)
        intervals = []
        for p, q in counts:
            if (polygon.point_segment_distance(p, a, b) > 1e-6 or
                    polygon.point_segment_distance(q, a, b) > 1e-6):
                continue
            t = sorted((sum((v[i] - a[i]) * (b[i] - a[i]) for i in range(3)) / length**2
                        for v in (p, q)))
            if t[0] >= -1e-6 and t[1] <= 1 + 1e-6:
                intervals.append(t)
        covered = 0
        for low, high in sorted(intervals):
            if low > covered + 1e-6:
                break
            covered = max(covered, high)
        if covered < 1 - 1e-6:
            raise RuntimeError('Selected frame is not represented by mesh edges')
    return len(elements), max(free)


def generate(boundary, output, size=.5):
    corners, edges, interior, frames, holes, symmetry, symmetry2, _, _, _, _, locked = polygon.read_input(boundary)
    if holes or symmetry or symmetry2 or not frames:
        raise ValueError('A framed planar sector is required')
    corners, edges, locked, collars = clipped_sector(corners, edges, locked, size)
    fixed = {tuple(sorted((point_key(a[1]), point_key(b[1]))))
             for index, stations in edges.items() if index in locked
             for a, b in zip(stations, stations[1:])}
    best = None
    for algorithm in (5, 8, 6):
        for factor in (.8, .7, .6, .5, .4, .35):
            try:
                nodes, quads, triangles, _ = polygon.generate_with_frames(
                    corners, edges, interior, frames, size, factor,
                    algorithm=algorithm, locked_edges=locked)
                present = {tuple(sorted((point_key(nodes[a]), point_key(nodes[b]))))
                           for element in quads + triangles
                           for a, b in zip(element, element[1:] + element[:1])}
                if fixed - present:
                    continue
                free = [math.dist(a, b) for a, b in present if (a, b) not in fixed]
                if max(free) > size + 1e-6:
                    print(f'collar alg={algorithm} factor={factor} max_free={max(free):.4f}', flush=True)
                    continue
                # The collars are sewn to the three cut edges, and retain
                # the fourth (original, unbroken) boundary edge.
                by_coordinate = {point_key(point): tag for tag, point in nodes.items()}
                for collar in collars:
                    quads.append(tuple(by_coordinate.setdefault(point_key(point), len(nodes) + 1)
                                       for point in collar))
                    for point in collar:
                        tag = by_coordinate[point_key(point)]
                        nodes.setdefault(tag, point)
                result = (len(quads) + len(triangles), len(triangles), algorithm, factor, nodes, quads, triangles)
                if best is None or result[:2] < best[:2]:
                    best = result
            except Exception as error:
                print(f'collar alg={algorithm} factor={factor}: {error}', flush=True)
    if best is None:
        raise RuntimeError('No collar candidate satisfies the free-edge size limit')
    _, _, algorithm, factor, nodes, quads, triangles = best
    with Path(output).open('w', newline='', encoding='ascii') as stream:
        writer = csv.writer(stream)
        for tag, point in nodes.items():
            writer.writerow(['N', tag, *(format(value, '.17g') for value in point)])
        for element in quads + triangles:
            writer.writerow(['E', *element])
    print(f'collar result: {len(quads)} quads {len(triangles)} triangles; '
          f'algorithm={algorithm} factor={factor} collars={len(collars)}', flush=True)


if __name__ == '__main__':
    generate(Path(sys.argv[1]), Path(sys.argv[2]), float(sys.argv[3]) if len(sys.argv) > 3 else .5)
