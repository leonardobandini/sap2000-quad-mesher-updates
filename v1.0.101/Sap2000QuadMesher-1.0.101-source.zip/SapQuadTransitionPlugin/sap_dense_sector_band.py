"""Complete a tapered sector's selected transverse guide with an internal band.

The input is a single sector. Geometry, not the area label or model name,
determines the similarity between the existing cross-section and main ring.
"""
import csv
import math
import os
from pathlib import Path

import sap_sector_blocks as blocks
import sap_general_polygon_mesher as polygon


def side_interval(side, point, maximum):
    """Locate a guide point strictly inside an existing radial-side interval."""
    if min(math.dist(point, station) for station in side) > maximum * .5:
        return None
    for index, (first, second) in enumerate(zip(side, side[1:])):
        direction = tuple(second[k] - first[k] for k in range(3))
        length2 = sum(value * value for value in direction)
        if length2 < 1e-12:
            continue
        fraction = sum((point[k] - first[k]) * direction[k] for k in range(3)) / length2
        projection = tuple(first[k] + fraction * direction[k] for k in range(3))
        if 1e-7 < fraction < 1 - 1e-7 and math.dist(point, projection) < maximum * 1e-7:
            return index, fraction
    return None


def shared_guide(folder, maximum):
    """Fit the complete/partial transverse guides of a selection together."""
    information = []
    for path in Path(folder).glob('area-*-boundary.csv'):
        if not blocks.applicable(path, maximum, extra_rows=4):
            return None
        inner, ring, _, side0, side1, _, _, extras, complete = blocks.read_sector(path, maximum, verbose=False)
        information.append((inner, ring, (side0, side1), extras, complete))
    if len(information) < 2:
        return None
    seeds = []
    for _, ring, sides, extras, complete in information:
        if len(complete) > 1 and extras:
            guide = complete[0]
            seeds.extend((blocks.polyline(ring, i/(len(guide)-1)), point)
                         for i, point in enumerate(guide))
    if len(seeds) < 2:
        for _, ring, sides, extras, complete in information:
            for point in {p for a, b, _, _ in extras for p in (a, b)}:
                for ring_end, side in zip((ring[0], ring[-1]), sides):
                    if any(math.dist(point, x) < 1e-7 for x in side):
                        seeds.append((ring_end, point))
    if len(seeds) < 3:
        return None

    def fit(pairs):
        px = sum(p[0][0] for p in pairs)/len(pairs)
        py = sum(p[0][1] for p in pairs)/len(pairs)
        qx = sum(p[1][0] for p in pairs)/len(pairs)
        qy = sum(p[1][1] for p in pairs)/len(pairs)
        denominator = sum((p[0][0]-px)**2+(p[0][1]-py)**2 for p in pairs)
        if denominator < 1e-10:
            return None
        a = sum((p[0][0]-px)*(p[1][0]-qx)+(p[0][1]-py)*(p[1][1]-qy) for p in pairs)/denominator
        b = sum((p[0][0]-px)*(p[1][1]-qy)-(p[0][1]-py)*(p[1][0]-qx) for p in pairs)/denominator
        return lambda p: (qx+a*(p[0]-px)-b*(p[1]-py),
                          qy+b*(p[0]-px)+a*(p[1]-py), p[2])

    preliminary = fit(seeds)
    if preliminary is None:
        return None
    pairs = {}
    rows = []
    for _, ring, sides, extras, complete in information:
        for point in {p for a, b, _, _ in extras for p in (a, b)}:
            index = min(range(len(ring)), key=lambda i: math.dist(point, preliminary(ring[i])))
            pairs[tuple(round(v, 8) for v in point)] = (ring[index], point)
            for side in sides:
                rows.extend(i for i, x in enumerate(side) if math.dist(x, point) < 1e-7)
    if len(pairs) < 3 or len(set(rows)) != 1:
        return None
    mapped = fit(list(pairs.values()))
    if mapped is None or max(math.dist(mapped(p), q) for p, q in pairs.values()) > maximum*.08:
        return None
    # One sector's guide may fit while neighboring radial sides have different
    # stations. Never mix a dense candidate with a Gmsh fallback on its seam.
    endpoint_errors = [(min(math.dist(mapped(ring[0]), station) for station in sides[0]),
                        min(math.dist(mapped(ring[-1]), station) for station in sides[1]))
                       for _, ring, sides, _, _ in information]
    if any(error > maximum*.08 and side_interval(side, mapped(point), maximum) is None
           for (_, ring, sides, _, _), errors in zip(information, endpoint_errors)
           for point, side, error in zip((ring[0], ring[-1]), sides, errors)):
        return None
    row = rows[0]
    if any(row < 2 or row >= min(len(side) for side in sides)-1 for _, _, sides, _, _ in information):
        return None
    # A selected opening with only two stations may need more radial growth
    # rows than the first guide provides. Add the same stations to every
    # sector so neighboring seams remain conforming.
    additions = max(1, max((len(ring) - len(inner) + 1) // 2 - row
                           for inner, ring, _, _, _ in information))
    if additions > 4:
        return None
    # Four extra rows beside an immutable opening interval longer than the
    # requested size can create narrow, highly skewed cells. Prefer the
    # established Gmsh route in this geometry.
    if additions > 3 and any(math.dist(first, second) > maximum * 1.001
                             for inner, _, _, _, _ in information
                             for first, second in zip(inner, inner[1:])):
        return None
    return mapped, row, additions


def prepare(source, destination, maximum):
    def reject(reason):
        if os.environ.get('SAP_QUAD_DEBUG_DENSE'):
            print(f'Dense band {Path(source).name}: {reason}', flush=True)
        return False

    inner, ring, _, side0, side1, _, _, extras, complete = blocks.read_sector(source, maximum, verbose=False)
    if len(ring) < 3 or len(inner) < 2:
        return reject('missing inner or ring stations')
    shared = (shared_guide(os.environ['SAP_QUAD_DENSE_BOUNDARIES'], maximum)
              if os.environ.get('SAP_QUAD_DENSE_BOUNDARIES') else None)
    if os.environ.get('SAP_QUAD_DENSE_BOUNDARIES') and shared is None:
        return reject('selection-wide guide does not fit')
    if shared:
        mapped, row, additions = shared
        guide_stations = []
        _, radial_edges, *_ = polygon.read_input(source)
        for ring_point, side in ((ring[0], side0), (ring[-1], side1)):
            point = mapped(ring_point)
            # Reuse a nearby prescribed station when the fitted guide is
            # already within the ordinary matching tolerance. Inserting a
            # second point a few centimeters away makes a skinny seam cell.
            if min(math.dist(point, station) for station in side) <= maximum * .08:
                continue
            if side_interval(side, point, maximum) is None:
                return reject('mapped guide endpoint is not on a radial side')
            for edge, stations in radial_edges.items():
                if not any(math.dist(side[0], station) < 1e-7 for _, station in stations):
                    continue
                for first, second in zip(stations, stations[1:]):
                    interval = side_interval((first[1], second[1]), point, maximum)
                    if interval:
                        fraction = interval[1]
                        guide_stations.append(['EDGE', edge, 'QT_BAND',
                                               format(first[0] + fraction * (second[0]-first[0]), '.17g'),
                                               *(format(value, '.17g') for value in point)])
                        break
                else:
                    continue
                break
            else:
                return reject('mapped guide endpoint has no boundary edge')
        if guide_stations:
            with Path(source).open(newline='', encoding='ascii') as stream:
                rows_with_guide = list(csv.reader(stream))
            with Path(destination).open('w', newline='', encoding='ascii') as stream:
                csv.writer(stream).writerows(rows_with_guide + guide_stations)
            source = destination
            inner, ring, _, side0, side1, _, _, extras, complete = blocks.read_sector(source, maximum, verbose=False)
        anchors = (min(side0, key=lambda x: math.dist(x, mapped(ring[0]))),
                   min(side1, key=lambda x: math.dist(x, mapped(ring[-1]))))
        if any(math.dist(a, mapped(r)) > maximum*.08 for a, r in zip(anchors, (ring[0], ring[-1]))):
            return reject('guide endpoint does not match a radial station')
        if any(math.dist(mapped(ring[i]), complete[0][i]) > maximum*.08
               for i in range(len(ring))) if len(complete) > 1 else False:
            return reject('complete guide does not fit the shared transform')
    # Without selection-wide guide data, do not choose independent transverse
    # stations: adjacent sectors would otherwise become nonconforming.
    elif len(complete) > 1:
        additions = 1
        anchors = (complete[0][0], complete[0][-1])
    elif extras:
        additions = 1
        endpoints = {point for a, b, _, _ in extras for point in (a, b)}
        left = [point for point in endpoints if any(math.dist(point, x) < 1e-7 for x in side0)]
        right = [point for point in endpoints if any(math.dist(point, x) < 1e-7 for x in side1)]
        if len(left) != 1 or len(right) != 1:
            return reject('partial guide endpoints are ambiguous')
        anchors = left[0], right[0]
    else:
        return False
    left, right = anchors
    rows = [i for i, point in enumerate(side0) if math.dist(point, left) < 1e-7]
    if len(rows) != 1 or rows[0] < 2 or rows[0] >= len(side0)-1 or right not in side1:
        return reject('guide has no consistent radial row')
    row = rows[0]
    p, q = ring[0], ring[-1]
    dx, dy = q[0]-p[0], q[1]-p[1]
    denominator = dx*dx+dy*dy
    if denominator < 1e-12:
        return reject('ring endpoints coincide')
    ex, ey = right[0]-left[0], right[1]-left[1]
    a, b = (dx*ex+dy*ey)/denominator, (dx*ey-dy*ex)/denominator
    def local_map(point):
        x, y = point[0]-p[0], point[1]-p[1]
        return (left[0]+a*x-b*y, left[1]+b*x+a*y, left[2]+point[2]-p[2])
    mapped = shared[0] if shared else local_map

    n = len(ring)-1
    prescribed = {0: left, n: right}
    original = {tuple(sorted((tuple(round(v, 8) for v in x), tuple(round(v, 8) for v in y))))
                for x, y, _, _ in extras}
    for x, y, _, _ in extras:
        for point in (x, y):
            index = min(range(n+1), key=lambda i: math.dist(mapped(ring[i]), point))
            if math.dist(mapped(ring[index]), point) > maximum*.08:
                return reject('partial guide point does not fit the shared transform')
            if index in prescribed and math.dist(prescribed[index], point) > 1e-7:
                return reject('incompatible prescribed guide points')
            prescribed[index] = point
    if len(complete) > 1:
        guide = complete[0]
        if len(guide) != n+1 or any(math.dist(mapped(x), y) > maximum*.08 for x, y in zip(ring, guide)):
            return reject('complete guide is incompatible with the ring')
        prescribed.update(enumerate(guide))
    def point(index):
        if index in prescribed:
            return prescribed[index]
        lower = max(i for i in prescribed if i < index)
        upper = min(i for i in prescribed if i > index)
        t = (index-lower)/(upper-lower)
        base = mapped(ring[index])
        delta0 = tuple(prescribed[lower][k]-mapped(ring[lower])[k] for k in range(3))
        delta1 = tuple(prescribed[upper][k]-mapped(ring[upper])[k] for k in range(3))
        return tuple(base[k]+(1-t)*delta0[k]+t*delta1[k] for k in range(3))
    guide = [point(index) for index in range(n+1)]
    if any(math.dist(x, y) > maximum+1e-7 for x, y in zip(guide, guide[1:])):
        return reject('transverse guide interval exceeds size')
    # The same stations on each prescribed side segment are shared by
    # adjacent sectors. Add enough rows before the guide for column growth.
    corners, edges, *_ = polygon.read_input(source)
    with Path(source).open(newline='', encoding='ascii') as stream:
        rows = list(csv.reader(stream))
    if shared:
        area = next(record[1] for record in rows if record[0] == 'AREA')
        original_boundary = Path(os.environ['SAP_QUAD_DENSE_BOUNDARIES']) / f'area-{area}-boundary.csv'
        _, original_edges, *_ = polygon.read_input(original_boundary)
    else:
        original_edges = edges
    radial = sorted(range(1, len(corners)+1),
                    key=lambda i: math.dist(corners[i], corners[i % len(corners)+1]), reverse=True)[:2]
    additions_to_write = []
    for edge in radial:
        stations = original_edges[edge]
        first_is_inner = min(math.dist(stations[0][1], inner[0]), math.dist(stations[0][1], inner[-1])) < 1e-7
        before, after = (stations[1], stations[2]) if first_is_inner else (stations[-3], stations[-2])
        for index in range(1, additions + 1):
            fraction = index / (additions + 1)
            station = tuple(x + fraction * (y-x) for x, y in zip(before[1], after[1]))
            if not any(math.dist(point, station) < 1e-7 for _, point in edges[edge]):
                additions_to_write.append(['EDGE', edge, 'QT_BAND',
                                           format(before[0] + fraction * (after[0]-before[0]), '.17g'),
                                           *(format(v, '.17g') for v in station)])
    frame_id = max(int(record[1]) for record in rows if record[0] == 'FRAME')
    rows.extend(additions_to_write)
    for x, y in zip(guide, guide[1:]):
        key = tuple(sorted((tuple(round(v, 8) for v in x), tuple(round(v, 8) for v in y))))
        if key not in original:
            frame_id += 1
            rows.append(['FRAME', frame_id, 'QT_VIRTUAL', 0,
                         *(format(v, '.17g') for v in (*x, *y)), 0, 0])
    with Path(destination).open('w', newline='', encoding='ascii') as stream:
        csv.writer(stream).writerows(rows)
    return True
