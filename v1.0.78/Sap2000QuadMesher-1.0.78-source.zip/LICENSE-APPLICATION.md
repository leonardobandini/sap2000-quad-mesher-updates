# License of SAP2000 Quad Mesher

Copyright (C) 2026 Leonardo Bandini.

Starting with release **1.0.78**, the original program code and documentation
owned by Leonardo Bandini are licensed under the **GNU General Public License,
version 2 or (at your option) any later version** (GPL-2.0-or-later). The full
GPLv2 text is in `LICENSE` and GPLv3 in `GPL-3.0.txt`. This grant does not
relicense code or binaries owned by others. Their copyrights and terms remain
in `THIRD_PARTY_NOTICES.md` and `licenses/` in the binary package.

`SapQuadTransitionPlugin/Plugin.cs` additionally carries the narrowly scoped
permission in `SAP2000-LINKING-EXCEPTION.md`. That permission applies only to
code whose copyright is controlled by Leonardo Bandini. It grants no right to
redistribute SAP2000 or its API DLL. The Gmsh backend is a separate executable
and is not covered by that permission.

Gmsh 4.15.2 remains under its copyright holders' GPL-2.0-or-later terms and
their specific exception. The binary backend also includes OpenSSL 3 under
Apache-2.0: to cover this combination without relying on GPLv2 compatibility
with Apache-2.0, this release elects the GPLv3 option permitted by the "or
later" clauses of our code and Gmsh. Recipients can choose GPLv2 for our
original code separately, where compatible with what they combine it with.
The original Gmsh license and exception are preserved without alteration.

Releases up to and including **1.0.77** were distributed under their then
applicable MIT license. This new license does not revoke recipients' existing
MIT permissions for those earlier versions.
