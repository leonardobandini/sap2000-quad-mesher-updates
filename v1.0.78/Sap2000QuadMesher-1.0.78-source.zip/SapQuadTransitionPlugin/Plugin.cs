// Copyright (C) 2026 Leonardo Bandini
// SPDX-License-Identifier: GPL-2.0-or-later
// Additional permission for the separately installed SAP2000 API:
// see SAP2000-LINKING-EXCEPTION.md.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Authentication;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.Script.Serialization;
using SAP2000v1;

namespace SapQuadTransitionPlugin
{
    [ComVisible(true)]
    [Guid("D64E6254-E9B2-46C8-8C0E-C8A5C78D94AA")]
    [ProgId("SapQuadTransitionPlugin.cPlugin")]
    [ClassInterface(ClassInterfaceType.None)]
    public class cPlugin : cPluginContract
    {
        private const double Tolerance = 1e-7;
        private const int PointObjectType = 1;
        private const int FrameObjectType = 2;
        private const int CableObjectType = 3;
        private const int TendonObjectType = 4;
        private const int AreaObjectType = 5;
        private const int SolidObjectType = 6;
        private const int LinkObjectType = 7;
        private const string PluginVersion = "1.0.78";
        private const string WindowTitle = "SAP2000 Quad Transition Mesh 1.0.78";
        private const string UpdateManifestUrl = "https://raw.githubusercontent.com/leonardobandini/sap2000-quad-mesher-updates/main/manifest.json";
        private static readonly Color UiNavy = Color.FromArgb(15, 23, 42);
        private static readonly Color UiBody = Color.FromArgb(30, 41, 59);
        private static readonly Color UiMuted = Color.FromArgb(71, 85, 105);
        private static readonly Color UiBlue = Color.FromArgb(37, 99, 235);
        private static readonly Color UiLight = Color.FromArgb(248, 250, 252);
        private static readonly Color UiInactive = Color.FromArgb(226, 232, 240);
        private static readonly Color UiBorder = Color.FromArgb(203, 213, 225);
        private static bool useItalian;

        private static string L(string english, string italian) { return useItalian ? italian : english; }
        private static string LocalizeMessage(string message)
        {
            if (!useItalian || string.IsNullOrEmpty(message)) return message;
            var replacements = new[]
            {
                new[] { "The model is locked. Unlock it before generating the mesh.", "Il modello e bloccato. Sbloccarlo prima di generare la mesh." },
                new[] { "Select at least one area object.", "Selezionare almeno un oggetto area." },
                new[] { "Invalid maximum size.", "Dimensione massima non valida." },
                new[] { "Regular meshing and local refinement are mutually exclusive.", "La mesh regolare e il raffinamento locale si escludono a vicenda." },
                new[] { "Select an opening-boundary group.", "Selezionare un gruppo per il contorno delle aperture." },
                new[] { "Select a hole-center group.", "Selezionare un gruppo di centri dei fori." },
                new[] { "Invalid hole diameter.", "Diametro del foro non valido." },
                new[] { "Preparing geometry...", "Preparazione della geometria..." },
                new[] { "Generating and optimizing the mesh...", "Generazione e ottimizzazione della mesh..." },
                new[] { "Creating SAP2000 points...", "Creazione dei punti SAP2000..." },
                new[] { "Creating shell elements and transferring loads...", "Creazione degli elementi shell e trasferimento dei carichi..." },
                new[] { "FAST: bulk importing points and shell elements...", "FAST: importazione massiva di punti ed elementi shell..." },
                new[] { "FAST: transferring assignments...", "FAST: trasferimento delle assegnazioni..." },
                new[] { "Mesh generator:", "Generatore mesh:" },
                new[] { "Undo failed.", "Annullamento non riuscito." },
                new[] { "Rollback failed:", "Ripristino non riuscito:" },
                new[] { "Selection restore failed:", "Ripristino della selezione non riuscito:" },
                new[] { "Exact symmetry", "La simmetria esatta" },
                new[] { "Area ", "Area " },
                new[] { "Selected point ", "Il punto selezionato " },
                new[] { "Frame ", "Il telaio " },
                new[] { "Circular hole", "Il foro circolare" },
                new[] { "The generated transition mesh is not exactly symmetric", "La mesh di transizione generata non e esattamente simmetrica" },
                new[] { "The generator returned an empty mesh.", "Il generatore ha restituito una mesh vuota." },
                new[] { "Unsupported connectivity.", "Connettivita non supportata." },
                new[] { "The area must be planar.", "L'area deve essere piana." },
                new[] { "Degenerate area.", "Area degenere." },
                new[] { "Areas processed:", "Aree elaborate:" },
                new[] { "Details are reported separately for each area.", "I dettagli sono riportati separatamente per ogni area." },
                new[] { "Nodes:", "Nodi:" },
                new[] { "Elements:", "Elementi:" },
                new[] { "quads", "quadrilateri" },
                new[] { "triangles", "triangoli" },
                new[] { "Constraining frames:", "Telai vincolanti:" },
                new[] { "Shell elements removed for holes:", "Elementi shell rimossi per i fori:" },
                new[] { "Maximum size", "Dimensione massima" },
                new[] { "Aspect ratio", "Rapporto d'aspetto" },
                new[] { "Quadrilateral skew", "Distorsione dei quadrilateri" },
                new[] { "Scaled Jacobian", "Jacobiano scalato" },
                new[] { "Quadrilateral angles", "Angoli dei quadrilateri" },
                new[] { "Triangle angles", "Angoli dei triangoli" },
                new[] { "Orientation", "Orientamento" },
                new[] { "Requested/constraints:", "Richiesta/vincoli:" },
                new[] { "degrees", "gradi" },
                new[] { "invalid elements", "elementi non validi" },
                new[] { "No inverted or degenerate elements", "Nessun elemento invertito o degenere" },
                new[] { "is ideal", "e ideale" },
                new[] { "EXCELLENT", "ECCELLENTE" },
                new[] { "ACCEPTABLE", "ACCETTABILE" },
                new[] { "POOR", "SCARSO" },
                new[] { "CRITICAL", "CRITICO" },
                new[] { "MINIMUM", "MINIMO" },
                new[] { "MAXIMUM", "MASSIMO" }
            };
            foreach (string[] replacement in replacements) message = message.Replace(replacement[0], replacement[1]);
            return message;
        }

        [DllImport("user32.dll")]
        private static extern bool EnableWindow(IntPtr window, bool enable);

        [DllImport("user32.dll")]
        private static extern bool IsWindowEnabled(IntPtr window);

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr window);

        [DllImport("user32.dll")]
        private static extern IntPtr SetActiveWindow(IntPtr window);

        public int Info(ref string text)
        {
            text = "SAP2000 Quad Transition Mesh " + PluginVersion + L(": conforming meshes with constrained frames, exact symmetry, and optional O-grid holes.",
                ": mesh conformi con telai vincolati, simmetria esatta e fori O-grid opzionali.");
            return 0;
        }

        public void Main(ref cSapModel model, ref cPluginCallback callback)
        {
            int error = 0;
            try { Run(model); }
            catch (Exception exception)
            {
                error = 1;
                string automationError = Environment.GetEnvironmentVariable("SAP_QUAD_AUTOMATION_ERROR");
                if (!string.IsNullOrEmpty(automationError))
                    try { File.WriteAllText(automationError, exception.ToString()); } catch { }
                else
                    MessageBox.Show(LocalizeMessage(exception.Message), WindowTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { callback.Finish(error); }
        }

        private static void Run(cSapModel model)
        {
            Console.WriteLine("mesh-stage=reading-model");
            eUnits presentUnits = model.GetPresentUnits();
            string lengthUnit = LengthUnit(presentUnits);
            int selectedCount = 0;
            int[] selectedTypes = null;
            string[] selectedNames = null;
            Check(model.SelectObj.GetSelected(ref selectedCount, ref selectedTypes, ref selectedNames), "reading the selection");
            Console.WriteLine("mesh-stage=selection-read objects=" + selectedCount);
            string[] areas = Enumerable.Range(0, selectedCount)
                .Where(i => selectedTypes[i] == AreaObjectType).Select(i => selectedNames[i]).Distinct().ToArray();
            string[] selectedPoints = Enumerable.Range(0, selectedCount)
                .Where(i => selectedTypes[i] == PointObjectType).Select(i => selectedNames[i]).Distinct().ToArray();
            string[] selectedFrames = Enumerable.Range(0, selectedCount)
                .Where(i => selectedTypes[i] == FrameObjectType).Select(i => selectedNames[i]).Distinct().ToArray();
            if (areas.Length == 0)
            {
                using (var dialog = new MeshOptionsDialog(lengthUnit, false, new string[0], new string[0],
                    new SymmetryAxis[0], false))
                {
                    IntPtr owner = Process.GetCurrentProcess().MainWindowHandle;
                    if (owner != IntPtr.Zero) dialog.ShowDialog(new WindowOwner(owner));
                    else dialog.ShowDialog();
                }
                return;
            }
            if (model.GetModelIsLocked())
                throw new InvalidOperationException(L("The model is locked. Unlock it before generating the mesh.",
                    "Il modello e bloccato. Sbloccarlo prima di generare la mesh."));

            Console.WriteLine("mesh-stage=building-area-contexts areas=" + areas.Length);
            List<AreaContext> initialContexts = BuildAreaContexts(model, areas, selectedPoints, selectedFrames);
            Console.WriteLine("mesh-stage=area-contexts-ready");
            bool hasFrames = initialContexts.Count > 1 || initialContexts.Any(context => context.FrameConstraints.Count > 0);
            string[] pointGroups = ReadPointGroups(model);
            string[] openingGroups = ReadOpeningGroups(model);
            SymmetryAxis[] symmetryAxes = DetectSymmetryAxes(initialContexts);
            Console.WriteLine("mesh-stage=options-ready");

            IntPtr sapWindow = Process.GetCurrentProcess().MainWindowHandle;
            bool sapWasEnabled = sapWindow != IntPtr.Zero && IsWindowEnabled(sapWindow);
            if (sapWasEnabled) EnableWindow(sapWindow, false);
            try
            {
                using (var dialog = new MeshOptionsDialog(lengthUnit, hasFrames, pointGroups, openingGroups, symmetryAxes))
                {
                bool leaveCompletedDialog = Environment.GetEnvironmentVariable("SAP_QUAD_LEAVE_COMPLETED_DIALOG") == "1";
                if (leaveCompletedDialog) dialog.ShowInTaskbar = true;
                if (sapWindow != IntPtr.Zero) dialog.Show(new WindowOwner(sapWindow)); else dialog.Show();
                Console.WriteLine("mesh-stage=dialog-visible");
                bool automatedExample = !string.IsNullOrEmpty(Environment.GetEnvironmentVariable("SAP_QUAD_ATOMIC_SIZE"));
                if (automatedExample) dialog.ApplyAutomatedOptions();
                while (dialog.Visible)
                {
                    while (dialog.Visible && !dialog.StartRequested)
                    {
                        Application.DoEvents();
                        Thread.Sleep(20);
                    }
                    if (!dialog.Visible) return;

                    string[] holePointNames = new string[0];
                    List<AreaContext> contexts = null;
                    var results = new List<MeshAttemptResult>();
                    FastTableSnapshot fastSnapshot = null;
                    PointSnapshot[] fastOriginalPoints = null;
                    string symmetryNotice = null;
                    try
                    {
                        holePointNames = dialog.GenerateCircularHoles
                            ? ReadGroupPoints(model, dialog.HoleGroup)
                            : new string[0];
                        string[] constraintPoints = selectedPoints.Except(holePointNames).ToArray();
                        contexts = BuildAreaContexts(model, areas, constraintPoints, selectedFrames);
                        if (dialog.Symmetric && contexts.Count > 1 && !dialog.PreferRegularMesh && !dialog.GenerateCircularHoles)
                            throw new InvalidOperationException("Exact symmetry across multiple source areas requires regular aligned meshing.");
                        if (dialog.GenerateCircularHoles)
                            AssignCircularHoles(model, contexts, holePointNames, dialog.HoleDiameter);
                        SymmetryAxis activeSymmetryAxis = dialog.Symmetric ? dialog.SelectedSymmetryAxis : null;
                        if (dialog.Symmetric)
                            activeSymmetryAxis = symmetryAxes.FirstOrDefault(axis => axis.SecondaryDirection != null) ?? activeSymmetryAxis;
                        if (dialog.Symmetric && activeSymmetryAxis == null)
                            symmetryNotice = "no reflection axis is compatible with the selected geometry and constraints";
                        if (activeSymmetryAxis != null && dialog.GenerateCircularHoles)
                        {
                            try { ValidateSymmetricHoles(contexts, activeSymmetryAxis); }
                            catch (Exception exception)
                            {
                                symmetryNotice = exception.Message;
                                activeSymmetryAxis = null;
                            }
                        }
                        HarmonizeSharedBoundaries(contexts, dialog.MaxSize);
                        HarmonizeAreaEdgeIntersections(contexts, dialog.MaxSize);
                        if (dialog.GenerateHoles)
                            AssignOpeningBoundaries(model, contexts, dialog.OpeningGroup);
                        ValidateCircularHoleConstraints(contexts);
                        PointCoordinateIndex pointIndex = ReadExactPointCoordinates(model, dialog.MaxSize);
                        if (dialog.FastMode)
                        {
                            fastOriginalPoints = CapturePointSnapshots(model,
                                contexts.SelectMany(context => context.CornerNames).Concat(selectedPoints).Concat(holePointNames));
                        }
                        dialog.SetMeshingAreas(0, contexts.Count);
                        foreach (AreaContext context in contexts)
                        {
                            SymmetryAxis contextAxis = contexts.Count == 1 ? activeSymmetryAxis : null;
                            try
                            {
                                results.Add(ExecuteMeshAttempt(model, context.Name, context.CornerNames.Length, context.CornerNames,
                                    context.Corners, context.EdgePoints, context.InteriorPoints, context.ConstraintPointNames.ToArray(),
                                    context.FrameConstraints, context.Holes, context.ForceRefinement, context.Plane,
                                    contextAxis, dialog, pointIndex, contexts));
                                dialog.SetMeshingAreas(results.Count, contexts.Count);
                            }
                            catch (Exception exception)
                            {
                                if (contextAxis == null || !exception.Message.StartsWith("Mesh generator:", StringComparison.Ordinal))
                                    throw new InvalidOperationException("Area " + context.Name + ": " + exception.Message, exception);
                                throw new InvalidOperationException("Area " + context.Name +
                                    ": exact symmetry could not be generated; no non-symmetric fallback was applied. " +
                                    exception.Message, exception);
                            }
                        }
                    }
                    catch (Exception exception)
                    {
                        try { UndoAttempts(model, results, fastSnapshot, fastOriginalPoints); }
                        catch (Exception rollback)
                        {
                            exception = new InvalidOperationException(exception.Message + " Rollback failed: " + rollback.Message);
                        }
                        try { RestoreSelection(model, selectedTypes, selectedNames); }
                        catch (Exception selectionRestore)
                        {
                            exception = new InvalidOperationException(exception.Message + " Selection restore failed: " + selectionRestore.Message);
                        }
                        model.View.RefreshView(0, false);
                        if (!string.IsNullOrEmpty(Environment.GetEnvironmentVariable("SAP_QUAD_AUTOMATION_ERROR")))
                            throw exception;
                        dialog.Fail(exception.Message);
                        continue;
                    }
                    MeshQualityReport combinedQuality = CombineQuality(contexts, results);
                    int generatedAreaCount = results.Sum(result => result.Operation.GeneratedAreas.Count);
                    model.View.RefreshView(0, false);
                    dialog.Complete(combinedQuality, generatedAreaCount, symmetryNotice, delegate
                    {
                        UndoAttempts(model, results, fastSnapshot, fastOriginalPoints);
                        RestoreSelection(model, selectedTypes, selectedNames);
                        model.View.RefreshView(0, false);
                    });
                    if (automatedExample && !leaveCompletedDialog) dialog.Close();
                    if (leaveCompletedDialog)
                    {
                        dialog.TopMost = true;
                        dialog.Activate();
                        SetForegroundWindow(dialog.Handle);
                    }
                    while (dialog.Visible && !dialog.RetryRequested && dialog.UndoFailure == null)
                    {
                        Application.DoEvents();
                        Thread.Sleep(20);
                    }
                    if (dialog.UndoFailure != null)
                    {
                        Exception undoFailure = dialog.UndoFailure;
                        dialog.Close();
                        throw new InvalidOperationException("Undo failed. The generated mesh was not committed; inspect the model before continuing.", undoFailure);
                    }
                    if (dialog.RetryRequested) continue;
                    CommitAttempts(model, results);
                    model.View.RefreshView(0, false);
                    return;
                }
                }
            }
            finally
            {
                if (sapWasEnabled)
                {
                    EnableWindow(sapWindow, true);
                    SetActiveWindow(sapWindow);
                    SetForegroundWindow(sapWindow);
                    Application.DoEvents();
                }
            }
        }

        private static List<AreaContext> BuildAreaContexts(cSapModel model, string[] areas, string[] selectedPoints, string[] selectedFrames)
        {
            List<AreaContext> contexts = areas.Select(area => BuildAreaContext(model, area)).ToList();
            foreach (string pointName in selectedPoints)
            {
                double[] point = Coordinate(model, pointName);
                bool assigned = false;
                foreach (AreaContext context in contexts)
                    assigned |= AddConstraintPoint(context, pointName, point);
                if (!assigned) throw new InvalidOperationException("Selected point " + pointName + " does not belong to the selected areas.");
            }
            foreach (string frameName in selectedFrames)
            {
                string firstName = "", secondName = "";
                Check(model.FrameObj.GetPoints(frameName, ref firstName, ref secondName), "reading frame endpoints for " + frameName);
                double[] first = Coordinate(model, firstName), second = Coordinate(model, secondName);
                if (Distance(first, second) <= Tolerance)
                    throw new InvalidOperationException("Frame " + frameName + " has zero length.");
                var covered = new List<SegmentInterval>();
                var parameters = new List<double> { 0, 1 };
                foreach (AreaContext context in contexts)
                {
                    if (Math.Abs(context.Plane.SignedDistance(first)) > Tolerance ||
                        Math.Abs(context.Plane.SignedDistance(second)) > Tolerance) continue;
                    double[] projectedFirst = context.Plane.Project(first), projectedSecond = context.Plane.Project(second);
                    double[][] polygon = context.Corners.Select(context.Plane.Project).ToArray();
                    for (int edge = 0; edge < polygon.Length; edge++)
                        AddSegmentIntersectionParameters(projectedFirst, projectedSecond, polygon[edge],
                            polygon[(edge + 1) % polygon.Length], parameters);
                }
                List<double> breakpoints = parameters.Select(value => Math.Max(0, Math.Min(1, value)))
                    .OrderBy(value => value).Aggregate(new List<double>(), (values, value) =>
                    {
                        if (values.Count == 0 || Math.Abs(values[values.Count - 1] - value) > Tolerance) values.Add(value);
                        return values;
                    });
                for (int index = 1; index < breakpoints.Count; index++)
                {
                    double low = breakpoints[index - 1], high = breakpoints[index];
                    if ((high - low) * Distance(first, second) <= Tolerance) continue;
                    double[] midpoint = Interpolate(first, second, (low + high) * 0.5);
                    List<AreaContext> hosts = contexts.Where(context =>
                        Math.Abs(context.Plane.SignedDistance(midpoint)) <= Tolerance &&
                        PointInsideOrBoundary(context.Plane.Project(midpoint),
                            context.Corners.Select(context.Plane.Project).ToArray())).ToList();
                    if (hosts.Count == 0) continue;
                    covered.Add(new SegmentInterval(low, high));
                    double[] start = Interpolate(first, second, low), end = Interpolate(first, second, high);
                    string startName = low <= Tolerance ? firstName : "QT_FRAME_INTERSECTION";
                    string endName = high >= 1 - Tolerance ? secondName : "QT_FRAME_INTERSECTION";
                    foreach (AreaContext context in hosts)
                    {
                        AddConstraintPoint(context, startName, start, low <= Tolerance);
                        AddConstraintPoint(context, endName, end, high >= 1 - Tolerance);
                        if (!FrameOnBoundary(context, start, end))
                            context.FrameConstraints.Add(new FrameConstraint(frameName, startName, endName, start, end));
                    }
                }
                if (covered.Count == 0)
                    throw new InvalidOperationException("Frame " + frameName + " does not intersect the selected areas.");
            }
            foreach (AreaContext context in contexts)
                for (int edge = 0; edge < context.EdgePoints.Length; edge++)
                    context.EdgePoints[edge] = context.EdgePoints[edge].OrderBy(point => point.T).ToList();

            return contexts;
        }

        private static string[] ReadPointGroups(cSapModel model)
        {
            int count = 0;
            string[] names = null;
            Check(model.GroupDef.GetNameList(ref count, ref names), "reading SAP2000 groups");
            return (names ?? new string[0]).Where(name => ReadGroupPoints(model, name).Length > 0)
                .OrderBy(name => name, StringComparer.CurrentCultureIgnoreCase).ToArray();
        }

        private static string[] ReadGroupPoints(cSapModel model, string groupName)
        {
            int count = 0;
            int[] types = null;
            string[] names = null;
            Check(model.GroupDef.GetAssignments(groupName, ref count, ref types, ref names), "reading group " + groupName);
            return Enumerable.Range(0, count).Where(index => types[index] == PointObjectType)
                .Select(index => names[index]).Distinct().ToArray();
        }

        private static string[] ReadOpeningGroups(cSapModel model)
        {
            int count = 0;
            string[] names = null;
            Check(model.GroupDef.GetNameList(ref count, ref names), "reading SAP2000 groups");
            return (names ?? new string[0]).Where(name => ReadGroupObjects(model, name).HasOpeningObjects)
                .OrderBy(name => name, StringComparer.CurrentCultureIgnoreCase).ToArray();
        }

        private static GroupObjects ReadGroupObjects(cSapModel model, string groupName)
        {
            int count = 0;
            int[] types = null;
            string[] names = null;
            Check(model.GroupDef.GetAssignments(groupName, ref count, ref types, ref names), "reading group " + groupName);
            var frames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var areas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int index = 0; index < count; index++)
            {
                if (types[index] == FrameObjectType) frames.Add(names[index]);
                else if (types[index] == AreaObjectType) areas.Add(names[index]);
            }
            return new GroupObjects(frames, areas);
        }

        private static void AssignOpeningBoundaries(cSapModel model, List<AreaContext> contexts, string groupName)
        {
            if (string.IsNullOrEmpty(groupName))
                throw new InvalidOperationException("Select an opening-boundary group.");
            GroupObjects members = ReadGroupObjects(model, groupName);
            int eligible = 0;
            foreach (AreaContext context in contexts)
                foreach (FrameConstraint frame in context.FrameConstraints)
                {
                    frame.CanBoundOpening = frame.Automatic
                        ? frame.SourceContext != null && members.Areas.Contains(frame.SourceContext.Name)
                        : members.Frames.Contains(frame.Name);
                    if (frame.CanBoundOpening) eligible++;
                }
            if (eligible == 0)
                throw new InvalidOperationException("The selected opening-boundary group contains no frame or shell-edge constraints in the selected areas.");
        }

        private static void AssignCircularHoles(cSapModel model, List<AreaContext> contexts, string[] pointNames, double diameter)
        {
            if (pointNames.Length == 0) throw new InvalidOperationException("The selected circular-hole group contains no point objects.");
            double radius = diameter * 0.5;
            int totalAssigned = 0;
            foreach (string pointName in pointNames)
            {
                double[] center = Coordinate(model, pointName);
                var intersected = new List<AreaContext>();
                foreach (AreaContext context in contexts)
                {
                    if (Math.Abs(context.Plane.SignedDistance(center)) > Tolerance) continue;
                    double[] projectedCenter = context.Plane.Project(center);
                    double[][] polygon = context.Corners.Select(context.Plane.Project).ToArray();
                    double clearance = Enumerable.Range(0, polygon.Length)
                        .Min(edge => DistancePointToSegment2D(projectedCenter, polygon[edge], polygon[(edge + 1) % polygon.Length]));
                    if (!PointInsideOrBoundary(projectedCenter, polygon) && clearance >= radius - Tolerance) continue;
                    intersected.Add(context);
                }
                if (intersected.Count == 0) continue;
                for (int sample = 0; sample < 64; sample++)
                {
                    double angle = 2 * Math.PI * sample / 64;
                    double[] sampleVector = intersected[0].Plane.VectorFromPlane(radius * Math.Cos(angle), radius * Math.Sin(angle));
                    double[] samplePoint = { center[0] + sampleVector[0], center[1] + sampleVector[1], center[2] + sampleVector[2] };
                    bool covered = contexts.Any(context =>
                    {
                        if (Math.Abs(context.Plane.SignedDistance(samplePoint)) > Tolerance) return false;
                        return PointInsideOrBoundary(context.Plane.Project(samplePoint),
                            context.Corners.Select(context.Plane.Project).ToArray());
                    });
                    if (!covered)
                        throw new InvalidOperationException("Circular hole at point " + pointName +
                            " is not fully covered by the selected coplanar areas.");
                }
                foreach (AreaContext context in intersected)
                {
                    foreach (ConstraintPoint constraint in context.InteriorPoints)
                        if (Distance(center, constraint.Coordinates) <= radius + Tolerance)
                            throw new InvalidOperationException("Selected point " + constraint.Name + " lies inside the circular hole centered at " + pointName + ".");
                    foreach (FrameConstraint frame in context.FrameConstraints)
                    {
                        double distance = DistancePointToSegment2D(context.Plane.Project(center),
                            context.Plane.Project(frame.First), context.Plane.Project(frame.Second));
                        if (distance <= radius + Tolerance)
                            throw new InvalidOperationException("Frame " + frame.Name + " crosses the circular hole centered at " + pointName + ".");
                    }
                    context.Holes.Add(new HoleDefinition(context.Holes.Count + 1, pointName, center, diameter));
                    totalAssigned++;
                }
            }
            if (totalAssigned == 0)
                throw new InvalidOperationException("None of the point objects in the selected circular-hole group belongs to the selected areas.");

            foreach (AreaContext context in contexts)
                for (int first = 0; first < context.Holes.Count; first++)
                    for (int second = first + 1; second < context.Holes.Count; second++)
                        if (Distance(context.Holes[first].Center, context.Holes[second].Center) <=
                            context.Holes[first].Radius + context.Holes[second].Radius + Tolerance)
                            throw new InvalidOperationException("Circular holes centered at points " + context.Holes[first].PointName + " and " +
                                context.Holes[second].PointName + " overlap or touch in area " + context.Name + ".");
        }

        private static double DistancePointToSegment2D(double[] point, double[] first, double[] second)
        {
            double dx = second[0] - first[0], dy = second[1] - first[1];
            double lengthSquared = dx * dx + dy * dy;
            double t = lengthSquared == 0 ? 0 : ((point[0] - first[0]) * dx + (point[1] - first[1]) * dy) / lengthSquared;
            t = Math.Max(0, Math.Min(1, t));
            double x = first[0] + t * dx, y = first[1] + t * dy;
            double px = point[0] - x, py = point[1] - y;
            return Math.Sqrt(px * px + py * py);
        }

        private static void ValidateCircularHoleConstraints(List<AreaContext> contexts)
        {
            foreach (AreaContext context in contexts)
                foreach (HoleDefinition hole in context.Holes)
                    foreach (FrameConstraint frame in context.FrameConstraints)
                        if (DistancePointToSegment2D(context.Plane.Project(hole.Center),
                            context.Plane.Project(frame.First), context.Plane.Project(frame.Second)) <= hole.Radius + Tolerance)
                            throw new InvalidOperationException("Constraint " + frame.Name + " crosses the circular hole centered at " + hole.PointName + ".");
        }

        private static void ValidateSymmetricHoles(List<AreaContext> contexts, SymmetryAxis axis)
        {
            if (axis == null)
                throw new InvalidOperationException("Symmetric circular holes require a detected symmetry axis.");
            if (contexts.Count > 1)
            {
                HoleDefinition[] uniqueHoles = contexts.SelectMany(item => item.Holes)
                    .GroupBy(hole => hole.PointName).Select(group => group.First()).ToArray();
                double scale = contexts.SelectMany(item => item.Corners)
                    .SelectMany(first => contexts.SelectMany(item => item.Corners).Select(second => Distance(first, second))).Max();
                double tolerance = Math.Max(Tolerance * 10, scale * 1e-6);
                foreach (HoleDefinition hole in uniqueHoles)
                {
                    double[] offset = Subtract(hole.Center, axis.Center);
                    double projection = Dot(offset, axis.Direction);
                    double[] perpendicular = Subtract(offset, new[] { axis.Direction[0] * projection,
                        axis.Direction[1] * projection, axis.Direction[2] * projection });
                    if (Norm(perpendicular) > tolerance)
                        throw new InvalidOperationException("Multi-area symmetric circular holes must currently be centered on the selected symmetry axis.");
                }
                return;
            }
            AreaContext context = contexts[0];
            double contextScale = context.Corners.SelectMany(first => context.Corners.Select(second => Distance(first, second))).Max();
            double maxRadius = context.Holes.Select(hole => hole.Radius).DefaultIfEmpty(0).Max();
            double symmetryTolerance = Math.Max(Tolerance * 10, Math.Min(contextScale * 0.01, maxRadius * 0.15));
            var unpaired = new HashSet<int>(Enumerable.Range(0, context.Holes.Count));
            while (unpaired.Count > 0)
            {
                int holeIndex = unpaired.First();
                HoleDefinition hole = context.Holes[holeIndex];
                unpaired.Remove(holeIndex);
                double[] offset = Subtract(hole.Center, axis.Center);
                double projection = Dot(offset, axis.Direction);
                double[] perpendicular = Subtract(offset, new[] { axis.Direction[0] * projection,
                    axis.Direction[1] * projection, axis.Direction[2] * projection });
                double axisDistance = Norm(perpendicular);
                if (axisDistance <= symmetryTolerance)
                {
                    double[] snapped =
                    {
                        axis.Center[0] + projection * axis.Direction[0],
                        axis.Center[1] + projection * axis.Direction[1],
                        axis.Center[2] + projection * axis.Direction[2]
                    };
                    context.Holes[holeIndex] = new HoleDefinition(hole.Id, hole.PointName, snapped, hole.Diameter);
                    continue;
                }
                if (axisDistance <= hole.Radius + Tolerance)
                    throw new InvalidOperationException("A circular hole centered at point " + hole.PointName +
                        " crosses the symmetry axis without being centered on it.");
                double[] reflected =
                {
                    axis.Center[0] + 2 * projection * axis.Direction[0] - offset[0],
                    axis.Center[1] + 2 * projection * axis.Direction[1] - offset[1],
                    axis.Center[2] + 2 * projection * axis.Direction[2] - offset[2]
                };
                int counterpart = unpaired.Where(candidate =>
                    Math.Abs(context.Holes[candidate].Diameter - hole.Diameter) <= Tolerance &&
                    Distance(context.Holes[candidate].Center, reflected) <= symmetryTolerance).DefaultIfEmpty(-1).First();
                if (counterpart < 0)
                {
                    double nearest = unpaired.Select(candidate => Distance(context.Holes[candidate].Center, reflected))
                        .DefaultIfEmpty(double.PositiveInfinity).Min();
                    throw new InvalidOperationException("Circular hole centered at point " + hole.PointName +
                        " has no reflected counterpart across the selected symmetry axis. Nearest center distance: " +
                        nearest.ToString("G6", CultureInfo.InvariantCulture) + "; tolerance: " +
                        symmetryTolerance.ToString("G6", CultureInfo.InvariantCulture) + ".");
                }
                HoleDefinition other = context.Holes[counterpart];
                double[] otherOffset = Subtract(other.Center, axis.Center);
                double otherProjection = Dot(otherOffset, axis.Direction);
                double[] otherPerpendicular = Subtract(otherOffset, new[] { axis.Direction[0] * otherProjection,
                    axis.Direction[1] * otherProjection, axis.Direction[2] * otherProjection });
                double commonProjection = (projection + otherProjection) * 0.5;
                double[] commonPerpendicular =
                {
                    (perpendicular[0] - otherPerpendicular[0]) * 0.5,
                    (perpendicular[1] - otherPerpendicular[1]) * 0.5,
                    (perpendicular[2] - otherPerpendicular[2]) * 0.5
                };
                double[] firstCenter =
                {
                    axis.Center[0] + commonProjection * axis.Direction[0] + commonPerpendicular[0],
                    axis.Center[1] + commonProjection * axis.Direction[1] + commonPerpendicular[1],
                    axis.Center[2] + commonProjection * axis.Direction[2] + commonPerpendicular[2]
                };
                double[] secondCenter =
                {
                    axis.Center[0] + commonProjection * axis.Direction[0] - commonPerpendicular[0],
                    axis.Center[1] + commonProjection * axis.Direction[1] - commonPerpendicular[1],
                    axis.Center[2] + commonProjection * axis.Direction[2] - commonPerpendicular[2]
                };
                context.Holes[holeIndex] = new HoleDefinition(hole.Id, hole.PointName, firstCenter, hole.Diameter);
                context.Holes[counterpart] = new HoleDefinition(other.Id, other.PointName, secondCenter, other.Diameter);
                unpaired.Remove(counterpart);
            }
        }

        private static SymmetryAxis[] DetectSymmetryAxes(List<AreaContext> contexts)
        {
            if (contexts.Count > 1) return DetectMultiAreaSymmetryAxes(contexts);
            if (contexts.Count != 1) return new SymmetryAxis[0];
            AreaContext context = contexts[0];
            double[][] corners = context.Corners.Select(context.Plane.Project).ToArray();
            double[] center2D =
            {
                corners.Average(point => point[0]),
                corners.Average(point => point[1])
            };
            double extent = corners.Max(point => Math.Sqrt((point[0] - center2D[0]) * (point[0] - center2D[0]) +
                (point[1] - center2D[1]) * (point[1] - center2D[1])));
            double tolerance = Math.Max(Tolerance * 10, extent * 1e-6);
            var candidates = new List<double[]>();
            foreach (double[] point in corners.Concat(Enumerable.Range(0, corners.Length)
                .Select(index => new[] { (corners[index][0] + corners[(index + 1) % corners.Length][0]) * 0.5,
                    (corners[index][1] + corners[(index + 1) % corners.Length][1]) * 0.5 })))
            {
                double dx = point[0] - center2D[0], dy = point[1] - center2D[1];
                double length = Math.Sqrt(dx * dx + dy * dy);
                if (length <= tolerance) continue;
                double[] direction = { dx / length, dy / length };
                if (!candidates.Any(existing => Math.Abs(existing[0] * direction[0] + existing[1] * direction[1]) >= 1 - 1e-8))
                    candidates.Add(direction);
            }

            double[][] boundaryPoints = context.EdgePoints.SelectMany(edge => edge).Select(point => context.Plane.Project(point.Coordinates)).ToArray();
            double[][] interiorPoints = context.InteriorPoints.Select(point => context.Plane.Project(point.Coordinates)).ToArray();
            Tuple<double[], double[]>[] frameSegments = context.FrameConstraints.Select(frame =>
                Tuple.Create(context.Plane.Project(frame.First), context.Plane.Project(frame.Second))).ToArray();
            var axes = new List<SymmetryAxis>();
            foreach (double[] direction in candidates)
            {
                if (!ReflectionMatches(corners, center2D, direction, tolerance) ||
                    !ReflectionEdgesMatch(corners, center2D, direction, tolerance) ||
                    !ReflectionMatches(boundaryPoints, center2D, direction, tolerance) ||
                    !ReflectionMatches(interiorPoints, center2D, direction, tolerance) ||
                    !ReflectionSegmentsMatch(frameSegments, center2D, direction, tolerance)) continue;
                double[] globalDirection = context.Plane.VectorFromPlane(direction[0], direction[1]);
                double[] globalCenter =
                {
                    context.Corners.Average(point => point[0]), context.Corners.Average(point => point[1]),
                    context.Corners.Average(point => point[2])
                };
                axes.Add(new SymmetryAxis(globalCenter, globalDirection, axes.Count + 1));
            }
            return AddDoublePrincipalSymmetry(axes, context.Corners);
        }

        private static SymmetryAxis[] DetectMultiAreaSymmetryAxes(List<AreaContext> contexts)
        {
            Plane plane = contexts[0].Plane;
            if (contexts.SelectMany(context => context.Corners).Any(point => Math.Abs(plane.SignedDistance(point)) > Tolerance))
                return new SymmetryAxis[0];
            double[][][] polygons = contexts.Select(context => context.Corners.Select(plane.Project).ToArray()).ToArray();
            double minX = polygons.SelectMany(polygon => polygon).Min(point => point[0]);
            double maxX = polygons.SelectMany(polygon => polygon).Max(point => point[0]);
            double minY = polygons.SelectMany(polygon => polygon).Min(point => point[1]);
            double maxY = polygons.SelectMany(polygon => polygon).Max(point => point[1]);
            double[] center = { (minX + maxX) * 0.5, (minY + maxY) * 0.5 };
            double tolerance = Math.Max(Tolerance * 10, Math.Max(maxX - minX, maxY - minY) * 1e-6);
            var directions = new List<double[]> { new[] { 0.0, 1.0 }, new[] { 1.0, 0.0 } };
            if (Math.Abs((maxX - minX) - (maxY - minY)) <= tolerance)
            {
                double inverseRoot = 1 / Math.Sqrt(2);
                directions.Add(new[] { inverseRoot, inverseRoot });
                directions.Add(new[] { inverseRoot, -inverseRoot });
            }
            var axes = new List<SymmetryAxis>();
            Tuple<double[], double[]>[] frameSegments = contexts.SelectMany(context => context.FrameConstraints.Select(frame =>
                Tuple.Create(plane.Project(frame.First), plane.Project(frame.Second)))).ToArray();
            foreach (double[] direction in directions)
            {
                bool matches = polygons.All(polygon =>
                {
                    double[][] reflected = polygon.Select(point => ReflectPoint(point, center, direction)).ToArray();
                    return polygons.Any(candidate => reflected.All(point =>
                        candidate.Any(candidatePoint => Distance2D(point, candidatePoint) <= tolerance)));
                });
                if (!matches || !ReflectionSegmentsMatch(frameSegments, center, direction, tolerance)) continue;
                axes.Add(new SymmetryAxis(plane.PointFromPlane(center[0], center[1]),
                    plane.VectorFromPlane(direction[0], direction[1]), axes.Count + 1));
            }
            return AddDoublePrincipalSymmetry(axes, contexts.SelectMany(context => context.Corners).ToArray());
        }

        private static SymmetryAxis[] AddDoublePrincipalSymmetry(List<SymmetryAxis> axes, double[][] corners)
        {
            var edgeDirections = new List<double[]>();
            for (int index = 0; index < corners.Length; index++)
            {
                double[] edge = Subtract(corners[(index + 1) % corners.Length], corners[index]);
                if (Norm(edge) > Tolerance) edgeDirections.Add(Normalize(edge));
            }
            SymmetryAxis[] principal = axes.Where(axis => edgeDirections.Any(edge =>
                Math.Abs(Dot(edge, axis.Direction)) >= 1 - 1e-8)).ToArray();
            for (int first = 0; first < principal.Length; first++)
                for (int second = first + 1; second < principal.Length; second++)
                    if (Math.Abs(Dot(principal[first].Direction, principal[second].Direction)) <= 1e-8)
                        return new[] { new SymmetryAxis(principal[first].Center, principal[first].Direction,
                            principal[second].Direction) }.Concat(axes).ToArray();
            return axes.ToArray();
        }

        private static bool ReflectionMatches(double[][] points, double[] center, double[] direction, double tolerance)
        {
            foreach (double[] point in points)
            {
                double dx = point[0] - center[0], dy = point[1] - center[1];
                double projection = dx * direction[0] + dy * direction[1];
                double[] reflected =
                {
                    center[0] + 2 * projection * direction[0] - dx,
                    center[1] + 2 * projection * direction[1] - dy
                };
                if (!points.Any(candidate => Math.Sqrt((candidate[0] - reflected[0]) * (candidate[0] - reflected[0]) +
                    (candidate[1] - reflected[1]) * (candidate[1] - reflected[1])) <= tolerance)) return false;
            }
            return true;
        }

        private static bool ReflectionEdgesMatch(double[][] polygon, double[] center, double[] direction, double tolerance)
        {
            for (int index = 0; index < polygon.Length; index++)
            {
                double[] first = ReflectPoint(polygon[index], center, direction);
                double[] second = ReflectPoint(polygon[(index + 1) % polygon.Length], center, direction);
                bool matched = Enumerable.Range(0, polygon.Length).Any(candidate =>
                    (Distance2D(first, polygon[candidate]) <= tolerance &&
                     Distance2D(second, polygon[(candidate + 1) % polygon.Length]) <= tolerance) ||
                    (Distance2D(second, polygon[candidate]) <= tolerance &&
                     Distance2D(first, polygon[(candidate + 1) % polygon.Length]) <= tolerance));
                if (!matched) return false;
            }
            return true;
        }

        private static bool ReflectionSegmentsMatch(Tuple<double[], double[]>[] segments, double[] center,
            double[] direction, double tolerance)
        {
            foreach (Tuple<double[], double[]> segment in segments)
            {
                double[] first = ReflectPoint(segment.Item1, center, direction);
                double[] second = ReflectPoint(segment.Item2, center, direction);
                if (!segments.Any(candidate =>
                    (Distance2D(first, candidate.Item1) <= tolerance && Distance2D(second, candidate.Item2) <= tolerance) ||
                    (Distance2D(first, candidate.Item2) <= tolerance && Distance2D(second, candidate.Item1) <= tolerance)))
                    return false;
            }
            return true;
        }

        private static double[] ReflectPoint(double[] point, double[] center, double[] direction)
        {
            double dx = point[0] - center[0], dy = point[1] - center[1];
            double projection = dx * direction[0] + dy * direction[1];
            return new[] { center[0] + 2 * projection * direction[0] - dx,
                center[1] + 2 * projection * direction[1] - dy };
        }

        private static double Distance2D(double[] first, double[] second)
        {
            double dx = first[0] - second[0], dy = first[1] - second[1];
            return Math.Sqrt(dx * dx + dy * dy);
        }

        private static string LengthUnit(eUnits units)
        {
            switch (units)
            {
                case eUnits.lb_in_F:
                case eUnits.kip_in_F: return "in";
                case eUnits.lb_ft_F:
                case eUnits.kip_ft_F: return "ft";
                case eUnits.kN_mm_C:
                case eUnits.kgf_mm_C:
                case eUnits.N_mm_C:
                case eUnits.Ton_mm_C: return "mm";
                case eUnits.kN_cm_C:
                case eUnits.kgf_cm_C:
                case eUnits.N_cm_C:
                case eUnits.Ton_cm_C: return "cm";
                case eUnits.kN_m_C:
                case eUnits.kgf_m_C:
                case eUnits.N_m_C:
                case eUnits.Ton_m_C: return "m";
                default: throw new InvalidOperationException("Unsupported SAP2000 present units: " + units + ".");
            }
        }

        private static void RestoreSelection(cSapModel model, int[] types, string[] names)
        {
            Check(model.SelectObj.ClearSelection(), "clearing the selection");
            for (int i = 0; i < (names == null ? 0 : names.Length); i++)
            {
                string name = names[i];
                switch (types[i])
                {
                    case PointObjectType: Check(model.PointObj.SetSelected(name, true, eItemType.Objects), "restoring selected point " + name); break;
                    case FrameObjectType: Check(model.FrameObj.SetSelected(name, true, eItemType.Objects), "restoring selected frame " + name); break;
                    case CableObjectType: Check(model.CableObj.SetSelected(name, true, eItemType.Objects), "restoring selected cable " + name); break;
                    case TendonObjectType: Check(model.TendonObj.SetSelected(name, true, eItemType.Objects), "restoring selected tendon " + name); break;
                    case AreaObjectType: Check(model.AreaObj.SetSelected(name, true, eItemType.Objects), "restoring selected area " + name); break;
                    case SolidObjectType: Check(model.SolidObj.SetSelected(name, true, eItemType.Objects), "restoring selected solid " + name); break;
                    case LinkObjectType: Check(model.LinkObj.SetSelected(name, true, eItemType.Objects), "restoring selected link " + name); break;
                    default: throw new InvalidOperationException("Unsupported selected SAP2000 object type: " + types[i] + ".");
                }
            }
        }

        private static AreaContext BuildAreaContext(cSapModel model, string areaName)
        {
            int cornerCount = 0;
            string[] cornerNames = null;
            Check(model.AreaObj.GetPoints(areaName, ref cornerCount, ref cornerNames), "reading area vertices for " + areaName);
            if (cornerCount < 3) throw new InvalidOperationException("Area " + areaName + " must have at least three edges.");
            double[][] corners = cornerNames.Select(name => Coordinate(model, name)).ToArray();
            var context = new AreaContext(areaName, cornerNames, corners, Plane.FromPolygon(corners));
            for (int edge = 0; edge < cornerCount; edge++)
            {
                context.EdgePoints[edge].Add(new BoundaryPoint(cornerNames[edge], 0, corners[edge]));
                context.EdgePoints[edge].Add(new BoundaryPoint(cornerNames[(edge + 1) % cornerCount], 1, corners[(edge + 1) % cornerCount]));
            }
            return context;
        }

        private static bool AddConstraintPoint(AreaContext context, string pointName, double[] point, bool captureSnapshot = true)
        {
            if (Math.Abs(context.Plane.SignedDistance(point)) > Tolerance) return false;
            for (int edge = 0; edge < context.Corners.Length; edge++)
            {
                double t;
                if (!OnSegment(point, context.Corners[edge], context.Corners[(edge + 1) % context.Corners.Length], out t)) continue;
                if (!context.EdgePoints[edge].Any(item => Math.Abs(item.T - t) <= Tolerance))
                    context.EdgePoints[edge].Add(new BoundaryPoint(pointName, t, point));
                if (captureSnapshot) context.ConstraintPointNames.Add(pointName);
                return true;
            }
            if (!PointInPolygon(context.Plane.Project(point), context.Corners.Select(context.Plane.Project).ToArray())) return false;
            if (!context.InteriorPoints.Any(item => Distance(item.Coordinates, point) <= Tolerance))
                context.InteriorPoints.Add(new ConstraintPoint(pointName, point));
            if (captureSnapshot) context.ConstraintPointNames.Add(pointName);
            return true;
        }

        private static bool FrameBelongsToArea(AreaContext context, double[] first, double[] second)
        {
            if (Math.Abs(context.Plane.SignedDistance(first)) > Tolerance || Math.Abs(context.Plane.SignedDistance(second)) > Tolerance)
                return false;
            double[][] polygon = context.Corners.Select(context.Plane.Project).ToArray();
            for (int sample = 0; sample <= 20; sample++)
            {
                double t = sample / 20.0;
                double[] point = Enumerable.Range(0, 3).Select(axis => first[axis] * (1 - t) + second[axis] * t).ToArray();
                if (!PointInsideOrBoundary(context.Plane.Project(point), polygon)) return false;
            }
            return true;
        }

        private static bool FrameOnBoundary(AreaContext context, double[] first, double[] second)
        {
            for (int edge = 0; edge < context.Corners.Length; edge++)
            {
                double firstT, secondT;
                if (OnSegment(first, context.Corners[edge], context.Corners[(edge + 1) % context.Corners.Length], out firstT) &&
                    OnSegment(second, context.Corners[edge], context.Corners[(edge + 1) % context.Corners.Length], out secondT)) return true;
            }
            return false;
        }

        private static void HarmonizeSharedBoundaries(List<AreaContext> contexts, double maxSize)
        {
            if (contexts.Count < 2) return;
            var sharedEdges = new HashSet<string>();
            for (int firstArea = 0; firstArea < contexts.Count; firstArea++)
                for (int secondArea = firstArea + 1; secondArea < contexts.Count; secondArea++)
                    for (int firstEdge = 0; firstEdge < contexts[firstArea].Corners.Length; firstEdge++)
                        for (int secondEdge = 0; secondEdge < contexts[secondArea].Corners.Length; secondEdge++)
                        {
                            double[] overlapStart, overlapEnd;
                            if (!TryGetCollinearOverlap(
                                contexts[firstArea].Corners[firstEdge], contexts[firstArea].Corners[(firstEdge + 1) % contexts[firstArea].Corners.Length],
                                contexts[secondArea].Corners[secondEdge], contexts[secondArea].Corners[(secondEdge + 1) % contexts[secondArea].Corners.Length],
                                out overlapStart, out overlapEnd)) continue;
                            sharedEdges.Add(firstArea + ":" + firstEdge);
                            sharedEdges.Add(secondArea + ":" + secondEdge);
                            var breakpoints = new List<double[]> { overlapStart, overlapEnd };
                            foreach (BoundaryPoint point in contexts[firstArea].EdgePoints[firstEdge].Concat(contexts[secondArea].EdgePoints[secondEdge]))
                            {
                                double ignored;
                                if (OnSegment(point.Coordinates, overlapStart, overlapEnd, out ignored) &&
                                    !breakpoints.Any(existing => Distance(existing, point.Coordinates) <= Tolerance))
                                    breakpoints.Add(point.Coordinates);
                            }
                            double[] direction = Subtract(overlapEnd, overlapStart);
                            double lengthSquared = Dot(direction, direction);
                            breakpoints = breakpoints.OrderBy(point => Dot(Subtract(point, overlapStart), direction) / lengthSquared).ToList();
                            for (int i = 1; i < breakpoints.Count; i++)
                            {
                                int divisions = Math.Max(1, (int)Math.Ceiling(Distance(breakpoints[i - 1], breakpoints[i]) / maxSize - 1e-9));
                                for (int division = 0; division <= divisions; division++)
                                {
                                    double t = (double)division / divisions;
                                    double[] point = Enumerable.Range(0, 3).Select(axis => breakpoints[i - 1][axis] * (1 - t) + breakpoints[i][axis] * t).ToArray();
                                    AddBoundaryCoordinate(contexts[firstArea], firstEdge, point);
                                    AddBoundaryCoordinate(contexts[secondArea], secondEdge, point);
                                }
                            }
                        }

            foreach (string key in sharedEdges)
            {
                string[] fields = key.Split(':');
                AreaContext context = contexts[int.Parse(fields[0], CultureInfo.InvariantCulture)];
                int edge = int.Parse(fields[1], CultureInfo.InvariantCulture);
                List<BoundaryPoint> points = context.EdgePoints[edge].OrderBy(point => point.T).ToList();
                for (int i = 1; i < points.Count; i++)
                {
                    int divisions = Math.Max(1, (int)Math.Ceiling(Distance(points[i - 1].Coordinates, points[i].Coordinates) / maxSize - 1e-9));
                    for (int division = 1; division < divisions; division++)
                    {
                        double t = (double)division / divisions;
                        AddBoundaryCoordinate(context, edge, Enumerable.Range(0, 3)
                            .Select(axis => points[i - 1].Coordinates[axis] * (1 - t) + points[i].Coordinates[axis] * t).ToArray());
                    }
                }
                context.EdgePoints[edge] = context.EdgePoints[edge].OrderBy(point => point.T).ToList();
            }
        }

        private static void AddBoundaryCoordinate(AreaContext context, int edge, double[] point)
        {
            double t;
            if (!OnSegment(point, context.Corners[edge], context.Corners[(edge + 1) % context.Corners.Length], out t))
                throw new InvalidOperationException("Failed to discretize a shared edge.");
            if (!context.EdgePoints[edge].Any(existing => Math.Abs(existing.T - t) <= Tolerance))
                context.EdgePoints[edge].Add(new BoundaryPoint("QT_SHARED", t, point));
        }

        private static void HarmonizeAreaEdgeIntersections(List<AreaContext> contexts, double maxSize)
        {
            var userConstrainedEdges = new HashSet<string>();
            var automaticBoundaryEdges = new HashSet<string>();
            var intersections = new List<AreaEdgeIntersection>();
            foreach (AreaContext context in contexts)
            {
                context.FrameConstraints.RemoveAll(frame => frame.Automatic);
                context.ForceRefinement = false;
            }
            for (int contextIndex = 0; contextIndex < contexts.Count; contextIndex++)
                for (int edge = 0; edge < contexts[contextIndex].EdgePoints.Length; edge++)
                    if (contexts[contextIndex].EdgePoints[edge].Count > 2)
                        userConstrainedEdges.Add(contextIndex + ":" + edge);
            for (int sourceIndex = 0; sourceIndex < contexts.Count; sourceIndex++)
                for (int hostIndex = 0; hostIndex < contexts.Count; hostIndex++)
                {
                    if (sourceIndex == hostIndex) continue;
                    AreaContext source = contexts[sourceIndex], host = contexts[hostIndex];
                    if (Math.Abs(Dot(source.Plane.Normal, host.Plane.Normal)) >= 1 - 1e-8) continue;
                    for (int edge = 0; edge < source.Corners.Length; edge++)
                    {
                        double[] first = source.Corners[edge], second = source.Corners[(edge + 1) % source.Corners.Length];
                        foreach (SegmentInterval interval in ClipSegmentToArea(host, first, second))
                            intersections.Add(new AreaEdgeIntersection(sourceIndex, edge, hostIndex, interval.Start, interval.End));
                    }
                }

            foreach (AreaEdgeIntersection intersection in intersections)
            {
                AreaContext source = contexts[intersection.SourceIndex];
                double[] first = source.Corners[intersection.SourceEdge];
                double[] second = source.Corners[(intersection.SourceEdge + 1) % source.Corners.Length];
                AddBoundaryCoordinate(source, intersection.SourceEdge, Interpolate(first, second, intersection.Start));
                AddBoundaryCoordinate(source, intersection.SourceEdge, Interpolate(first, second, intersection.End));
            }

            foreach (AreaEdgeIntersection intersection in intersections)
            {
                AreaContext source = contexts[intersection.SourceIndex];
                List<BoundaryPoint> current = source.EdgePoints[intersection.SourceEdge]
                    .Where(point => point.T >= intersection.Start - Tolerance && point.T <= intersection.End + Tolerance)
                    .OrderBy(point => point.T).ToList();
                for (int i = 1; i < current.Count; i++)
                {
                    int divisions = Math.Max(1, (int)Math.Ceiling(Distance(current[i - 1].Coordinates, current[i].Coordinates) / maxSize - 1e-9));
                    for (int division = 1; division < divisions; division++)
                        AddBoundaryCoordinate(source, intersection.SourceEdge,
                            Interpolate(current[i - 1].Coordinates, current[i].Coordinates, (double)division / divisions));
                }
                source.EdgePoints[intersection.SourceEdge] = source.EdgePoints[intersection.SourceEdge].OrderBy(point => point.T).ToList();
            }

            foreach (AreaEdgeIntersection intersection in intersections)
            {
                AreaContext source = contexts[intersection.SourceIndex], host = contexts[intersection.HostIndex];
                source.ForceRefinement = true;
                List<BoundaryPoint> points = source.EdgePoints[intersection.SourceEdge]
                    .Where(point => point.T >= intersection.Start - Tolerance && point.T <= intersection.End + Tolerance)
                    .OrderBy(point => point.T).ToList();
                for (int i = 1; i < points.Count; i++)
                {
                    BoundaryPoint start = points[i - 1], end = points[i];
                    if (Distance(start.Coordinates, end.Coordinates) <= Tolerance) continue;
                    AddConstraintPoint(host, start.Name, start.Coordinates, false);
                    AddConstraintPoint(host, end.Name, end.Coordinates, false);
                    for (int hostEdge = 0; hostEdge < host.Corners.Length; hostEdge++)
                    {
                        double ignored;
                        if (OnSegment(start.Coordinates, host.Corners[hostEdge], host.Corners[(hostEdge + 1) % host.Corners.Length], out ignored) ||
                            OnSegment(end.Coordinates, host.Corners[hostEdge], host.Corners[(hostEdge + 1) % host.Corners.Length], out ignored))
                            automaticBoundaryEdges.Add(intersection.HostIndex + ":" + hostEdge);
                    }
                    if (!host.FrameConstraints.Any(frame => SameSegment(frame.First, frame.Second, start.Coordinates, end.Coordinates)))
                        host.FrameConstraints.Add(new FrameConstraint("QT_INTERSECTION_" + source.Name + "_" + (intersection.SourceEdge + 1),
                            start.Name, end.Name, start.Coordinates, end.Coordinates, true, source, intersection.SourceEdge));
                }
            }

            foreach (AreaContext context in contexts) SplitConstraintIntersections(context);
            foreach (AreaContext context in contexts) SplitAutomaticConstraintsAtSourcePoints(context);
            foreach (string key in automaticBoundaryEdges.Where(key => !userConstrainedEdges.Contains(key)))
            {
                string[] fields = key.Split(':');
                AreaContext context = contexts[int.Parse(fields[0], CultureInfo.InvariantCulture)];
                int edge = int.Parse(fields[1], CultureInfo.InvariantCulture);
                List<BoundaryPoint> points = context.EdgePoints[edge].OrderBy(point => point.T).ToList();
                for (int i = 1; i < points.Count; i++)
                {
                    int divisions = Math.Max(1, (int)Math.Ceiling(Distance(points[i - 1].Coordinates, points[i].Coordinates) / maxSize - 1e-9));
                    for (int division = 1; division < divisions; division++)
                    {
                        double t = (double)division / divisions;
                        AddBoundaryCoordinate(context, edge, Enumerable.Range(0, 3)
                            .Select(axis => points[i - 1].Coordinates[axis] * (1 - t) + points[i].Coordinates[axis] * t).ToArray());
                    }
                }
                context.EdgePoints[edge] = context.EdgePoints[edge].OrderBy(point => point.T).ToList();
            }
        }

        private static List<SegmentInterval> ClipSegmentToArea(AreaContext host, double[] first, double[] second)
        {
            var intervals = new List<SegmentInterval>();
            if (Math.Abs(host.Plane.SignedDistance(first)) > Tolerance || Math.Abs(host.Plane.SignedDistance(second)) > Tolerance)
                return intervals;
            double[] start = host.Plane.Project(first), end = host.Plane.Project(second);
            double[][] polygon = host.Corners.Select(host.Plane.Project).ToArray();
            var parameters = new List<double> { 0, 1 };
            for (int edge = 0; edge < polygon.Length; edge++)
                AddSegmentIntersectionParameters(start, end, polygon[edge], polygon[(edge + 1) % polygon.Length], parameters);
            List<double> sorted = parameters.Select(value => Math.Max(0, Math.Min(1, value))).OrderBy(value => value).ToList();
            var unique = new List<double>();
            foreach (double value in sorted)
                if (unique.Count == 0 || Math.Abs(unique[unique.Count - 1] - value) > Tolerance) unique.Add(value);
            for (int i = 1; i < unique.Count; i++)
            {
                double low = unique[i - 1], high = unique[i];
                if ((high - low) * Distance(first, second) <= Tolerance) continue;
                if (!PointInsideOrBoundary(Interpolate(start, end, (low + high) * 0.5), polygon)) continue;
                if (!FrameOnBoundary(host, Interpolate(first, second, low), Interpolate(first, second, high)))
                    intervals.Add(new SegmentInterval(low, high));
            }
            return intervals;
        }

        private static void AddSegmentIntersectionParameters(double[] first, double[] second, double[] edgeFirst, double[] edgeSecond,
            List<double> parameters)
        {
            double rx = second[0] - first[0], ry = second[1] - first[1];
            double sx = edgeSecond[0] - edgeFirst[0], sy = edgeSecond[1] - edgeFirst[1];
            double qx = edgeFirst[0] - first[0], qy = edgeFirst[1] - first[1];
            double denominator = Cross2(rx, ry, sx, sy);
            if (Math.Abs(denominator) > Tolerance)
            {
                double t = Cross2(qx, qy, sx, sy) / denominator;
                double u = Cross2(qx, qy, rx, ry) / denominator;
                if (t >= -Tolerance && t <= 1 + Tolerance && u >= -Tolerance && u <= 1 + Tolerance) parameters.Add(t);
                return;
            }
            if (Math.Abs(Cross2(qx, qy, rx, ry)) > Tolerance) return;
            double lengthSquared = rx * rx + ry * ry;
            if (lengthSquared <= Tolerance * Tolerance) return;
            parameters.Add((qx * rx + qy * ry) / lengthSquared);
            parameters.Add(((edgeSecond[0] - first[0]) * rx + (edgeSecond[1] - first[1]) * ry) / lengthSquared);
        }

        private static void SplitConstraintIntersections(AreaContext host)
        {
            List<FrameConstraint> frames = host.FrameConstraints.OrderByDescending(frame => frame.Automatic).ToList();
            var breakpoints = frames.Select(frame => new List<double[]> { frame.First, frame.Second }).ToArray();
            for (int first = 0; first < frames.Count; first++)
                for (int second = first + 1; second < frames.Count; second++)
                    AddConstraintIntersection(host.Plane, frames[first], frames[second], breakpoints[first], breakpoints[second]);
            host.FrameConstraints.Clear();
            for (int index = 0; index < frames.Count; index++)
            {
                FrameConstraint frame = frames[index];
                List<double[]> points = breakpoints[index].OrderBy(point => SegmentParameter(point, frame.First, frame.Second)).ToList();
                for (int i = 1; i < points.Count; i++)
                {
                    double[] first = points[i - 1], second = points[i];
                    if (Distance(first, second) <= Tolerance || host.FrameConstraints.Any(item => SameSegment(item.First, item.Second, first, second))) continue;
                    AddConstraintPoint(host, "QT_INTERSECTION", first, false);
                    AddConstraintPoint(host, "QT_INTERSECTION", second, false);
                    if (frame.Automatic)
                    {
                        AddBoundaryCoordinate(frame.SourceContext, frame.SourceEdge, first);
                        AddBoundaryCoordinate(frame.SourceContext, frame.SourceEdge, second);
                    }
                    host.FrameConstraints.Add(new FrameConstraint(frame.Name, frame.FirstName, frame.SecondName, first, second,
                        frame.Automatic, frame.SourceContext, frame.SourceEdge));
                }
            }
        }

        private static void AddConstraintIntersection(Plane plane, FrameConstraint first, FrameConstraint second,
            List<double[]> firstPoints, List<double[]> secondPoints)
        {
            double[] a = plane.Project(first.First), b = plane.Project(first.Second);
            double[] c = plane.Project(second.First), d = plane.Project(second.Second);
            double rx = b[0] - a[0], ry = b[1] - a[1], sx = d[0] - c[0], sy = d[1] - c[1];
            double qx = c[0] - a[0], qy = c[1] - a[1], denominator = Cross2(rx, ry, sx, sy);
            if (Math.Abs(denominator) > Tolerance)
            {
                double t = Cross2(qx, qy, sx, sy) / denominator;
                double u = Cross2(qx, qy, rx, ry) / denominator;
                if (t >= -Tolerance && t <= 1 + Tolerance && u >= -Tolerance && u <= 1 + Tolerance)
                {
                    double[] point = Interpolate(first.First, first.Second, Math.Max(0, Math.Min(1, t)));
                    AddUniquePoint(firstPoints, point); AddUniquePoint(secondPoints, point);
                }
                return;
            }
            if (Math.Abs(Cross2(qx, qy, rx, ry)) > Tolerance) return;
            foreach (double[] point in new[] { first.First, first.Second, second.First, second.Second })
            {
                double firstT, secondT;
                if (OnSegment(point, first.First, first.Second, out firstT) && OnSegment(point, second.First, second.Second, out secondT))
                { AddUniquePoint(firstPoints, point); AddUniquePoint(secondPoints, point); }
            }
        }

        private static void SplitAutomaticConstraintsAtSourcePoints(AreaContext host)
        {
            var split = new List<FrameConstraint>();
            foreach (FrameConstraint frame in host.FrameConstraints)
            {
                if (!frame.Automatic)
                {
                    split.Add(frame);
                    continue;
                }
                List<double[]> points = frame.SourceContext.EdgePoints[frame.SourceEdge].Select(point => point.Coordinates)
                    .Where(point =>
                    {
                        double ignored;
                        return OnSegment(point, frame.First, frame.Second, out ignored);
                    }).OrderBy(point => SegmentParameter(point, frame.First, frame.Second)).ToList();
                for (int i = 1; i < points.Count; i++)
                    if (Distance(points[i - 1], points[i]) > Tolerance &&
                        !split.Any(item => SameSegment(item.First, item.Second, points[i - 1], points[i])))
                        split.Add(new FrameConstraint(frame.Name, frame.FirstName, frame.SecondName, points[i - 1], points[i],
                            true, frame.SourceContext, frame.SourceEdge));
            }
            host.FrameConstraints.Clear();
            host.FrameConstraints.AddRange(split);
        }

        private static void AddUniquePoint(List<double[]> points, double[] point)
        {
            if (!points.Any(existing => Distance(existing, point) <= Tolerance)) points.Add(point);
        }

        private static bool SameSegment(double[] firstStart, double[] firstEnd, double[] secondStart, double[] secondEnd)
        {
            return (Distance(firstStart, secondStart) <= Tolerance && Distance(firstEnd, secondEnd) <= Tolerance) ||
                (Distance(firstStart, secondEnd) <= Tolerance && Distance(firstEnd, secondStart) <= Tolerance);
        }

        private static double SegmentParameter(double[] point, double[] first, double[] second)
        {
            double[] direction = Subtract(second, first);
            return Dot(Subtract(point, first), direction) / Dot(direction, direction);
        }

        private static double[] Interpolate(double[] first, double[] second, double t)
        {
            return Enumerable.Range(0, first.Length).Select(axis => first[axis] * (1 - t) + second[axis] * t).ToArray();
        }

        private static double Cross2(double ax, double ay, double bx, double by) { return ax * by - ay * bx; }

        private static bool TryGetCollinearOverlap(double[] firstStart, double[] firstEnd, double[] secondStart, double[] secondEnd,
            out double[] overlapStart, out double[] overlapEnd)
        {
            overlapStart = overlapEnd = null;
            double[] firstDirection = Subtract(firstEnd, firstStart), secondDirection = Subtract(secondEnd, secondStart);
            double firstLength = Norm(firstDirection), secondLength = Norm(secondDirection);
            if (Norm(Cross(firstDirection, secondDirection)) > Tolerance * firstLength * secondLength) return false;
            if (Norm(Cross(Subtract(secondStart, firstStart), firstDirection)) > Tolerance * firstLength ||
                Norm(Cross(Subtract(secondEnd, firstStart), firstDirection)) > Tolerance * firstLength) return false;
            double denominator = Dot(firstDirection, firstDirection);
            double secondT0 = Dot(Subtract(secondStart, firstStart), firstDirection) / denominator;
            double secondT1 = Dot(Subtract(secondEnd, firstStart), firstDirection) / denominator;
            double low = Math.Max(0, Math.Min(secondT0, secondT1));
            double high = Math.Min(1, Math.Max(secondT0, secondT1));
            if ((high - low) * firstLength <= Tolerance) return false;
            overlapStart = Enumerable.Range(0, 3).Select(axis => firstStart[axis] + low * firstDirection[axis]).ToArray();
            overlapEnd = Enumerable.Range(0, 3).Select(axis => firstStart[axis] + high * firstDirection[axis]).ToArray();
            return true;
        }

        private static MeshQualityReport CombineQuality(List<AreaContext> contexts, List<MeshAttemptResult> results)
        {
            if (results.Count == 1) return results[0].Quality;
            var combined = new MeshQualityReport(results.All(result => result.Quality.Passed),
                "Areas processed: " + results.Count + ". Details are reported separately for each area.");
            for (int i = 0; i < results.Count; i++)
                foreach (QualityMetric metric in results[i].Quality.Metrics)
                    combined.Metrics.Add(new QualityMetric(contexts[i].Name + " - " + metric.Name,
                        metric.Value, metric.Reference, metric.Score));
            return combined;
        }

        private static MeshAttemptResult ExecuteMeshAttempt(cSapModel model, string areaName, int cornerCount,
            string[] sourceCornerNames, double[][] sourceCorners, List<BoundaryPoint>[] sourceEdgePoints,
            List<ConstraintPoint> interiorPoints, string[] selectedPoints, List<FrameConstraint> frameConstraints,
            List<HoleDefinition> holes, bool forceRefinement, Plane plane, SymmetryAxis symmetryAxis,
            MeshOptionsDialog dialog, PointCoordinateIndex pointIndex, List<AreaContext> allContexts)
        {
            double maxSize = dialog.MaxSize;
            bool symmetric = dialog.Symmetric && symmetryAxis != null;
            dialog.BeginWork("Preparing geometry...");
            string[] cornerNames = sourceCornerNames;
            double[][] corners = sourceCorners;
            List<BoundaryPoint>[] edgePoints = sourceEdgePoints;
            bool rectangularTransition = false;
            int transitionPair;

            if (!forceRefinement && frameConstraints.Count == 0 && holes.Count == 0 && cornerCount == 4 && interiorPoints.Count == 0 && TryGetTransitionPair(edgePoints, out transitionPair))
            {
                if (transitionPair == 1)
                {
                    cornerNames = Rotate(cornerNames, 1);
                    corners = Rotate(corners, 1);
                    edgePoints = Rotate(edgePoints, 1);
                }
                try
                {
                    EnsureRectangularSymmetry(corners);
                    rectangularTransition = true;
                }
                catch
                {
                    rectangularTransition = false;
                }
            }

            if (symmetric)
            {
                if (symmetryAxis == null)
                    throw new InvalidOperationException("Select a symmetry axis compatible with the area and its constrained points.");
            }

            var regularGuidePoints = new List<double[]>();
            if (dialog.PreferRegularMesh)
            {
                List<AreaContext> coplanar = allContexts.Where(context =>
                    context.Corners.All(point => Math.Abs(plane.SignedDistance(point)) <= Tolerance)).ToList();
                regularGuidePoints.AddRange(coplanar.SelectMany(context => context.Corners));
                regularGuidePoints.AddRange(coplanar.SelectMany(context => context.FrameConstraints)
                    .SelectMany(frame => new[] { frame.First, frame.Second }));
                double[][] projected = regularGuidePoints.Select(plane.Project).ToArray();
                if (projected.Length > 0)
                    regularGuidePoints.Add(plane.PointFromPlane(
                        (projected.Min(point => point[0]) + projected.Max(point => point[0])) * 0.5,
                        (projected.Min(point => point[1]) + projected.Max(point => point[1])) * 0.5));
            }

            string property = "";
            double localAngle = 0, mass = 0;
            bool localAdvanced = false, edgeConstraint = false;
            Check(model.AreaObj.GetProperty(areaName, ref property), "reading the area property");
            model.AreaObj.GetLocalAxes(areaName, ref localAngle, ref localAdvanced);
            model.AreaObj.GetMass(areaName, ref mass);
            model.AreaObj.GetEdgeConstraint(areaName, ref edgeConstraint);
            if (localAdvanced) throw new InvalidOperationException("Advanced local axes are not supported.");
            AreaLoads areaLoads = CaptureAreaLoads(model, areaName);
            PointSnapshot[] originalPoints = CapturePointSnapshots(model,
                sourceCornerNames.Concat(selectedPoints).Concat(holes.Select(hole => hole.PointName)));

            string token = Guid.NewGuid().ToString("N");
            string boundaryFile = Path.Combine(Path.GetTempPath(), "sap_mesh_boundary_" + token + ".csv");
            string meshFile = Path.Combine(Path.GetTempPath(), "sap_mesh_output_" + token + ".csv");
            try
            {
                WriteBoundary(boundaryFile, areaName, property, cornerNames, corners, edgePoints, interiorPoints,
                    frameConstraints, holes, symmetric ? symmetryAxis : null, forceRefinement, dialog.StressRefinement,
                    dialog.PreferRegularMesh, regularGuidePoints);
                string boundaryTrace = Environment.GetEnvironmentVariable("SAP_QUAD_BOUNDARY_TRACE");
                if (!string.IsNullOrEmpty(boundaryTrace)) File.Copy(boundaryFile, boundaryTrace, true);
                string boundaryTraceDirectory = Environment.GetEnvironmentVariable("SAP_QUAD_BOUNDARY_TRACE_DIR");
                if (!string.IsNullOrEmpty(boundaryTraceDirectory))
                    File.Copy(boundaryFile, Path.Combine(boundaryTraceDirectory, "area-" + areaName + "-boundary.csv"), true);
                string scriptName = symmetric && rectangularTransition ? "sap_quad_transition_mesher.py" :
                    (rectangularTransition ? "sap_rectangular_transition_mesher.py" : "sap_general_polygon_mesher.py");
                dialog.SetIndeterminate("Generating and optimizing the mesh...");
                RunMesher(scriptName, boundaryFile, meshFile, maxSize);
                MeshData mesh = ReadMesh(meshFile);
                if (symmetric) ValidateMeshSymmetry(mesh, symmetryAxis);
                if (dialog.GenerateHoles || holes.Count > 0) RemoveEnclosedElements(mesh, areaName, allContexts);
                MeshQualityReport quality = EvaluateMeshQuality(mesh, plane, AllowedMaxSize(maxSize, edgePoints), frameConstraints.Count);
                MeshOperation operation = dialog.FastMode
                    ? ApplyMeshFast(model, areaName, property, localAngle, mass, edgeConstraint, areaLoads, mesh, dialog, originalPoints, pointIndex)
                    : ApplyMesh(model, areaName, property, localAngle, mass, edgeConstraint, areaLoads, mesh, dialog, originalPoints, pointIndex);
                PropagateGeneratedIntersectionEdges(areaName, plane, mesh, allContexts);
                return new MeshAttemptResult(operation, quality);
            }
            catch
            {
                string failedBoundary = Environment.GetEnvironmentVariable("SAP_QUAD_FAILED_BOUNDARY");
                if (!string.IsNullOrEmpty(failedBoundary))
                    try { File.Copy(boundaryFile, failedBoundary, true); } catch { }
                throw;
            }
            finally
            {
                TryDelete(boundaryFile);
                TryDelete(meshFile);
            }
        }

        private static void PropagateGeneratedIntersectionEdges(string sourceArea, Plane sourcePlane,
            MeshData mesh, List<AreaContext> contexts)
        {
            int sourceIndex = contexts.FindIndex(context => context.Name == sourceArea);
            if (sourceIndex < 0 || sourceIndex == contexts.Count - 1) return;
            var meshEdges = mesh.Elements.SelectMany(element => Enumerable.Range(0, element.Length)
                .Select(index => new[] { mesh.Nodes[element[index]], mesh.Nodes[element[(index + 1) % element.Length]] })).ToList();
            foreach (AreaContext target in contexts.Skip(sourceIndex + 1))
                for (int edge = 0; edge < target.Corners.Length; edge++)
                {
                    double[] start = target.Corners[edge], end = target.Corners[(edge + 1) % target.Corners.Length];
                    if (Math.Abs(sourcePlane.SignedDistance(start)) > Tolerance ||
                        Math.Abs(sourcePlane.SignedDistance(end)) > Tolerance) continue;
                    foreach (double[][] segment in meshEdges)
                    {
                        double firstT, secondT;
                        if (!OnSegment(segment[0], start, end, out firstT) ||
                            !OnSegment(segment[1], start, end, out secondT) ||
                            Math.Abs(firstT - secondT) <= Tolerance) continue;
                        AddBoundaryCoordinate(target, edge, segment[0]);
                        AddBoundaryCoordinate(target, edge, segment[1]);
                    }
                    target.EdgePoints[edge] = target.EdgePoints[edge].OrderBy(point => point.T).ToList();
                }
        }

        private static bool TryGetTransitionPair(List<BoundaryPoint>[] edges, out int pairStart)
        {
            bool constrained02 = edges[0].Count > 2 && edges[2].Count > 2;
            bool constrained13 = edges[1].Count > 2 && edges[3].Count > 2;
            pairStart = constrained02 ? 0 : 1;
            return constrained02 != constrained13;
        }

        private static void ValidateMeshSymmetry(MeshData mesh, SymmetryAxis symmetryAxis)
        {
            var signatures = new HashSet<string>(mesh.Elements.Select(element => MeshElementSignature(mesh, element)));
            foreach (int[] element in mesh.Elements)
            {
                string reflected = MeshElementSignature(element.Select(tag =>
                    ReflectPoint3D(mesh.Nodes[tag], symmetryAxis.Center, symmetryAxis.Direction)));
                if (!signatures.Contains(reflected))
                    throw new InvalidDataException("The generated transition mesh is not exactly symmetric about the selected axis.");
                if (symmetryAxis.SecondaryDirection == null) continue;
                string secondary = MeshElementSignature(element.Select(tag =>
                    ReflectPoint3D(mesh.Nodes[tag], symmetryAxis.Center, symmetryAxis.SecondaryDirection)));
                if (!signatures.Contains(secondary))
                    throw new InvalidDataException("The generated transition mesh is not exactly symmetric about the secondary axis.");
            }
        }

        private static string MeshElementSignature(MeshData mesh, int[] element)
        {
            return MeshElementSignature(element.Select(tag => mesh.Nodes[tag]));
        }

        private static string MeshElementSignature(IEnumerable<double[]> points)
        {
            return string.Join("|", points.Select(point => string.Join(":", point.Select(value =>
                Math.Round(value, 8).ToString("R", CultureInfo.InvariantCulture)))).OrderBy(value => value));
        }

        private static double[] ReflectPoint3D(double[] point, double[] center, double[] direction)
        {
            double[] offset = Subtract(point, center);
            double projection = Dot(offset, direction);
            return Enumerable.Range(0, 3).Select(axis => center[axis] + 2 * projection * direction[axis] - offset[axis]).ToArray();
        }

        private static void ValidateSymmetricEdges(List<BoundaryPoint> first, List<BoundaryPoint> opposite)
        {
            foreach (List<BoundaryPoint> edge in new[] { first, opposite })
            {
                int segments = edge.Count - 1;
                if (segments < 2 || segments % 2 != 0)
                    throw new InvalidOperationException("In symmetric mode, each transition edge must have an even number of intervals.");
                for (int i = 0; i < edge.Count; i++)
                    if (Math.Abs(edge[i].T + edge[edge.Count - 1 - i].T - 1) > 1e-5)
                        throw new InvalidOperationException("The edge distribution is not symmetric about the midpoint.");
            }
        }

        private static void WriteBoundary(string path, string area, string property, string[] names, double[][] corners,
            List<BoundaryPoint>[] edges, List<ConstraintPoint> interior, List<FrameConstraint> frames,
            List<HoleDefinition> holes, SymmetryAxis symmetryAxis, bool forceRefinement, bool stressRefinement,
            bool preferRegular, List<double[]> regularGuidePoints)
        {
            using (var writer = new StreamWriter(path, false, Encoding.ASCII))
            {
                writer.WriteLine("AREA," + area + "," + property);
                if (forceRefinement) writer.WriteLine("REFINE,1");
                if (stressRefinement) writer.WriteLine("STRESS_REFINE,1");
                if (preferRegular) writer.WriteLine("PREFER_REGULAR,1");
                foreach (double[] point in regularGuidePoints)
                    WritePointRow(writer, "REGULAR_POINT", 0, "", 0, point);
                if (symmetryAxis != null)
                {
                    writer.WriteLine(string.Join(",", "SYMMETRY",
                        symmetryAxis.Center[0].ToString("R", CultureInfo.InvariantCulture),
                        symmetryAxis.Center[1].ToString("R", CultureInfo.InvariantCulture),
                        symmetryAxis.Center[2].ToString("R", CultureInfo.InvariantCulture),
                        symmetryAxis.Direction[0].ToString("R", CultureInfo.InvariantCulture),
                        symmetryAxis.Direction[1].ToString("R", CultureInfo.InvariantCulture),
                        symmetryAxis.Direction[2].ToString("R", CultureInfo.InvariantCulture)));
                    if (symmetryAxis.SecondaryDirection != null)
                        writer.WriteLine(string.Join(",", "SYMMETRY2",
                            symmetryAxis.Center[0].ToString("R", CultureInfo.InvariantCulture),
                            symmetryAxis.Center[1].ToString("R", CultureInfo.InvariantCulture),
                            symmetryAxis.Center[2].ToString("R", CultureInfo.InvariantCulture),
                            symmetryAxis.SecondaryDirection[0].ToString("R", CultureInfo.InvariantCulture),
                            symmetryAxis.SecondaryDirection[1].ToString("R", CultureInfo.InvariantCulture),
                            symmetryAxis.SecondaryDirection[2].ToString("R", CultureInfo.InvariantCulture)));
                }
                for (int i = 0; i < corners.Length; i++) WritePointRow(writer, "CORNER", i + 1, names[i], 0, corners[i]);
                for (int edge = 0; edge < edges.Length; edge++)
                    foreach (BoundaryPoint point in edges[edge]) WritePointRow(writer, "EDGE", edge + 1, point.Name, point.T, point.Coordinates);
                foreach (ConstraintPoint point in interior) WritePointRow(writer, "INTERIOR", 0, point.Name, 0, point.Coordinates);
                foreach (HoleDefinition hole in holes)
                    WritePointRow(writer, "HOLE", hole.Id, "", hole.Diameter, hole.Center);
                for (int i = 0; i < frames.Count; i++)
                {
                    FrameConstraint frame = frames[i];
                    writer.WriteLine(string.Join(",", "FRAME", (i + 1).ToString(CultureInfo.InvariantCulture), frame.Name, "0",
                        frame.First[0].ToString("R", CultureInfo.InvariantCulture), frame.First[1].ToString("R", CultureInfo.InvariantCulture), frame.First[2].ToString("R", CultureInfo.InvariantCulture),
                        frame.Second[0].ToString("R", CultureInfo.InvariantCulture), frame.Second[1].ToString("R", CultureInfo.InvariantCulture), frame.Second[2].ToString("R", CultureInfo.InvariantCulture),
                        frame.Automatic ? "1" : "0", frame.CanBoundOpening ? "1" : "0"));
                }
            }
        }

        private static void WritePointRow(StreamWriter writer, string kind, int edge, string name, double t, double[] p)
        {
            writer.WriteLine(string.Join(",", kind, edge.ToString(CultureInfo.InvariantCulture), name,
                t.ToString("R", CultureInfo.InvariantCulture), p[0].ToString("R", CultureInfo.InvariantCulture),
                p[1].ToString("R", CultureInfo.InvariantCulture), p[2].ToString("R", CultureInfo.InvariantCulture)));
        }

        private static string RunMesher(string scriptName, string boundary, string mesh, double maxSize)
        {
            string pluginDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            string script = Path.Combine(pluginDirectory, scriptName);
            string backend = Path.Combine(pluginDirectory, "mesher", "SapQuadMesherBackend.exe");
            if (!File.Exists(script)) throw new FileNotFoundException("Mesh script not found.", script);
            if (!File.Exists(backend)) throw new FileNotFoundException("The Python/Gmsh runtime bundled with the plugin was not found.", backend);
            var start = new ProcessStartInfo(backend, Quote(script) + " " + Quote(boundary) + " " + Quote(mesh) + " " +
                maxSize.ToString("R", CultureInfo.InvariantCulture))
            {
                UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true,
                WorkingDirectory = pluginDirectory
            };
            start.EnvironmentVariables.Remove("PYTHONHOME");
            start.EnvironmentVariables.Remove("PYTHONPATH");
            start.EnvironmentVariables["PYTHONNOUSERSITE"] = "1";
            start.EnvironmentVariables["PYTHONDONTWRITEBYTECODE"] = "1";
            var backendClock = Stopwatch.StartNew();
            using (Process process = Process.Start(start))
            {
                string profileDirectory = Environment.GetEnvironmentVariable("SAP_QUAD_PROFILE_DIR");
                if (!string.IsNullOrEmpty(profileDirectory))
                    try { File.AppendAllText(Path.Combine(profileDirectory, "backend-start.csv"),
                        process.Id.ToString(CultureInfo.InvariantCulture) + Environment.NewLine); } catch { }
                try
                {
                    var outputTask = process.StandardOutput.ReadToEndAsync();
                    var errorTask = process.StandardError.ReadToEndAsync();
                    while (!process.WaitForExit(50)) Application.DoEvents();
                    string output = outputTask.GetAwaiter().GetResult();
                    string error = errorTask.GetAwaiter().GetResult();
                    if (process.ExitCode != 0) throw new InvalidOperationException("Mesh generator: " + error.Trim());
                    return output.Trim();
                }
                finally
                {
                    if (!string.IsNullOrEmpty(profileDirectory))
                        try
                        {
                            string timingPath = Path.Combine(profileDirectory, "csharp-backends.csv");
                            if (!File.Exists(timingPath)) File.WriteAllText(timingPath, "area,pid,seconds,exit_code" + Environment.NewLine);
                            File.AppendAllText(timingPath, string.Join(",", File.ReadLines(boundary).First().Split(',')[1],
                                process.Id.ToString(CultureInfo.InvariantCulture),
                                backendClock.Elapsed.TotalSeconds.ToString("R", CultureInfo.InvariantCulture),
                                process.HasExited ? process.ExitCode.ToString(CultureInfo.InvariantCulture) : "running") + Environment.NewLine);
                        }
                        catch { }
                }
            }
        }

        private static MeshData ReadMesh(string path)
        {
            var data = new MeshData();
            foreach (string line in File.ReadLines(path))
            {
                string[] fields = line.Split(',');
                if (fields[0] == "N")
                    data.Nodes[int.Parse(fields[1], CultureInfo.InvariantCulture)] = new[]
                    {
                        double.Parse(fields[2], CultureInfo.InvariantCulture), double.Parse(fields[3], CultureInfo.InvariantCulture),
                        double.Parse(fields[4], CultureInfo.InvariantCulture)
                    };
                else if (fields[0] == "E")
                    data.Elements.Add(fields.Skip(1).Select(value => int.Parse(value, CultureInfo.InvariantCulture)).ToArray());
                else if (fields[0] == "Q")
                    data.Elements.Add(fields.Skip(1).Select(value => int.Parse(value, CultureInfo.InvariantCulture)).ToArray());
                else if (fields[0] == "F")
                    data.ProtectedEdges.Add(EdgeKey(int.Parse(fields[1], CultureInfo.InvariantCulture),
                        int.Parse(fields[2], CultureInfo.InvariantCulture)));
            }
            if (data.Nodes.Count == 0 || data.Elements.Count == 0) throw new InvalidDataException("The generator returned an empty mesh.");
            if (data.Elements.Any(element => element.Length < 3 || element.Length > 4)) throw new InvalidDataException("Unsupported connectivity.");
            return data;
        }

        private static string EdgeKey(int first, int second)
        {
            return first < second ? first + ":" + second : second + ":" + first;
        }

        private static void RemoveEnclosedElements(MeshData mesh, string areaName, List<AreaContext> contexts)
        {
            var owners = new Dictionary<string, List<int>>();
            for (int elementIndex = 0; elementIndex < mesh.Elements.Count; elementIndex++)
            {
                int[] element = mesh.Elements[elementIndex];
                for (int i = 0; i < element.Length; i++)
                {
                    string edge = EdgeKey(element[i], element[(i + 1) % element.Length]);
                    List<int> edgeOwners;
                    if (!owners.TryGetValue(edge, out edgeOwners)) owners[edge] = edgeOwners = new List<int>();
                    edgeOwners.Add(elementIndex);
                }
            }
            if (owners.Values.Any(items => items.Count > 2))
                throw new InvalidDataException("Invalid mesh topology: an edge belongs to more than two shell elements.");

            var exterior = new HashSet<int>();
            var pending = new Queue<int>();
            foreach (KeyValuePair<string, List<int>> item in owners.Where(item => item.Value.Count == 1))
            {
                if (mesh.ProtectedEdges.Contains(item.Key) || IsSharedUnionBoundary(mesh, item.Key, areaName, contexts)) continue;
                if (exterior.Add(item.Value[0])) pending.Enqueue(item.Value[0]);
            }
            var elementEdges = new List<string>[mesh.Elements.Count];
            for (int i = 0; i < elementEdges.Length; i++) elementEdges[i] = new List<string>();
            foreach (KeyValuePair<string, List<int>> item in owners)
                foreach (int elementIndex in item.Value) elementEdges[elementIndex].Add(item.Key);

            while (pending.Count > 0)
            {
                int current = pending.Dequeue();
                foreach (string edge in elementEdges[current])
                {
                    List<int> edgeOwners = owners[edge];
                    if (mesh.ProtectedEdges.Contains(edge) || edgeOwners.Count != 2) continue;
                    int neighbor = edgeOwners[0] == current ? edgeOwners[1] : edgeOwners[0];
                    if (exterior.Add(neighbor)) pending.Enqueue(neighbor);
                }
            }

            mesh.RemovedElements = mesh.Elements.Count - exterior.Count;
            if (mesh.RemovedElements == 0) return;
            List<int[]> retained = mesh.Elements.Where((element, index) => exterior.Contains(index)).ToList();
            if (retained.Count == 0) throw new InvalidDataException("The closed frames would remove the entire area.");
            mesh.Elements.Clear();
            mesh.Elements.AddRange(retained);
            var usedNodes = new HashSet<int>(mesh.Elements.SelectMany(element => element));
            foreach (int tag in mesh.Nodes.Keys.Where(tag => !usedNodes.Contains(tag)).ToArray()) mesh.Nodes.Remove(tag);
        }

        private static bool IsSharedUnionBoundary(MeshData mesh, string edge, string areaName, List<AreaContext> contexts)
        {
            string[] tags = edge.Split(':');
            double[] first = mesh.Nodes[int.Parse(tags[0], CultureInfo.InvariantCulture)];
            double[] second = mesh.Nodes[int.Parse(tags[1], CultureInfo.InvariantCulture)];
            double[] midpoint = Interpolate(first, second, 0.5);
            AreaContext current = contexts.First(context => context.Name == areaName);
            foreach (AreaContext context in contexts)
            {
                if (context == current || Math.Abs(Dot(current.Plane.Normal, context.Plane.Normal)) < 1 - 1e-8 ||
                    Math.Abs(context.Plane.SignedDistance(midpoint)) > Tolerance) continue;
                if (PointInsideOrBoundary(context.Plane.Project(midpoint), context.Corners.Select(context.Plane.Project).ToArray()))
                    return true;
            }
            return false;
        }

        private static double AllowedMaxSize(double maxSize, List<BoundaryPoint>[] edges)
        {
            double allowedMax = maxSize;
            foreach (List<BoundaryPoint> edge in edges.Where(item => item.Count > 2))
                for (int i = 1; i < edge.Count; i++)
                    allowedMax = Math.Max(allowedMax, Distance(edge[i - 1].Coordinates, edge[i].Coordinates));
            return allowedMax;
        }

        private static MeshQualityReport EvaluateMeshQuality(MeshData mesh, Plane plane, double allowedMax, int frameCount)
        {
            double minEdge = double.MaxValue, maxEdge = 0, maxAspect = 0;
            double minAngle = 180, maxAngle = 0, maxQuadSkew = 0, minQuadJacobian = 1;
            double minTriangleAngle = 180, maxTriangleAngle = 0;
            int triangles = 0, quads = 0, invalid = 0;
            foreach (int[] element in mesh.Elements)
            {
                double[][] points = element.Select(tag => mesh.Nodes[tag]).ToArray();
                double[] lengths = Enumerable.Range(0, points.Length)
                    .Select(i => Distance(points[i], points[(i + 1) % points.Length])).ToArray();
                minEdge = Math.Min(minEdge, lengths.Min());
                maxEdge = Math.Max(maxEdge, lengths.Max());
                maxAspect = Math.Max(maxAspect, lengths.Max() / lengths.Min());
                bool elementInvalid = false;
                for (int i = 0; i < points.Length; i++)
                {
                    double[] previous = Subtract(points[(i - 1 + points.Length) % points.Length], points[i]);
                    double[] following = Subtract(points[(i + 1) % points.Length], points[i]);
                    double scaledJacobian = Norm(Cross(previous, following)) / (Norm(previous) * Norm(following));
                    double cosine = Math.Max(-1, Math.Min(1, Dot(previous, following) / (Norm(previous) * Norm(following))));
                    double angle = Math.Acos(cosine) * 180 / Math.PI;
                    minAngle = Math.Min(minAngle, angle);
                    maxAngle = Math.Max(maxAngle, angle);
                    if (Dot(Cross(following, previous), plane.Normal) <= Tolerance) elementInvalid = true;
                    if (points.Length == 3)
                    {
                        minTriangleAngle = Math.Min(minTriangleAngle, angle);
                        maxTriangleAngle = Math.Max(maxTriangleAngle, angle);
                    }
                    if (points.Length == 4)
                    {
                        maxQuadSkew = Math.Max(maxQuadSkew, Math.Abs(angle - 90));
                        minQuadJacobian = Math.Min(minQuadJacobian, scaledJacobian);
                    }
                }
                if (elementInvalid) invalid++;
                if (points.Length == 3) triangles++; else quads++;
            }

            bool sizeOk = maxEdge <= allowedMax * 1.001;
            bool aspectOk = maxAspect <= 4.0001;
            bool quadShapeOk = quads == 0 || (maxQuadSkew <= 45.0001 && minQuadJacobian >= 0.4999 && minAngle >= 44.9999 && maxAngle <= 135.0001);
            bool triangleShapeOk = triangles == 0 || (minTriangleAngle >= 29.9999 && maxTriangleAngle <= 90.0001);
            bool orientationOk = invalid == 0;
            bool passed = sizeOk && aspectOk && quadShapeOk && triangleShapeOk && orientationOk;
            string F(double value) { return value.ToString("0.###", CultureInfo.InvariantCulture); }
            var report = new MeshQualityReport(passed,
                "Nodes: " + mesh.Nodes.Count + "    Elements: " + quads + " quads, " + triangles + " triangles" +
                (frameCount > 0 ? "    Constraining frames: " + frameCount : "") +
                (mesh.RemovedElements > 0 ? "    Shell elements removed for holes: " + mesh.RemovedElements : ""));
            report.Metrics.Add(new QualityMetric("Maximum size", F(maxEdge), "Requested/constraints: <= " + F(allowedMax),
                sizeOk ? 1 : Math.Max(0, 2 - maxEdge / allowedMax)));
            report.Metrics.Add(new QualityMetric("Aspect ratio", F(maxAspect), "CUBIT/Verdict: 1 - 4",
                Clamp01(1 - (maxAspect - 1) / 6)));
            if (quads > 0)
            {
                double normalizedSkew = maxQuadSkew / 90;
                report.Metrics.Add(new QualityMetric("Quadrilateral skew", F(normalizedSkew) + "  (" + F(maxQuadSkew) + " degrees)",
                    "CUBIT/Verdict: 0 - 0.5; 0 is ideal", Clamp01(1 - normalizedSkew)));
                report.Metrics.Add(new QualityMetric("Scaled Jacobian", F(minQuadJacobian),
                    "CUBIT/Verdict: 0.5 - 1; 1 is ideal", Clamp01(minQuadJacobian)));
                report.Metrics.Add(new QualityMetric("Quadrilateral angles", F(minAngle) + " - " + F(maxAngle) + " degrees",
                    "CUBIT/Verdict: 45 - 135 degrees", quadShapeOk ? 0.75 : 0.25));
            }
            if (triangles > 0)
                report.Metrics.Add(new QualityMetric("Triangle angles", F(minTriangleAngle) + " - " + F(maxTriangleAngle) + " degrees",
                    "CUBIT/Verdict: 30 - 90 degrees", triangleShapeOk ? 0.75 : 0.25));
            report.Metrics.Add(new QualityMetric("Orientation", invalid == 0 ? "0 invalid elements" : invalid + " invalid elements",
                "No inverted or degenerate elements", orientationOk ? 1 : 0));
            return report;
        }

        private static double Clamp01(double value) { return Math.Max(0, Math.Min(1, value)); }

        private static MeshOperation ApplyMesh(cSapModel model, string sourceArea, string property, double angle, double mass,
            bool edgeConstraint, AreaLoads areaLoads, MeshData mesh, MeshOptionsDialog progress, PointSnapshot[] originalPoints,
            PointCoordinateIndex existingCoordinates)
        {
            string backupArea = "QTUNDO_" + Guid.NewGuid().ToString("N").Substring(0, 12);
            Check(model.AreaObj.ChangeName(sourceArea, backupArea), "preparing original area for undo");
            var operation = new MeshOperation(sourceArea, backupArea, originalPoints);
            var pointNames = new Dictionary<int, string>();
            int existingPointCount = 0;
            string[] existingPointNames = null;
            model.PointObj.GetNameList(ref existingPointCount, ref existingPointNames);
            var preExistingPoints = new HashSet<string>(existingPointNames ?? new string[0]);
            int completed = 0, total = mesh.Nodes.Count + mesh.Elements.Count;
            var progressClock = Stopwatch.StartNew();
            try
            {
                foreach (KeyValuePair<int, double[]> item in mesh.Nodes)
                {
                    string name;
                    double[] point = item.Value;
                    if (!existingCoordinates.TryFind(point, out name))
                    {
                        name = "";
                        Check(model.PointObj.AddCartesian(point[0], point[1], point[2], ref name, "", "Global", false, 0), "creating point");
                        existingCoordinates.Add(point, name);
                    }
                    pointNames[item.Key] = name;
                    if (!preExistingPoints.Contains(name) && !operation.GeneratedPoints.Contains(name))
                        operation.GeneratedPoints.Add(name);
                    completed++;
                    if (progressClock.ElapsedMilliseconds >= 100)
                    {
                        progress.SetProgress("Creating SAP2000 points...", completed, total);
                        progressClock.Restart();
                    }
                }
                for (int i = 0; i < mesh.Elements.Count; i++)
                {
                    string[] points = mesh.Elements[i].Select(tag => pointNames[tag]).ToArray();
                    string name = "";
                    Check(model.AreaObj.AddByPoint(points.Length, ref points, ref name, property, i == 0 ? sourceArea : ""), "creating shell element");
                    operation.GeneratedAreas.Add(name);
                    if (Math.Abs(angle) > Tolerance) model.AreaObj.SetLocalAxes(name, angle, eItemType.Objects);
                    if (Math.Abs(mass) > Tolerance) model.AreaObj.SetMass(name, mass, true, eItemType.Objects);
                    if (edgeConstraint) model.AreaObj.SetEdgeConstraint(name, true, eItemType.Objects);
                    areaLoads.Apply(name);
                    completed++;
                    if (completed == total || progressClock.ElapsedMilliseconds >= 100)
                    {
                        progress.SetProgress("Creating shell elements and transferring loads...", completed, total);
                        progressClock.Restart();
                    }
                }
                return operation;
            }
            catch
            {
                UndoMesh(model, operation);
                throw;
            }
        }

        private static MeshOperation ApplyMeshFast(cSapModel model, string sourceArea, string property, double angle, double mass,
            bool edgeConstraint, AreaLoads areaLoads, MeshData mesh, MeshOptionsDialog progress, PointSnapshot[] originalPoints,
            PointCoordinateIndex existingCoordinates)
        {
            string token = Guid.NewGuid().ToString("N").Substring(0, 8);
            var operation = new MeshOperation(sourceArea, null, originalPoints) { FastMode = true };
            EditableTable joints = null, areas = null, sections = null;
            try
            {
                joints = ReadEditableTable(model, "Joint Coordinates");
                areas = ReadEditableTable(model, "Connectivity - Area");
                sections = ReadEditableTable(model, "Area Section Assignments");
                RequireFields(joints, "Joint", "CoordSys", "CoordType", "XorR", "Y", "Z", "SpecialJt", "GUID");
                RequireFields(areas, "Area", "Joint1", "Joint2", "Joint3", "GUID");
                RequireFields(sections, "Area", "Section");

                var usedPointNames = new HashSet<string>(joints.Values("Joint"));
                var usedAreaNames = new HashSet<string>(areas.Values("Area"));
                var meshPointNames = new Dictionary<int, string>();
                int pointSequence = 1;
                foreach (KeyValuePair<int, double[]> item in mesh.Nodes)
                {
                    string pointName;
                    if (!existingCoordinates.TryFind(item.Value, out pointName))
                    {
                        do pointName = "QTP" + token.ToUpperInvariant() + (pointSequence++).ToString("D6", CultureInfo.InvariantCulture);
                        while (usedPointNames.Contains(pointName));
                        usedPointNames.Add(pointName);
                        existingCoordinates.Add(item.Value, pointName);
                        operation.GeneratedPoints.Add(pointName);
                        joints.Append(new Dictionary<string, string>
                        {
                            { "Joint", pointName }, { "CoordSys", "GLOBAL" }, { "CoordType", "Cartesian" },
                            { "XorR", item.Value[0].ToString("R", CultureInfo.InvariantCulture) },
                            { "Y", item.Value[1].ToString("R", CultureInfo.InvariantCulture) },
                            { "T", "" }, { "Z", item.Value[2].ToString("R", CultureInfo.InvariantCulture) },
                            { "SpecialJt", "No" }, { "GUID", "" }
                        });
                    }
                    meshPointNames[item.Key] = pointName;
                }

                var expectedConnectivity = new Dictionary<string, string[]>();
                for (int i = 0; i < mesh.Elements.Count; i++)
                {
                    string areaName = "QTA" + token.ToUpperInvariant() + i.ToString("D6", CultureInfo.InvariantCulture);
                    while (usedAreaNames.Contains(areaName)) areaName += "X";
                    usedAreaNames.Add(areaName);
                    operation.GeneratedAreas.Add(areaName);
                    if (i == 0) operation.PrimaryGeneratedArea = areaName;
                    string[] pointNames = mesh.Elements[i].Select(tag => meshPointNames[tag]).ToArray();
                    if (pointNames.Length > areas.MaxJointField)
                        throw new InvalidDataException("FAST does not support the connectivity required by shell element " + areaName + ".");
                    expectedConnectivity[areaName] = pointNames;
                    var connectivity = new Dictionary<string, string>
                    {
                        { "Area", areaName }, { "NumJoints", pointNames.Length.ToString(CultureInfo.InvariantCulture) }, { "GUID", "" }
                    };
                    for (int joint = 1; joint <= areas.MaxJointField; joint++)
                        connectivity["Joint" + joint] = joint <= pointNames.Length ? pointNames[joint - 1] : "";
                    areas.Append(connectivity);
                    sections.Append(new Dictionary<string, string>
                    {
                        { "Area", areaName }, { "Section", property }, { "MatProp", "Default" }
                    });
                }

                progress.SetIndeterminate("FAST: bulk importing points and shell elements...");
                WriteEditableTable(model, joints);
                WriteEditableTable(model, areas);
                WriteEditableTable(model, sections);
                int fatal = 0, errors = 0, warnings = 0, information = 0;
                string importLog = "";
                Check(model.DatabaseTables.ApplyEditedTables(true, ref fatal, ref errors, ref warnings, ref information, ref importLog),
                    "applying FAST tables");
                int expectedContinuationErrors = ExpectedContinuationErrors(areas);
                if (fatal != 0 || warnings != 0 || !HasOnlyExpectedContinuationErrors(importLog, errors, expectedContinuationErrors))
                    throw new InvalidOperationException("Invalid FAST import: " + ImportSummary(fatal, errors, warnings, importLog));

                EditableTable resultingJoints = ReadEditableTable(model, "Joint Coordinates");
                EditableTable resultingAreas = ReadEditableTable(model, "Connectivity - Area");
                EditableTable resultingSections = ReadEditableTable(model, "Area Section Assignments");
                Dictionary<string, string[]> areaRows = resultingAreas.RowsBy("Area");
                Dictionary<string, string[]> sectionRows = resultingSections.RowsBy("Area");
                foreach (KeyValuePair<string, string[]> expected in expectedConnectivity)
                {
                    string[] row;
                    if (!areaRows.TryGetValue(expected.Key, out row)) throw new InvalidDataException("FAST: missing shell element " + expected.Key);
                    for (int i = 0; i < expected.Value.Length; i++)
                        if (resultingAreas.Value(row, "Joint" + (i + 1)) != expected.Value[i])
                            throw new InvalidDataException("FAST: invalid connectivity for " + expected.Key);
                    if (!sectionRows.TryGetValue(expected.Key, out row) || resultingSections.Value(row, "Section") != property)
                        throw new InvalidDataException("FAST: invalid property for " + expected.Key);
                }
                if (resultingJoints.RecordCount != joints.RecordCount || resultingAreas.RecordCount != areas.RecordCount)
                    throw new InvalidDataException("FAST: inconsistent imported object count.");

                int completed = 0;
                foreach (string areaName in operation.GeneratedAreas)
                {
                    if (Math.Abs(angle) > Tolerance) Check(model.AreaObj.SetLocalAxes(areaName, angle, eItemType.Objects), "setting FAST local axes");
                    if (Math.Abs(mass) > Tolerance) Check(model.AreaObj.SetMass(areaName, mass, true, eItemType.Objects), "setting FAST mass");
                    if (edgeConstraint) Check(model.AreaObj.SetEdgeConstraint(areaName, true, eItemType.Objects), "edge constraint FAST");
                    areaLoads.Apply(areaName);
                    completed++;
                    if (completed == operation.GeneratedAreas.Count || completed % 500 == 0)
                        progress.SetProgress("FAST: transferring assignments...", completed, operation.GeneratedAreas.Count);
                }
                return operation;
            }
            catch (Exception exception)
            {
                model.DatabaseTables.CancelTableEditing();
                try { UndoMesh(model, operation, false); }
                catch (Exception rollback)
                {
                    throw new InvalidOperationException(exception.Message + " FAST rollback failed: " + rollback.Message, exception);
                }
                throw;
            }
        }

        private static FastTableSnapshot CaptureFastSnapshot(cSapModel model)
        {
            var snapshot = new FastTableSnapshot(ReadEditableTable(model, "Joint Coordinates"),
                ReadEditableTable(model, "Connectivity - Area"), ReadEditableTable(model, "Area Section Assignments"));
            RequireFields(snapshot.Joints, "Joint", "GUID");
            RequireFields(snapshot.Areas, "Area", "GUID");
            return snapshot;
        }

        private static void UndoAttempts(cSapModel model, List<MeshAttemptResult> results, FastTableSnapshot snapshot,
            PointSnapshot[] originalPoints)
        {
            if (snapshot == null)
            {
                for (int i = results.Count - 1; i >= 0; i--) UndoMesh(model, results[i].Operation, false);
                return;
            }
            model.DatabaseTables.CancelTableEditing();
            WriteEditableTable(model, snapshot.Joints);
            WriteEditableTable(model, snapshot.Areas);
            WriteEditableTable(model, snapshot.Sections);
            int fatal = 0, errors = 0, warnings = 0, information = 0; string log = "";
            Check(model.DatabaseTables.ApplyEditedTables(true, ref fatal, ref errors, ref warnings, ref information, ref log),
                "restoring FAST tables");
            int expectedContinuationErrors = ExpectedContinuationErrors(snapshot.Areas);
            if (fatal != 0 || warnings != 0 || !HasOnlyExpectedContinuationErrors(log, errors, expectedContinuationErrors))
                throw new InvalidOperationException("Invalid FAST restore: " + ImportSummary(fatal, errors, warnings, log));
            EditableTable joints = ReadEditableTable(model, "Joint Coordinates");
            EditableTable areas = ReadEditableTable(model, "Connectivity - Area");
            ValidateGuids(joints, "Joint", snapshot.JointGuids);
            ValidateGuids(areas, "Area", snapshot.AreaGuids);
            if (joints.RecordCount != snapshot.Joints.RecordCount || areas.RecordCount != snapshot.Areas.RecordCount)
                throw new InvalidDataException("FAST restore: inconsistent object count.");
            RestorePointSnapshots(model, originalPoints ?? new PointSnapshot[0]);
            foreach (MeshAttemptResult result in results)
            {
                result.Operation.Active = false;
                result.Operation.Undone = true;
            }
        }

        private static EditableTable ReadEditableTable(cSapModel model, string key)
        {
            int version = 0, records = 0;
            string[] fields = null, data = null;
            Check(model.DatabaseTables.GetTableForEditingArray(key, "", ref version, ref fields, ref records, ref data), "reading table " + key);
            return new EditableTable(key, version, fields ?? new string[0], data ?? new string[0]);
        }

        private static PointCoordinateIndex ReadExactPointCoordinates(cSapModel model, double maxSize)
        {
            var result = new PointCoordinateIndex(Math.Max(Tolerance, Math.Max(1, maxSize) * 1e-6));
            int count = 0; string[] names = null;
            Check(model.PointObj.GetNameList(ref count, ref names), "reading FAST coordinate inventory");
            foreach (string name in names ?? new string[0]) result.Add(Coordinate(model, name), name);
            return result;
        }

        private static void WriteEditableTable(cSapModel model, EditableTable table)
        {
            int version = table.Version;
            string[] fields = table.Fields.ToArray(), data = table.Data.ToArray();
            Check(model.DatabaseTables.SetTableForEditingArray(table.Key, ref version, ref fields, table.RecordCount, ref data),
                "preparing table " + table.Key);
        }

        private static void RequireFields(EditableTable table, params string[] fields)
        {
            string missing = fields.FirstOrDefault(field => !table.Fields.Contains(field));
            if (missing != null) throw new InvalidDataException("FAST is unavailable: field " + missing + " is missing from " + table.Key + ".");
        }

        private static void ValidateGuids(EditableTable table, string nameField, Dictionary<string, string> expected)
        {
            Dictionary<string, string[]> rows = table.RowsBy(nameField);
            foreach (KeyValuePair<string, string> item in expected)
            {
                string[] row;
                if (!rows.TryGetValue(item.Key, out row) || table.Value(row, "GUID") != item.Value)
                    throw new InvalidDataException("FAST: GUID changed for " + item.Key + ".");
            }
        }

        private static string ImportSummary(int fatal, int errors, int warnings, string log)
        {
            string[] lines = (log ?? "").Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            return "fatal=" + fatal + ", errors=" + errors + ", warnings=" + warnings + ". " + string.Join(" ", lines.Take(12));
        }

        private static int ExpectedContinuationErrors(EditableTable table)
        {
            int areaField = Array.IndexOf(table.Fields, "Area");
            int firstJointField = Array.IndexOf(table.Fields, "Joint1");
            if (areaField < 0 || firstJointField < 0) return 0;
            var seenAreas = new HashSet<string>();
            int expected = 0;
            for (int record = 0; record < table.RecordCount; record++)
            {
                int offset = record * table.Fields.Length;
                string area = table.Data[offset + areaField];
                bool continuation = !string.IsNullOrEmpty(area) && seenAreas.Contains(area) &&
                    !string.IsNullOrEmpty(table.Data[offset + firstJointField]);
                if (continuation)
                    for (int joint = 2; joint <= table.MaxJointField; joint++)
                    {
                        int field = Array.IndexOf(table.Fields, "Joint" + joint);
                        if (field >= 0 && string.IsNullOrEmpty(table.Data[offset + field])) expected++;
                    }
                if (!string.IsNullOrEmpty(area)) seenAreas.Add(area);
            }
            return expected;
        }

        private static bool HasOnlyExpectedContinuationErrors(string log, int actualErrors, int expectedErrors)
        {
            if (actualErrors != expectedErrors) return false;
            if (expectedErrors == 0) return true;
            string[] blocks = (log ?? "").Split(new[] { "*** Error Message" }, StringSplitOptions.None).Skip(1).ToArray();
            if (blocks.Length != expectedErrors) return false;
            return blocks.All(block =>
            {
                string normalized = block.ToUpperInvariant();
                return normalized.Contains("TABLE NAME:  CONNECTIVITY - AREA") &&
                    (normalized.Contains("FIELD NAME:  JOINT2") || normalized.Contains("FIELD NAME:  JOINT3") || normalized.Contains("FIELD NAME:  JOINT4")) &&
                    normalized.Contains("INVALID JOINT NAME") && normalized.Contains("JOINT SKIPPED");
            });
        }

        private static void UndoMesh(cSapModel model, MeshOperation operation, bool refresh = true)
        {
            if (!operation.Active) return;
            int areaCount = 0;
            string[] areaNames = null;
            Check(model.AreaObj.GetNameList(ref areaCount, ref areaNames), "reading areas before undo");
            var remainingAreas = new HashSet<string>(areaNames ?? new string[0]);
            for (int i = operation.GeneratedAreas.Count - 1; i >= 0; i--)
                if (remainingAreas.Contains(operation.GeneratedAreas[i]))
                    Check(model.AreaObj.Delete(operation.GeneratedAreas[i], eItemType.Objects), "removing generated area " + operation.GeneratedAreas[i]);
            int pointCount = 0;
            string[] pointNames = null;
            Check(model.PointObj.GetNameList(ref pointCount, ref pointNames), "reading points before undo");
            var remainingPoints = new HashSet<string>(pointNames ?? new string[0]);
            foreach (string pointName in operation.GeneratedPoints)
            {
                if (!remainingPoints.Contains(pointName)) continue;
                Check(model.PointObj.SetSpecialPoint(pointName, true, eItemType.Objects), "preparing generated point removal " + pointName);
                Check(model.PointObj.DeleteSpecialPoint(pointName, eItemType.Objects), "removing generated point " + pointName);
            }
            if (operation.FastMode)
            {
                RestorePointSnapshots(model, operation.OriginalPoints);
                operation.Active = false;
                operation.Undone = true;
                if (refresh) model.View.RefreshView(0, false);
                return;
            }
            Check(model.AreaObj.ChangeName(operation.BackupArea, operation.SourceArea), "restoring the original area");
            RestorePointSnapshots(model, operation.OriginalPoints);
            operation.Active = false;
            operation.Undone = true;
            if (refresh) model.View.RefreshView(0, false);
        }

        private static void CommitMesh(cSapModel model, MeshOperation operation)
        {
            if (!operation.Active) return;
            if (operation.FastMode)
            {
                Check(model.AreaObj.Delete(operation.SourceArea, eItemType.Objects), "committing the FAST mesh");
                Check(model.AreaObj.ChangeName(operation.PrimaryGeneratedArea, operation.SourceArea), "renaming the FAST mesh area");
                operation.Active = false;
                return;
            }
            Check(model.AreaObj.Delete(operation.BackupArea, eItemType.Objects), "committing the mesh");
            operation.Active = false;
        }

        private static void CommitAttempts(cSapModel model, List<MeshAttemptResult> results)
        {
            if (!results.Any(result => result.Operation.FastMode))
            {
                foreach (MeshAttemptResult result in results) CommitMesh(model, result.Operation);
                return;
            }

            var prepared = new List<MeshOperation>();
            string token = Guid.NewGuid().ToString("N").Substring(0, 8).ToUpperInvariant();
            try
            {
                for (int i = 0; i < results.Count; i++)
                {
                    MeshOperation operation = results[i].Operation;
                    operation.CommitBackupArea = "QTB" + token + i.ToString("D4", CultureInfo.InvariantCulture);
                    Check(model.AreaObj.ChangeName(operation.SourceArea, operation.CommitBackupArea), "preparing FAST commit");
                    try { Check(model.AreaObj.ChangeName(operation.PrimaryGeneratedArea, operation.SourceArea), "renaming the FAST mesh area"); }
                    catch (Exception renameFailure)
                    {
                        try { Check(model.AreaObj.ChangeName(operation.CommitBackupArea, operation.SourceArea), "rolling back the current FAST source area"); }
                        catch (Exception rollback)
                        {
                            throw new InvalidOperationException(renameFailure.Message + " FAST commit rollback failed: " + rollback.Message, renameFailure);
                        }
                        operation.CommitBackupArea = null;
                        throw;
                    }
                    prepared.Add(operation);
                }
            }
            catch (Exception exception)
            {
                Exception rollbackFailure = null;
                for (int i = prepared.Count - 1; i >= 0; i--)
                {
                    MeshOperation operation = prepared[i];
                    try
                    {
                        Check(model.AreaObj.ChangeName(operation.SourceArea, operation.PrimaryGeneratedArea), "rolling back FAST mesh name");
                        Check(model.AreaObj.ChangeName(operation.CommitBackupArea, operation.SourceArea), "rolling back FAST source area");
                        operation.CommitBackupArea = null;
                    }
                    catch (Exception rollback) { if (rollbackFailure == null) rollbackFailure = rollback; }
                }
                if (rollbackFailure != null)
                    throw new InvalidOperationException(exception.Message + " FAST commit rollback failed: " + rollbackFailure.Message, exception);
                throw;
            }

            try
            {
                Check(model.SelectObj.ClearSelection(), "clearing selection for FAST commit");
                foreach (MeshOperation operation in prepared)
                    Check(model.AreaObj.SetSelected(operation.CommitBackupArea, true, eItemType.Objects), "selecting FAST commit backup");
            }
            catch (Exception exception)
            {
                Exception rollbackFailure = RollBackFastCommitNames(model, prepared);
                if (rollbackFailure != null)
                    throw new InvalidOperationException(exception.Message + " FAST commit rollback failed: " + rollbackFailure.Message, exception);
                throw;
            }
            int deleteResult = model.AreaObj.Delete("", eItemType.SelectedObjects);
            int remainingCount = 0;
            string[] remainingNames = null;
            Check(model.AreaObj.GetNameList(ref remainingCount, ref remainingNames), "verifying FAST commit cleanup");
            var remaining = new HashSet<string>(remainingNames ?? new string[0]);
            List<MeshOperation> retainedBackups = prepared.Where(operation => remaining.Contains(operation.CommitBackupArea)).ToList();
            if (deleteResult != 0 || retainedBackups.Count != 0)
            {
                if (retainedBackups.Count == prepared.Count)
                {
                    Exception rollbackFailure = RollBackFastCommitNames(model, prepared);
                    if (rollbackFailure != null)
                        throw new InvalidOperationException("SAP2000 could not remove the original FAST areas and rollback failed: " + rollbackFailure.Message);
                }
                throw new InvalidOperationException("SAP2000 could not remove all original FAST areas (code " + deleteResult +
                    "). The generated meshes retain their final names; inspect these backup areas: " +
                    string.Join(", ", retainedBackups.Select(operation => operation.CommitBackupArea)) + ".");
            }
            foreach (MeshOperation operation in prepared)
            {
                operation.CommitBackupArea = null;
                operation.Active = false;
            }
        }

        private static Exception RollBackFastCommitNames(cSapModel model, List<MeshOperation> operations)
        {
            Exception failure = null;
            for (int i = operations.Count - 1; i >= 0; i--)
            {
                MeshOperation operation = operations[i];
                try
                {
                    Check(model.AreaObj.ChangeName(operation.SourceArea, operation.PrimaryGeneratedArea), "rolling back FAST mesh name");
                    Check(model.AreaObj.ChangeName(operation.CommitBackupArea, operation.SourceArea), "rolling back FAST source area");
                    operation.CommitBackupArea = null;
                }
                catch (Exception exception) { if (failure == null) failure = exception; }
            }
            return failure;
        }

        private static PointSnapshot[] CapturePointSnapshots(cSapModel model, IEnumerable<string> pointNames)
        {
            var snapshots = new List<PointSnapshot>();
            foreach (string name in pointNames.Distinct())
            {
                bool special = false;
                int groupCount = 0;
                string[] groups = null;
                model.PointObj.GetSpecialPoint(name, ref special);
                model.PointObj.GetGroupAssign(name, ref groupCount, ref groups);
                snapshots.Add(new PointSnapshot(name, Coordinate(model, name), special, groups ?? new string[0]));
            }
            return snapshots.ToArray();
        }

        private static void RestorePointSnapshots(cSapModel model, PointSnapshot[] snapshots)
        {
            int pointCount = 0;
            string[] pointNames = null;
            model.PointObj.GetNameList(ref pointCount, ref pointNames);
            var existing = new HashSet<string>(pointNames ?? new string[0]);
            foreach (PointSnapshot snapshot in snapshots)
            {
                if (existing.Contains(snapshot.Name)) continue;
                string restoredName = "";
                Check(model.PointObj.AddCartesian(snapshot.Coordinates[0], snapshot.Coordinates[1], snapshot.Coordinates[2],
                    ref restoredName, snapshot.Name, "Global", snapshot.Special, 0), "restoring point " + snapshot.Name);
                foreach (string group in snapshot.Groups)
                    model.PointObj.SetGroupAssign(restoredName, group, false, eItemType.Objects);
            }
        }

        private static AreaLoads CaptureAreaLoads(cSapModel model, string areaName)
        {
            var loads = new AreaLoads();
            int count = 0;
            string[] names = null, patterns = null, systems = null, patternNames = null;
            double[] x = null, y = null, z = null, values = null;
            int[] components = null, directions = null, types = null, distributionTypes = null;

            Check(model.AreaObj.GetLoadGravity(areaName, ref count, ref names, ref patterns, ref systems,
                ref x, ref y, ref z, eItemType.Objects), "reading gravity loads");
            for (int i = 0; i < count; i++)
            {
                string pattern = patterns[i], system = systems[i]; double gx = x[i], gy = y[i], gz = z[i];
                loads.Add(target => Check(model.AreaObj.SetLoadGravity(target, pattern, gx, gy, gz, false, system, eItemType.Objects), "transferring gravity load"));
            }

            count = 0; names = patterns = patternNames = null; values = null;
            Check(model.AreaObj.GetLoadPorePressure(areaName, ref count, ref names, ref patterns, ref values,
                ref patternNames, eItemType.Objects), "reading pore pressure load");
            for (int i = 0; i < count; i++)
            {
                string pattern = patterns[i], valuePattern = patternNames[i]; double value = values[i];
                loads.Add(target => Check(model.AreaObj.SetLoadPorePressure(target, pattern, value, valuePattern, false, eItemType.Objects), "transferring pore pressure load"));
            }

            count = 0; names = patterns = null; values = null;
            Check(model.AreaObj.GetLoadRotate(areaName, ref count, ref names, ref patterns, ref values, eItemType.Objects), "reading rotational load");
            for (int i = 0; i < count; i++)
            {
                string pattern = patterns[i]; double value = values[i];
                loads.Add(target => Check(model.AreaObj.SetLoadRotate(target, pattern, value, false, eItemType.Objects), "transferring rotational load"));
            }

            count = 0; names = patterns = patternNames = null; components = null; values = null;
            Check(model.AreaObj.GetLoadStrain(areaName, ref count, ref names, ref patterns, ref components, ref values,
                ref patternNames, eItemType.Objects), "reading strain loads");
            for (int i = 0; i < count; i++)
            {
                string pattern = patterns[i], valuePattern = patternNames[i]; int component = components[i]; double value = values[i];
                loads.Add(target => Check(model.AreaObj.SetLoadStrain(target, pattern, component, value, false, valuePattern, eItemType.Objects), "transferring strain load"));
            }

            count = 0; names = patterns = patternNames = null; components = null; values = null;
            Check(model.AreaObj.GetLoadSurfacePressure(areaName, ref count, ref names, ref patterns, ref components,
                ref values, ref patternNames, eItemType.Objects), "reading surface pressure loads");
            for (int i = 0; i < count; i++)
            {
                string pattern = patterns[i], valuePattern = patternNames[i]; int face = components[i]; double value = values[i];
                loads.Add(target => Check(model.AreaObj.SetLoadSurfacePressure(target, pattern, face, value, valuePattern, false, eItemType.Objects), "transferring surface pressure load"));
            }

            count = 0; names = patterns = patternNames = null; types = null; values = null;
            Check(model.AreaObj.GetLoadTemperature(areaName, ref count, ref names, ref patterns, ref types, ref values,
                ref patternNames, eItemType.Objects), "reading temperature loads");
            for (int i = 0; i < count; i++)
            {
                string pattern = patterns[i], valuePattern = patternNames[i]; int loadType = types[i]; double value = values[i];
                loads.Add(target => Check(model.AreaObj.SetLoadTemperature(target, pattern, loadType, value, valuePattern, false, eItemType.Objects), "transferring temperature load"));
            }

            count = 0; names = patterns = systems = null; directions = null; values = null;
            Check(model.AreaObj.GetLoadUniform(areaName, ref count, ref names, ref patterns, ref systems, ref directions,
                ref values, eItemType.Objects), "reading uniform loads");
            for (int i = 0; i < count; i++)
            {
                string pattern = patterns[i], system = systems[i]; int direction = directions[i]; double value = values[i];
                loads.Add(target => Check(model.AreaObj.SetLoadUniform(target, pattern, value, direction, false, system, eItemType.Objects), "transferring uniform load"));
            }

            count = 0; names = patterns = systems = null; directions = distributionTypes = null; values = null;
            Check(model.AreaObj.GetLoadUniformToFrame(areaName, ref count, ref names, ref patterns, ref systems,
                ref directions, ref values, ref distributionTypes, eItemType.Objects), "reading uniform-to-frame loads");
            for (int i = 0; i < count; i++)
            {
                string pattern = patterns[i], system = systems[i]; int direction = directions[i], distribution = distributionTypes[i]; double value = values[i];
                loads.Add(target => Check(model.AreaObj.SetLoadUniformToFrame(target, pattern, value, direction, distribution, false, system, eItemType.Objects), "transferring uniform-to-frame load"));
            }

            count = 0; names = patterns = null; types = distributionTypes = null; values = null;
            Check(model.AreaObj.GetLoadWindPressure_1(areaName, ref count, ref names, ref patterns, ref types,
                ref values, ref distributionTypes, eItemType.Objects), "reading wind pressure loads");
            for (int i = 0; i < count; i++)
            {
                string pattern = patterns[i]; int loadType = types[i], distribution = distributionTypes[i]; double coefficient = values[i];
                loads.Add(target => Check(model.AreaObj.SetLoadWindPressure_1(target, pattern, loadType, coefficient, distribution, eItemType.Objects), "transferring wind pressure load"));
            }
            return loads;
        }

        private static double[] Coordinate(cSapModel model, string name)
        {
            double x = 0, y = 0, z = 0;
            Check(model.PointObj.GetCoordCartesian(name, ref x, ref y, ref z, "Global"), "reading point " + name);
            return new[] { x, y, z };
        }

        private static bool PointInPolygon(double[] point, double[][] polygon3D)
        {
            bool inside = false;
            for (int i = 0, j = polygon3D.Length - 1; i < polygon3D.Length; j = i++)
            {
                double xi = polygon3D[i][0], yi = polygon3D[i][1], xj = polygon3D[j][0], yj = polygon3D[j][1];
                if ((yi > point[1]) != (yj > point[1]) && point[0] < (xj - xi) * (point[1] - yi) / (yj - yi) + xi) inside = !inside;
            }
            return inside;
        }

        private static bool PointInsideOrBoundary(double[] point, double[][] polygon)
        {
            if (PointInPolygon(point, polygon)) return true;
            for (int i = 0; i < polygon.Length; i++)
            {
                double[] first = polygon[i], second = polygon[(i + 1) % polygon.Length];
                double dx = second[0] - first[0], dy = second[1] - first[1];
                double lengthSquared = dx * dx + dy * dy;
                double t = lengthSquared == 0 ? 0 : ((point[0] - first[0]) * dx + (point[1] - first[1]) * dy) / lengthSquared;
                t = Math.Max(0, Math.Min(1, t));
                double qx = first[0] + t * dx, qy = first[1] + t * dy;
                if (Math.Sqrt((point[0] - qx) * (point[0] - qx) + (point[1] - qy) * (point[1] - qy)) <= Tolerance)
                    return true;
            }
            return false;
        }

        private static bool OnSegment(double[] p, double[] a, double[] b, out double t)
        {
            double[] ab = Subtract(b, a), ap = Subtract(p, a);
            t = Dot(ap, ab) / Dot(ab, ab);
            double[] projection = { a[0] + t * ab[0], a[1] + t * ab[1], a[2] + t * ab[2] };
            return t >= -Tolerance && t <= 1 + Tolerance && Distance(p, projection) <= Tolerance;
        }

        private static void EnsureRectangularSymmetry(double[][] p)
        {
            double[] bottom = Subtract(p[1], p[0]), top = Subtract(p[2], p[3]);
            double[] left = Subtract(p[3], p[0]), right = Subtract(p[2], p[1]);
            double scale = Math.Max(Math.Max(Distance(p[0], p[1]), Distance(p[1], p[2])), 1.0);
            if (Distance(bottom, top) > Tolerance * scale || Distance(left, right) > Tolerance * scale ||
                Math.Abs(Dot(bottom, left)) > Tolerance * Distance(p[0], p[1]) * Distance(p[0], p[3]))
                throw new InvalidOperationException("Symmetric mode requires a rectangular area.");
        }

        private static T[] Rotate<T>(T[] values, int offset) { return Enumerable.Range(0, values.Length).Select(i => values[(i + offset) % values.Length]).ToArray(); }
        private static string Quote(string value) { return "\"" + value.Replace("\"", "\\\"") + "\""; }
        private static void TryDelete(string path) { try { if (File.Exists(path)) File.Delete(path); } catch { } }
        private static double[] Subtract(double[] a, double[] b) { return new[] { a[0] - b[0], a[1] - b[1], a[2] - b[2] }; }
        private static double Dot(double[] a, double[] b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
        private static double[] Cross(double[] a, double[] b) { return new[] { a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0] }; }
        private static double Norm(double[] value) { return Math.Sqrt(Dot(value, value)); }
        private static double[] Normalize(double[] value) { double n = Norm(value); return value.Select(x => x / n).ToArray(); }
        private static double Distance(double[] a, double[] b) { return Norm(Subtract(a, b)); }
        private static void Check(int result, string operation) { if (result != 0) throw new InvalidOperationException("SAP2000 error while " + operation + ": code " + result); }

        private sealed class BoundaryPoint
        {
            public readonly string Name; public readonly double T; public readonly double[] Coordinates;
            public BoundaryPoint(string name, double t, double[] coordinates) { Name = name; T = t; Coordinates = coordinates; }
        }
        private sealed class ConstraintPoint
        {
            public readonly string Name; public readonly double[] Coordinates;
            public ConstraintPoint(string name, double[] coordinates) { Name = name; Coordinates = coordinates; }
        }
        private sealed class FrameConstraint
        {
            public readonly string Name, FirstName, SecondName;
            public readonly double[] First, Second;
            public readonly bool Automatic;
            public bool CanBoundOpening;
            public readonly AreaContext SourceContext;
            public readonly int SourceEdge;
            public FrameConstraint(string name, string firstName, string secondName, double[] first, double[] second, bool automatic = false,
                AreaContext sourceContext = null, int sourceEdge = -1)
            {
                Name = name; FirstName = firstName; SecondName = secondName; First = first; Second = second;
                Automatic = automatic; SourceContext = sourceContext; SourceEdge = sourceEdge;
            }
        }
        private sealed class GroupObjects
        {
            public readonly HashSet<string> Frames;
            public readonly HashSet<string> Areas;
            public bool HasOpeningObjects { get { return Frames.Count > 0 || Areas.Count > 0; } }
            public GroupObjects(HashSet<string> frames, HashSet<string> areas) { Frames = frames; Areas = areas; }
        }
        private sealed class HoleDefinition
        {
            public readonly int Id;
            public readonly string PointName;
            public readonly double[] Center;
            public readonly double Diameter;
            public double Radius { get { return Diameter * 0.5; } }
            public HoleDefinition(int id, string pointName, double[] center, double diameter)
            { Id = id; PointName = pointName; Center = center; Diameter = diameter; }
        }
        private sealed class SymmetryAxis
        {
            public readonly double[] Center;
            public readonly double[] Direction;
            public readonly double[] SecondaryDirection;
            private readonly string englishLabel, italianLabel;
            public SymmetryAxis(double[] center, double[] direction, int index)
            {
                Center = center; Direction = direction;
                englishLabel = string.Format(CultureInfo.InvariantCulture, "Axis {0}: direction ({1:0.###}, {2:0.###}, {3:0.###})",
                    index, direction[0], direction[1], direction[2]);
                italianLabel = string.Format(CultureInfo.InvariantCulture, "Asse {0}: direzione ({1:0.###}, {2:0.###}, {3:0.###})",
                    index, direction[0], direction[1], direction[2]);
            }
            public SymmetryAxis(double[] center, double[] direction, double[] secondaryDirection)
            {
                Center = center; Direction = direction; SecondaryDirection = secondaryDirection;
                englishLabel = string.Format(CultureInfo.InvariantCulture,
                    "Double symmetry: principal axes ({0:0.###}, {1:0.###}, {2:0.###}) / ({3:0.###}, {4:0.###}, {5:0.###})",
                    direction[0], direction[1], direction[2], secondaryDirection[0], secondaryDirection[1], secondaryDirection[2]);
                italianLabel = string.Format(CultureInfo.InvariantCulture,
                    "Doppia simmetria: assi principali ({0:0.###}, {1:0.###}, {2:0.###}) / ({3:0.###}, {4:0.###}, {5:0.###})",
                    direction[0], direction[1], direction[2], secondaryDirection[0], secondaryDirection[1], secondaryDirection[2]);
            }
            public override string ToString() { return L(englishLabel, italianLabel); }
        }
        private sealed class SegmentInterval
        {
            public readonly double Start, End;
            public SegmentInterval(double start, double end) { Start = start; End = end; }
        }
        private sealed class AreaEdgeIntersection
        {
            public readonly int SourceIndex, SourceEdge, HostIndex;
            public readonly double Start, End;
            public AreaEdgeIntersection(int sourceIndex, int sourceEdge, int hostIndex, double start, double end)
            {
                SourceIndex = sourceIndex; SourceEdge = sourceEdge; HostIndex = hostIndex; Start = start; End = end;
            }
        }
        private sealed class MeshData
        {
            public readonly Dictionary<int, double[]> Nodes = new Dictionary<int, double[]>();
            public readonly List<int[]> Elements = new List<int[]>();
            public readonly HashSet<string> ProtectedEdges = new HashSet<string>();
            public int RemovedElements;
        }
        private sealed class EditableTable
        {
            public readonly string Key;
            public readonly int Version;
            public readonly string[] Fields;
            public readonly List<string> Data;
            public EditableTable(string key, int version, string[] fields, IEnumerable<string> data)
            {
                Key = key; Version = version; Fields = fields; Data = new List<string>(data);
                if (Fields.Length == 0 || Data.Count % Fields.Length != 0) throw new InvalidDataException("Invalid FAST table: " + key);
            }
            public int RecordCount { get { return Data.Count / Fields.Length; } }
            public int MaxJointField
            {
                get
                {
                    return Fields.Where(field => field.StartsWith("Joint", StringComparison.Ordinal) && field.Length > 5)
                        .Select(field => { int value; return int.TryParse(field.Substring(5), out value) ? value : 0; }).DefaultIfEmpty().Max();
                }
            }
            public void Append(Dictionary<string, string> values)
            {
                foreach (string field in Fields)
                {
                    string value;
                    Data.Add(values.TryGetValue(field, out value) ? value : "");
                }
            }
            public IEnumerable<string> Values(string field)
            {
                int index = Array.IndexOf(Fields, field);
                if (index < 0) throw new InvalidDataException("Missing FAST field: " + field);
                for (int record = 0; record < RecordCount; record++) yield return Data[record * Fields.Length + index];
            }
            public Dictionary<string, string[]> RowsBy(string field)
            {
                int index = Array.IndexOf(Fields, field);
                if (index < 0) throw new InvalidDataException("Missing FAST field: " + field);
                var result = new Dictionary<string, string[]>();
                for (int record = 0; record < RecordCount; record++)
                {
                    string[] row = Data.Skip(record * Fields.Length).Take(Fields.Length).ToArray();
                    result[row[index]] = row;
                }
                return result;
            }
            public string Value(string[] row, string field)
            {
                int index = Array.IndexOf(Fields, field);
                if (index < 0) throw new InvalidDataException("Missing FAST field: " + field);
                return row[index];
            }
            public Dictionary<string, string> NonEmptyMap(string nameField, string valueField, IEnumerable<string> excluded)
            {
                var excludedNames = new HashSet<string>(excluded);
                var result = new Dictionary<string, string>();
                int nameIndex = Array.IndexOf(Fields, nameField), valueIndex = Array.IndexOf(Fields, valueField);
                if (nameIndex < 0 || valueIndex < 0) throw new InvalidDataException("Missing FAST identity field.");
                for (int record = 0; record < RecordCount; record++)
                {
                    string name = Data[record * Fields.Length + nameIndex];
                    string value = Data[record * Fields.Length + valueIndex];
                    if (!excludedNames.Contains(name) && !string.IsNullOrEmpty(value)) result[name] = value;
                }
                return result;
            }
            public EditableTable Clone() { return new EditableTable(Key, Version, Fields.ToArray(), Data.ToArray()); }
        }
        private sealed class PointCoordinateIndex
        {
            private sealed class Entry
            {
                public readonly double[] Point;
                public readonly string Name;
                public Entry(double[] point, string name) { Point = point; Name = name; }
            }
            private readonly Dictionary<string, List<Entry>> buckets = new Dictionary<string, List<Entry>>();
            private readonly double tolerance;
            public PointCoordinateIndex(double tolerance) { this.tolerance = tolerance; }
            private long Cell(double value) { return (long)Math.Floor(value / tolerance); }
            private static string Key(long x, long y, long z) { return x + ":" + y + ":" + z; }
            public void Add(double[] point, string name)
            {
                string key = Key(Cell(point[0]), Cell(point[1]), Cell(point[2]));
                List<Entry> entries;
                if (!buckets.TryGetValue(key, out entries)) buckets[key] = entries = new List<Entry>();
                if (!entries.Any(entry => entry.Name == name)) entries.Add(new Entry(point.ToArray(), name));
            }
            public bool TryFind(double[] point, out string name)
            {
                long x = Cell(point[0]), y = Cell(point[1]), z = Cell(point[2]);
                for (long dx = -1; dx <= 1; dx++) for (long dy = -1; dy <= 1; dy++) for (long dz = -1; dz <= 1; dz++)
                {
                    List<Entry> entries;
                    if (!buckets.TryGetValue(Key(x + dx, y + dy, z + dz), out entries)) continue;
                    Entry match = entries.FirstOrDefault(entry => Distance(entry.Point, point) <= tolerance);
                    if (match != null) { name = match.Name; return true; }
                }
                name = null;
                return false;
            }
        }
        private sealed class FastTableSnapshot
        {
            public readonly EditableTable Joints, Areas, Sections;
            public readonly Dictionary<string, string> JointGuids, AreaGuids;
            public FastTableSnapshot(EditableTable joints, EditableTable areas, EditableTable sections)
            {
                Joints = joints; Areas = areas; Sections = sections;
                JointGuids = joints.NonEmptyMap("Joint", "GUID", new string[0]);
                AreaGuids = areas.NonEmptyMap("Area", "GUID", new string[0]);
            }
        }
        private sealed class AreaContext
        {
            public readonly string Name;
            public readonly string[] CornerNames;
            public readonly double[][] Corners;
            public readonly Plane Plane;
            public readonly List<BoundaryPoint>[] EdgePoints;
            public readonly List<ConstraintPoint> InteriorPoints = new List<ConstraintPoint>();
            public readonly List<FrameConstraint> FrameConstraints = new List<FrameConstraint>();
            public readonly List<HoleDefinition> Holes = new List<HoleDefinition>();
            public readonly HashSet<string> ConstraintPointNames = new HashSet<string>();
            public bool ForceRefinement;
            public AreaContext(string name, string[] cornerNames, double[][] corners, Plane plane)
            {
                Name = name;
                CornerNames = cornerNames;
                Corners = corners;
                Plane = plane;
                EdgePoints = Enumerable.Range(0, corners.Length).Select(index => new List<BoundaryPoint>()).ToArray();
            }
        }
        private sealed class MeshOperation
        {
            public readonly string SourceArea, BackupArea;
            public readonly PointSnapshot[] OriginalPoints;
            public readonly List<string> GeneratedAreas = new List<string>();
            public readonly List<string> GeneratedPoints = new List<string>();
            public bool FastMode;
            public string PrimaryGeneratedArea;
            public string CommitBackupArea;
            public bool Active = true;
            public bool Undone;
            public MeshOperation(string sourceArea, string backupArea, PointSnapshot[] originalPoints)
            { SourceArea = sourceArea; BackupArea = backupArea; OriginalPoints = originalPoints; }
        }
        private sealed class MeshAttemptResult
        {
            public readonly MeshOperation Operation;
            public readonly MeshQualityReport Quality;
            public MeshAttemptResult(MeshOperation operation, MeshQualityReport quality)
            { Operation = operation; Quality = quality; }
        }
        private sealed class PointSnapshot
        {
            public readonly string Name;
            public readonly double[] Coordinates;
            public readonly bool Special;
            public readonly string[] Groups;
            public PointSnapshot(string name, double[] coordinates, bool special, string[] groups)
            { Name = name; Coordinates = coordinates; Special = special; Groups = groups; }
        }
        private sealed class MeshQualityReport
        {
            public readonly bool Passed;
            public readonly string Summary;
            public readonly List<QualityMetric> Metrics = new List<QualityMetric>();
            public MeshQualityReport(bool passed, string summary) { Passed = passed; Summary = summary; }
        }
        private sealed class QualityMetric
        {
            public readonly string Name, Value, Reference;
            public readonly double Score;
            public QualityMetric(string name, string value, string reference, double score)
            { Name = name; Value = value; Reference = reference; Score = Clamp01(score); }
            public string Level
            {
                get
                {
                    if (Score >= 0.75) return "EXCELLENT";
                    if (Score >= 0.50) return "ACCEPTABLE";
                    if (Score >= 0.25) return "POOR";
                    return "CRITICAL";
                }
            }
        }
        private sealed class AreaLoads
        {
            private readonly List<Action<string>> assignments = new List<Action<string>>();
            public int Count { get { return assignments.Count; } }
            public void Add(Action<string> assignment) { assignments.Add(assignment); }
            public void Apply(string areaName) { foreach (Action<string> assignment in assignments) assignment(areaName); }
        }
        private sealed class Plane
        {
            private readonly double[] origin, u, v, normal;
            private Plane(double[] origin, double[] u, double[] v, double[] normal) { this.origin = origin; this.u = u; this.v = v; this.normal = normal; }
            public static Plane FromPolygon(double[][] points)
            {
                double[] first = Subtract(points[1], points[0]);
                double[] normal = null;
                for (int i = 2; i < points.Length && normal == null; i++)
                {
                    double[] candidate = Cross(first, Subtract(points[i], points[0]));
                    if (Norm(candidate) > Tolerance) normal = Normalize(candidate);
                }
                if (normal == null) throw new InvalidOperationException("Degenerate area.");
                var plane = new Plane(points[0], Normalize(first), Normalize(Cross(normal, Normalize(first))), normal);
                if (points.Any(point => Math.Abs(plane.SignedDistance(point)) > Tolerance))
                    throw new InvalidOperationException("The area must be planar.");
                return plane;
            }
            public double SignedDistance(double[] point) { return Dot(Subtract(point, origin), normal); }
            public double[] Project(double[] point) { double[] d = Subtract(point, origin); return new[] { Dot(d, u), Dot(d, v) }; }
            public double[] VectorFromPlane(double x, double y)
            { return new[] { x * u[0] + y * v[0], x * u[1] + y * v[1], x * u[2] + y * v[2] }; }
            public double[] PointFromPlane(double x, double y)
            { return new[] { origin[0] + x * u[0] + y * v[0], origin[1] + x * u[1] + y * v[1], origin[2] + x * u[2] + y * v[2] }; }
            public double[] Normal { get { return normal; } }
        }
        private static Panel CreateDialogHeader(string title, string subtitle, int width)
        {
            var header = new Panel { Left = 0, Top = 0, Width = width, Height = 76, BackColor = UiNavy };
            header.Controls.Add(new Label
            {
                Left = 22, Top = 13, Width = width - 44, Height = 31, Text = title,
                Font = new Font("Segoe UI", 15, FontStyle.Bold), ForeColor = Color.White, BackColor = UiNavy
            });
            header.Controls.Add(new Label
            {
                Left = 24, Top = 45, Width = width - 48, Height = 20, Text = subtitle,
                Font = new Font("Segoe UI", 8.5f), ForeColor = UiBorder, BackColor = UiNavy
            });
            return header;
        }

        private static void StyleButton(Button button, bool primary)
        {
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 1;
            button.FlatAppearance.BorderColor = primary ? UiBlue : UiBorder;
            button.BackColor = primary ? UiBlue : Color.White;
            button.ForeColor = primary ? Color.White : UiBody;
            button.Font = new Font("Segoe UI", 9, primary ? FontStyle.Bold : FontStyle.Regular);
            button.Height = 32;
            button.Cursor = Cursors.Default;
        }

        private static void AddDialogFooter(Form form, int top, int width)
        {
            form.Controls.Add(new Panel { Left = 20, Top = top, Width = width - 40, Height = 1, BackColor = UiBorder });
            string logoPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "img", "logo.png");
            if (File.Exists(logoPath))
            {
                var logo = new PictureBox
                {
                    Left = 20, Top = top + 4, Width = 46, Height = 42,
                    SizeMode = PictureBoxSizeMode.Zoom, Cursor = Cursors.Default
                };
                using (Image fileImage = Image.FromFile(logoPath)) logo.Image = new Bitmap(fileImage);
                logo.Click += delegate
                {
                    Process.Start(new ProcessStartInfo("https://www.csi-italia.eu") { UseShellExecute = true });
                };
                var tooltip = new ToolTip();
                tooltip.SetToolTip(logo, "CSi Italia");
                form.Disposed += delegate { tooltip.Dispose(); logo.Image.Dispose(); };
                form.Controls.Add(logo);
            }
            else
            {
                var company = new LinkLabel
                {
                    Left = 20, Top = top + 12, Width = 150, Height = 22, Text = "CSi Italia",
                    LinkColor = UiBlue, ActiveLinkColor = UiNavy, VisitedLinkColor = UiBlue,
                    Font = new Font("Segoe UI", 9, FontStyle.Bold), Cursor = Cursors.Default
                };
                company.LinkClicked += delegate
                {
                    Process.Start(new ProcessStartInfo("https://www.csi-italia.eu") { UseShellExecute = true });
                };
                form.Controls.Add(company);
            }
            var licenseLink = new LinkLabel
            {
                Left = 78, Top = top + 12, Width = 96, Height = 22,
                Text = L("GPL / Source", "GPL / Fonti"), Tag = "license-link",
                LinkColor = UiBlue, ActiveLinkColor = UiNavy, VisitedLinkColor = UiBlue
            };
            licenseLink.LinkClicked += delegate
            {
                string root = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                MessageBox.Show(form,
                    L("Copyright (C) 2026 Leonardo Bandini. GPL version 2 or later; no warranty. " +
                      "Read LICENSE, GPL-3.0.txt and SOURCE.md in " + root + " for license terms and corresponding source.",
                      "Copyright (C) 2026 Leonardo Bandini. GPL versione 2 o successiva; nessuna garanzia. " +
                      "Leggere LICENSE, GPL-3.0.txt e SOURCE.md in " + root + " per licenze e sorgenti corrispondenti."),
                    WindowTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
            };
            form.Controls.Add(licenseLink);
            form.Controls.Add(new Label
            {
                Left = width - 180, Top = top + 12, Width = 160, Height = 22,
                Text = L("Version ", "Versione ") + PluginVersion, TextAlign = ContentAlignment.TopRight,
                ForeColor = UiMuted, Tag = "version"
            });
        }

        private sealed class MeshOptionsDialog : Form
        {
            private readonly TextBox size = new TextBox();
            private readonly CheckBox symmetric = new CheckBox();
            private readonly ComboBox symmetryAxis = new ComboBox();
            private readonly TabControl profiles = new TabControl();
            private readonly CheckBox generateHoles = new CheckBox();
            private readonly Label openingGroupLabel = new Label();
            private readonly ComboBox openingGroup = new ComboBox();
            private readonly CheckBox generateCircularHoles = new CheckBox();
            private readonly Label holeGroupLabel = new Label();
            private readonly ComboBox holeGroup = new ComboBox();
            private readonly Label holeDiameterLabel = new Label();
            private readonly TextBox holeDiameter = new TextBox();
            private readonly CheckBox preferRegular = new CheckBox();
            private readonly CheckBox stressRefinement = new CheckBox();
            private readonly CheckBox fastMode = new CheckBox();
            private readonly ProgressBar progress = new ProgressBar();
            private readonly Label status = new Label();
            private readonly System.Windows.Forms.Timer elapsedTimer = new System.Windows.Forms.Timer();
            private readonly Stopwatch meshClock = new Stopwatch();
            private readonly Stopwatch operationClock = new Stopwatch();
            private int meshAreasCompleted;
            private int meshAreasTotal;
            private bool meshingActive;
            private readonly Button generate = new Button();
            private readonly Button close = new Button();
            private readonly Button details = new Button();
            private readonly Button undo = new Button();
            private readonly ComboBox language = new ComboBox();
            private readonly LinkLabel verifiedExamples = new LinkLabel();
            private readonly LinkLabel updateNotice = new LinkLabel();
            private readonly Label headerTitle;
            private readonly Label headerSubtitle;
            private readonly Label maximumSizeLabel = new Label();
            private readonly Label replacementNotice = new Label();
            private readonly bool hasFrames;
            private readonly bool hasSelectedAreas;
            private readonly bool hasSymmetryAxes;
            private readonly SymmetryAxis doubleSymmetryAxis;
            private readonly SymmetryAxis[] symmetryAxes;
            private readonly string units;
            private bool working;
            private bool checkingUpdates;
            private string availableVersion;
            private string availableReleaseUrl;
            private string availableDownloadUrl;
            private MeshQualityReport qualityReport;
            private Action undoAction;
            public double MaxSize { get; private set; }
            public bool Symmetric { get { return symmetric.Checked; } }
            public SymmetryAxis SelectedSymmetryAxis { get { return DoubleSymmetrySelected
                ? doubleSymmetryAxis : symmetryAxis.SelectedItem as SymmetryAxis; } }
            public bool DoubleSymmetrySelected { get { return (symmetryAxis.SelectedItem as SymmetryAxis) != null &&
                (symmetryAxis.SelectedItem as SymmetryAxis).SecondaryDirection != null; } }
            public bool GenerateHoles { get { return generateHoles.Checked; } }
            public string OpeningGroup { get { return openingGroup.SelectedItem as string; } }
            public bool GenerateCircularHoles { get { return profiles.SelectedIndex != 0 && generateCircularHoles.Checked; } }
            public string HoleGroup { get { return holeGroup.SelectedItem as string; } }
            public double HoleDiameter { get; private set; }
            public bool PreferRegularMesh { get { return preferRegular.Checked; } }
            public bool StressRefinement { get { return stressRefinement.Checked; } }
            public bool FastMode { get { return fastMode.Checked; } }
            public bool StartRequested { get; private set; }
            public bool RetryRequested { get; private set; }
            public Exception UndoFailure { get; private set; }
            public MeshOptionsDialog(string units, bool hasFrames, string[] pointGroups, string[] openingGroups,
                SymmetryAxis[] symmetryAxes, bool hasSelectedAreas = true)
            {
                this.units = units;
                this.hasFrames = hasFrames;
                this.hasSelectedAreas = hasSelectedAreas;
                this.symmetryAxes = symmetryAxes;
                hasSymmetryAxes = symmetryAxes.Length > 0;
                doubleSymmetryAxis = symmetryAxes.FirstOrDefault(axis => axis.SecondaryDirection != null);
                Text = WindowTitle; FormBorderStyle = FormBorderStyle.FixedDialog; StartPosition = FormStartPosition.CenterScreen;
                ClientSize = new Size(570, 710); MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false;
                Font = new Font("Segoe UI", 9); BackColor = Color.White; ForeColor = UiBody; AutoScaleMode = AutoScaleMode.Dpi;
                Panel header = CreateDialogHeader("SAP2000 Quad Transition Mesh", "Conforming quadrilateral mesh generation", ClientSize.Width);
                headerTitle = (Label)header.Controls[0]; headerSubtitle = (Label)header.Controls[1]; Controls.Add(header);
                headerTitle.Width = 390; headerSubtitle.Width = 410;
                verifiedExamples.Left = 414; verifiedExamples.Top = 10; verifiedExamples.Width = 136; verifiedExamples.Height = 27;
                verifiedExamples.Tag = "atomic-report"; verifiedExamples.TextAlign = ContentAlignment.MiddleRight;
                verifiedExamples.BackColor = UiNavy; verifiedExamples.LinkColor = UiBorder;
                verifiedExamples.ActiveLinkColor = Color.White; verifiedExamples.VisitedLinkColor = UiBorder;
                verifiedExamples.Cursor = Cursors.Hand;
                verifiedExamples.LinkClicked += delegate
                {
                    string report = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location),
                        "docs", "SAP2000-Quad-Mesher-Atomic-Examples.pdf");
                    if (!File.Exists(report))
                    {
                        MessageBox.Show(this, L("The verified examples PDF is missing from the installation.",
                            "Il PDF degli esempi verificati non e presente nell'installazione."),
                            WindowTitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    Process.Start(new ProcessStartInfo(report) { UseShellExecute = true });
                };
                header.Controls.Add(verifiedExamples);
                language.Left = 442; language.Top = 43; language.Width = 108; language.Height = 24;
                language.DropDownStyle = ComboBoxStyle.DropDownList; language.FlatStyle = FlatStyle.Flat;
                language.Items.AddRange(new object[] { "English", "Italiano" }); language.SelectedIndex = useItalian ? 1 : 0;
                Controls.Add(language); language.BringToFront();
                profiles.Left = 20; profiles.Top = 92; profiles.Width = 530; profiles.Height = 38;
                profiles.TabPages.Add("Reinforced Concrete"); profiles.TabPages.Add("Steel Structures"); profiles.TabPages.Add("General Purpose");
                profiles.DrawMode = TabDrawMode.OwnerDrawFixed; profiles.SizeMode = TabSizeMode.Fixed; profiles.ItemSize = new Size(174, 34);
                profiles.DrawItem += delegate(object sender, DrawItemEventArgs e)
                {
                    bool active = e.Index == profiles.SelectedIndex;
                    Rectangle bounds = e.Bounds;
                    using (var background = new SolidBrush(active ? UiBlue : UiInactive)) e.Graphics.FillRectangle(background, bounds);
                    using (var border = new Pen(active ? UiBlue : UiBorder)) e.Graphics.DrawRectangle(border, bounds.X, bounds.Y, bounds.Width - 1, bounds.Height - 1);
                    using (var tabFont = new Font("Segoe UI", 8.5f, FontStyle.Bold))
                        TextRenderer.DrawText(e.Graphics, profiles.TabPages[e.Index].Text, tabFont, bounds,
                            active ? Color.White : UiBody, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine);
                };
                profiles.SelectedIndex = 2; Controls.Add(profiles);
                maximumSizeLabel.Left = 20; maximumSizeLabel.Top = 151; maximumSizeLabel.Width = 250; Controls.Add(maximumSizeLabel);
                size.Left = 440; size.Top = 147; size.Width = 110; size.Text = DefaultLength(0.1, units); size.BorderStyle = BorderStyle.FixedSingle; Controls.Add(size);
                symmetric.Left = 20; symmetric.Top = 184; symmetric.Width = 210; symmetric.Text = "Enforce exact symmetry";
                symmetric.FlatStyle = FlatStyle.Flat;
                symmetric.Enabled = true; Controls.Add(symmetric);
                symmetryAxis.Left = 235; symmetryAxis.Top = 180; symmetryAxis.Width = 315; symmetryAxis.DropDownStyle = ComboBoxStyle.DropDownList; symmetryAxis.FlatStyle = FlatStyle.Flat;
                symmetryAxis.Items.AddRange(symmetryAxes); if (hasSymmetryAxes) symmetryAxis.SelectedIndex = 0;
                symmetryAxis.Enabled = false; Controls.Add(symmetryAxis);
                symmetric.CheckedChanged += delegate { symmetryAxis.Enabled = symmetric.Checked && hasSymmetryAxes && !working; };
                generateHoles.Left = 20; generateHoles.Top = 216; generateHoles.Width = 530; generateHoles.FlatStyle = FlatStyle.Flat;
                generateHoles.Text = "Generate holes enclosed by selected frames or shell edges";
                generateHoles.Enabled = hasFrames; Controls.Add(generateHoles);
                openingGroupLabel.Left = 40; openingGroupLabel.Top = 250; openingGroupLabel.Width = 190; openingGroupLabel.Text = "Opening-boundary group:"; Controls.Add(openingGroupLabel);
                openingGroup.Left = 235; openingGroup.Top = 246; openingGroup.Width = 315; openingGroup.DropDownStyle = ComboBoxStyle.DropDownList; openingGroup.FlatStyle = FlatStyle.Flat;
                openingGroup.Items.AddRange(openingGroups); if (openingGroups.Length > 0) openingGroup.SelectedIndex = 0; Controls.Add(openingGroup);
                generateHoles.CheckedChanged += delegate { UpdateOptionState(); };
                generateCircularHoles.Left = 20; generateCircularHoles.Top = 280; generateCircularHoles.Width = 530; generateCircularHoles.FlatStyle = FlatStyle.Flat;
                generateCircularHoles.Text = "Generate circular O-grid holes";
                generateCircularHoles.Enabled = pointGroups.Length > 0; Controls.Add(generateCircularHoles);
                holeGroupLabel.Left = 40; holeGroupLabel.Top = 314; holeGroupLabel.Width = 180; holeGroupLabel.Text = "Hole-center group:"; Controls.Add(holeGroupLabel);
                holeGroup.Left = 235; holeGroup.Top = 310; holeGroup.Width = 315; holeGroup.DropDownStyle = ComboBoxStyle.DropDownList; holeGroup.FlatStyle = FlatStyle.Flat;
                holeGroup.Items.AddRange(pointGroups); if (pointGroups.Length > 0) holeGroup.SelectedIndex = 0; Controls.Add(holeGroup);
                holeDiameterLabel.Left = 40; holeDiameterLabel.Top = 346; holeDiameterLabel.Width = 250; holeDiameterLabel.Text = "Hole diameter (" + units + "):"; Controls.Add(holeDiameterLabel);
                holeDiameter.Left = 440; holeDiameter.Top = 342; holeDiameter.Width = 110; holeDiameter.Text = DefaultLength(0.05, units); holeDiameter.BorderStyle = BorderStyle.FixedSingle; Controls.Add(holeDiameter);
                holeGroup.Enabled = holeDiameter.Enabled = false;
                generateCircularHoles.CheckedChanged += delegate { UpdateOptionState(); };
                preferRegular.Left = 20; preferRegular.Top = 376; preferRegular.Width = 530; preferRegular.FlatStyle = FlatStyle.Flat;
                preferRegular.Text = "Prefer regular meshes aligned with principal orthogonal axes"; Controls.Add(preferRegular);
                stressRefinement.Left = 20; stressRefinement.Top = 408; stressRefinement.Width = 530; stressRefinement.FlatStyle = FlatStyle.Flat;
                stressRefinement.Text = "Refine near stress concentrations and geometry changes"; Controls.Add(stressRefinement);
                preferRegular.CheckedChanged += delegate
                {
                    if (preferRegular.Checked) stressRefinement.Checked = false;
                    UpdateOptionState();
                };
                stressRefinement.CheckedChanged += delegate
                {
                    if (stressRefinement.Checked) preferRegular.Checked = false;
                    UpdateOptionState();
                };
                profiles.SelectedIndexChanged += delegate
                {
                    if (profiles.SelectedIndex == 0) { generateCircularHoles.Checked = false; preferRegular.Checked = true; stressRefinement.Checked = false; }
                    else if (profiles.SelectedIndex == 1) { preferRegular.Checked = false; stressRefinement.Checked = true; }
                    UpdateOptionState();
                };
                fastMode.Left = 20; fastMode.Top = 440; fastMode.Width = 530; fastMode.FlatStyle = FlatStyle.Flat;
                fastMode.Text = "FAST - bulk insertion through SAP2000 tables"; Controls.Add(fastMode);
                replacementNotice.Left = 20; replacementNotice.Top = 474; replacementNotice.Width = 530;
                replacementNotice.Height = 28; replacementNotice.ForeColor = UiMuted; Controls.Add(replacementNotice);

                status.Left = 20; status.Top = 508; status.Width = 530; status.Height = 54; status.Text = "Ready."; status.ForeColor = UiBody; Controls.Add(status);
                elapsedTimer.Interval = 1000;
                elapsedTimer.Tick += delegate { if (meshingActive) UpdateMeshingStatus(); };
                progress.Left = 20; progress.Top = 566; progress.Width = 530; progress.Height = 20;
                progress.Minimum = 0; progress.Maximum = 100; progress.Value = 0; Controls.Add(progress);

                generate.Text = "Generate"; generate.Left = 20; generate.Top = 606; generate.Width = 96; StyleButton(generate, true);
                undo.Text = "Undo mesh"; undo.Left = 124; undo.Top = 606; undo.Width = 104; undo.Enabled = false; StyleButton(undo, false);
                details.Text = "Mesh details"; details.Left = 236; details.Top = 606; details.Width = 112; details.Enabled = false; StyleButton(details, false);
                close.Text = "Cancel"; close.Left = 454; close.Top = 606; close.Width = 96; StyleButton(close, false);
                generate.Click += delegate
                {
                    if (!hasSelectedAreas) return;
                    double value;
                    if (!double.TryParse(size.Text.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out value) || value <= 0)
                    { MessageBox.Show(L("Invalid maximum size.", "Dimensione massima non valida."), WindowTitle, MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                    MaxSize = value;
                    if (PreferRegularMesh && StressRefinement)
                    { MessageBox.Show(L("Regular meshing and local refinement are mutually exclusive.", "La mesh regolare e il raffinamento locale si escludono a vicenda."), WindowTitle, MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                    if (GenerateHoles && openingGroup.SelectedItem == null)
                    { MessageBox.Show(L("Select an opening-boundary group.", "Selezionare un gruppo per il contorno delle aperture."), WindowTitle, MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                    if (GenerateCircularHoles)
                    {
                        double diameter;
                        if (holeGroup.SelectedItem == null)
                        { MessageBox.Show(L("Select a hole-center group.", "Selezionare un gruppo di centri dei fori."), WindowTitle, MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                        if (!double.TryParse(holeDiameter.Text.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out diameter) ||
                            double.IsNaN(diameter) || double.IsInfinity(diameter) || diameter <= 0)
                        { MessageBox.Show(L("Invalid hole diameter.", "Diametro del foro non valido."), WindowTitle, MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                        HoleDiameter = diameter;
                    }
                    RetryRequested = false;
                    operationClock.Restart();
                    StartRequested = true;
                };
                details.Click += delegate
                {
                    if (qualityReport != null)
                        using (var qualityDialog = new QualityReportDialog(qualityReport)) qualityDialog.ShowDialog(this);
                };
                undo.Click += delegate
                {
                    if (undoAction == null) return;
                    working = true;
                    ControlBox = false;
                    undo.Enabled = false;
                    details.Enabled = false;
                    close.Enabled = false;
                    SetIndeterminate(L("Restoring the original objects and selection...", "Ripristino degli oggetti originali e della selezione..."));
                    try
                    {
                        undoAction();
                        undoAction = null;
                        qualityReport = null;
                        ResetReady();
                    }
                    catch (Exception exception)
                    {
                        UndoFailure = exception;
                        status.Text = L("Undo failed.", "Annullamento non riuscito.");
                    }
                    finally
                    {
                        working = false;
                        ControlBox = true;
                        close.Enabled = true;
                    }
                };
                close.Click += delegate { Close(); };
                FormClosing += delegate(object sender, FormClosingEventArgs e) { if (working) e.Cancel = true; };
                Controls.Add(generate); Controls.Add(undo); Controls.Add(details); Controls.Add(close);
                AddDialogFooter(this, 656, ClientSize.Width);
                updateNotice.Width = 210; updateNotice.Left = (ClientSize.Width - updateNotice.Width) / 2;
                updateNotice.Top = 668; updateNotice.Height = 23;
                updateNotice.TextAlign = ContentAlignment.MiddleCenter; updateNotice.Tag = "update-notice";
                updateNotice.LinkColor = UiBlue; updateNotice.ActiveLinkColor = UiNavy;
                updateNotice.VisitedLinkColor = UiBlue; updateNotice.Cursor = Cursors.Default;
                updateNotice.LinkClicked += async delegate
                {
                    if (!string.IsNullOrEmpty(availableDownloadUrl))
                    {
                        MessageBox.Show(this, L("The ZIP download will open in your browser. Extract it, close SAP2000, then run install_plugin.cmd from the extracted folder. Reopen SAP2000 to use the new version.",
                            "Il download dello ZIP si aprira nel browser. Estrailo, chiudi SAP2000, quindi esegui install_plugin.cmd dalla cartella estratta. Riapri SAP2000 per usare la nuova versione."),
                            WindowTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Process.Start(new ProcessStartInfo(availableDownloadUrl) { UseShellExecute = true });
                    }
                    else await CheckForUpdatesAsync();
                };
                Controls.Add(updateNotice);
                Shown += async delegate { await CheckForUpdatesAsync(); };
                CancelButton = close;
                language.SelectedIndexChanged += delegate { useItalian = language.SelectedIndex == 1; ApplyLanguage(); };
                ApplyLanguage();
                UpdateOptionState();
            }
            private static bool TryGetNewRelease(string json, out string version, out string releaseUrl, out string downloadUrl)
            {
                version = releaseUrl = downloadUrl = null;
                var manifest = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(json);
                object value, url, download;
                if (manifest == null || !manifest.TryGetValue("version", out value) ||
                    !manifest.TryGetValue("releaseUrl", out url) ||
                    !manifest.TryGetValue("downloadUrl", out download)) return false;
                Version candidate, current;
                if (!Version.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture), out candidate) ||
                    !Version.TryParse(PluginVersion, out current) || candidate.CompareTo(current) <= 0) return false;
                Uri uri, downloadUri;
                if (!Uri.TryCreate(Convert.ToString(url, CultureInfo.InvariantCulture), UriKind.Absolute, out uri) ||
                    uri.Scheme != Uri.UriSchemeHttps || uri.Host != "github.com" ||
                    uri.AbsolutePath != "/leonardobandini/sap2000-quad-mesher-updates/releases/tag/v" + candidate ||
                    !Uri.TryCreate(Convert.ToString(download, CultureInfo.InvariantCulture), UriKind.Absolute, out downloadUri) ||
                    downloadUri.Scheme != Uri.UriSchemeHttps || downloadUri.Host != "github.com" ||
                    downloadUri.AbsolutePath != "/leonardobandini/sap2000-quad-mesher-updates/releases/download/v" + candidate + "/Sap2000QuadMesher-" + candidate + ".zip")
                    return false;
                version = candidate.ToString();
                releaseUrl = uri.AbsoluteUri;
                downloadUrl = downloadUri.AbsoluteUri;
                return true;
            }
            private async Task CheckForUpdatesAsync()
            {
                if (checkingUpdates || IsDisposed) return;
                checkingUpdates = true;
                updateNotice.Text = L("Checking for updates...", "Ricerca aggiornamenti...");
                try
                {
                    using (var handler = new HttpClientHandler { SslProtocols = SslProtocols.Tls12 })
                    using (var client = new HttpClient(handler))
                    {
                        client.Timeout = TimeSpan.FromSeconds(3);
                        client.DefaultRequestHeaders.UserAgent.ParseAdd("SapQuadMesher/" + PluginVersion);
                        string json = await client.GetStringAsync(UpdateManifestUrl);
                        string version, releaseUrl, downloadUrl;
                        if (TryGetNewRelease(json, out version, out releaseUrl, out downloadUrl))
                        {
                            availableVersion = version;
                            availableReleaseUrl = releaseUrl;
                            availableDownloadUrl = downloadUrl;
                        }
                    }
                }
                catch (Exception)
                {
                    // No network connection must never prevent the options window from opening.
                }
                finally
                {
                    checkingUpdates = false;
                    if (!IsDisposed) UpdateNoticeText();
                }
            }
            private void UpdateNoticeText()
            {
                updateNotice.Text = checkingUpdates ? L("Checking for updates...", "Ricerca aggiornamenti...") :
                    availableVersion == null ? L("Check for updates", "Cerca aggiornamenti") :
                    L("Download version ", "Scarica versione ") + availableVersion;
            }
            private static string DefaultLength(double meters, string lengthUnit)
            {
                double scale;
                switch (lengthUnit)
                {
                    case "mm": scale = 1000; break;
                    case "cm": scale = 100; break;
                    case "m": scale = 1; break;
                    case "in": scale = 1 / 0.0254; break;
                    case "ft": scale = 1 / 0.3048; break;
                    default: throw new InvalidOperationException("Unsupported length unit: " + lengthUnit);
                }
                return (meters * scale).ToString("0.########", CultureInfo.InvariantCulture);
            }
            public void SetMeshingAreas(int completed, int total)
            {
                if (completed == 0)
                {
                    meshClock.Restart();
                    elapsedTimer.Start();
                }
                meshAreasCompleted = completed;
                meshAreasTotal = total;
                meshingActive = completed < total;
                if (meshingActive) UpdateMeshingStatus();
                else elapsedTimer.Stop();
            }
            public void ApplyAutomatedOptions()
            {
                string profile = Environment.GetEnvironmentVariable("SAP_QUAD_ATOMIC_PROFILE");
                int index = profile == "Reinforced Concrete" ? 0 : profile == "Steel Structures" ? 1 : 2;
                profiles.SelectedIndex = index;
                size.Text = Environment.GetEnvironmentVariable("SAP_QUAD_ATOMIC_SIZE");
                string group = Environment.GetEnvironmentVariable("SAP_QUAD_ATOMIC_HOLE_GROUP");
                if (!string.IsNullOrEmpty(group))
                {
                    if (!holeGroup.Items.Contains(group)) throw new InvalidOperationException("Hole-center group not found: " + group);
                    generateCircularHoles.Checked = true;
                    holeGroup.SelectedItem = group;
                    holeDiameter.Text = Environment.GetEnvironmentVariable("SAP_QUAD_ATOMIC_DIAMETER");
                }
                string opening = Environment.GetEnvironmentVariable("SAP_QUAD_ATOMIC_OPENING_GROUP");
                if (!string.IsNullOrEmpty(opening))
                {
                    if (!openingGroup.Items.Contains(opening)) throw new InvalidOperationException("Opening-boundary group not found: " + opening);
                    generateHoles.Checked = true;
                    openingGroup.SelectedItem = opening;
                }
                if (Environment.GetEnvironmentVariable("SAP_QUAD_ATOMIC_SYMMETRY") == "1") symmetric.Checked = true;
                fastMode.Checked = Environment.GetEnvironmentVariable("SAP_QUAD_ATOMIC_FAST") == "1";
                if (Environment.GetEnvironmentVariable("SAP_QUAD_ATOMIC_REGULAR") == "1") preferRegular.Checked = true;
                generate.PerformClick();
                if (!StartRequested) throw new InvalidOperationException("The automated mesh options could not be applied.");
                Console.WriteLine("mesh-stage=automation-generate");
            }
            protected override void Dispose(bool disposing)
            {
                if (disposing) elapsedTimer.Dispose();
                base.Dispose(disposing);
            }
            private void UpdateMeshingStatus()
            {
                string elapsed = L("Elapsed: ", "Trascorso: ") + meshClock.Elapsed.ToString(@"mm\:ss");
                string estimate = L("ETA available after the first area.", "Stima disponibile dopo la prima area.");
                if (meshAreasCompleted > 0)
                {
                    TimeSpan estimatedTotal = TimeSpan.FromTicks(
                        meshClock.Elapsed.Ticks * meshAreasTotal / meshAreasCompleted);
                    TimeSpan remaining = estimatedTotal - meshClock.Elapsed;
                    estimate = L("Estimated remaining: ", "Tempo residuo stimato: ") + remaining.ToString(@"mm\:ss");
                }
                status.Text = L("Generating and optimizing the mesh may take several minutes. Please be patient.",
                    "La generazione e l'ottimizzazione della mesh possono richiedere alcuni minuti. Attendere.") +
                    "\n" + L("Area ", "Area ") + (meshAreasCompleted + 1) + "/" + meshAreasTotal +
                    "  |  " + elapsed + "  |  " + estimate;
            }
            private void ApplyLanguage()
            {
                headerTitle.Text = "SAP2000 Quad Transition Mesh";
                headerSubtitle.Text = L("Conforming quadrilateral mesh generation", "Generazione di mesh quadrilatere conformi");
                verifiedExamples.Text = L("Verified examples", "Esempi verificati");
                profiles.TabPages[0].Text = L("Reinforced Concrete", "Calcestruzzo armato");
                profiles.TabPages[1].Text = L("Steel Structures", "Strutture in acciaio");
                profiles.TabPages[2].Text = L("General Purpose", "Uso generale");
                maximumSizeLabel.Text = L("Maximum size (", "Dimensione massima (") + units + "):";
                symmetric.Text = L("Enforce exact symmetry", "Imponi simmetria esatta");
                generateHoles.Text = L("Generate holes enclosed by selected frames or shell edges", "Genera aperture chiuse da telai o bordi shell selezionati");
                openingGroupLabel.Text = L("Opening-boundary group:", "Gruppo contorno aperture:");
                generateCircularHoles.Text = L("Generate circular O-grid holes", "Genera fori circolari O-grid");
                holeGroupLabel.Text = L("Hole-center group:", "Gruppo centri dei fori:");
                holeDiameterLabel.Text = L("Hole diameter (", "Diametro foro (") + units + "):";
                preferRegular.Text = L("Prefer regular meshes aligned with principal orthogonal axes", "Preferisci mesh regolari allineate agli assi ortogonali principali");
                stressRefinement.Text = L("Refine near stress concentrations and geometry changes", "Raffina vicino a concentrazioni di tensione e variazioni geometriche");
                fastMode.Text = L("FAST - bulk insertion through SAP2000 tables", "FAST - inserimento massivo tramite tabelle SAP2000");
                replacementNotice.Text = L("Generate replaces the selected areas; properties and loads are transferred.",
                    "Genera sostituisce le aree selezionate; proprieta e carichi vengono trasferiti.");
                generate.Text = L("Generate", "Genera");
                undo.Text = L("Undo mesh", "Annulla mesh");
                details.Text = L("Mesh details", "Dettagli mesh");
                close.Text = qualityReport == null ? L("Cancel", "Annulla") : L("Apply", "Applica");
                if (!working && qualityReport == null && !RetryRequested) status.Text = L("Ready.", "Pronto.");
                if (!hasSelectedAreas) status.Text = L("Select at least one area in SAP2000, then reopen the plugin.",
                    "Selezionare almeno un'area in SAP2000, poi riaprire il plugin.");
                UpdateNoticeText();
                foreach (Control control in Controls)
                {
                    if (control.Tag as string == "version") control.Text = L("Version ", "Versione ") + PluginVersion;
                    if (control.Tag as string == "license-link") control.Text = L("GPL / Source", "GPL / Fonti");
                }
                object selected = symmetryAxis.SelectedItem;
                symmetryAxis.Items.Clear(); symmetryAxis.Items.AddRange(symmetryAxes);
                if (selected != null) symmetryAxis.SelectedItem = selected;
                else if (hasSymmetryAxes) symmetryAxis.SelectedIndex = 0;
                profiles.Invalidate();
            }
            private void UpdateOptionState()
            {
                bool circularVisible = profiles.SelectedIndex != 0;
                generateCircularHoles.Visible = holeGroupLabel.Visible = holeGroup.Visible = holeDiameterLabel.Visible = holeDiameter.Visible = circularVisible;
                preferRegular.Visible = profiles.SelectedIndex != 1;
                stressRefinement.Visible = profiles.SelectedIndex != 0;
                if (working) return;
                if (!hasSelectedAreas)
                {
                    profiles.Enabled = size.Enabled = symmetric.Enabled = symmetryAxis.Enabled = false;
                    generateHoles.Enabled = openingGroup.Enabled = generateCircularHoles.Enabled = false;
                    holeGroup.Enabled = holeDiameter.Enabled = preferRegular.Enabled = stressRefinement.Enabled = false;
                    fastMode.Enabled = generate.Enabled = false;
                    return;
                }
                symmetric.Enabled = hasSymmetryAxes;
                symmetryAxis.Enabled = symmetric.Checked && hasSymmetryAxes;
                generateHoles.Enabled = hasFrames && openingGroup.Items.Count > 0;
                openingGroup.Enabled = generateHoles.Checked && generateHoles.Enabled;
                generateCircularHoles.Enabled = circularVisible && holeGroup.Items.Count > 0;
                holeGroup.Enabled = holeDiameter.Enabled = GenerateCircularHoles;
                preferRegular.Enabled = preferRegular.Visible && !stressRefinement.Checked;
                stressRefinement.Enabled = stressRefinement.Visible && !preferRegular.Checked;
            }
            public void BeginWork(string text)
            {
                working = true;
                ControlBox = false;
                size.Enabled = false;
                profiles.Enabled = false;
                symmetric.Enabled = false;
                symmetryAxis.Enabled = false;
                generateHoles.Enabled = false;
                openingGroup.Enabled = false;
                generateCircularHoles.Enabled = false;
                holeGroup.Enabled = false;
                holeDiameter.Enabled = false;
                preferRegular.Enabled = false;
                stressRefinement.Enabled = false;
                fastMode.Enabled = false;
                language.Enabled = false;
                generate.Enabled = false;
                close.Enabled = false;
                details.Enabled = false;
                SetIndeterminate(text);
            }
            public void SetIndeterminate(string text)
            {
                meshingActive = text == "Generating and optimizing the mesh..." && meshAreasTotal > meshAreasCompleted;
                status.Text = LocalizeMessage(text);
                if (meshingActive) UpdateMeshingStatus();
                progress.Style = ProgressBarStyle.Marquee;
                progress.MarqueeAnimationSpeed = 28;
                Application.DoEvents();
            }
            public void SetProgress(string text, int completed, int total)
            {
                meshingActive = false;
                status.Text = LocalizeMessage(text);
                progress.MarqueeAnimationSpeed = 0;
                progress.Style = ProgressBarStyle.Continuous;
                progress.Value = Math.Max(0, Math.Min(100, total == 0 ? 100 : (int)Math.Round(100.0 * completed / total)));
                Application.DoEvents();
            }
            public void Complete(MeshQualityReport report, int generatedAreaCount, string symmetryNotice, Action undoMesh)
            {
                meshingActive = false;
                elapsedTimer.Stop();
                operationClock.Stop();
                qualityReport = report;
                undoAction = undoMesh;
                UndoFailure = null;
                working = false;
                ControlBox = true;
                progress.MarqueeAnimationSpeed = 0;
                progress.Style = ProgressBarStyle.Continuous;
                progress.Value = 100;
                status.Text = report.Passed
                    ? L("Mesh completed. Area elements created: ", "Mesh completata. Elementi area creati: ") + generatedAreaCount +
                        L(". Quality checks passed.", ". Controlli di qualita superati.")
                    : L("Mesh completed. Area elements created: ", "Mesh completata. Elementi area creati: ") + generatedAreaCount +
                        L(". Review the quality warnings.", ". Verificare gli avvisi sulla qualita.");
                status.Text += L(" Elapsed: ", " Tempo impiegato: ") +
                    operationClock.Elapsed.TotalSeconds.ToString("0.0", CultureInfo.InvariantCulture) + " s.";
                if (symmetric.Checked)
                    status.Text += symmetryNotice == null ? L(" Exact symmetry applied.", " Simmetria esatta applicata.") :
                        L(" Exact symmetry was not applied: ", " La simmetria esatta non e stata applicata: ") +
                        LocalizeMessage(symmetryNotice) + L(". A non-symmetric mesh was generated instead.", ". E stata invece generata una mesh non simmetrica.");
                string completionTrace = Environment.GetEnvironmentVariable("SAP_QUAD_COMPLETION_TRACE");
                if (!string.IsNullOrEmpty(completionTrace))
                    try { File.WriteAllText(completionTrace, "elements=" + generatedAreaCount.ToString(CultureInfo.InvariantCulture) +
                        Environment.NewLine + "seconds=" + operationClock.Elapsed.TotalSeconds.ToString("R", CultureInfo.InvariantCulture) +
                        Environment.NewLine + "message=" + status.Text + Environment.NewLine); } catch { }
                details.Enabled = true;
                undo.Enabled = true;
                close.Enabled = true;
                close.Text = L("Apply", "Applica");
                language.Enabled = true;
                AcceptButton = details;
                Application.DoEvents();
            }
            public void Fail(string message)
            {
                meshingActive = false;
                elapsedTimer.Stop();
                StartRequested = false;
                working = false;
                ControlBox = true;
                qualityReport = null;
                undoAction = null;
                progress.MarqueeAnimationSpeed = 0;
                progress.Style = ProgressBarStyle.Continuous;
                progress.Value = 0;
                status.Text = L("Mesh generation did not complete. Change the options and try again.",
                    "Generazione della mesh non completata. Modificare le opzioni e riprovare.");
                size.Enabled = true;
                profiles.Enabled = true;
                UpdateOptionState();
                fastMode.Enabled = true;
                language.Enabled = true;
                generate.Enabled = true;
                close.Enabled = true;
                close.Text = L("Cancel", "Annulla");
                undo.Enabled = false;
                details.Enabled = false;
                MessageBox.Show(this, LocalizeMessage(message), WindowTitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Activate();
            }
            private void ResetReady()
            {
                StartRequested = false;
                RetryRequested = true;
                working = false;
                ControlBox = true;
                progress.MarqueeAnimationSpeed = 0;
                progress.Style = ProgressBarStyle.Continuous;
                progress.Value = 0;
                status.Text = L("Original objects and selection restored. Ready to generate again.",
                    "Oggetti originali e selezione ripristinati. Pronto per generare di nuovo.");
                size.Enabled = true;
                profiles.Enabled = true;
                UpdateOptionState();
                fastMode.Enabled = true;
                language.Enabled = true;
                generate.Enabled = true;
                undo.Enabled = false;
                details.Enabled = false;
                close.Enabled = true;
                close.Text = L("Cancel", "Annulla");
                AcceptButton = generate;
                Application.DoEvents();
            }
        }
        private sealed class WindowOwner : IWin32Window
        {
            public IntPtr Handle { get; private set; }
            public WindowOwner(IntPtr handle) { Handle = handle; }
        }
        private sealed class QualityReportDialog : Form
        {
            private const string CubitReference = "https://www.sandia.gov/files/cubit/15.2/help_manual/WebHelp/mesh_generation/mesh_quality_assessment/quadrilateral_metrics.htm";
            public QualityReportDialog(MeshQualityReport report)
            {
                Text = WindowTitle + L(" - Mesh Quality", " - Qualita della mesh");
                FormBorderStyle = FormBorderStyle.FixedDialog;
                StartPosition = FormStartPosition.CenterScreen;
                ClientSize = new Size(780, 650);
                MaximizeBox = false;
                MinimizeBox = false;
                ShowInTaskbar = false;
                Font = new Font("Segoe UI", 9);
                BackColor = Color.White;
                ForeColor = UiBody;
                AutoScaleMode = AutoScaleMode.Dpi;
                Controls.Add(CreateDialogHeader(L("Mesh quality", "Qualita della mesh"),
                    L("Element metrics and acceptance checks", "Metriche degli elementi e verifiche di accettazione"), ClientSize.Width));

                var outcome = new Label
                {
                    Left = 20, Top = 91, Width = 740, Height = 31,
                    Text = report.Passed ? L("RESULT: ACCEPTABLE QUALITY", "RISULTATO: QUALITA ACCETTABILE") :
                        L("RESULT: REVIEW THE HIGHLIGHTED METRICS", "RISULTATO: VERIFICARE LE METRICHE EVIDENZIATE"),
                    Font = new Font("Segoe UI", 12, FontStyle.Bold),
                    ForeColor = report.Passed ? Color.FromArgb(28, 110, 62) : Color.FromArgb(180, 82, 20)
                };
                Controls.Add(outcome);
                Controls.Add(new Label { Left = 20, Top = 124, Width = 740, Height = 22,
                    Text = LocalizeMessage(report.Summary), ForeColor = UiMuted });

                var metrics = new FlowLayoutPanel
                {
                    Left = 16, Top = 151, Width = 748, Height = 346, AutoScroll = true,
                    FlowDirection = FlowDirection.TopDown, WrapContents = false, BackColor = UiLight,
                    Padding = new Padding(4)
                };
                foreach (QualityMetric metric in report.Metrics)
                    metrics.Controls.Add(new QualityMetricControl(metric) { Width = 718, Height = 84, Margin = new Padding(2, 2, 2, 5) });
                Controls.Add(metrics);

                Controls.Add(new Label
                {
                    Left = 20, Top = 509, Width = 740, Height = 32, ForeColor = UiMuted,
                    Text = L("Scale: CRITICAL -> POOR -> ACCEPTABLE -> EXCELLENT. Acceptance thresholds are based on CUBIT/Verdict (Knupp).",
                        "Scala: CRITICO -> SCARSO -> ACCETTABILE -> ECCELLENTE. Le soglie di accettazione sono basate su CUBIT/Verdict (Knupp).")
                });
                var source = new LinkLabel
                {
                    Left = 20, Top = 548, Width = 560, Height = 22,
                    Text = L("Open the CUBIT/Verdict technical references", "Apri i riferimenti tecnici CUBIT/Verdict"),
                    LinkColor = UiBlue, ActiveLinkColor = UiNavy, VisitedLinkColor = UiBlue, Cursor = Cursors.Default
                };
                source.LinkClicked += delegate
                {
                    Process.Start(new ProcessStartInfo(CubitReference) { UseShellExecute = true });
                };
                Controls.Add(source);
                var close = new Button { Left = 664, Top = 542, Width = 96,
                    Text = L("Close", "Chiudi"), DialogResult = DialogResult.OK };
                StyleButton(close, true);
                Controls.Add(close);
                AddDialogFooter(this, 594, ClientSize.Width);
                AcceptButton = close;
                CancelButton = close;
            }
        }
        private sealed class QualityMetricControl : Control
        {
            private readonly QualityMetric metric;
            public QualityMetricControl(QualityMetric metric)
            {
                this.metric = metric;
                DoubleBuffered = true;
                BackColor = Color.White;
                ForeColor = UiBody;
                Font = new Font("Segoe UI", 8.5f);
            }
            protected override void OnPaint(PaintEventArgs e)
            {
                base.OnPaint(e);
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                using (var bold = new Font(Font, FontStyle.Bold))
                {
                    using (var bodyBrush = new SolidBrush(UiBody))
                    {
                        e.Graphics.DrawString(LocalizeMessage(metric.Name), bold, bodyBrush, 10, 6);
                        e.Graphics.DrawString(LocalizeMessage(metric.Value), bold, bodyBrush, 230, 6);
                    }
                    string level = LocalizeMessage(metric.Level);
                    SizeF levelSize = e.Graphics.MeasureString(level, bold);
                    e.Graphics.DrawString(level, bold, LevelBrush(metric.Score), Width - levelSize.Width - 12, 6);
                }
                using (var mutedBrush = new SolidBrush(UiMuted)) e.Graphics.DrawString(LocalizeMessage(metric.Reference), Font, mutedBrush, 10, 27);

                int left = 10, top = 48, barWidth = Math.Max(100, Width - 20), barHeight = 13;
                Color[] colors = { Color.FromArgb(196, 55, 55), Color.FromArgb(230, 133, 45), Color.FromArgb(224, 190, 58), Color.FromArgb(55, 155, 92) };
                for (int i = 0; i < colors.Length; i++)
                {
                    int x1 = left + i * barWidth / colors.Length;
                    int x2 = left + (i + 1) * barWidth / colors.Length;
                    using (var brush = new SolidBrush(colors[i])) e.Graphics.FillRectangle(brush, x1, top, x2 - x1, barHeight);
                }
                using (var border = new Pen(UiBorder))
                {
                    e.Graphics.DrawRectangle(border, left, top, barWidth, barHeight);
                    e.Graphics.DrawRectangle(border, 0, 0, Width - 1, Height - 1);
                }
                int marker = left + (int)Math.Round(metric.Score * barWidth);
                using (var pen = new Pen(UiNavy, 2)) e.Graphics.DrawLine(pen, marker, top - 5, marker, top + barHeight + 5);
                Point[] arrow = { new Point(marker - 5, top - 6), new Point(marker + 5, top - 6), new Point(marker, top) };
                using (var navyBrush = new SolidBrush(UiNavy)) e.Graphics.FillPolygon(navyBrush, arrow);
                using (var mutedBrush = new SolidBrush(UiMuted)) e.Graphics.DrawString(L("MINIMUM", "MINIMO"), Font, mutedBrush, left, top + 18);
                string maximum = L("MAXIMUM", "MASSIMO");
                SizeF maximumSize = e.Graphics.MeasureString(maximum, Font);
                using (var mutedBrush = new SolidBrush(UiMuted)) e.Graphics.DrawString(maximum, Font, mutedBrush, left + barWidth - maximumSize.Width, top + 18);
            }
            private static Brush LevelBrush(double score)
            {
                if (score >= 0.75) return Brushes.SeaGreen;
                if (score >= 0.50) return Brushes.DarkGoldenrod;
                if (score >= 0.25) return Brushes.DarkOrange;
                return Brushes.Firebrick;
            }
        }
    }
}
