# SAP2000 Quad Transition Plugin

Plugin locale x64 per SAP2000 27. Genera mesh quad-dominant su aree piane da 3 a N spigoli senza servizi remoti.

## Requisiti

- SAP2000 27 x64.
- .NET Framework 4.8.

Il pacchetto distribuibile include Python 3.12 e Gmsh 4.15.2 in un runtime privato. Non usa Python installato nel sistema, non modifica `PATH` e non richiede `pip`.

Dal rilascio 1.0.78 il codice originale e GPL-2.0-or-later. `LICENSE` (GPLv2), `GPL-3.0.txt`, `LICENSE-APPLICATION.md` e `SOURCE.md` nel pacchetto indicano diritti, istruzioni e sorgenti corrispondenti della release pubblica. Per la combinazione binaria con OpenSSL 3 viene scelta l'opzione GPLv3. L'ulteriore permesso per il solo codice C# relativo all'API SAP2000 installata separatamente e descritto in `SAP2000-LINKING-EXCEPTION.md`; Gmsh conserva la propria licenza GPL-2.0-or-later e la sua eccezione specifica.

## Installazione

1. Estrarre interamente lo ZIP della release.
2. Chiudere SAP2000.
3. Eseguire `install_plugin.cmd`; non sono richiesti privilegi di amministratore.
4. In SAP2000 aggiungere il nome `SapQuadTransitionPlugin` da `Tools > Add/Show Plugins`.

L'installer verifica il runtime e copia il pacchetto in `%LOCALAPPDATA%\Programs\SAP2000QuadMesher`, nella cartella **Programmi dell'utente** (non in Download e senza richiedere UAC). Sostituisce la precedente installazione solo dopo aver verificato i nuovi file e registra il plugin per il solo utente corrente. La cartella temporanea della versione 1.0.75, `%LOCALAPPDATA%\Programs\SQM_Plugin`, viene rimossa solo se era quella attivamente registrata. Gli installer `.cmd` invocano direttamente `SQMPluginInstaller.exe`, senza PowerShell. Per rimuovere l'installazione chiudere SAP2000 ed eseguire `uninstall_plugin.cmd` dalla cartella dello ZIP estratto.

## Selezione

- Selezionare una o piu aree piane con almeno tre spigoli, anche disgiunte.
- Selezionare i point object del contorno che devono essere riutilizzati per la congruenza. La distribuzione puo essere non uniforme.
- Selezionare eventuali point object interni che devono diventare nodi della mesh.
- Selezionare eventuali frame interni che devono coincidere con spigoli della mesh. Sono supportate catene aperte, forme chiuse e piu catene disgiunte non intersecanti.
- I vertici geometrici dell'area sono inclusi automaticamente.

La finestra principale contiene tutte le opzioni di esecuzione e riporta nel titolo e nel footer la versione del plugin. Usa uno sfondo bianco, intestazione blu notte, caratteri Segoe UI, azioni blu e bordi grigio chiaro; il footer include il collegamento a `CSi Italia`. E modale rispetto a SAP2000 e rimane in primo piano fino alla chiusura. Durante l'intera operazione la barra di avanzamento e animata quando il tempo residuo non e stimabile e mostra una percentuale durante la creazione degli oggetti SAP2000. Al termine il comando `Dettagli mesh` apre, su richiesta, il controllo indipendente di dimensioni, aspect ratio, angoli, skew, Jacobiano scalato, orientamento ed elementi degeneri. Anche questa finestra usa lo stesso stile e footer. Ogni metrica e rappresentata su una scala grafica da `CRITICA` a `OTTIMA`, con valore misurato e intervallo tecnico di riferimento.

Il link `Verified examples` / `Esempi verificati` nell'intestazione apre il PDF incluso in `docs/`. Le prove riportate furono eseguite con il plugin **v0.0.57**; la tabella misura la durata del test SAP2000 completo, non il tempo di generazione della mesh della release corrente. Il link di aggiornamento e centrato nel footer.

L'opzione `FAST - inserimento bulk tramite tabelle SAP2000` accelera la fase finale inviando in blocco le tabelle editabili `Joint Coordinates`, `Connectivity - Area` e `Area Section Assignments`. Durante l'anteprima le aree originali restano intatte e tutte le shell generate usano label temporanee alfanumeriche corte e distinte; dopo l'importazione vengono verificati conteggi, connettivita e proprieta. Le diagnostiche note delle righe di continuazione usate da SAP2000 per aree con piu di quattro vertici sono distinte dagli errori reali. Il percorso COM ordinario resta disponibile lasciando FAST disattivato.

Quando sono selezionati frame interni, il mesher incorpora ogni frame come curva protetta e converte la discretizzazione in soli quadrilateri. Il frame puo corrispondere a piu spigoli shell consecutivi; nessun quadrilatero puo attraversarlo usandolo come diagonale. In questo modo gli elementi racchiusi da forme chiuse possono essere individuati e cancellati per creare aperture. I frame originali non vengono modificati o suddivisi dal plugin.

L'opzione `Generate holes enclosed by selected frames or shell edges` elimina automaticamente dalla mesh tutte le shell isolate dal bordo esterno da catene chiuse formate da frame selezionati, spigoli incidenti di altre shell selezionate o una combinazione dei due. Le catene aperte non producono cancellazioni. Il comando `Undo mesh` ripristina anche le shell omesse, ricreando l'area originale completa.

L'opzione `Generate circular O-grid holes` usa i point object del gruppo scelto come centri di fori con diametro comune, espresso nelle unita correnti SAP2000. Ogni foro riceve un contorno poligonale inscritto e un anello O-grid transfinito full-quad, collegato con una transizione quadrangolare alla mesh esterna. Sulle piastre rettangolari non vincolate viene usato automaticamente un percorso strutturato: 48 o piu corde, sette strati radiali con transizione cerchio-quadrato e griglia cartesiana esterna congruente. Il plugin verifica preventivamente che i dischi siano interni all'area, disgiunti e liberi da altri nodi vincolanti.

Quando vengono elaborate piu aree, ogni area mantiene proprieta e carichi propri. Gli spigoli coincidenti, anche se orientati in verso opposto o sovrapposti solo parzialmente, vengono discretizzati con lo stesso insieme di nodi; le mesh adiacenti risultano quindi congruenti. La generazione, l'annullamento e la conferma sono transazionali sull'intera selezione.

Ogni spigolo di ogni area selezionata viene clippato nel piano di tutte le altre aree. Ogni tratto interno, completo o parziale, viene incorporato come linea protetta nelle mesh ospiti; lo stesso spigolo puo quindi incidere su piu aree e ogni area puo ricevere piu vincoli. Gli incroci tra vincoli vengono suddivisi prima della meshatura. La suddivisione e propagata alle shell sorgenti e tutte le superfici riutilizzano gli stessi point object lungo ciascun tratto comune, anche con orientamenti 3D generici.

Vicino agli spigoli incidenti il mesher applica un raffinamento locale graduato basato sui campi Gmsh `Distance` e `Threshold`, con fascia fine limitata e transizione progressiva verso la dimensione globale. La mesh rimane full-quad nelle aree che contengono i vincoli e continua a usare le metriche di aspect ratio, skew, angoli e Jacobiano scalato del report qualita.

Il comando `Undo mesh` e disponibile finche la finestra rimane aperta. Nel percorso COM l'area originale viene conservata integralmente con un nome temporaneo. Nel percorso FAST le aree originali rimangono inalterate durante l'anteprima e l'annullamento elimina in modo mirato shell e point object temporanei; `Close` elimina le aree originali e assegna alle mesh confermate i nomi definitivi. Questo meccanismo non dipende dall'undo di SAP2000 e non salva automaticamente il modello.

Se il generatore non trova una mesh che soddisfa i requisiti, l'errore viene mostrato senza chiudere il plugin. La finestra torna allo stato iniziale e permette di modificare dimensione o simmetria e avviare un nuovo tentativo.

Le soglie visualizzate derivano dalle metriche CUBIT/Verdict: per i quadrilateri aspect ratio `1-4`, skew normalizzato `0-0.5`, angoli `45-135 gradi` e Jacobiano scalato `0.5-1`; per i triangoli angoli `30-90 gradi`. La scala qualitativa suddivide l'intero dominio della metrica e non sostituisce uno studio di convergenza sul risultato strutturale.

Riferimenti:

- C. Geuzaine e J.-F. Remacle, *Gmsh: a three-dimensional finite element mesh generator with built-in pre- and post-processing facilities*, IJNME 79 (2009), per entita incorporate e campi di dimensione.
- J.-F. Remacle et al., *Blossom-Quad: A non-uniform quadrilateral mesh generator using a minimum-cost perfect-matching algorithm*, IJNME 89 (2012), per la ricombinazione quadrangolare.
- P. Knupp, *Algebraic Mesh Quality Metrics*, SIAM Journal on Scientific Computing 23 (2001), e P. Pebay, *Planar Quadrangle Quality Measures*, Engineering with Computers 20 (2004).
- CUBIT 15.2, [Metrics for Quadrilateral Elements](https://www.sandia.gov/files/cubit/15.2/help_manual/WebHelp/mesh_generation/mesh_quality_assessment/quadrilateral_metrics.htm), con riferimenti a P. Knupp, *Algebraic Mesh Quality Metrics*.
- CUBIT 15.2, [Metrics for Triangular Elements](https://www.sandia.gov/files/cubit/15.2/help_manual/WebHelp/mesh_generation/mesh_quality_assessment/triangular_metrics.htm).
- COMSOL 6.3, [Mesh Element Quality](https://doc.comsol.com/6.3/doc/com.comsol.help.comsol/comsol_ref_mesh.24.24.html), per l'interpretazione normalizzata `0` degenerato - `1` ideale.

## Modalita generale

- Gestisce poligoni piani da 3 a N spigoli, anche non convessi se il contorno e semplice.
- Incorpora i nodi interni selezionati come vincoli geometrici.
- Uno spigolo con almeno un nodo interno selezionato e vincolato: usa esclusivamente i nodi presenti e non introduce nuovi nodi su quello spigolo.
- Uno spigolo senza nodi interni selezionati e libero: puo essere suddiviso per rendere uniforme la mesh e rispettare il lato massimo.
- Ricombina la mesh in quadrilateri e accoppia ulteriori triangoli soltanto quando il quadrilatero risultante soddisfa aspect ratio <= 3 e skew <= 45 gradi; conserva gli altri triangoli residui invece di forzare accoppiamenti scadenti.
- Non richiede simmetria o spaziatura uniforme.

Una mesh solo quadrangolare non e sempre topologicamente possibile mantenendo invariato il contorno. In particolare, un numero dispari di intervalli complessivi sul perimetro richiede almeno un triangolo oppure l'aggiunta di un nodo di bordo.

## Transizione rettangolare automatica

Quando la selezione contiene un rettangolo, nessun vincolo interno e nodi su due soli bordi opposti, il plugin non usa il mesher poligonale generale. Attiva automaticamente il mesher strutturato di transizione, con:

- discretizzazioni dei due bordi mantenute esattamente, anche se non uniformi;
- crescita dimensionale regolare verso l'interno;
- soli quadrilateri;
- controllo automatico di lato massimo, aspect ratio <= 3, skew <= 45 gradi e Jacobiano scalato >= 0.5.

Se il numero totale di intervalli sui due bordi vincolati e dispari, i due bordi liberi ricevono discretizzazioni differenti di un intervallo per rendere possibile una topologia full-quad. Il plugin tenta prima i limiti ordinari; soltanto se nessun candidato li soddisfa ammette uno skew massimo di `60 gradi`, mantenendo aspect ratio <= 3 e Jacobiano scalato >= 0.5. Il report qualita evidenzia comunque il superamento dell'intervallo CUBIT/Verdict.

Quando la spaziatura definita dai nodi vincolati supera gia la dimensione richiesta e rende impossibili anche i limiti precedenti, viene tentato un ultimo fallback controllato: aspect ratio <= 5, skew <= 70 gradi e Jacobiano scalato >= 0.3. La mesh viene accettata soltanto se resta full-quad, non invertita, congruente e copre interamente l'area; la finestra `Dettagli mesh` evidenzia le metriche fuori dall'intervallo raccomandato.

Se anche tali soglie non sono raggiungibili, il plugin amplia automaticamente la ricerca delle suddivisioni sui lati liberi e seleziona il miglior candidato geometricamente valido. In questo livello finale le metriche qualitative non sono vincoli bloccanti: restano inderogabili il contorno imposto, la topologia full-quad, il Jacobiano orientato positivo, l'assenza di elementi invertiti e la copertura completa. I valori fuori riferimento vengono mostrati come avvisi nel report, lasciando all'utente la decisione finale tramite `Chiudi` oppure `Annulla mesh`.

La checkbox di simmetria non serve ad attivare questo percorso: se selezionata impone anche la specchiatura geometrica e topologica esatta.

Se un intervallo appartenente a uno spigolo vincolato supera il lato massimo richiesto, prevale la congruenza: il plugin conserva il bordo, completa la mesh e segnala il superamento nel riepilogo.

## Modalita simmetrica

Il plugin rileva gli assi di riflessione compatibili con il contorno e con tutti i point object vincolanti selezionati. Attivando `Enforce exact symmetry` e possibile scegliere l'asse da un menu quando la forma ne possiede piu di uno. Il dominio viene tagliato sull'asse, viene meshata una sola meta e la connettivita viene riflessa esattamente; il percorso supporta poligoni semplici piani, anche non rettangolari e concavi, purche la semisezione sia connessa.

La modalita opera su una sola area e puo includere fori circolari disposti in coppie speculari oppure con il centro esattamente sull'asse. Gli O-grid vengono costruiti nella semipiastra e riflessi insieme a corde e connettivita; per i fori sull'asse viene generato un mezzo O-grid che, dopo la riflessione, forma il contorno circolare completo senza aggiungere nodi agli spigoli vincolati. Non e ancora supportata la combinazione, nello stesso tentativo, di fori sull'asse e coppie fuori asse. Anche i frame selezionati e gli spigoli incidenti di altre shell restano esclusi. Se il contorno o i nodi vincolanti non sono speculari, la checkbox rimane disabilitata.

## Dati conservati

Il plugin trasferisce proprieta shell, angolo degli assi locali ordinari, massa per area, edge constraint e tutti i carichi assegnati direttamente all'area. Sono conservati carichi di gravita, pressione interstiziale, rotazione, deformazione imposta, pressione superficiale, temperatura, carichi uniformi, carichi uniformi trasferiti ai frame e pressioni del vento. Ogni intensita viene riapplicata a tutti i nuovi elementi, mantenendo pattern, direzione, sistema di riferimento e gli altri parametri dell'assegnazione. Il modello non viene salvato automaticamente.

## Limiti

- Molle, thickness overwrite, modificatori e assi locali avanzati assegnati direttamente all'area non vengono trasferiti.
- I frame vincolanti devono essere complanari, interamente contenuti nell'area e non devono incrociarsi se l'intersezione non coincide con un estremo comune.
- I fori circolari O-grid non possono ancora essere combinati con frame selezionati o spigoli incidenti di altre shell; in questi casi il plugin interrompe l'operazione prima di modificare il modello.
- La simmetria esatta generale richiede una sola area, una semisezione connessa e un asse rilevabile dal contorno. I fori devono formare coppie speculari oppure essere tutti centrati sull'asse; le due configurazioni non possono ancora essere combinate nello stesso tentativo. I vincoli lineari non sono ancora ammessi.
- I nodi selezionati devono giacere sul piano e all'interno o sul bordo dell'area.
- Le aree complanari sono armonizzate sui bordi coincidenti o parzialmente sovrapposti; una sovrapposizione bidimensionale tra superfici complanari non viene suddivisa automaticamente.
- La qualita vicino a vertici molto acuti e limitata dalla geometria del poligono.
