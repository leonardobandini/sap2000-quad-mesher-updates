# Additional permission for the separately obtained SAP2000 API

Copyright (C) 2026 Leonardo Bandini.

As an additional permission from the copyright holder to recipients using
GNU GPL version 2 or a later version (including section 7 of GPLv3), the
copyright holder grants permission to combine and link the original C# code
in `SapQuadTransitionPlugin/Plugin.cs` with `SAP2000v1.dll`
supplied separately to the user as part of a properly licensed SAP2000
installation, and to convey the resulting plugin under the GNU GPL with this
additional permission.

This permission is limited to code for which Leonardo Bandini can grant it.
It does not apply to Gmsh or any other third-party work, grant a license to
SAP2000 or `SAP2000v1.dll`, or allow redistribution of any CSI binary. Those
must be obtained separately from the respective rights holder. The chosen
GPL version otherwise remains fully in force; modified versions may remove
this additional permission as permitted by the applicable GPL version.
