# Corresponding source for SAP2000 Quad Mesher {VERSION}

This binary package is distributed under the terms in `LICENSE` (GPLv2),
`GPL-3.0.txt`, `LICENSE-APPLICATION.md` and `THIRD_PARTY_NOTICES.md`. The
original program code is GPL-2.0-or-later. For the combined binary with
OpenSSL 3 (Apache-2.0), this release elects the GPLv3 option available for
our code and Gmsh. Gmsh retains its own, narrower exception. The SAP2000 API
is **not** distributed here.

Equivalent public access to the corresponding source is available from the
**same release page** as this binary ZIP:

https://github.com/leonardobandini/sap2000-quad-mesher-updates/releases/tag/v{VERSION}

Download both `Sap2000QuadMesher-{VERSION}-source.zip` (plugin, installer,
Python backend, exact Gmsh Python binding, build scripts and instructions)
and `gmsh-4.15.2-source.tgz` (unmodified upstream Gmsh source). Each has an
accompanying `.sha256` checksum file. The SHA-256 values of the original
Windows Gmsh wheel and the exact DLL bundled here are recorded in
`THIRD_PARTY_NOTICES.md` and the source archive's build instructions.

The previously distributed versions before 1.0.78 retain their own license
terms. If you redistribute this binary package, you must comply with the
GPL's corresponding-source requirements yourself.
