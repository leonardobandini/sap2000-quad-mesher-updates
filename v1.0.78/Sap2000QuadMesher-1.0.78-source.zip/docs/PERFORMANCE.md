# Prestazioni: misure e prossimi interventi

## Interpretare correttamente i tempi

Il PDF `examples/atomic/results/SAP2000-Quad-Mesher-Atomic-Examples.pdf` documenta 36 regressioni eseguite con **v0.0.57**. I tempi della tabella sono durate complessive dei test SAP2000 isolati (avvio, apertura del modello, mesh, inserimento, salvataggio e verifica/diagrammi): **non** misurano soltanto il mesher e **non** sono benchmark della release corrente. La versione e la provenienza sono fissate in `examples/atomic/results/report-provenance.json`.

L'ottimizzazione che ordina i candidati O-grid prima dei fallback costosi e arrivata con **v0.0.59**, dopo i test del PDF atomico. Le misure separate in `examples/comparisons/MODO/measurements.json` registrano per il caso MODO con frame un backend da 250,32 a 15,06 s e una durata totale da 294,69 a 68,79 s, con geometria/proprieta della mesh invariata. Nel caso adiacente il backend scende da 230,97 a 11,21 s e il totale da 277 a 48,75 s. Il caso della sola piastra ha invece un tempo totale variabile per la concorrenza: non e corretto dedurne un miglioramento generalizzato da una singola misura.

In una prova successiva della mesh regolare FAST MODO (30 mm, fori da 30 mm, quattro aree), la durata complessiva e stata 49,27 s, di cui 10,95 s nel backend e 38,31 s nelle altre fasi, compreso l'avvio di SAP2000 e la produzione dei diagrammi. Queste cifre indicano dove cercare, ma non isolano ancora il costo del solo inserimento SAP.

## Priorita per ulteriori ottimizzazioni

1. **Separare le fasi prima di modificarle.** Misurare indipendentemente avvio SAP, caricamento/salvataggio modello, preparazione geometrica, backend per area, importazione FAST/COM, trasferimento assegnazioni, verifica e diagrammi. Ripetere i casi senza concorrenza e riportare mediana e variabilita, con versione e parametri del plugin.
2. **Analizzare le tabelle SAP per modelli grandi.** `ApplyMeshFast` legge `Joint Coordinates`, `Connectivity - Area` e `Area Section Assignments` per ogni area. Una lettura o un'applicazione condivisa tra aree potrebbe ridurre i trasferimenti, ma va confrontata con i tempi delle chiamate e richiede di mantenere identici nomi dei nodi, assegnazioni e rollback. `nTEST021` (14.167 shell) e `nTEST028/035` (FAST/COM) sono casi utili.
3. **Profilare il lavoro geometrico su piu aree.** La propagazione dei bordi d'intersezione confronta attualmente gli spigoli della mesh con i bordi delle aree successive; su mesh grandi vale la pena misurarla e, soltanto se significativa, indicizzare spazialmente gli spigoli candidati.
4. **Valutare un backend persistente solo se conviene.** Oggi viene avviato un processo per ogni area; nelle prove MODO le tre aree successive alla piastra richiedevano circa 0,25 s ciascuna, mentre la prima richiedeva circa 10 s. La complessita di un processo persistente non e giustificata senza misurare ripetutamente un sovraccarico rilevante.

Ogni intervento prestazionale deve conservare mesh, vincoli, nodi condivisi e proprieta nelle regressioni SAP. Il backend puo gia registrare il proprio tempo per area tramite `SAP_QUAD_PROFILE_DIR`; i tempi del PDF storico non vanno sostituiti senza una nuova esecuzione documentata con la versione effettivamente provata.
