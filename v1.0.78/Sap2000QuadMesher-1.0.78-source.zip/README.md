# SAP2000 Quad Transition Plugin

Plugin desktop in preparazione per SAP2000 27 x64. Genera mesh quad-dominant su aree piane usando C#/.NET Framework, l'API COM di SAP2000 e Python/Gmsh.

La versione pubblicata corrente e `1.0.78`. Il progetto principale si trova in [`SapQuadTransitionPlugin`](SapQuadTransitionPlugin/README.md).

## Stato del progetto

Questa e la copia di progetto ripulita del workspace storico. Contiene il plugin, utility sperimentali, modelli SAP2000, fixture e risultati di test; build, cache e release storiche sono escluse dal controllo versione. Le fixture SAP2000 sono gestite con Git LFS.

Documentazione di continuita:

- [`docs/PROJECT_STATUS.md`](docs/PROJECT_STATUS.md): stato funzionale e tecnico verificato.
- [`docs/DEVELOPMENT.md`](docs/DEVELOPMENT.md): ambiente, build e strategia di test.
- [`docs/MIGRATION_AND_RELEASE.md`](docs/MIGRATION_AND_RELEASE.md): trasferimento, GitHub e packaging.
- [`docs/UPDATES.md`](docs/UPDATES.md): manifest GitHub, notifica aggiornamenti e procedura di pubblicazione.
- [`SapQuadTransitionPlugin/README.md`](SapQuadTransitionPlugin/README.md): uso del plugin e comportamento delle mesh.

## Verifica rapida

Dal root del progetto:

```cmd
dotnet build SapQuadTransitionPlugin\SapQuadTransitionPlugin.csproj -c Release
python -c "import gmsh; print(gmsh.__version__)"
```

Verifica eseguita il 24 settembre 2026:

- compilazione Release completata con 0 warning e 0 errori;
- Python 3.12.7;
- Gmsh 4.15.2;
- SAP2000 27 interop disponibile localmente.

Il pacchetto binario include un runtime Python 3.12 privato e Gmsh 4.15.2. L'utente finale non deve installare Python, Gmsh o pacchetti `pip`.

## Avvertenza

`SAP2000v1.dll` non fa parte del progetto e non deve essere pubblicata o inclusa nei pacchetti. Le fixture SAP2000 presenti sono state dichiarate pubblicabili dal loro autore, ma sono escluse dal pacchetto binario del plugin.

## Licenza

Dal rilascio 1.0.78 il codice originale e distribuito secondo [GNU GPL v2 o successiva](LICENSE) (`SPDX-License-Identifier: GPL-2.0-or-later`), con il [limitato permesso per l'API SAP2000 installata separatamente](SAP2000-LINKING-EXCEPTION.md). Per la combinazione binaria con OpenSSL 3 viene scelta l'opzione GPLv3, il cui [testo](GPL-3.0.txt) e incluso. Ambito, versioni precedenti e diritti dei componenti terzi sono spiegati in [`LICENSE-APPLICATION.md`](LICENSE-APPLICATION.md) e [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md). I sorgenti corrispondenti sono allegati alla stessa [release pubblica](https://github.com/leonardobandini/sap2000-quad-mesher-updates/releases/tag/v1.0.78), insieme al sorgente originale Gmsh.
