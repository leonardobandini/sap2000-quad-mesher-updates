# Additional permission for the author's C# code

Copyright (C) 2026 Leonardo Bandini.

For the original code in `SapQuadTransitionPlugin/Plugin.cs` **only to the
extent Leonardo Bandini holds its rights**, he permits recipients to combine
that code with `SAP2000v1.dll` obtained independently as part of a licensed
SAP2000 installation, and to distribute their resulting C# work under GPL
version 2 or any later version. This is an additional permission for **his C#
code**, including under section 7 when GPLv3 is chosen.

This text **does not grant or claim any right to SAP2000, `SAP2000v1.dll`,
Gmsh, or other third-party software**. It does not allow redistribution of a
CSI binary. Each recipient must obtain any required third-party rights from
the respective rights holder. All other GPL terms continue to apply.
