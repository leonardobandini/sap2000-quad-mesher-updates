# Migrazione e rilascio

Questo documento conserva la storia della migrazione dal workspace originale. **Ogni versione citata qui prima della 1.0.79 era una build di sviluppo o prova**, anche se temporaneamente accessibile online: nei paragrafi storici la parola "release" non indica una versione destinata agli utenti. La **1.0.79 e la prima beta distribuibile agli utenti**. Il codice originale e GPL-2.0-or-later dal test GPL 1.0.78; le build di sviluppo precedenti conservano i diritti gia concessi sotto MIT.

## Stato attuale

- Cartella definitiva: `C:\Users\leona\Projects\sap2000-quad-mesher`.
- Workspace storico conservato intatto in `C:\DOCUMENTI\TEST_MESH_AI`.
- Tutti i sorgenti, report e file di test copiati; esclusi solo build e cache rigenerabili.
- Fixture dichiarate pubblicabili e configurate per Git LFS.
- Repository GitHub previsto: `leonardobandini/sap2000-quad-mesher`, inizialmente privato.
- Licenza delle build di sviluppo fino a 1.0.77: MIT; dal test GPL 1.0.78 il codice originale e GPL-2.0-or-later, con la 1.0.79 prima beta per utenti.

## Stato di partenza

- Workspace: `C:\DOCUMENTI\TEST_MESH_AI`.
- Nessun repository Git inizializzato.
- Plugin compilabile nella sottocartella `SapQuadTransitionPlugin`.
- 1.137 file per circa 283,34 MB.
- Numerosi `bin`, `obj`, `__pycache__` e release storiche rigenerabili.
- Modelli e output SAP2000 mescolati ai sorgenti.
- Un file da circa 144,63 MB non accettabile da GitHub senza LFS.
- GitHub CLI autenticata come `leonardobandini`.

## Decisioni

Decisioni gia prese:

1. nuova cartella in `C:\Users\leona\Projects\sap2000-quad-mesher`;
2. repository `sap2000-quad-mesher`, inizialmente privato;
3. modelli di test pubblicabili;
4. Git LFS per modelli, backup, export e immagini.

La prima licenza dei prototipi era MIT; dal test 1.0.78 il codice originale e GPL-2.0-or-later.

## Struttura obiettivo

```text
project-root/
  src/
    SapQuadTransitionPlugin/
  tests/
    integration/
    geometry/
  test-data/
    public/
    local-private/
  tools/
  docs/
  packaging/
  README.md
  LICENSE
  CHANGELOG.md
  CONTRIBUTING.md
  THIRD_PARTY_NOTICES.md
  .gitignore
```

La riorganizzazione fisica in `src`, `tests` e `test-data` e rinviata per non rompere le utility storiche durante il primo trasferimento. Le categorie restano la struttura obiettivo per il refactoring successivo.

## Classificazione iniziale

Da versionare:

- sorgenti C# e Python del plugin;
- progetti compilabili mantenuti;
- script di installazione senza dipendenze proprietarie incluse;
- documentazione;
- fixture CSV piccole e sintetiche;
- report benchmark utili e riproducibili;
- utility ancora necessarie, dopo rimozione dei percorsi assoluti.

Da rigenerare e ignorare:

- `bin/` e `obj/`;
- `__pycache__/` e `*.pyc`;
- `*.dll`, `*.exe`, `*.pdb`, `*.tlb` prodotti dalla build;
- cartelle di release storiche;
- output temporanei e copie automatiche.

Da conservare localmente e valutare prima di GitHub:

- `*.sdb`, `*.sbk`, `*.$2k`, `*.ico`;
- immagini o report riferiti a modelli reali;
- fixture di grandi dimensioni;
- qualsiasi modello contenente dati di commessa o di terzi.

Da non distribuire salvo autorizzazione esplicita:

- `SAP2000v1.dll` e altri file CSI copiati negli output;
- dipendenze con licenza incompatibile o non verificata.

## Procedura di trasferimento sicuro

1. Creare la cartella definitiva accanto al workspace storico, senza rinominare o cancellare l'originale.
2. Copiare sorgenti, documentazione, utility e tutti i test classificati.
3. Collocare i fixture pubblicabili in `test-data/public`.
4. Collocare i fixture non pubblicabili o troppo grandi in `test-data/local-private`.
5. Aggiungere regole `.gitignore` che escludano il contenuto privato e gli output generati.
6. Rendere portabili i riferimenti a SAP2000 e i percorsi delle utility.
7. Compilare dalla nuova cartella.
8. Eseguire smoke test Python e checklist SAP2000 su copie dei modelli.
9. Confrontare inventario e hash dei file trasferiti con il workspace storico.
10. Conservare il workspace storico come backup finche build, test, push e pacchetto non sono verificati.

## Git e GitHub

Sequenza prevista nella cartella definitiva:

```cmd
git init -b main
git add .
git status
git diff --cached --stat
git commit -m "Initial open source release"
gh repo create NOME_REPOSITORY --source . --remote origin --push
```

Prima del commit devono essere controllati almeno:

- assenza di DLL CSI;
- assenza di token o dati personali;
- assenza di percorsi utente negli artefatti;
- assenza di file oltre 100 MB non gestiti con LFS;
- presenza di licenza, README e avvisi terze parti;
- build pulita da clone o cartella senza output precedenti.

E preferibile creare inizialmente il repository privato durante la bonifica, quindi renderlo pubblico solo dopo il controllo finale.

## Contenuto del pacchetto binario

Il pacchetto di release dovrebbe contenere:

```text
 Sap2000QuadMesher-VERSION/
  SapQuadTransitionPlugin.dll
  mesher/
    SapQuadMesherBackend.exe
    _internal/
  sap_general_polygon_mesher.py
  sap_rectangular_transition_mesher.py
  sap_quad_transition_mesher.py
  install_plugin.cmd
  uninstall_plugin.cmd
  SQMPluginInstaller.exe
  licenses/
    GMSH-LICENSE.txt
    PYTHON-LICENSE.txt
  README.md
  LICENSE
  THIRD_PARTY_NOTICES.md
```

Non dovrebbe contenere `SAP2000v1.dll`. Il prerequisito SAP2000 va rilevato o documentato. Valutare separatamente se includere PDB per diagnostica.

## Processo di release desiderato

1. Aggiornare versione in progetto, assembly, documentazione e changelog.
2. Eseguire build Release pulita.
3. Ricostruire e verificare il backend autonomo Python/Gmsh.
4. Eseguire test automatici indipendenti da SAP2000.
5. Eseguire checklist manuale/integrata con SAP2000.
6. Assemblare il pacchetto da uno script, non copiando file a mano.
7. Ispezionare il contenuto e verificare l'assenza di DLL proprietarie.
8. Generare checksum SHA-256.
9. Creare tag Git `vVERSION`.
10. Pubblicare sorgenti, ZIP e checksum in una GitHub Release.

## Licenza e dipendenze

Il testo GPLv2 e in `LICENSE` e quello GPLv3 in `GPL-3.0.txt`; ambito, opzione GPLv3 scelta per il binario combinato e licenze storiche sono in `LICENSE-APPLICATION.md`. Le dipendenze mantengono le rispettive licenze: l'archivio sorgente corrispondente al backend e il sorgente Gmsh vanno pubblicati insieme allo ZIP binario di ogni release GPL.

Dipendenze da documentare:

- SAP2000 e `SAP2000v1.dll`: software proprietario CSI, richiesto all'utente e non redistribuito;
- Gmsh e relativo modulo Python: runtime GPLv2+ incorporato, licenza inclusa e sorgente corrispondente pubblicato con la release;
- .NET Framework e Windows Forms: prerequisiti runtime Microsoft.

## Definizione di completamento della migrazione

La migrazione e conclusa quando:

- la nuova cartella contiene tutto il materiale necessario, inclusi i test locali;
- nessun file necessario dipende dal vecchio percorso assoluto;
- una build pulita riesce;
- i test concordati passano;
- Git traccia soltanto contenuti autorizzati e mantenibili;
- il repository remoto e pubblicato;
- un pacchetto installabile e riproducibile e disponibile con sorgenti e documentazione;
- il workspace storico rimane archiviato come backup fino alla prima release stabile.
