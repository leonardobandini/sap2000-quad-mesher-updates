# Prestazioni: misure e prossimi interventi

La [regressione completa v1.0.87 e il confronto multicore su mesh identica](MULTICORE_PERFORMANCE_1_0_87.md) riportano 36/36 esempi eseguiti in serie su una sola istanza SAP2000 persistente e, separatamente, i tempi dei backend di TEST03 con uno o il massimo numero di worker. La riduzione misurata dei soli backend nel confronto appaiato e del 50,8%; non equivale a un benchmark generale della durata complessiva del plugin.

## Interpretare correttamente i tempi

Il PDF `examples/atomic/results/SAP2000-Quad-Mesher-Atomic-Examples.pdf` documenta 36 regressioni della **build di sviluppo v0.0.57**. I tempi della tabella sono durate complessive dei test SAP2000 isolati (avvio, apertura del modello, mesh, inserimento, salvataggio e verifica/diagrammi): **non** misurano soltanto il mesher e **non** sono benchmark della prima beta per utenti 1.0.79. La versione e la provenienza sono fissate in `examples/atomic/results/report-provenance.json`.

L'ottimizzazione che ordina i candidati O-grid prima dei fallback costosi e arrivata nella **build di sviluppo v0.0.59**, dopo i test del PDF atomico. Le misure di sviluppo separate in `examples/comparisons/MODO/measurements.json` registrano per il caso MODO con frame un backend da 250,32 a 15,06 s e una durata totale da 294,69 a 68,79 s, con geometria/proprieta della mesh invariata. Nel caso adiacente il backend scende da 230,97 a 11,21 s e il totale da 277 a 48,75 s. Il caso della sola piastra ha invece un tempo totale variabile per la concorrenza: non e corretto dedurne un miglioramento generalizzato da una singola misura.

In una successiva prova di sviluppo della mesh regolare FAST MODO (30 mm, fori da 30 mm, quattro aree), la durata complessiva e stata 49,27 s, di cui 10,95 s nel backend e 38,31 s nelle altre fasi, compreso l'avvio di SAP2000 e la produzione dei diagrammi. Queste cifre indicano dove cercare, ma non isolano ancora il costo del solo inserimento SAP e non costituiscono una misura garantita della beta.

## Priorita per ulteriori ottimizzazioni

1. **Separare le fasi prima di modificarle.** Misurare indipendentemente avvio SAP, caricamento/salvataggio modello, preparazione geometrica, backend per area, importazione FAST/COM, trasferimento assegnazioni, verifica e diagrammi. Ripetere i casi senza concorrenza e riportare mediana e variabilita, con versione e parametri del plugin.
2. **Analizzare le tabelle SAP per modelli grandi.** `ApplyMeshFast` legge `Joint Coordinates`, `Connectivity - Area` e `Area Section Assignments` per ogni area. Una lettura o un'applicazione condivisa tra aree potrebbe ridurre i trasferimenti, ma va confrontata con i tempi delle chiamate e richiede di mantenere identici nomi dei nodi, assegnazioni e rollback. `nTEST021` (14.167 shell) e `nTEST028/035` (FAST/COM) sono casi utili.
3. **Profilare il lavoro geometrico su piu aree.** La propagazione dei bordi d'intersezione confronta attualmente gli spigoli della mesh con i bordi delle aree successive; su mesh grandi vale la pena misurarla e, soltanto se significativa, indicizzare spazialmente gli spigoli candidati.
4. **Valutare un backend persistente solo se conviene.** Oggi viene avviato un processo per ogni area; nelle prove MODO le tre aree successive alla piastra richiedevano circa 0,25 s ciascuna, mentre la prima richiedeva circa 10 s. La complessita di un processo persistente non e giustificata senza misurare ripetutamente un sovraccarico rilevante.

Ogni intervento prestazionale deve conservare mesh, vincoli, nodi condivisi e proprieta nelle regressioni SAP. Il backend puo gia registrare il proprio tempo per area tramite `SAP_QUAD_PROFILE_DIR`; i tempi del PDF storico non vanno sostituiti senza una nuova esecuzione documentata con la versione effettivamente provata.

## Prova diagnostica precedente alla beta 1.0.80 (27 settembre 2026)

Con una build di sviluppo locale precedente al rilascio 1.0.80, la preparazione delle quattro mesh MODO e
stata separata dall'inserimento: le tre tabelle FAST sono lette e applicate
insieme una volta sola. E stato anche corretto il caso in cui Gmsh dimezzava
una seconda volta segmenti di bordo gia raffinati nell'area precedente. La
stessa correzione elimina una discontinuita nell'apertura coplanare `nTEST028`.

Prove automatiche su copie dell'originale MODO: tutte le aree 1-4, gruppo
`BOLT`, dimensione massima e diametro fori 30 mm; SAP2000 27. Un'altra istanza
SAP2000 dell'utente era aperta. **Una sola esecuzione per scenario e versione**:
sono osservazioni diagnostiche sull'operazione completa (inclusi avvio SAP,
salvataggio e diagramma), non benchmark isolati ne prestazioni garantite.

| Impostazione | Beta 1.0.79: totale / backend | Sviluppo: totale / backend | Risultato |
| --- | --- | --- | --- |
| Regolare | 50,64 / 11,49 s | 44,68 / 11,43 s | 5.022 quad identici per geometria e sezioni; tre giunzioni congruenti |
| Raffittita | 96,17 / 43,52 s | 87,26 / 43,25 s | La beta ha tre giunzioni non conformi; la correzione le rende conformi |

Nella prova raffittita la beta generava 7.254 quad e quella corretta 6.930:
la diversa topologia sulle pareti impedisce di attribuire tutta la variazione
del tempo al batch. I 3.822 quad della piastra, con le sezioni assegnate,
sono risultati identici. Nel nuovo profilo `csharp-fast-phases.csv` l'unica
lettura, preparazione, applicazione e verifica delle tabelle FAST richiede
circa 2,4 s nel caso regolare e 3,7 s nel caso raffittito. Per una mediana
ripetibile, nel workspace di sviluppo che contiene la fixture privata MODO e
senza altre istanze SAP2000, si puo usare
`python tools/benchmark_modo_batch.py --runs 3`; il comando confronta i modelli
e verifica i tre bordi prima di riportare i tempi. Per la prova raffittita
aggiungere `--refined`: in questo caso confronta la sola piastra invariata,
perche la topologia delle pareti deve cambiare per ripristinare la congruenza.
La beta pubblicata 1.0.79 non include queste modifiche; la 1.0.80 si basa
sullo stesso codice della build di sviluppo verificata.

La correzione successiva destinata alla **1.0.81** e stata verificata anche
con 36/36 prove atomiche passate su tre istanze SAP2000 persistenti e due
prove separate di mesh regolare per `nTEST006` (foro da 0,03 m) e `nTEST026`
(fori da 0,02 m). I tempi delle regressioni concorrenti non sostituiscono
le misure precedenti e non sono benchmark di prestazione della nuova beta.

## Annullamento nella beta 1.0.82

Il backend attende la richiesta di annullamento riutilizzando il ciclo UI
esistente con intervallo di 100 ms. La preparazione di tabelle grandi controlla
l'interruzione a blocchi di 512 elementi e non elabora gli eventi UI piu di
una volta ogni 150 ms; non viene introdotto un `DoEvents` per nodo o shell.
SAP2000 completa una chiamata API in corso prima che il plugin ripristini
un'eventuale importazione FAST o COM. Le unità sono convertite solo quando
viene premuto **Genera**, senza lavoro aggiuntivo durante la meshatura.

In due coppie sequenziali MODO regolare (30 mm/30 mm, 5.022 quad identici),
con una sola istanza SAP di test alla volta, l'operazione misurata dal plugin
ha richiesto **21,0 e 15,0 s** nella beta 1.0.81 contro **14,8 e 15,9 s**
nella build candidata 1.0.82. Una coppia migliora e l'altra peggiora: questi
pochi campioni non permettono di attribuire un guadagno o un rallentamento
sistematico all'annullamento. Il confronto riproducibile nel workspace che
contiene la fixture privata MODO e
`python tools/benchmark_modo_batch.py --baseline-version 1.0.81 --runs 2`.
