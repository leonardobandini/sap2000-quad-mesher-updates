# Stato del progetto

Ultimo aggiornamento: 29 settembre 2026.

## Sintesi

`SAP2000 Quad Transition Plugin` e un plugin COM x64 per SAP2000 27 che sostituisce una o piu aree piane selezionate con mesh quad-dominant. Il calcolo geometrico viene delegato a tre backend Python/Gmsh; il plugin C# gestisce selezione, vincoli, trasferimento dati, inserimento nel modello, anteprima, conferma e rollback.

La **1.0.79 e stata la prima beta destinata agli utenti**; la 1.0.80 ne ha corretto i bordi raffittiti e l'import FAST multi-area, la 1.0.81 i fallback regolari e i piccoli fori, e la 1.0.82 ha aggiunto annullamento e misure con unita esplicite. Dalla 1.0.83 FAST e preselezionato, nella 1.0.84 l'installer aggiunge automaticamente la voce Tools in SAP2000 27, nella 1.0.85 FAST gestisce i diagnostici noti dei triangoli e poligoni gia presenti e nella **1.0.87** offre candidati multicore e nodi congruenti con mesh adiacenti gia presenti. Lo scopo prevalente e didattico: mostrare come collegare SAP2000, C# e Python/Gmsh per automatizzare e migliorare un flusso di lavoro. Tutte le versioni precedenti alla 1.0.79 erano build di sviluppo o di prova, non release per utenti. Il codice completo resta un progetto dimostrativo e i risultati vanno verificati nel modello concreto.

## Versione e tecnologie

- Prima beta per utenti: `1.0.79` (GPL-2.0-or-later per il codice originale; opzione GPLv3 per la combinazione binaria).
- Beta corrente: `1.0.87`, con candidati multicore (worker automatici o 1..CPU logiche, vincolati da candidati e memoria), nodi dei bordi di mesh adiacenti preesistenti, FAST per triangoli generati, menu Tools registrato automaticamente, annullamento durante la generazione e input di lunghezze `m`, `cm`, `mm`, `ft`, `in`.
- Prima della pubblicazione 1.0.81: 36/36 regressioni di integrazione PASS in tre istanze SAP2000 persistenti e controllate su risultati separati. Verificati anche `nTEST006` con `hole_centers`, diametro 0,03 m, mesh regolare e FAST, e `nTEST026` con `foro`, diametro 0,02 m, 0,05 m massimo, mesh regolare e FAST. Il PDF atomico storico rimane riferito alla build di sviluppo v0.0.57.
- Prima della 1.0.82: 36/36 regressioni su tre istanze SAP2000 persistenti. Su copie isolate, verificati quattro punti di interruzione (backend, FAST multi-area, FAST singola area, COM); i modelli originali, le sezioni e la selezione sono rimasti invariati. Le conversioni di unita sono state verificate tramite test del parser e prove SAP con suffissi espliciti.
- Prima della 1.0.87: 36/36 regressioni su **una istanza SAP2000 persistente**, con worker CPU impostati al massimo, timeout per modello e risultati isolati. Tempi e confronto geometrico appaiato 1 worker / massimo worker nel [report multicore](MULTICORE_PERFORMANCE_1_0_87.md); il PDF atomico storico resta riferito alla build di sviluppo v0.0.57.
- Regola di rilascio: incrementare sempre la versione visibile dopo ogni ciclo di correzioni, prima di distribuire e testare il plugin.
- Schema `MAJOR.MINOR.BUILD`: incrementare BUILD (`1.0.75`, `1.0.76`, ...) per le build interne, MINOR per nuove caratteristiche importanti e MAJOR per modifiche radicali. La versione dell'assembly COM resta `1.0.0.0` per conservare la registrazione.
- Progetto: `SapQuadTransitionPlugin/SapQuadTransitionPlugin.csproj`.
- Entry point COM: `SapQuadTransitionPlugin.cPlugin` in `SapQuadTransitionPlugin/Plugin.cs`.
- Runtime: .NET Framework 4.8, C# 7.3, x64.
- UI: Windows Forms.
- Integrazione: API COM `SAP2000v1` di SAP2000 27.
- Meshing: Python e Gmsh.
- Distribuzione: backend PyInstaller `onedir` con Python 3.12 e Gmsh 4.15.2 incorporati.
- Backend: `sap_general_polygon_mesher.py`, `sap_rectangular_transition_mesher.py`, `sap_quad_transition_mesher.py`.

## Flusso principale

1. Verifica che il modello SAP2000 non sia bloccato.
2. Legge aree, point object e frame selezionati.
3. Costruisce un sistema di coordinate piano per ogni area.
4. Associa nodi e frame alle rispettive aree.
5. Uniforma bordi condivisi e intervalli di spigolo incidenti, completi o parziali, tra tutte le superfici selezionate.
6. Raccoglie opzioni e dimensione obiettivo dalla UI.
7. Seleziona automaticamente il mesher generale, rettangolare o simmetrico.
8. Scambia la geometria con Python tramite CSV temporanei.
9. Calcola metriche di qualita per tutte le aree e, in FAST, verifica i bordi e importa le tre tabelle una sola volta per l'intera selezione; il percorso COM crea gli oggetti area per area.
10. Mantiene un'anteprima annullabile, quindi conferma o ripristina l'operazione completa.

## Funzioni implementate

- Poligoni piani semplici da 3 a N lati, anche non convessi.
- Mesh di piu aree, anche disgiunte, in una sola operazione.
- Congruenza su bordi coincidenti o parzialmente sovrapposti.
- Congruenza molti-a-molti lungo spigoli incidenti completi o parziali, anche su piani e orientamenti generici.
- Raffinamento locale graduato vicino agli spigoli incidenti mediante campi Gmsh `Distance` e `Threshold`.
- Riutilizzo dei point object selezionati sul bordo.
- Inserimento obbligatorio dei point object interni selezionati.
- Frame interni protetti, catene aperte o chiuse e piu catene disgiunte.
- Aperture ottenute rimuovendo le shell racchiuse da frame o spigoli di altre shell selezionate.
- Modalita generale quad-dominant.
- Transizione rettangolare automatica full-quad.
- Transizione rettangolare con simmetria geometrica e topologica esatta.
- Percorso standard tramite API COM.
- Percorso FAST tramite un'unica applicazione delle tabelle editabili SAP2000 per piu aree selezionate.
- Anteprima, conferma e rollback transazionale multi-area.
- Interruzione della generazione su richiesta dall'interfaccia: terminazione del backend in esecuzione o rollback SAP dopo il completamento della chiamata API corrente, senza chiudere SAP2000.
- Dimensione massima della mesh e diametro dei fori con suffissi di lunghezza `m`, `cm`, `mm`, `ft`, `in`, convertiti nell'unita corrente SAP; senza suffisso restano validi i valori nell'unita corrente.
- Report di dimensione, aspect ratio, angoli, skew, Jacobiano, orientamento e degenerazione.
- Trasferimento di proprieta shell, assi locali ordinari, massa, edge constraint e numerosi carichi area.

La descrizione operativa completa e in `SapQuadTransitionPlugin/README.md`.

## Dati trasferiti

Il plugin trasferisce alle nuove shell:

- proprieta shell;
- angolo degli assi locali ordinari;
- massa per area;
- edge constraint;
- carichi di gravita;
- pressione interstiziale;
- rotazione;
- deformazione imposta;
- pressione superficiale;
- temperatura;
- carichi uniformi;
- carichi uniformi trasferiti ai frame;
- pressione del vento.

Il modello non viene salvato automaticamente.

## Limiti noti

- Molle, thickness overwrite, modificatori e assi locali avanzati non vengono trasferiti.
- Altre assegnazioni area non esplicitamente gestite potrebbero andare perse quando l'area viene sostituita.
- I frame devono essere complanari e interni; gli incroci con altri vincoli vengono suddivisi automaticamente.
- La qualita e geometricamente limitata vicino a vertici molto acuti.
- Le sovrapposizioni bidimensionali tra shell complanari non vengono interpretate come intersezioni lineari; i bordi complanari coincidenti restano gestiti come bordi condivisi.
- La tolleranza geometrica C# e assoluta (`1e-7`) e non dipende dalla scala del modello.
- Lo scambio CSV usa scrittura manuale ASCII; nomi con virgole o caratteri non ASCII sono fragili.
- Il processo Python non ha timeout automatico; puo essere interrotto con **Annulla generazione** mentre il plugin rimane aperto.
- Alcuni errori API SAP2000 e alcune operazioni di rollback non controllano il codice di ritorno.
- La modalita FAST dipende dai nomi e dallo schema inglese delle tabelle di SAP2000 27.
- La UI e l'operazione SAP2000 condividono il thread e usano `Application.DoEvents`.
- Un report fuori soglia avvisa l'utente ma non impedisce automaticamente la conferma.

## Test esistenti

Non esiste ancora un test runner unitario. I controlli correnti sono programmi e script di integrazione eseguiti manualmente:

- `run_test01_fast.cs`: automazione end-to-end FAST, standard e undo.
- `test_sap_bulk.cs`: inserimento bulk minimo.
- `test_sap_bulk_preserve.cs`: conservazione di GUID, assi e massa.
- `test_sap_table_roundtrip.cs`: snapshot, round-trip e ripristino delle tabelle.
- `verify_transition_mesh.cs`: geometria, qualita, congruenza e simmetria.
- `verify_testqm01.py`: vincoli interni, bordi, area e qualita.
- `verify_mesh_report.py`: analisi dell'export testuale SAP2000.

Sono presenti fixture per:

- `TEST01`: mesh generale, congruenza, FAST/standard, fori e rollback;
- `testMesh01`: transizione rettangolare e simmetrica;
- `TESTQM01`: poligono generale con nodi interni;
- `areeframe`: vincoli frame;
- piastre con uno o sei fori;
- trave carroponte di grandi dimensioni.

I report Markdown storici attestano esecuzioni riuscite, ma non costituiscono test automatici riproducibili.

## Stato verificato

Verifica locale del 24 settembre 2026:

- `dotnet build Sap2000QuadMesher.sln -c Release`: riuscita per tutti i 14 progetti, 0 warning, 0 errori;
- Python 3.12.7 disponibile nel `PATH`;
- import di Gmsh 4.15.2 riuscito;
- Git 2.54 e GitHub CLI 2.94 disponibili;
- GitHub CLI autenticata per l'account `leonardobandini`;
- repository Git locale inizializzato sul branch `main`, con Git LFS attivo per le fixture SAP2000.

Verifiche SAP2000 automatiche della build di sviluppo `0.0.39`:

- `TEST02`: FAST riuscito con 650 quadrilateri e 8 segmenti congruenti sullo spigolo tra shell ortogonali;
- `TEST03`: FAST riuscito su 6 aree con 1686 quadrilateri e 32 segmenti congruenti molti-a-molti;
- `TEST01`: Undo FAST riuscito con lato `0.03` e ripristino esatto delle 7 selezioni iniziali;
- `TEST05`: simmetria esatta con quattro O-grid speculari, 1816 quadrilateri e 32 corde per foro;
- `TEST06`: foro centrato sull'asse con diametro `0.05`, 1906 quadrilateri totali, 16 corde e bordi vincolati da 10/34 intervalli invariati;
- il runner chiude SAP2000 in `finally` anche in caso di errore o timeout.

## Debito prioritario

1. Separare sorgenti, test, fixture e documentazione dagli output generati.
2. Mantenere aggiornati inventario, licenze e avvisi delle dipendenze per ogni beta.
3. Rendere configurabile il percorso di `SAP2000v1.dll`.
4. Non distribuire la DLL proprietaria CSI.
5. Verificare installazione e disinstallazione su una macchina Windows pulita senza Python.
6. Trasformare i test geometrici in test automatici indipendenti da SAP2000 dove possibile.
7. Documentare e automatizzare i test di integrazione che richiedono SAP2000.
8. Creare un packaging riproducibile, con versione e checksum.
9. Separare il codice monolitico di `Plugin.cs` in componenti testabili, senza alterare il comportamento.
10. Migliorare robustezza CSV, timeout Python e controllo dei codici di ritorno SAP2000.

## Dimensioni del workspace storico

Al momento della ricognizione:

- 1.137 file;
- circa 283,34 MB totali;
- circa 173,09 MB di export `.$2k`;
- circa 66,31 MB di modelli `.sdb`;
- circa 21,10 MB di DLL generate o copiate;
- file maggiore: `TRAVE_CARROPONTE_20M.$2k`, circa 144,63 MB.

Il file maggiore supera il limite ordinario di 100 MB per singolo oggetto GitHub. Va conservato fuori Git, ridotto oppure gestito con Git LFS dopo averne verificato la pubblicabilita.
