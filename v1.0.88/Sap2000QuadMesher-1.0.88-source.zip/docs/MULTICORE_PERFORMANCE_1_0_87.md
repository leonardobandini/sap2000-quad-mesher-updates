# Regressione e studio multicore — v1.0.87

Data della prova: 2026-09-29. Build SAP2000 Quad Mesher 1.0.87; SAP2000 27.1.0; Windows x64; Intel Core i7-13700H (14 core fisici, 20 processori logici); circa 32 GB di RAM.

## Risultato della regressione

**36/36 PASS**, una sola istanza SAP2000 persistente, esempi eseguiti in serie con **massimo numero di worker** preselezionato. Timeout di 600 s per modello; menu dei plugin salvato e ripristinato dal runner. File sorgenti dei modelli non sovrascritti.

I tempi seguenti sono per esempio completo nella stessa istanza SAP: apertura del modello, generazione, inserimento, controlli, salvataggio e diagrammi. Non includono l'avvio iniziale/la chiusura finale di SAP o la costruzione del report. Non sono i soli tempi del mesher e non vanno confrontati direttamente con le prove concorrenti o con il PDF storico v0.0.57.

| Esempio | Profilo | Esito | Durata completa (s) |
| --- | --- | --- | ---: |
| nTEST001 | Reinforced Concrete | PASS | 13.69 |
| nTEST002 | Reinforced Concrete | PASS | 14.89 |
| nTEST003 | Reinforced Concrete | PASS | 19.74 |
| nTEST004 | General Purpose | PASS | 9.07 |
| nTEST005 | Steel Structures | PASS | 9.52 |
| nTEST006 | Steel Structures | PASS | 10.34 |
| nTEST007 | Reinforced Concrete | PASS | 9.52 |
| nTEST008 | Reinforced Concrete | PASS | 11.17 |
| nTEST009 | General Purpose | PASS | 14.38 |
| nTEST010 | Reinforced Concrete | PASS | 21.51 |
| nTEST011 | General Purpose | PASS | 11.28 |
| nTEST012 | General Purpose | PASS | 9.56 |
| nTEST013 | Reinforced Concrete | PASS | 8.89 |
| nTEST014 | General Purpose | PASS | 9.70 |
| nTEST015 | General Purpose | PASS | 10.36 |
| nTEST016 | General Purpose | PASS | 10.38 |
| nTEST017 | Steel Structures | PASS | 12.62 |
| nTEST018 | General Purpose | PASS | 10.68 |
| nTEST019 | General Purpose | PASS | 17.44 |
| nTEST020 | General Purpose | PASS | 56.95 |
| nTEST021 | General Purpose | PASS | 126.31 |
| nTEST022 | General Purpose | PASS | 12.21 |
| nTEST023 | General Purpose | PASS | 22.36 |
| nTEST024 | General Purpose | PASS | 9.04 |
| nTEST025 | General Purpose | PASS | 11.06 |
| nTEST026 | Steel Structures | PASS | 17.44 |
| nTEST027 | General Purpose | PASS | 10.81 |
| nTEST028 | General Purpose | PASS | 13.43 |
| nTEST029 | Reinforced Concrete | PASS | 7.52 |
| nTEST030 | Reinforced Concrete | PASS | 7.59 |
| nTEST031 | Steel Structures | PASS | 6.76 |
| nTEST032 | General Purpose | PASS | 12.58 |
| nTEST033 | General Purpose | PASS | 9.04 |
| nTEST034 | Reinforced Concrete | PASS | 10.28 |
| nTEST035 | General Purpose | PASS | 20.73 |
| nTEST036 | Steel Structures | PASS | 15.02 |

Somma delle durate per esempio: **603.87 s**; mediana: **11.12 s**; intervallo: 6.76–126.31 s.
Provenienza: `summary.json` della regressione seriale v1.0.87, SHA-256 `75029e35e9056707b6a06098b686fa2346428dbae41ad0ca0f814f0ef052704c`. I risultati completi, i modelli e i log restano nel workspace locale di prova.

## Confronto controllato: due triangoli di TEST03

Stesso modello di partenza su copie isolate; aree 1 e 3 selezionate insieme, dimensione massima 500 mm, profilo Uso generale, FAST. Confronto tra **1 worker** e **massimo worker**, senza altre istanze di prova simultanee. Il controllo degli export SAP2000 ha trovato **geometria degli elementi e sezioni identiche** nei due risultati: 1.271 aree totali, di cui 971 nuove (51 triangoli), 300 aree non selezionate conservate, lato massimo nuovo 499,134 mm. L'uguaglianza riguarda coordinate e sezioni, non i nomi temporanei dei nuovi oggetti.

| Ambito cronometrato | 1 worker (s) | Massimo worker (s) | Riduzione |
| --- | ---: | ---: | ---: |
| Backend area 1 | 38.05 | 19.67 | 48.3% |
| Backend area 3 | 86.64 | 41.66 | 51.9% |
| **Backend totali** | **124.69** | **61.34** | **50.8%** |

Accelerazione dei **soli backend**: **2.03×** in questa coppia di prove. Sono durate misurate nel plugin dall'avvio alla conclusione del backend per area; l'import FAST e il resto dell'operazione SAP restano esclusi. Una sola misura per configurazione: non è una garanzia per altri modelli.

I candidati Gmsh sono processi distinti. In una verifica sulla stessa geometria, due worker hanno totalizzato **9,78 secondi CPU in 5,02 secondi reali** (affinità su tutti i 20 processori logici): il lavoro è realmente concorrente. Gmsh in questo flusso non utilizza la GPU. Il massimo di processi effettivi è limitato a runtime da candidati indipendenti e RAM libera: scegliere 20 nella UI non genera 20 copie quando sono disponibili soltanto nove fattori candidati.

La velocità dipende dal caso: i backend con una sola costruzione rapida possono non trarre beneficio da altri processi; i bordi con raffinamento forzato, le aperture e altri algoritmi specializzati mantengono il percorso collaudato. Le aree che si passano nuovi nodi di bordo sono elaborate in sequenza per conservare la congruenza.

Il PDF `SAP2000-Quad-Mesher-Atomic-Examples.pdf` incluso nel progetto documenta separatamente la vecchia build di sviluppo v0.0.57 e non è stato riscritto con tempi nuovi.
