"""Compare section and geometry of SAP2000 areas, ignoring temporary object names."""

import argparse
import collections
import re
from pathlib import Path


def signature(path):
    table = ""
    points, areas, sections = {}, {}, {}
    for line in Path(path).read_text(encoding="utf-8-sig", errors="replace").splitlines():
        if line.startswith('TABLE:  "'):
            table = line.split('"')[1]
        elif table == "JOINT COORDINATES" and "Joint=" in line:
            name = re.search(r"\bJoint=(\S+)", line).group(1)
            points[name] = tuple(round(float(re.search(rf"\b{axis}=([^ ]+)", line).group(1)), 6)
                                 for axis in ("XorR", "Y", "Z"))
        elif table == "CONNECTIVITY - AREA" and "Area=" in line:
            area = re.search(r"\bArea=(\S+)", line).group(1)
            areas.setdefault(area, []).extend(re.findall(r"\bJoint\d+=(\S+)", line))
        elif table == "AREA SECTION ASSIGNMENTS" and "Area=" in line:
            area = re.search(r"\bArea=(\S+)", line).group(1)
            sections[area] = re.search(r"\bSection=(\S+)", line).group(1)
    return collections.Counter((sections[area], tuple(sorted(points[name] for name in vertices)))
                               for area, vertices in areas.items())


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("baseline")
parser.add_argument("maximum")
args = parser.parse_args()
baseline, maximum = signature(args.baseline), signature(args.maximum)
print(f"baseline areas={sum(baseline.values())}; maximum areas={sum(maximum.values())}; "
      f"baseline-only={sum((baseline - maximum).values())}; "
      f"maximum-only={sum((maximum - baseline).values())}")
if baseline != maximum:
    raise SystemExit("Different mesh geometries or sections")
print("Identical area geometry and sections: PASS")
