"""Record the current persistent-SAP regression and controlled Gmsh timing comparison."""

import argparse
import csv
import hashlib
import json
import statistics
from datetime import date
from pathlib import Path
from xml.etree import ElementTree


ROOT = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--summary", type=Path, required=True)
parser.add_argument("--single", type=Path, required=True, help="1-worker csharp-backends.csv")
parser.add_argument("--maximum", type=Path, required=True, help="maximum-worker csharp-backends.csv")
parser.add_argument("--output", type=Path, default=ROOT / "docs" / "MULTICORE_PERFORMANCE_1_0_87.md")
args = parser.parse_args()

version = ElementTree.parse(ROOT / "SapQuadTransitionPlugin" / "SapQuadTransitionPlugin.csproj").findtext(".//Version")
if version != "1.0.87":
    raise SystemExit(f"Unexpected plugin version: {version}")
summary_bytes = args.summary.read_bytes()
rows = json.loads(summary_bytes.decode("utf-8-sig"))
if [item["id"] for item in rows] != [f"nTEST{n:03d}" for n in range(1, 37)]:
    raise SystemExit("Regression is not a complete ordered 36-example run")
if any(item["status"] != "PASS" for item in rows):
    raise SystemExit("Some regressions did not pass")


def backend_times(path):
    with path.open(newline="", encoding="utf-8-sig") as stream:
        measurements = list(csv.DictReader(stream))
    if [item["area"] for item in measurements] != ["1", "3"] or any(
        item["exit_code"] != "0" for item in measurements
    ):
        raise ValueError(f"Expected successful TEST03 areas 1 and 3 in {path}")
    return [float(item["seconds"]) for item in measurements]


single, maximum = backend_times(args.single), backend_times(args.maximum)
total_single, total_maximum = sum(single), sum(maximum)
seconds = [float(item["seconds"]) for item in rows]
lines = [
    "# Regressione e studio multicore — v1.0.87",
    "",
    f"Data della prova: {date.today().isoformat()}. Build SAP2000 Quad Mesher {version}; SAP2000 27.1.0; "
    "Windows x64; Intel Core i7-13700H (14 core fisici, 20 processori logici); circa 32 GB di RAM.",
    "",
    "## Risultato della regressione",
    "",
    "**36/36 PASS**, una sola istanza SAP2000 persistente, esempi eseguiti in serie con "
    "**massimo numero di worker** preselezionato. Timeout di 600 s per modello; "
    "menu dei plugin salvato e ripristinato dal runner. File sorgenti dei modelli non sovrascritti.",
    "",
    "I tempi seguenti sono per esempio completo nella stessa istanza SAP: apertura del modello, "
    "generazione, inserimento, controlli, salvataggio e diagrammi. "
    "Non includono l'avvio iniziale/la chiusura finale di SAP o la costruzione del report. "
    "Non sono i soli tempi del mesher e non vanno confrontati direttamente con le prove "
    "concorrenti o con il PDF storico v0.0.57.",
    "",
    "| Esempio | Profilo | Esito | Durata completa (s) |",
    "| --- | --- | --- | ---: |",
]
for item in rows:
    lines.append(f"| {item['id']} | {item['profile']} | {item['status']} | {float(item['seconds']):.2f} |")
lines += [
    "",
    f"Somma delle durate per esempio: **{sum(seconds):.2f} s**; mediana: "
    f"**{statistics.median(seconds):.2f} s**; intervallo: "
    f"{min(seconds):.2f}–{max(seconds):.2f} s.",
    f"Provenienza: `summary.json` della regressione seriale v{version}, "
    f"SHA-256 `{hashlib.sha256(summary_bytes).hexdigest()}`. "
    "I risultati completi, i modelli e i log restano nel workspace locale di prova.",
    "",
    "## Confronto controllato: due triangoli di TEST03",
    "",
    "Stesso modello di partenza su copie isolate; aree 1 e 3 selezionate insieme, "
    "dimensione massima 500 mm, profilo Uso generale, FAST. "
    "Confronto tra **1 worker** e **massimo worker**, senza altre istanze di prova simultanee. "
    "Il controllo degli export SAP2000 ha trovato **geometria degli elementi e sezioni identiche** "
    "nei due risultati: 1.271 aree totali, di cui 971 nuove (51 triangoli), "
    "300 aree non selezionate conservate, lato massimo nuovo 499,134 mm. "
    "L'uguaglianza riguarda coordinate e sezioni, non i nomi temporanei dei nuovi oggetti.",
    "",
    "| Ambito cronometrato | 1 worker (s) | Massimo worker (s) | Riduzione |",
    "| --- | ---: | ---: | ---: |",
]
for label, before, after in zip(("Backend area 1", "Backend area 3"), single, maximum):
    lines.append(f"| {label} | {before:.2f} | {after:.2f} | {(1-after/before)*100:.1f}% |")
lines += [
    f"| **Backend totali** | **{total_single:.2f}** | **{total_maximum:.2f}** | "
    f"**{(1-total_maximum/total_single)*100:.1f}%** |",
    "",
    f"Accelerazione dei **soli backend**: **{total_single/total_maximum:.2f}×** "
    "in questa coppia di prove. Sono durate misurate nel plugin dall'avvio alla conclusione "
    "del backend per area; l'import FAST e il resto dell'operazione SAP restano esclusi. "
    "Una sola misura per configurazione: non è una garanzia per altri modelli.",
    "",
    "I candidati Gmsh sono processi distinti. In una verifica sulla stessa geometria, "
    "due worker hanno totalizzato **9,78 secondi CPU in 5,02 secondi reali** "
    "(affinità su tutti i 20 processori logici): il lavoro è realmente concorrente. "
    "Gmsh in questo flusso non utilizza la GPU. Il massimo di processi effettivi è "
    "limitato a runtime da candidati indipendenti e RAM libera: scegliere 20 nella UI "
    "non genera 20 copie quando sono disponibili soltanto nove fattori candidati.",
    "",
    "La velocità dipende dal caso: i backend con una sola costruzione rapida possono "
    "non trarre beneficio da altri processi; i bordi con raffinamento forzato, le aperture "
    "e altri algoritmi specializzati mantengono il percorso collaudato. Le aree che "
    "si passano nuovi nodi di bordo sono elaborate in sequenza per conservare la congruenza.",
    "",
    "Il PDF `SAP2000-Quad-Mesher-Atomic-Examples.pdf` incluso nel progetto documenta "
    "separatamente la vecchia build di sviluppo v0.0.57 e non è stato riscritto con tempi nuovi.",
    "",
]
args.output.write_text("\n".join(lines), encoding="utf-8")
print(f"REPORT={args.output} PASS={len(rows)} BACKEND_SPEEDUP={total_single/total_maximum:.2f}x")
