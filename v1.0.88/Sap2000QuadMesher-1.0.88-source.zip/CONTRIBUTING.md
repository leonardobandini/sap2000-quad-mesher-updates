# Contribuire

Il repository e in fase di preparazione. Prima di contribuire leggere `docs/PROJECT_STATUS.md` e `docs/DEVELOPMENT.md`.

## Ambiente

- Windows x64.
- SAP2000 27 x64 per build e test di integrazione.
- .NET Framework 4.8 e .NET SDK.
- Python con le dipendenze di `requirements.txt`.

Se SAP2000 e installato in un percorso diverso, impostare una proprieta MSBuild:

```cmd
dotnet build SapQuadTransitionPlugin\SapQuadTransitionPlugin.csproj -c Release -p:Sap2000InstallDir="D:\percorso\SAP2000 27"
```

oppure indicare direttamente l'assembly:

```cmd
dotnet build SapQuadTransitionPlugin\SapQuadTransitionPlugin.csproj -c Release -p:Sap2000ApiPath="D:\sdk\SAP2000v1.dll"
```

## Regole

- Non aggiungere `SAP2000v1.dll` o altri binari proprietari CSI.
- Eseguire i test SAP2000 soltanto su copie dei modelli.
- Aggiungere fixture sintetiche e prive di dati riservati.
- Documentare i test manuali e i risultati riproducibili.
- Mantenere versione, changelog e pacchetto coerenti.

## Verifica minima

```cmd
python -m pip install -r requirements.txt
dotnet build SapQuadTransitionPlugin\SapQuadTransitionPlugin.csproj -c Release
```

I test di integrazione SAP2000 richiedono un desktop interattivo e una licenza valida; consultare `docs/DEVELOPMENT.md`.
