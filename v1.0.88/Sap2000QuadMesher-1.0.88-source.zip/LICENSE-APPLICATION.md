# License of SAP2000 Quad Mesher

Copyright (C) 2026 Leonardo Bandini (original material only).

Leonardo Bandini is identified as the author of the original project code.
**Only that code and documentation, to the extent he holds the rights,** are
licensed under GPL-2.0-or-later. The full GPLv2 text is in `LICENSE`; the
GPLv3 text is in `GPL-3.0.txt`. These texts are the license terms, not a
promise of warranty or a claim to own anyone else's work.

This license grants **no rights in SAP2000, its API DLL or Gmsh**. Users must
obtain SAP2000 and its API independently under the terms of their owner.
`SAP2000-LINKING-EXCEPTION.md` gives an additional permission only concerning
the author's C# code; it does not license the SAP2000 API or Gmsh. The third-
party terms are listed in `THIRD_PARTY_NOTICES.md` and `licenses/`.

Gmsh 4.15.2 is GPL-2.0-or-later under its own copyright holders' terms. The
distributed Python/Gmsh backend also contains OpenSSL 3 (Apache-2.0), so the
binary combination is distributed using the GPLv3 option permitted by the
"or later" clauses. This does not alter Gmsh's original license or exception.

Builds before **1.0.79** were for development and testing, even when a test
ZIP was briefly available online. Those through 1.0.77 used MIT for original
code; the 1.0.78 GPL package was a test build. **1.0.79 is the first beta
intended for users.** If anyone obtained an earlier copy, its granted rights
remain in force; a later release does not revoke them.
