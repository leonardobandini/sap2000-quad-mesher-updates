import csv
import math
import sys

# Copyright (C) 2026 Leonardo Bandini
# SPDX-License-Identifier: GPL-2.0-or-later
import gmsh


def read_boundary(path):
    corners = {}
    edges = {1: [], 2: [], 3: [], 4: []}
    prefer_regular = False
    with open(path, newline="", encoding="ascii") as stream:
        for row in csv.reader(stream):
            if row[0] == "CORNER":
                corners[int(row[1])] = tuple(float(value) for value in row[4:7])
            elif row[0] == "EDGE":
                edges[int(row[1])].append((float(row[3]), tuple(float(value) for value in row[4:7])))
            elif row[0] == "PREFER_REGULAR":
                prefer_regular = row[1] == "1"
    for edge in edges.values():
        edge.sort()
    if len(corners) != 4 or len(edges[1]) < 3 or len(edges[3]) < 3:
        raise RuntimeError("Dati di bordo incompleti")
    return corners, edges, prefer_regular


def refine_edge(points, max_size):
    if len(points) > 2:
        return [point for _, point in points]
    refined = []
    for (_, first), (_, second) in zip(points[:-1], points[1:]):
        if not refined:
            refined.append(first)
        divisions = max(1, math.ceil(math.dist(first, second) / max_size - 1e-9))
        for index in range(1, divisions + 1):
            refined.append(tuple((1 - index / divisions) * a + (index / divisions) * b for a, b in zip(first, second)))
    return refined


def pair_triangles(nodes, triangles):
    if not triangles:
        return []
    edge_owners = {}
    for index, triangle in enumerate(triangles):
        for i in range(3):
            edge = tuple(sorted((triangle[i], triangle[(i + 1) % 3])))
            edge_owners.setdefault(edge, []).append(index)
    candidates = {index: [] for index in range(len(triangles))}
    pair_quads = {}
    for owners in edge_owners.values():
        if len(owners) != 2:
            continue
        first, second = owners
        vertices = set(triangles[first]) | set(triangles[second])
        if len(vertices) != 4:
            continue
        cx = sum(nodes[tag][0] for tag in vertices) / 4
        cy = sum(nodes[tag][1] for tag in vertices) / 4
        quad = tuple(sorted(vertices, key=lambda tag: math.atan2(nodes[tag][1] - cy, nodes[tag][0] - cx)))
        turns = []
        for i in range(4):
            a, b, c = (nodes[quad[(i + offset) % 4]] for offset in (0, 1, 2))
            turns.append((b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]))
        if min(turns) <= 1e-12:
            continue
        lengths = [math.dist(nodes[quad[i]], nodes[quad[(i + 1) % 4]]) for i in range(4)]
        score = max(lengths) / min(lengths)
        candidates[first].append((score, second))
        candidates[second].append((score, first))
        pair_quads[tuple(sorted((first, second)))] = quad

    def solve(remaining, selected):
        if not remaining:
            return selected
        current = min(remaining, key=lambda item: sum(other in remaining for _, other in candidates[item]))
        for _, other in sorted(candidates[current]):
            if other not in remaining:
                continue
            result = solve(remaining - {current, other}, selected + [(current, other)])
            if result is not None:
                return result
        return None

    pairs = solve(set(range(len(triangles))), [])
    if pairs is None:
        raise RuntimeError("Residual triangles cannot be paired")
    return [pair_quads[tuple(sorted(pair))] for pair in pairs]


def improve_angles(nodes, quads, width, height):
    incident = {tag: [] for tag in nodes}
    neighbors = {tag: set() for tag in nodes}
    for quad_index, quad in enumerate(quads):
        for i, tag in enumerate(quad):
            incident[tag].append(quad_index)
            neighbors[tag].update((quad[(i - 1) % 4], quad[(i + 1) % 4]))

    def score(quad):
        points = [nodes[tag] for tag in quad]
        area = 0.5 * sum(points[i][0] * points[(i + 1) % 4][1] - points[(i + 1) % 4][0] * points[i][1] for i in range(4))
        if area <= 1e-12:
            return 1e9
        lengths = [math.dist(points[i], points[(i + 1) % 4]) for i in range(4)]
        skew = 0
        for i in range(4):
            previous, current, following = points[(i - 1) % 4], points[i], points[(i + 1) % 4]
            a = (previous[0] - current[0], previous[1] - current[1])
            b = (following[0] - current[0], following[1] - current[1])
            cosine = (a[0] * b[0] + a[1] * b[1]) / (math.hypot(*a) * math.hypot(*b))
            angle = math.degrees(math.acos(max(-1, min(1, cosine))))
            skew = max(skew, abs(angle - 90))
        return skew + 100 * max(0, max(lengths) / min(lengths) - 3)

    movable = [tag for tag, (x, y) in nodes.items() if 1e-8 < x < width / 2 - 1e-8 and 1e-8 < y < height - 1e-8]
    for _ in range(100):
        changed = False
        for tag in movable:
            old = nodes[tag]
            local = [quads[index] for index in incident[tag]]
            best, best_score = old, max(score(quad) for quad in local)
            average = (
                sum(nodes[other][0] for other in neighbors[tag]) / len(neighbors[tag]),
                sum(nodes[other][1] for other in neighbors[tag]) / len(neighbors[tag]),
            )
            for alpha in (0.1, 0.25, 0.5, 0.75):
                candidate = ((1 - alpha) * old[0] + alpha * average[0], (1 - alpha) * old[1] + alpha * average[1])
                nodes[tag] = candidate
                candidate_score = max(score(quad) for quad in local)
                if candidate_score < best_score - 1e-8:
                    best, best_score = candidate, candidate_score
            nodes[tag] = best
            changed |= best != old
        if not changed:
            break


def align_regular_edges(nodes, quads, width, height):
    parents = {tag: tag for tag in nodes}

    def root(tag):
        while parents[tag] != tag:
            parents[tag] = parents[parents[tag]]
            tag = parents[tag]
        return tag

    def union(first, second):
        first, second = root(first), root(second)
        if first != second:
            parents[second] = first

    for quad in quads:
        for index in range(4):
            first, second = quad[index], quad[(index + 1) % 4]
            dx = abs(nodes[first][0] - nodes[second][0])
            dy = abs(nodes[first][1] - nodes[second][1])
            if dx > 1e-9 and dy <= 0.1 * dx:
                union(first, second)

    groups = {}
    for tag in nodes:
        groups.setdefault(root(tag), []).append(tag)
    for group in groups.values():
        if len(group) < 2:
            continue
        ordinates = [nodes[tag][1] for tag in group]
        if min(ordinates) < 1e-9 or max(ordinates) > height - 1e-9:
            continue
        ordinate = sum(ordinates) / len(ordinates)
        for tag in group:
            nodes[tag] = (nodes[tag][0], ordinate)


def extend_with_structured_region(nodes, quads, width, transition_height, height, horizontal_segments, max_size):
    by_coordinate = {(round(x, 12), round(y, 12)): tag for tag, (x, y) in nodes.items()}

    def add(x, y):
        key = (round(x, 12), round(y, 12))
        if key in by_coordinate:
            return by_coordinate[key]
        tag = max(nodes) + 1
        nodes[tag] = (x, y)
        by_coordinate[key] = tag
        return tag

    horizontal_size = width / (2 * horizontal_segments)
    vertical_segments = max(1, math.ceil((height - transition_height) / min(max_size, horizontal_size) - 1e-9))
    previous = [add(width * column / (2 * horizontal_segments), transition_height)
                for column in range(horizontal_segments + 1)]
    for row in range(1, vertical_segments + 1):
        y = transition_height + (height - transition_height) * row / vertical_segments
        current = [add(width * column / (2 * horizontal_segments), y)
                   for column in range(horizontal_segments + 1)]
        for column in range(horizontal_segments):
            quads.append((previous[column], previous[column + 1], current[column + 1], current[column]))
        previous = current
    return vertical_segments


def generate_half(width, height, bottom_segments, top_segments, side_segments, max_size, algorithm):
    gmsh.initialize()
    try:
        gmsh.option.setNumber("General.Terminal", 0)
        gmsh.model.add("sap_quad_transition_half")
        p1 = gmsh.model.geo.addPoint(0, 0, 0, max_size / 2)
        p2 = gmsh.model.geo.addPoint(width / 2, 0, 0, max_size / 2)
        p3 = gmsh.model.geo.addPoint(width / 2, height, 0, max_size / 2)
        p4 = gmsh.model.geo.addPoint(0, height, 0, max_size / 2)
        curves = [
            gmsh.model.geo.addLine(p1, p2), gmsh.model.geo.addLine(p2, p3),
            gmsh.model.geo.addLine(p3, p4), gmsh.model.geo.addLine(p4, p1),
        ]
        surface = gmsh.model.geo.addPlaneSurface([gmsh.model.geo.addCurveLoop(curves)])
        gmsh.model.geo.synchronize()
        for curve, count in zip(curves, (bottom_segments, side_segments, top_segments, side_segments)):
            gmsh.model.mesh.setTransfiniteCurve(curve, count + 1)
        gmsh.model.mesh.setRecombine(2, surface)
        gmsh.option.setNumber("Mesh.MeshSizeMin", max_size * 0.18)
        gmsh.option.setNumber("Mesh.MeshSizeMax", max_size * 0.50)
        gmsh.option.setNumber("Mesh.MeshSizeExtendFromBoundary", 0)
        gmsh.option.setNumber("Mesh.Algorithm", algorithm)
        gmsh.option.setNumber("Mesh.RecombinationAlgorithm", 1)
        gmsh.option.setNumber("Mesh.RecombineAll", 1)
        gmsh.option.setNumber("Mesh.Smoothing", 100)
        gmsh.model.mesh.generate(2)
        gmsh.model.mesh.optimize("Relocate2D", force=True, niter=100)
        tags, xyz, _ = gmsh.model.mesh.getNodes()
        nodes = {int(tag): (float(xyz[i]), float(xyz[i + 1])) for tag, i in zip(tags, range(0, len(xyz), 3))}
        quads, triangles = [], []
        types, _, connectivity = gmsh.model.mesh.getElements(2)
        for element_type, values in zip(types, connectivity):
            if element_type == 3:
                quads.extend(tuple(int(v) for v in values[i:i + 4]) for i in range(0, len(values), 4))
            elif element_type == 2:
                triangles.extend(tuple(int(v) for v in values[i:i + 3]) for i in range(0, len(values), 3))
        quads.extend(pair_triangles(nodes, triangles))
        improve_angles(nodes, quads, width, height)
        return nodes, quads
    finally:
        gmsh.finalize()


def interpolate(a, b, t):
    return tuple((1 - t) * x + t * y for x, y in zip(a, b))


def curve_point(points, parameter):
    scaled = max(0, min(1, parameter)) * (len(points) - 1)
    index = min(int(math.floor(scaled)), len(points) - 2)
    return interpolate(points[index], points[index + 1], scaled - index)


def map_world(bottom, top, u, v):
    return interpolate(curve_point(bottom, u), curve_point(top, u), v)


def build_full_mesh(corners, bottom, top, half_nodes, half_quads, width, height):
    nodes, by_parameter = {}, {}

    def add(u, v):
        key = (round(u, 12), round(v, 12))
        if key in by_parameter:
            return by_parameter[key]
        tag = len(nodes) + 1
        by_parameter[key] = tag
        nodes[tag] = map_world(bottom, top, u, v)
        return tag

    left, right = {}, {}
    for tag, (x, y) in half_nodes.items():
        u, v = x / width, y / height
        left[tag], right[tag] = add(u, v), add(1 - u, v)
    quads = []
    for quad in half_quads:
        quads.append(tuple(left[tag] for tag in quad))
        mirrored = tuple(right[tag] for tag in quad)
        quads.append((mirrored[0], mirrored[3], mirrored[2], mirrored[1]))
    return nodes, quads


def build_structured_mesh(bottom, top, side_segments):
    horizontal_segments = len(bottom) - 1
    nodes = {}
    grid = []
    for row in range(side_segments + 1):
        v = row / side_segments
        grid_row = []
        for column in range(horizontal_segments + 1):
            u = column / horizontal_segments
            tag = len(nodes) + 1
            nodes[tag] = map_world(bottom, top, u, v)
            grid_row.append(tag)
        grid.append(grid_row)
    quads = []
    for row in range(side_segments):
        for column in range(horizontal_segments):
            quads.append((grid[row][column], grid[row][column + 1], grid[row + 1][column + 1], grid[row + 1][column]))
    return nodes, quads


def metrics(nodes, quads):
    min_edge, max_edge, max_aspect = float("inf"), 0, 0
    min_angle, max_angle, max_skew, min_jacobian = 180, 0, 0, 1
    for quad in quads:
        points = [nodes[tag] for tag in quad]
        lengths = [math.dist(points[i], points[(i + 1) % 4]) for i in range(4)]
        min_edge, max_edge = min(min_edge, min(lengths)), max(max_edge, max(lengths))
        max_aspect = max(max_aspect, max(lengths) / min(lengths))
        for i in range(4):
            previous, current, following = points[(i - 1) % 4], points[i], points[(i + 1) % 4]
            a = tuple(previous[j] - current[j] for j in range(3))
            b = tuple(following[j] - current[j] for j in range(3))
            dot = sum(a[j] * b[j] for j in range(3))
            la, lb = math.dist(previous, current), math.dist(following, current)
            angle = math.degrees(math.acos(max(-1, min(1, dot / (la * lb)))))
            cross = (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])
            jacobian = math.sqrt(sum(value * value for value in cross)) / (la * lb)
            min_angle, max_angle = min(min_angle, angle), max(max_angle, angle)
            max_skew, min_jacobian = max(max_skew, abs(angle - 90)), min(min_jacobian, jacobian)
    return min_edge, max_edge, max_aspect, min_angle, max_angle, max_skew, min_jacobian


def main():
    if len(sys.argv) != 4:
        raise RuntimeError("Usage: mesher.py boundary.csv mesh.csv max_size")
    boundary_path, output_path, max_size = sys.argv[1], sys.argv[2], float(sys.argv[3])
    corners, edges, prefer_regular = read_boundary(boundary_path)
    bottom = refine_edge(edges[1], max_size)
    top = list(reversed(refine_edge(edges[3], max_size)))
    bottom_segments, top_segments = len(bottom) - 1, len(top) - 1
    constrained_lengths = [
        math.dist(first[1], second[1])
        for edge in (edges[1], edges[3]) if len(edge) > 2
        for first, second in zip(edge[:-1], edge[1:])
    ]
    allowed_max = max([max_size] + constrained_lengths)
    if bottom_segments % 2 or top_segments % 2:
        raise RuntimeError("Transition edges must have an even number of intervals")
    width = 0.5 * (math.dist(corners[1], corners[2]) + math.dist(corners[4], corners[3]))
    height = 0.5 * (math.dist(corners[1], corners[4]) + math.dist(corners[2], corners[3]))
    best = None
    if bottom_segments == top_segments:
        target_vertical = min(max_size, width / bottom_segments)
        side_segments = max(1, math.ceil(height / target_vertical - 1e-9))
        nodes, quads = build_structured_mesh(bottom, top, side_segments)
        quality = metrics(nodes, quads)
        penalty = max(quality[1] / allowed_max, quality[2] / 3, quality[5] / 45, 0.5 / quality[6])
        best = (penalty, nodes, quads, quality, side_segments)
    else:
        transition_fractions = (0.25, 0.35, 0.45, 0.55, 0.65, 0.75) if prefer_regular else (1.0,)
        for fraction in transition_fractions:
            transition_height = height * fraction
            first_side = max(2, math.ceil(transition_height / (max_size * 0.5)))
            fraction_best = None
            for algorithm in (5, 6):
                for side_segments in range(first_side, first_side + 16):
                    try:
                        half_nodes, half_quads = generate_half(width, transition_height, bottom_segments // 2,
                                                               top_segments // 2, side_segments, max_size, algorithm)
                        if prefer_regular:
                            align_regular_edges(half_nodes, half_quads, width, transition_height)
                            structured_segments = extend_with_structured_region(
                                half_nodes, half_quads, width, transition_height, height, top_segments // 2, max_size)
                        else:
                            structured_segments = 0
                        nodes, quads = build_full_mesh(corners, bottom, top, half_nodes, half_quads, width, height)
                        quality = metrics(nodes, quads)
                        penalty = max(quality[1] / allowed_max, quality[2] / 3, quality[5] / 45, 0.5 / quality[6])
                        candidate = (penalty, nodes, quads, quality, side_segments + structured_segments)
                        if fraction_best is None or candidate[0] < fraction_best[0]:
                            fraction_best = candidate
                        if penalty <= 1 + 1e-7:
                            break
                    except Exception:
                        continue
                if fraction_best is not None and fraction_best[0] <= 1 + 1e-7:
                    break
            if fraction_best is not None and (best is None or fraction_best[0] < best[0]):
                best = fraction_best
            if fraction_best is not None and fraction_best[0] <= 1 + 1e-7:
                break
    if best is None or best[0] > 1 + 1e-7:
        raise RuntimeError("Unable to obtain a mesh satisfying maximum edge length, aspect ratio, skew, and Jacobian limits")

    _, nodes, quads, quality, side_segments = best
    with open(output_path, "w", newline="", encoding="ascii") as stream:
        writer = csv.writer(stream)
        for tag, xyz in nodes.items():
            writer.writerow(["N", tag, *[f"{value:.17g}" for value in xyz]])
        for quad in quads:
            writer.writerow(["Q", *quad])
    print(f"Quadrilaterals: {len(quads)}; nodes: {len(nodes)}; side edges: {side_segments}")
    if prefer_regular:
        print("Regular alignment: structured edge-aligned region with a confined transition band")
    print(f"Edge length: {quality[0]:.6g}..{quality[1]:.6g}; max AR: {quality[2]:.3f}; "
          f"angles: {quality[3]:.3f}..{quality[4]:.3f}; skew: {quality[5]:.3f}; min Jsc: {quality[6]:.3f}")
    if allowed_max > max_size * 1.001:
        print(f"Note: requested limit {max_size:.6g} exceeded on constrained edges; only selected points were retained (maximum interval {allowed_max:.6g}).")


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
