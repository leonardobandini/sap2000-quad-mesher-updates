# SPDX-License-Identifier: GPL-2.0-or-later
$installer = Join-Path $PSScriptRoot 'SQMPluginInstaller.exe'
if (-not (Test-Path $installer)) { throw "Installer not found: $installer" }
& $installer uninstall
if ($LASTEXITCODE -ne 0) { throw "Uninstallation failed with code $LASTEXITCODE." }
