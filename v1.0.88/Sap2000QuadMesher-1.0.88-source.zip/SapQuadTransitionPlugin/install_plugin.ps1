# SPDX-License-Identifier: GPL-2.0-or-later
$installer = Join-Path $PSScriptRoot 'SQMPluginInstaller.exe'
if (-not (Test-Path $installer)) { throw "Installer not found: $installer" }
& $installer install $PSScriptRoot
if ($LASTEXITCODE -ne 0) { throw "Installation failed with code $LASTEXITCODE." }
