"""Label the historical atomic report without rerunning SAP2000 or replacing its diagrams."""

import hashlib
import json
from pathlib import Path

from docx import Document
from docx.oxml import OxmlElement
from docx.text.paragraph import Paragraph
from pypdf import PdfReader
from win32com.client import DispatchEx


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
provenance = json.loads((RESULTS / "report-provenance.json").read_text(encoding="utf-8"))
summary = RESULTS / "summary.json"
actual_hash = hashlib.sha256(summary.read_bytes()).hexdigest()
if actual_hash != provenance["summarySha256"]:
    raise RuntimeError("Results differ from the historical report; do not label them with the old plugin version.")

docx_path = RESULTS / "SAP2000-Quad-Mesher-Atomic-Examples.docx"
pdf_path = docx_path.with_suffix(".pdf")
document = Document(docx_path)
label = f'Plugin used for these runs: v{provenance["pluginVersion"]}'
development_label = "Release stage: " + provenance["releaseStage"]
table = document.tables[0]
changed = False
for text in (label, development_label, "Timing scope: " + provenance["timingScope"],
             "These are historical regression results, not performance measurements of the current release."):
    if not any(text in paragraph.text for paragraph in document.paragraphs):
        element = OxmlElement("w:p")
        table._element.addprevious(element)
        paragraph = Paragraph(element, document._body)
        paragraph.add_run(text)
        changed = True
if changed:
    document.save(docx_path)

temporary_pdf = pdf_path.with_name(pdf_path.stem + "-verified.tmp.pdf")
word = DispatchEx("Word.Application")
word.Visible = False
word.DisplayAlerts = 0
opened = None
try:
    opened = word.Documents.Open(str(docx_path), ReadOnly=True)
    opened.ExportAsFixedFormat(str(temporary_pdf), 17)
finally:
    if opened is not None:
        opened.Close(False)
    word.Quit()

first_page = PdfReader(temporary_pdf).pages[0].extract_text() or ""
if label not in first_page or development_label not in first_page:
    raise RuntimeError("The exported PDF does not show the development status and version on its first page.")
temporary_pdf.replace(pdf_path)
print(f"Atomic report: {label}; PDF={pdf_path}")

# The MODO comparison also predates the first downloadable user beta. Its
# reported timings are engineering development measurements, not user-release
# benchmarks. Retain the underlying numbers and add this context visibly.
modo_docx = ROOT.parent / "comparisons" / "MODO" / "MODO-performance-comparison.docx"
modo_pdf = modo_docx.with_suffix(".pdf")
modo_label = "Development comparison only; performed before the first downloadable user beta (v1.0.79)."
modo_document = Document(modo_docx)
if not any(modo_label in paragraph.text for paragraph in modo_document.paragraphs):
    element = OxmlElement("w:p")
    modo_document.tables[0]._element.addprevious(element)
    Paragraph(element, modo_document._body).add_run(modo_label)
    modo_document.save(modo_docx)
temporary_modo_pdf = modo_pdf.with_name(modo_pdf.stem + "-verified.tmp.pdf")
word = DispatchEx("Word.Application")
word.Visible = False
word.DisplayAlerts = 0
opened = None
try:
    opened = word.Documents.Open(str(modo_docx), ReadOnly=True)
    opened.ExportAsFixedFormat(str(temporary_modo_pdf), 17)
finally:
    if opened is not None:
        opened.Close(False)
    word.Quit()
if modo_label not in (PdfReader(temporary_modo_pdf).pages[0].extract_text() or ""):
    raise RuntimeError("MODO PDF does not identify the development comparison.")
temporary_modo_pdf.replace(modo_pdf)
print(f"MODO comparison: development-only label; PDF={modo_pdf}")
