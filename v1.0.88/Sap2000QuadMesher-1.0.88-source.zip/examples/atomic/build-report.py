import json
import hashlib
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"


def ui_rows(item):
    return [
        (True, f'Maximum size: {item["maxSize"]} m'),
        (bool(item.get("symmetry")), "Enforce exact symmetry"),
        (bool(item.get("openingGroup")), f'Generate grouped enclosed openings: {item.get("openingGroup", "not selected")}'),
        (bool(item.get("circularGroup")), f'Generate circular O-grid holes: {item.get("circularGroup", "not selected")}'),
        (bool(item.get("circularGroup")), f'Hole diameter: {item.get("diameter", "not selected")} m'),
        (item["profile"] == "Reinforced Concrete", "Prefer regular meshes aligned with principal orthogonal axes"),
        (item["profile"] == "Steel Structures", "Refine near stress concentrations and geometry changes"),
        (item.get("fast", True), "FAST - bulk insertion through SAP2000 tables"),
    ]


def build_ui_diagram(item, tested_version):
    diagrams = RESULTS / "diagrams"
    diagrams.mkdir(parents=True, exist_ok=True)
    svg_path = diagrams / f'{item["id"]}-options.svg'
    png_path = diagrams / f'{item["id"]}-options.png'
    tabs = ["Reinforced Concrete", "Steel Structures", "General Purpose"]
    rows = ui_rows(item)
    svg = ['<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="720">',
           '<rect width="1200" height="720" fill="#f8fafc"/>',
           '<rect x="150" y="55" width="900" height="610" rx="14" fill="white" stroke="#94a3b8"/>',
           '<text x="185" y="105" font-family="Arial" font-size="28" font-weight="700" fill="#0f172a">SAP2000 Quad Transition Mesh</text>']
    image = Image.new("RGB", (1200, 720), (248, 250, 252))
    draw = ImageDraw.Draw(image)
    font_path = r"C:\Windows\Fonts\segoeui.ttf"
    bold_path = r"C:\Windows\Fonts\segoeuib.ttf"
    font = ImageFont.truetype(font_path, 22)
    small = ImageFont.truetype(font_path, 18)
    bold = ImageFont.truetype(bold_path, 28)
    draw.rounded_rectangle((150, 55, 1050, 665), radius=14, fill="white", outline="#94a3b8", width=2)
    draw.text((185, 75), "SAP2000 Quad Transition Mesh", font=bold, fill="#0f172a")
    for index, tab in enumerate(tabs):
        x = 185 + index * 270
        active = tab == item["profile"]
        fill = "#2563eb" if active else "#e2e8f0"
        text = "white" if active else "#334155"
        svg.append(f'<rect x="{x}" y="130" width="250" height="50" rx="8" fill="{fill}"/>')
        svg.append(f'<text x="{x + 125}" y="162" text-anchor="middle" font-family="Arial" font-size="18" font-weight="700" fill="{text}">{tab}</text>')
        draw.rounded_rectangle((x, 130, x + 250, 180), radius=8, fill=fill)
        box = draw.textbbox((0, 0), tab, font=small)
        draw.text((x + 125 - (box[2] - box[0]) / 2, 144), tab, font=small, fill=text)
    for index, (checked, label) in enumerate(rows):
        y = 215 + index * 54
        mark = "#2563eb" if checked else "white"
        svg.append(f'<rect x="200" y="{y - 21}" width="28" height="28" rx="4" fill="{mark}" stroke="#64748b"/>')
        if checked:
            svg.append(f'<path d="M207 {y - 7} l7 7 l12 -15" fill="none" stroke="white" stroke-width="4"/>')
        svg.append(f'<text x="250" y="{y}" font-family="Arial" font-size="21" fill="#1e293b">{label}</text>')
        draw.rounded_rectangle((200, y - 21, 228, y + 7), radius=4, fill=mark, outline="#64748b", width=2)
        if checked:
            draw.line((207, y - 7, 214, y, 226, y - 15), fill="white", width=4, joint="curve")
        draw.text((250, y - 20), label, font=font, fill="#1e293b")
    svg.append('<line x1="185" y1="625" x2="1015" y2="625" stroke="#cbd5e1"/>')
    svg.append('<text x="185" y="650" font-family="Arial" font-size="16" font-weight="700" fill="#2563eb">CSi Italia</text>')
    svg.append(f'<text x="1015" y="650" text-anchor="end" font-family="Arial" font-size="16" fill="#475569">Version {tested_version}</text>')
    draw.line((185, 625, 1015, 625), fill="#cbd5e1", width=2)
    draw.text((185, 635), "CSi Italia", font=small, fill="#2563eb")
    version = f"Version {tested_version}"
    version_box = draw.textbbox((0, 0), version, font=small)
    draw.text((1015 - (version_box[2] - version_box[0]), 635), version, font=small, fill="#475569")
    svg.append('</svg>')
    svg_path.write_text("\n".join(svg), encoding="utf-8")
    image.save(png_path)
    return png_path


def main():
    manifest = {item["id"]: item for item in json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))}
    provenance = json.loads((RESULTS / "report-provenance.json").read_text(encoding="utf-8"))
    summary_path = RESULTS / "summary.json"
    if hashlib.sha256(summary_path.read_bytes()).hexdigest() != provenance["summarySha256"]:
        raise RuntimeError("The summary changed: update the measured plugin version and timing provenance before rebuilding the report")
    summary = json.loads(summary_path.read_text(encoding="utf-8-sig"))
    if set(manifest) != {item["id"] for item in summary} or any(item["status"] != "PASS" for item in summary):
        raise RuntimeError("The atomic report requires one successful run for every manifest example")
    for result in summary:
        for name in ("source", "result"):
            if not (RESULTS / "diagrams" / f'{result["id"]}-{name}.png').is_file():
                raise RuntimeError(f'Missing {name} diagram for {result["id"]}')
    for item in manifest.values():
        build_ui_diagram(item, provenance["pluginVersion"])
    document = Document()
    title = document.add_heading("SAP2000 Quad Mesher - Atomic Example Report", 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    document.add_paragraph(
        "Automated isolated runs. Geometry diagrams are generated from coordinates read through the SAP2000 API; no SAP2000 window screenshots are used."
    )
    document.add_paragraph("Plugin used for these runs: v" + provenance["pluginVersion"])
    document.add_paragraph("Release stage: " + provenance["releaseStage"])
    document.add_paragraph("Timing scope: " + provenance["timingScope"])
    document.add_paragraph("These are historical regression results, not performance measurements of the current release.")
    table = document.add_table(rows=1, cols=4)
    table.style = "Table Grid"
    for cell, text in zip(table.rows[0].cells, ("Example", "Profile", "Status", "Duration")):
        cell.text = text
    for result in summary:
        row = table.add_row().cells
        row[0].text = result["id"]
        row[1].text = result["profile"]
        row[2].text = result["status"]
        row[3].text = f'{result["seconds"]:.2f} s'

    for result in summary:
        item = manifest[result["id"]]
        document.add_page_break()
        document.add_heading(f'{result["id"]} - {item["title"]}', level=1)
        if item.get("sourceName"):
            document.add_paragraph(f'Original source model: {item["sourceName"]}')
        document.add_paragraph(f'Profile: {item["profile"]}')
        document.add_paragraph(f'Purpose: {", ".join(item.get("features", []))}')
        document.add_paragraph(f'Criticality: {item.get("risk", "Not specified")}')
        document.add_paragraph(f'Expected result: {item["expected"]}')
        document.add_paragraph(f'Batch status: {result["status"]} ({result["seconds"]:.2f} s)')
        document.add_heading("Acceptance criteria", level=2)
        for assertion in item.get("assertions", []):
            document.add_paragraph(assertion, style="List Bullet")
        images = [
            ("Initial geometry", RESULTS / "diagrams" / f'{result["id"]}-source.png'),
            ("Selected plugin options", RESULTS / "diagrams" / f'{result["id"]}-options.png'),
            ("Generated mesh", RESULTS / "diagrams" / f'{result["id"]}-result.png'),
        ]
        for caption, image in images:
            document.add_heading(caption, level=2)
            if image.exists():
                paragraph = document.add_paragraph()
                paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                paragraph.add_run().add_picture(str(image), width=Inches(6.7))
            else:
                document.add_paragraph("Diagram unavailable.")
        stdout = RESULTS / result["stdout"]
        if stdout.exists():
            lines = [line.strip() for line in stdout.read_text(encoding="utf-8", errors="replace").splitlines()
                     if line.startswith("atomic-") or line.startswith("exact-symmetric") or line.startswith("saved=")]
            if lines:
                document.add_heading("Verification", level=2)
                for line in lines:
                    document.add_paragraph(line, style="List Bullet")

    styles = document.styles
    styles["Normal"].font.name = "Aptos"
    styles["Normal"].font.size = Pt(9)
    output = RESULTS / "SAP2000-Quad-Mesher-Atomic-Examples.docx"
    document.save(output)
    print(f"report={output}")


if __name__ == "__main__":
    main()
