# SPDX-License-Identifier: GPL-2.0-or-later
"""Attach a fixed-name installer ZIP to the published latest V2 release.

Permanent public URL:
https://github.com/leonardobandini/sap2000-quad-mesher-updates/releases/latest/download/Sap2000QuadMesher-latest.zip

Run after publishing the versioned ZIP and before announcing the release in
either update feed. Does not replace an existing asset or alter an older release.
"""
import hashlib
import json
import shutil
import subprocess
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
REPOSITORY = 'leonardobandini/sap2000-quad-mesher-updates'
ALIAS = 'Sap2000QuadMesher-latest.zip'
URL = f'https://github.com/{REPOSITORY}/releases/latest/download/{ALIAS}'


def gh(*args):
    return subprocess.run(['gh', *args], check=True, capture_output=True, text=True).stdout


def ensure_latest_installer(version):
    tag = 'v' + version
    named = f'Sap2000QuadMesher-{version}.zip'
    source = ROOT / 'artifacts' / named
    checksum_file = ROOT / 'artifacts' / (named + '.sha256')
    expected = hashlib.sha256(source.read_bytes()).hexdigest()
    if tuple(checksum_file.read_text(encoding='ascii').split()) != (expected, named):
        raise ValueError('Local installer ZIP does not match its checksum')
    latest = json.loads(gh('api', f'repos/{REPOSITORY}/releases/latest'))
    if latest['tag_name'] != tag or latest['draft'] or latest['prerelease']:
        raise ValueError('The requested V2 release is not the published latest release')
    assets = {asset['name']: asset for asset in latest['assets']}
    digest = 'sha256:' + expected
    if named not in assets or assets[named]['digest'] != digest:
        raise ValueError('The public versioned ZIP differs from the local installer')
    if ALIAS in assets:
        if assets[ALIAS]['digest'] != digest or assets[ALIAS]['size'] != source.stat().st_size:
            raise ValueError('The latest release already has a different fixed-name installer')
        print(f'LATEST_INSTALLER=UNCHANGED VERSION={version} SHA256={expected} URL={URL}')
        return URL

    parent = Path(tempfile.gettempdir()) / 'opencode'
    if not parent.is_dir():
        raise FileNotFoundError('Approved temporary directory is missing: ' + str(parent))
    with tempfile.TemporaryDirectory(prefix='sqm-latest-installer-', dir=parent) as folder:
        alias = Path(folder) / ALIAS
        shutil.copyfile(source, alias)
        if hashlib.sha256(alias.read_bytes()).hexdigest() != expected:
            raise IOError('Staged fixed-name installer differs from the release ZIP')
        gh('release', 'upload', tag, str(alias), '-R', REPOSITORY)
    published = json.loads(gh('api', f'repos/{REPOSITORY}/releases/latest'))
    actual = next((asset for asset in published['assets'] if asset['name'] == ALIAS), None)
    if published['tag_name'] != tag or actual is None or actual['digest'] != digest or actual['size'] != source.stat().st_size:
        raise RuntimeError('The fixed URL is not backed by the verified installer ZIP')
    print(f'LATEST_INSTALLER=PUBLISHED VERSION={version} SHA256={expected} URL={URL}')
    return URL


if __name__ == '__main__':
    manifest = json.loads((ROOT / 'updates' / 'manifest-v2.json').read_text(encoding='utf-8'))
    ensure_latest_installer(manifest['version'])
