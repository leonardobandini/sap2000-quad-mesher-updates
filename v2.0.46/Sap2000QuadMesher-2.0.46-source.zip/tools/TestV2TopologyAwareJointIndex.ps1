# Coincident SAP joints may have distinct topological ownership.
param([string]$Plugin = (Join-Path (Split-Path -Parent $PSScriptRoot) 'SapQuadTransitionPlugin\bin\Release\net48\SapQuadTransitionPlugin.dll'))
$ErrorActionPreference = 'Stop'
Add-Type -Path 'C:\Program Files\Computers and Structures\SAP2000 27\CSiAPIv1.dll'
$assembly = [Reflection.Assembly]::LoadFrom((Resolve-Path -LiteralPath $Plugin).Path)
$type = $assembly.GetType('SapQuadTransitionPlugin.cPlugin+PointCoordinateIndex', $true)
$flags = [Reflection.BindingFlags]'Instance,Public,NonPublic'
$index = $type.GetConstructors($flags)[0].Invoke([object[]]@(0.0006))
$register = $type.GetMethod('RegisterArea', $flags)
$permit = $type.GetMethod('Permit', $flags)
$add = $type.GetMethod('AddOriginal', $flags)
$generated = $type.GetMethod('Add', $flags)
$lookup = $type.GetMethod('TryFind', $flags)
function Register($area, [int]$group, [string[]]$corners) {
    $args = [object[]]::new(3); $args[0]=$area; $args[1]=$group; $args[2]=$corners
    $register.Invoke($index,$args) | Out-Null
}
function AddOriginal($name, [double[]]$xyz) {
    $args = [object[]]::new(2); $args[0]=$xyz; $args[1]=$name
    $add.Invoke($index,$args) | Out-Null
}
function Lookup($area, [double[]]$xyz) {
    $args = [object[]]::new(3); $args[0]=$xyz; $args[1]=$area; $args[2]=$null
    $found = $lookup.Invoke($index,$args)
    return $(if ($found) { [string]$args[2] } else { '' })
}
Register '845' 0 ([string[]]@('878'))
Register '444' 1 ([string[]]@('109'))
Register 'S1' 2 ([string[]]@('A'))
Register 'S2' 2 ([string[]]@('B'))
$permit.Invoke($index,[object[]]@('845','109')) | Out-Null
$permit.Invoke($index,[object[]]@('845','878')) | Out-Null
$permit.Invoke($index,[object[]]@('444','109')) | Out-Null
AddOriginal '109' ([double[]]@(1200,600,0))
AddOriginal '878' ([double[]]@(1200,600,0))
$corner = [double[]]@(1200,600,0)
$first = Lookup '845' $corner
$second = Lookup '444' $corner
if ($first -ne '878' -or $second -ne '109') {
    throw "A coincident foreign node displaced the owner area corner: 845=$first 444=$second"
}
$new = [double[]]@(5000,600,0)
$generated.Invoke($index,[object[]]@($new,'QTPNEW','S1')) | Out-Null
if ((Lookup 'S2' $new) -ne 'QTPNEW' -or (Lookup '845' $new) -ne '') {
    throw 'Generated nodes must be shared only within a connected component.'
}
$isolated = $type.GetConstructors($flags)[0].Invoke([object[]]@(0.0006))
$register.Invoke($isolated,[object[]]@('845',0,[string[]]@('878'))) | Out-Null
$register.Invoke($isolated,[object[]]@('444',1,[string[]]@('109'))) | Out-Null
$permit.Invoke($isolated,[object[]]@('845','878')) | Out-Null
$permit.Invoke($isolated,[object[]]@('444','109')) | Out-Null
$add.Invoke($isolated,[object[]]@($corner,'109')) | Out-Null
$add.Invoke($isolated,[object[]]@($corner,'878')) | Out-Null
$meshType = $assembly.GetType('SapQuadTransitionPlugin.cPlugin+MeshData', $true)
$mesh = $meshType.GetConstructors($flags)[0].Invoke([object[]]@())
$meshType.GetField('Nodes',$flags).GetValue($mesh).Add(1,$corner)
$check = $type.GetMethod('HasForeignCoincidentJoint',$flags)
if ($check.Invoke($isolated,[object[]]@($mesh,'845')) -ne $true) {
    throw 'Coincident but unrelated original joints must force a topology-safe import.'
}
'TOPOLOGICAL_POINT_IDENTITY=PASS DISCONNECTED_GROUPS=PASS SHARED_COMPONENT=PASS TRIANGLE_FAST_GATE=PASS'
