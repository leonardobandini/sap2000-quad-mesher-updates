# Pubblicazione e controllo aggiornamenti

La **1.0.79 e la prima beta offerta agli utenti**. Le versioni precedenti erano build di sviluppo e test, anche quando una pagina di download temporanea era accessibile. L'archivio GPL delle sorgenti rimane pubblico per ogni build che sia stata messa a disposizione.

Il plugin legge, senza bloccare la finestra, il manifest JSON pubblico:

`https://raw.githubusercontent.com/leonardobandini/sap2000-quad-mesher-updates/main/manifest.json`

All'apertura della finestra esegue una richiesta con timeout di tre secondi. Il comando **Check for updates / Cerca aggiornamenti** permette di riprovare; se la versione remota e successiva, **Download version / Scarica versione** apre lo ZIP della GitHub Release nel browser. Estrarre lo ZIP, chiudere SAP2000, eseguire `install_plugin.cmd` dalla cartella estratta e riaprire SAP2000. L'installer verifica il pacchetto, lo copia in `%LOCALAPPDATA%\Programs\SAP2000QuadMesher` (non in Download), poi aggiorna la registrazione COM per-utente. Il confronto usa i tre componenti numerici (`1.0.83 > 1.0.82`); un errore di rete non impedisce la mesh. Non viene eseguita alcuna installazione automatica.

Versionamento `MAJOR.MINOR.BUILD`: le build interne incrementano il terzo numero (`1.0.75`, `1.0.76`, ...); il secondo segnala nuove caratteristiche importanti e il primo cambiamenti radicali. L'`AssemblyVersion` COM rimane `1.0.0.0` per mantenere stabile la registrazione.

Nella finestra del plugin il link di aggiornamento e centrato nel footer; **Verified examples / Esempi verificati**, sopra il selettore della lingua, apre il PDF locale `docs/SAP2000-Quad-Mesher-Atomic-Examples.pdf`. Il report riporta test di sviluppo con v0.0.57: le durate non sono benchmark della beta corrente.

Per pubblicare una nuova versione:

1. Aggiornare versione visibile, versione nel progetto e changelog, poi compilare e verificare test/plugin.
2. Eseguire `packaging\build-release.ps1` e controllare **tutti** gli asset e checksum SHA-256: ZIP binario, ZIP sorgente e sorgente originale Gmsh 4.15.2. Il pacchetto binario include `SOURCE.md` con i collegamenti agli archivi pubblici e i testi GPLv2/GPLv3.
3. Aggiornare `updates/manifest.json` nel repository sorgente privato. L'URL e la versione devono coincidere con la Release pubblica.
4. Pubblicare **nel repository pubblico** la nuova release e i sei asset tramite il comando seguente, dopo aver aggiornato e pubblicato sorgenti e tag nel repository di sviluppo:

   ```cmd
   python packaging\publish-release.py v1.0.83 --title "SAP2000 Quad Mesher 1.0.83 beta" --notes "FAST preselected by default; GPL-2.0-or-later source, matching binary and Gmsh source."
   ```

   Lo script verifica i checksum locali e remoti, **archivia prima i sorgenti GPL** nel ramo pubblico permanente [`source-archive`](https://github.com/leonardobandini/sap2000-quad-mesher-updates/tree/source-archive) e, solo dopo, aggiorna il manifest pubblico ed elimina release e tag precedenti. In caso di errore prima della verifica di release, archivio e manifest non elimina la versione precedente. Per vedere cosa verrebbe eliminato, usare lo stesso comando con `--dry-run`.

5. Verificare in una sessione senza login che manifest, link alla Release, ZIP binario e **entrambi gli archivi sorgente** siano pubblicamente accessibili e che rimangano soltanto il tag e la release nuovi. Il repository di sviluppo `sap2000-quad-mesher` resta privato e conserva cronologia e tag propri; la cronologia Git del repository pubblico non viene riscritta. Chi avesse gia scaricato una versione precedente conserva la sua copia e i relativi diritti. L'eventuale sito `www.leonardobandini.it` puo rimandare alla stessa pagina GitHub senza diventare un secondo servizio da mantenere.

Le voci nel menu SAP2000 sono preferenze dell'utente, indipendenti dalla registrazione COM del plugin. `tools\ShowMODOComparison.ps1` salva e ripristina la sezione `[PlugIn]` perche i test con tre istanze SAP condividono lo stesso file INI.
